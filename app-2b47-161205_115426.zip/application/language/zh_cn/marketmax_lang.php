<?php 
$lang['notice_bad_request']         = "请求失败";
$lang['notice_params_empty']        = "不能为空";
$lang['notice_not_find']            = "没有找到相应的数据";

$lang['notice_product_exists']      = "App ID 已经存在";

$lang['success_delete']             = "删除成功";
$lang['success_done']               = "成功";

$lang['company_exists_code']        = "唯一代码已经存在。";











/* End of file accountmax_lang.php */
/* Location: ./system/language/english/accountmax_lang.php */