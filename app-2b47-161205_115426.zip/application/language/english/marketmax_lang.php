<?php
$lang['notice_bad_request']         = "The request failed";
$lang['notice_params_empty']        = "This is not empty";
$lang['notice_not_find']            = "Not Find Data";


$lang['notice_product_exists']      = "App ID exists";

$lang['success_delete']             = "Delete successfully";
$lang['success_done']               = "Successfully";

$lang['company_exists_code']        = "Only code has been";





/* End of file accountmax_lang.php */
/* Location: ./system/language/english/accountmax_lang.php */