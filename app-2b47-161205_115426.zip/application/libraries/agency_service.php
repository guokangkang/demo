<?php

/**
 * Created by PhpStorm.
 * User: palmax
 * Date: 2016/9/12
 * Time: 10:07
 */
class Agency_service
{
    protected $_ci;

    public function __construct()
    {
        $this->_ci=&get_instance();
        $this->_ci->load->model('user_model');
        $this->_ci->load->driver('cache');
        $this->_ci->load->model('ad_model');
        $this->_ci->load->model('reports_model');
        $this->_ci->load->model('publisher_adaccount_model');
    }

    /**
     * 根据条件获取用户统计信息
     * @param array $where
     * @return mixed
     */
    public function get_review_agency_data($where=['user.type'=>2, 'user.publisher_type'=>2])
    {
        //获取分组所以账号

        $data=$this->_ci->publisher_adaccount_model->get_all_acounts($where);
        return $data;
    }

    /**
     * 根据条件获取用户统计分布信息
     * @param array $where
     */

    public function get_review_agency_all($where=['user.type'=>2, 'user.publisher_type'=>2])
    {
        $user_ids_info=$this->_ci->user_model->get_all($where, 1, 100);
        //获取acount_id
        if ($user_ids_info) {
            $group_data=[];
            asort($user_ids_info);
            foreach ($user_ids_info as $item) {
                $account_ids=$this->_ci->publisher_adaccount_model->get_all_data(['publisher_adaccount.publisher_id'=>$item['user_id'], 'is_new'=>1], 'count(DISTINCT(ad.ad_id)) as ads');
                $images=$this->_ci->publisher_adaccount_model->get_all_data(['publisher_adaccount.publisher_id'=>$item['user_id'], 'ad.object_type'=>'SHARE', 'is_new'=>1], 'count(DISTINCT(ad.ad_id)) as images');
                $more_shares=$this->_ci->publisher_adaccount_model->get_all_data(['publisher_adaccount.publisher_id'=>$item['user_id'], 'ad.object_type'=>'MORE_SHARE', 'is_new'=>1], 'count(DISTINCT(ad.ad_id)) as more_shares');
                $video=$this->_ci->publisher_adaccount_model->get_all_data(['publisher_adaccount.publisher_id'=>$item['user_id'], 'ad.object_type'=>'VIDEO', 'is_new'=>1], 'count(DISTINCT(ad.market_ad_id)) as videos');
                $campaigns=$this->_ci->publisher_adaccount_model->get_all_data(['publisher_adaccount.publisher_id'=>$item['user_id'], 'is_new'=>1], 'count(DISTINCT(ad.campaign_id)) as campaigns');
                $pendings=$this->_ci->publisher_adaccount_model->get_all_data(['publisher_adaccount.publisher_id'=>$item['user_id'], 'ad.verify'=>0, 'is_new'=>1], 'count(DISTINCT(ad.ad_id)) as pendings');
                $approveds=$this->_ci->publisher_adaccount_model->get_all_data(['publisher_adaccount.publisher_id'=>$item['user_id'], 'ad.verify'=>1, 'is_new'=>1], 'count(DISTINCT(ad.ad_id)) as approveds');
                $suspecteds=$this->_ci->publisher_adaccount_model->get_all_data(['publisher_adaccount.publisher_id'=>$item['user_id'], 'ad.verify'=>2, 'is_new'=>1], 'count(DISTINCT(ad.ad_id)) as suspecteds');
                $illegals=$this->_ci->publisher_adaccount_model->get_all_data(['publisher_adaccount.publisher_id'=>$item['user_id'], 'ad.verify'=>3, 'is_new'=>1], 'count(DISTINCT(ad.ad_id)) as illegals');
                $group_data[]=[
                    'user_name'=>$item['user_name'],
                    'user_id'=>$item['user_id'],
                    'videos'=>$video?$video[0]['videos']:0,
                    'images'=>$images?$images[0]['images']:0,
                    'more_share'=>$more_shares?$more_shares[0]['more_shares']:0,
                    'ads'=>$account_ids?$account_ids[0]['ads']:0,
                    'campaigns'=>$campaigns?$campaigns[0]['campaigns']:0,
                    'pendings'=>$pendings?$pendings[0]['pendings']:0,
                    'approveds'=>$approveds?$approveds[0]['approveds']:0,
                    'suspecteds'=>$suspecteds?$suspecteds[0]['suspecteds']:0,
                    'illegals'=>$illegals?$illegals[0]['illegals']:0,
                ];
            }
            return $group_data;
        }
    }


    /**
     * 获取advertiser list
     * @param $advertiser_id
     */
    public function get_agency($advertiser_id)
    {
        $chart=[];
        $agency_sql="select marketmax_publisher_adaccount.publisher_id,marketmax_publisher_adaccount.publisher_name from marketmax_reports RIGHT JOIN marketmax_publisher_adaccount ON marketmax_publisher_adaccount.account_id = marketmax_reports.account_id where advertiser_id=" . $advertiser_id . " and marketmax_publisher_adaccount.publisher_type=2 group by marketmax_publisher_adaccount.publisher_id,marketmax_publisher_adaccount.publisher_name";
        $agency_list=$this->_ci->reports_model->get_report_data($agency_sql);
        if ($agency_list) {
            foreach ($agency_list as & $item) {
                $agency_info=$this->_ci->user_model->get_by_id($item['publisher_id']);
                $item['letters']=get_first_letters($item['publisher_name'], 2);
                $sql="select product_id from marketmax_reports RIGHT JOIN marketmax_publisher_adaccount ON marketmax_publisher_adaccount.account_id = marketmax_reports.account_id where marketmax_publisher_adaccount.publisher_id=" . $item['publisher_id'] . " group by product_id";
                $item['product']=count($this->_ci->reports_model->get_report_data($sql, true, 48*3600));

                $sql="select account_id from marketmax_publisher_adaccount where publisher_id=" . $item['publisher_id'];
                $account_id=$this->_ci->reports_model->get_report_data($sql, true, 48*3600);
                $item['account_id']=count($account_id);
                $accounts=[];
                foreach ($account_id as $value) {
                    $accounts[]=$value['account_id'];
                }
                $sql="select sum(results) as results, sum(shares) as shares from marketmax_reports RIGHT JOIN marketmax_publisher_adaccount ON marketmax_publisher_adaccount.account_id = marketmax_reports.account_id where marketmax_publisher_adaccount.publisher_id=" . $item['publisher_id'];
                $insights=$this->_ci->reports_model->get_report_data($sql, true, 48*3600);
                $item['results']=$item['shares']=0;
                if ($insights) {
                    $item['results']=$insights[0]['results'];
                    $item['shares']=$insights[0]['shares'];
                }
                $item['illegal']=0;
                $item['illegal_rate']=0;
                $illegal_rate=0.00;
                if ($accounts) {
                    $illegal=$this->_ci->ad_model->get_query("select count(*) as count from ad where verify=3 and account_id in (" . implode(',', $accounts) . ")");
                    $item['illegal']=$illegal?$illegal[0]['count']:0;
                    $ad_count=$this->_ci->ad_model->get_query("select count(*) as count from ad where account_id in (" . implode(',', $accounts) . ")");
                    $illegal_rate=0;
                    if ($ad_count && $ad_count[0]['count'] > 0) {
                        $item['illegal_rate']=sprintf("%.2f", ($item['illegal'] / $ad_count[0]['count'] * 100));
                    }
                }
                $item['score']=$agency_info['score'];
                $item['tags']=$agency_info['tags'];
                $chart=$item['chart']=json_decode($agency_info['agency_chart'], true);
                $item['addtime']=$agency_info['addtime'];

            }
        }
        return [$agency_list, $chart];
    }

    public function get_agency_admin()
    {
        $chart=[];
        $sql = "select * from user where type=2 and publisher_type=2 and status=1";
        $agency_list = $this->_ci->user_model->get_query($sql);
        if ($agency_list) {
            foreach ($agency_list as & $item) {

                $item['publisher_id'] = $item['user_id'];
                $item['publisher_name'] = $item['user_name'];

                $agency_info=$this->_ci->user_model->get_by_id($item['user_id']);
                $item['letters']=get_first_letters($item['user_name'], 2);
                $sql="select product_id from marketmax_reports RIGHT JOIN marketmax_publisher_adaccount ON marketmax_publisher_adaccount.account_id = marketmax_reports.account_id where marketmax_publisher_adaccount.publisher_id=" . $item['user_id'] . " group by product_id";
                $item['product']=count($this->_ci->reports_model->get_report_data($sql, true, 48*3600));

                $sql="select account_id from marketmax_publisher_adaccount where publisher_id=" . $item['user_id'];
                $account_id=$this->_ci->reports_model->get_report_data($sql, true, 48*3600);
                $item['account_id']=count($account_id);
                $accounts=[];
                foreach ($account_id as $value) {
                    $accounts[]=$value['account_id'];
                }
                $sql="select sum(results) as results, sum(shares) as shares from marketmax_reports RIGHT JOIN marketmax_publisher_adaccount ON marketmax_publisher_adaccount.account_id = marketmax_reports.account_id where marketmax_publisher_adaccount.publisher_id=" . $item['user_id'];
                $insights=$this->_ci->reports_model->get_report_data($sql, true, 48*3600);
                $item['results']=$item['shares']=0;
                if ($insights) {
                    $item['results']=$insights[0]['results'];
                    $item['shares']=$insights[0]['shares'];
                }
                $item['illegal']=0;
                $item['illegal_rate']=0;
                $illegal_rate=0.00;
                if ($accounts) {
                    $illegal=$this->_ci->ad_model->get_query("select count(*) as count from ad where verify=3 and account_id in (" . implode(',', $accounts) . ")");
                    $item['illegal']=$illegal?$illegal[0]['count']:0;
                    $ad_count=$this->_ci->ad_model->get_query("select count(*) as count from ad where account_id in (" . implode(',', $accounts) . ")");
                    $illegal_rate=0;
                    if ($ad_count && $ad_count[0]['count'] > 0) {
                        $item['illegal_rate']=sprintf("%.2f", ($item['illegal'] / $ad_count[0]['count'] * 100));
                    }
                }
                $item['score']=$agency_info['score'];
                $item['tags']=$agency_info['tags'];
                $chart=$item['chart']=json_decode($agency_info['agency_chart'], true);
                $item['addtime']=$agency_info['addtime'];

            }
        }
        return [$agency_list, $chart];
    }

    /**
     * get advertiser follow publisher
     * @param $advertiser_id
     * @return mixed
     */
    public function get_publisher($advertiser_id)
    {
        //缓存文件
        $publisher_sql="select publisher_id,publisher_name,count(marketmax_reports.product_id) as product_id from marketmax_reports where advertiser_id=" . $advertiser_id . " group by publisher_id,publisher_name";
        $publisher_list=$this->_ci->reports_model->get_report_data($publisher_sql);
        foreach ($publisher_list as $k=>&$item) {
            $publisher_info=$this->_ci->user_model->get_by_id($item['publisher_id']);
            if (!empty($publisher_info['label'])) {

                $item['letters']=get_first_letters($item['publisher_name'], 2);
                $sql="select product_id from marketmax_reports RIGHT JOIN marketmax_publisher_adaccount ON marketmax_publisher_adaccount.account_id = marketmax_reports.account_id where marketmax_publisher_adaccount.publisher_id=" . $item['publisher_id'] . " group by product_id";
                $item['product']=count($this->_ci->reports_model->get_report_data($sql, true, 48*3600));

                $sql="select marketmax_reports.account_id from marketmax_reports RIGHT JOIN marketmax_publisher_adaccount ON marketmax_publisher_adaccount.account_id = marketmax_reports.account_id where marketmax_publisher_adaccount.publisher_id=" . $item['publisher_id'] . " group by marketmax_reports.account_id";
                $account_id=$this->_ci->reports_model->get_report_data($sql, true, 48*3600);
                $item['account_id']=count($account_id);
                $accounts=[];
                foreach ($account_id as $value) {
                    $value['account_id'] && $accounts[]=$value['account_id'];
                }

                $sql="select sum(results) as results, sum(shares) as shares from marketmax_reports RIGHT JOIN marketmax_publisher_adaccount ON marketmax_publisher_adaccount.account_id = marketmax_reports.account_id where marketmax_publisher_adaccount.publisher_id=" . $item['publisher_id'];
                $insights=$this->_ci->reports_model->get_report_data($sql, true, 48*3600);
                $item['results']=$item['shares']=0;
                if ($insights) {
                    $item['results']=$insights[0]['results'];
                    $item['shares']=$insights[0]['shares'];
                }
                $item['illegal_rate']=0;
                $item['illegal']=0;
                $illegal_rate=0;
                if ($accounts) {
                    $accounts = array_slice($accounts, 0, 10);
                    $sql = "SELECT 
                            count(*) as count
                            FROM marketmax_reviews 
                            LEFT JOIN marketmax_reviews_verify on marketmax_reviews.ad_id = marketmax_reviews_verify.ad_id
                            WHERE marketmax_reviews_verify.status=3 and account_id in (" . implode(',', $accounts) . ")
                            group by marketmax_reviews.ad_id";
                    $illegal=$this->_ci->reports_model->get_report_data($sql, true, 48*3600);
                    $item['illegal']=count($illegal);

                    $sql = "SELECT 
                            count(*) as count
                            FROM marketmax_reviews 
                            WHERE account_id in (" . implode(',', $accounts) . ")
                            group by marketmax_reviews.ad_id";
                    $ad_count=$this->_ci->reports_model->get_report_data($sql, true, 48*3600);
                    $ad_count = count($ad_count);
                    if ($ad_count > 0) {
                        $item['illegal_rate']=sprintf("%.2f", ($item['illegal'] / $ad_count * 100));
                    }
                }
                $item['score']=$publisher_info['score'];
                $item['tags']=$publisher_info['tags'];
                $item['chart']=json_decode($publisher_info['agency_chart'], true);
            } else {
                unset($publisher_list[$k]);
            }
        }
        return $publisher_list;
    }


    public function get_publisher_admin()
    {
        //缓存文件
        $sql = "select * from user where type=2 and status=1 and publisher_type=1 and label!=''";
        $publisher_list = $this->_ci->user_model->get_query($sql);

        foreach ($publisher_list as $k=>&$item) {

                $item['publisher_id'] = $item['user_id'];
                $item['publisher_name'] = $item['user_name'];

                $item['letters']=get_first_letters($item['user_name'], 2);
                $sql="select product_id from marketmax_reports where publisher_id=" . $item['user_id'] . " group by product_id";
                $item['product']=count($this->_ci->reports_model->get_report_data($sql, true, 48*3600));

                $sql="select marketmax_reports.account_id from marketmax_reports where publisher_id=" . $item['user_id'] . " group by marketmax_reports.account_id";
                $account_id=$this->_ci->reports_model->get_report_data($sql, true, 48*3600);
                $item['account_id']=count($account_id);
                $accounts=[];
                foreach ($account_id as $value) {
                    $value['account_id'] && $accounts[]=$value['account_id'];
                }

                $sql="select sum(results) as results, sum(shares) as shares from marketmax_reports where publisher_id=" . $item['user_id'];
                $insights=$this->_ci->reports_model->get_report_data($sql, true, 48*3600);
                $item['results']=$item['shares']=0;
                if ($insights) {
                    $item['results']=$insights[0]['results'];
                    $item['shares']=$insights[0]['shares'];
                }
                $item['illegal']=0;
                $illegal_rate=0;
                $item['illegal_rate']=0;
                if ($accounts) {
                    $accounts = array_slice($accounts, 0, 10);
                    $sql = "SELECT 
                            count(*) as count
                            FROM marketmax_reviews 
                            LEFT JOIN marketmax_reviews_verify on marketmax_reviews.ad_id = marketmax_reviews_verify.ad_id
                            WHERE marketmax_reviews_verify.status=3 and account_id in (" . implode(',', $accounts) . ")
                            group by marketmax_reviews.ad_id";
                    $illegal=$this->_ci->reports_model->get_report_data($sql, true, 48*3600);
                    $item['illegal']=count($illegal);

                    $sql = "SELECT 
                            count(*) as count
                            FROM marketmax_reviews 
                            WHERE account_id in (" . implode(',', $accounts) . ")
                            group by marketmax_reviews.ad_id";
                    $ad_count=$this->_ci->reports_model->get_report_data($sql, true, 48*3600);
                    $ad_count = count($ad_count);
                    
                    if ($ad_count > 0) {
                        $item['illegal_rate']=sprintf("%.2f", ($item['illegal'] / $ad_count * 100));
                    }
                }
                $item['score']=$item['score'];
                $item['tags']=$item['tags'];
                $item['chart']=json_decode($item['agency_chart'], true);
           
        }
        return $publisher_list;
    }
}