<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Review extends CI_Controller {

    public function __construct()
    {
        parent::__construct();

        $this->load->model('business_model');
        $this->load->model('adaccount_model');
        $this->load->model('ad_model');
        $this->load->model('ad_extend_model');
        $this->load->model('ad_insight_model');
        $this->load->model('product_model');
        $this->load->model('publisher_adaccount_model');

        $this->load->library('Aws');
    }

    /**
     * 通过object store url 获取产品信息
     * @param  [type] $object_store_url [description]
     * @return [type]                   [description]
     */
    private function get_product_info($object_store_url){
        $app_id = get_app_id($object_store_url);
        if ($app_id) {
            return $this->product_model->get_by_fields(['app_id'=>$app_id]);
        }

        return [];
    }


    /**
     * 获取account_id 对应的流量主
     * @param  [type] $market_account_id [description]
     * @return [type]                    [description]
     */
    private function get_publisher_info($account_id)
    {
        $data = $this->publisher_adaccount_model->get_query("select * from publisher_offer where account_id=".$account_id." limit 1");
        
        return $data?$data[0]:[];
    }


    private function ad_insights($vars, $insights)
    {
        if ($insights) {
            $data = $insights[0];

            $result = ['account_id'=>$vars['account_id'], 'campaign_id'=>$vars['campaign_id'], 'adset_id'=>$vars['adset_id']];

            $result['account_name']     = $vars['account_name'];
            $result['campaign_name']    = $vars['campaign_name'];
            $result['adset_name']       = $vars['adset_name'];
            $result['ad_name']          = $vars['name'];
            $result['ad_id']            = $vars['ad_id'];
            $result['market_ad_id']     = $vars['market_ad_id'];

            $fields = $this->ad_insight_model->fields;

            $result['results'] = 0;
            $result['link_clicks'] = 0;
            $result['ctr_link'] = 0;
            $result['cost'] = 0;
            $result['cpc_link'] = 0;
            foreach ($data as $key => $value) {
                if (in_array($key, $fields)) {
                    is_array($value) && $value = json_encode($value);
                    $result[$key] = $value;
                }
                if ($key=='actions') {
                    foreach ($value as $k => $v) {
                        if ($v['action_type'] == 'mobile_app_install') {
                            $result['results'] = $v['value'];
                        }
                        if ($v['action_type'] == 'link_click') {
                            $result['link_clicks'] = $v['value'];
                            $result['ctr_link'] = $data['impressions']>0?$v['value']/$data['impressions']*100:0;
                        }
                        if ($v['action_type'] == 'comment') {
                            $result['comments'] = $v['value'];
                        }
                        if ($v['action_type'] == 'post') {
                            $result['shares'] = $v['value'];
                        }
                        if ($v['action_type'] == 'post_like') {
                            $result['likes'] = $v['value'];
                        }
                    }
                }
                if ($key=='cost_per_action_type') {
                    foreach ($value as $k => $v) {
                        if ($v['action_type'] == 'mobile_app_install') {
                            $result['cost'] = $v['value'];
                        }
                        if ($v['action_type'] == 'link_click') {
                            $result['cpc_link'] = $v['value'];
                        }
                    }
                }
                if ($key=='relevance_score') {
                    $result['relevance_score'] = isset($value['score'])?$value['score']:0;
                }
            }

            $result['date_start'] = strtotime($result['date_start']);
            $result['date_stop'] = strtotime($result['date_stop']);
            //$result['backup'] = json_encode($data);

            $insightinfo = $this->ad_insight_model->get_by_fields(['market_ad_id'=>$result['market_ad_id'], 'date_start'=>$result['date_start'], 'date_stop'=>$result['date_stop']]);
            if($insightinfo){
                $this->ad_insight_model->update_row_by_id($insightinfo['insight_id'], $result);
            }else{
                $this->ad_insight_model->add_one($result);
            }
        }
    }

    /**
     * 获取抓取数据时所使用的token
     * @param string $value [description]
     */
    private function get_token_user($account_id)
    {
        $publisher_adaccount = $this->ad_model->get_query("select * from publisher_adaccount where publisher_id=10040 and account_id=".$account_id);
        if ($publisher_adaccount) {
            return config_item('FACEBOOK_TOKEN');
        }else{
            $other_account = $this->ad_model->get_query("select * from publisher_adaccount where account_id=".$account_id);
            if (!$other_account) {
                return "Token Invalid";
            }

            $userinfo = $this->ad_model->get_query("select * from user where user_id=".$other_account[0]['publisher_id']);
            if (!$userinfo) {
                return "Token Invalid";
            }
            return $userinfo[0]['token'];
        }
    }



    /**
     * 抓取ad信息
     * @param  [type] $adset        [description]
     * @param  [type] $publisher_id [description]
     * @param  string $date         [description]
     * @return [type]               [description]
     */
    public function sync($adset, $publisher_id, $date="yesterday")
    {
        $this->load->model('user_model');
        try{
            $user_id = $this->get_token_user($adset['account_id']);
            $this->load->library('facebookapi', ['token'=>$user_id]);

            if ($date=='yesterday') {
                $date = strtotime(date('Y-m-d', strtotime("-1 day")));
            }else{
                $date = strtotime(date('Y-m-d'));
            }

            $product_info = $this->get_product_info($adset['object_store_url']);
            if (!$product_info) {
                return false;
            }

            $publisher_info = $this->get_publisher_info($adset['account_id']);
            if (!$publisher_info) {
                return false;
            }
            //$date = strtotime("2016-08-01");

            $data = $this->facebookapi->getAdsetToAds($adset['adset_id'], $date);
            foreach ($data as $item) {
                $ad_info = $this->ad_model->get_by_fields(['ad_id'=>$item['id'], 'is_new'=>1]);

                $vars = ['advertiser_id'=>$product_info['user_id'], 'advertiser_name'=>$product_info['user_name'], 'product_id'=>$product_info['product_id'],
                        'product_name'=>$product_info['name'], 'publisher_id'=>$publisher_info['publisher_id'], 'publisher_name'=>$publisher_info['publisher_name']];
            
                $vars['ad_id']          = $item['id'];
                $vars['name']           = $item['name'];
                $vars['adset_id']       = $adset['adset_id'];
                $vars['adset_name']     = $adset['adset_name'];
                $vars['campaign_id']    = $adset['campaign_id'];
                $vars['campaign_name']  = $adset['campaign_name'];
                $vars['account_id']     = $adset['account_id'];
                $vars['account_name']   = $adset['account_name'];

 
                $created_time = (array)$item['created_time'];
                $updated_time = (array)$item['updated_time'];

                $vars['updated_time']   = strtotime($updated_time['date']);
                $vars['created_time']   = strtotime($created_time['date']);

                if (!$item['adcreatives']) {
                    continue;
                }

                $creatives = $item['adcreatives'][0];

                $vars['creatives'] = $creatives['id'];
                //$vars['ad_review_feedback'] = json_encode($item['ad_review_feedback']);
                $vars['status'] = $item['status'];
                $vars['effective_status'] = $item['effective_status'];
                $vars['configured_status'] = $item['configured_status'];
                    
                $vars['object_story_spec'] =  json_encode($creatives['object_story_spec']);
                $vars['object_story_id'] = isset($creatives['object_story_id'])?$creatives['object_story_id']:'';
                $vars['object_type'] = $creatives['object_type'];
                $vars['offer_id'] = $adset['offer_id'];
                //$vars['backup'] = json_encode($item);

                //视频
                if ($vars['object_type'] == 'VIDEO') {
                    if (isset($creatives['object_story_spec']['video_data'])) {
                        $vars['image_url'] = $creatives['object_story_spec']['video_data']['image_url'];
                        

                        $path = "image/" . time() . rand( 1 , 10000 ) . ".png";
                        $vars['image_url'] = str_replace("https", "http", $vars['image_url']);
                        $this->aws->upload(config_item('Marketmax_Creative'), $path, @file_get_contents($vars['image_url']));
                        $vars['image_url'] = $path;
                        
                        $vars['title'] = $creatives['object_story_spec']['video_data']['call_to_action']['value']['link_title'];
                        $vars['message'] = $creatives['object_story_spec']['video_data']['description'];
                    
                        $video_data = $this->facebookapi->getVideo($creatives['object_story_spec']['video_data']['video_id']);
                        if ($video_data) {
                            $path = "video/" . time() . rand( 1 , 10000 ) . ".mp4";

                            $video_data['source'] = str_replace("https", "http", $video_data['source']);
                            $this->aws->upload(config_item('Marketmax_Creative'), $path, @file_get_contents($video_data['source']));
                            
                            $vars['video_url'] = $path;
                        }
                    }
                }

                if (isset($creatives['object_story_spec']['link_data'])) {
                    $object_story_spec = $creatives['object_story_spec']['link_data'];
                    $vars['message'] = $object_story_spec['message'];
                    isset($object_story_spec['call_to_action']['value']['link_title']) && $vars['title'] = $object_story_spec['call_to_action']['value']['link_title'];
                    
                    //多图
                    if (isset($object_story_spec['child_attachments']) && $object_story_spec['child_attachments']) {
                        $hash = [];
                        $child_list = [];
                        foreach ($object_story_spec['child_attachments'] as $child) {
                            $hash[] = $child['image_hash'];
                            $child_list[$child['image_hash']] = $child['name'];
                            if (!isset($vars['title'])) {
                                $vars['title'] = $child['name'];
                            }
                        }
                        $data = $this->facebookapi->getImages("act_".$vars['account_id'], $hash);
                        
                        $image_hash = [];
                        foreach ($data as $val) {
                            $image = ['name'=>$child_list[$val['hash']]];

                            $path = "image/" . time() . rand( 1 , 10000 ) . ".png";
                            $val['url'] = str_replace("https", "http", $val['url']);
                            $s = $this->aws->upload(config_item('Marketmax_Creative'), $path, @file_get_contents($val['url']));
                            
                            if ($s) {
                                $image['url'] = $path;
                            }else{
                                $image['url'] = $val['url'];
                            }

                            $image_hash[] = $image;
                        }
                        $vars['more_image'] = json_encode($image_hash);
                        $vars['object_type'] = "MORE_SHARE";
                    }
                }
                $width = 600;
                $height = 300;
                if ($vars['object_type'] == 'MORE_SHARE') {//600*600
                    $width = $height = 600;
                }elseif ($vars['object_type'] == 'SHARE') {//1200*628
                    $width = 600;
                    $height = 314;
                }elseif ($vars['object_type'] == 'VIDEO') {//1200*675
                    $width = 600;
                    $height = 337;
                }

                
                
                if (isset($creatives['image_url'])) {
                    $path = "image/" . time() . rand( 1 , 10000 ) . ".png";
                    $creatives['image_url'] = str_replace("https", "http", $creatives['image_url']);
                    $s = $this->aws->upload(config_item('Marketmax_Creative'), $path, @file_get_contents($creatives['image_url']));
                    if ($s) {
                        $vars['image_url'] = $path;
                    }else{
                        $vars['image_url'] = $creatives['image_url'];
                    }
                    $vars['org_image_url'] = $creatives['image_url'];
                }

                if (isset($creatives['thumbnail_url'])) {

                    $thumbnail_url = $creatives['thumbnail_url'];

                    $creatives['thumbnail_url']  = str_replace("https", "http", $creatives['thumbnail_url']); 
                    $creatives['thumbnail_url']  = str_replace("w=64", "w=".$width, $creatives['thumbnail_url']); 
                    $creatives['thumbnail_url']  = str_replace("h=64", "h=".$height, $creatives['thumbnail_url']); 

                    $path = "image/" . time() . rand( 1 , 10000 ) . ".png";
                    $s = $this->aws->upload(config_item('Marketmax_Creative'), $path, @file_get_contents($creatives['thumbnail_url']));
                    
                    if ($s) {
                        $vars['thumbnail_url'] = $path;
                    }else{
                        $vars['thumbnail_url'] = $creatives['thumbnail_url'];
                    }
                    $vars['org_thumbnail_url'] = $creatives['thumbnail_url'];
                }

                if ($ad_info) {
                    if ($ad_info['updated_time']!=$vars['updated_time']) {
                        $this->ad_model->update_row_by_fields(['ad_id'=>$item['id']], ['is_new'=>0]);

                        $vars['is_new'] = 1;
                        $market_ad_id = $this->ad_model->add_one($vars);
                    }else{
                        $market_ad_id = $ad_info['market_ad_id'];
                        $this->ad_model->update_row_by_id($ad_info['market_ad_id'], $vars);
                    }
                }else{
                    $market_ad_id = $this->ad_model->add_one($vars);
                }
                $vars['market_ad_id'] = $market_ad_id;
                if (isset($item['insights'])) {
                    $this->ad_insights($vars, $item['insights']);
                }
                
                $extend = $this->ad_extend_model->get_by_fields(['ad_id'=>$vars['ad_id'], 'updated_time'=>$vars['updated_time']]);
            
                if ($extend) {
                    $this->ad_extend_model->update_row_by_id($extend['extend_id'], ['facebook_backup'=>json_encode($item)]);
                }else{
                    $this->ad_extend_model->add_one(['facebook_backup'=>json_encode($item), 'ad_id'=>$vars['ad_id'], 'updated_time'=>$vars['updated_time']]);
                }
            }
        }catch(Exception $e){
            fetch_exception($adset['account_id'], 'fetch_review', $e->getMessage());

            log_message('error', "queue_review_data: ".$adset['account_id'].'_'.$adset['adset_id']." fetch faild ->".date('Y-m-d H:i:s') . " ".$e->getMessage());
        }
    }


    /**
     * 获取当前使用的表名称
     * 每个月都要创建一个新表
     * @return [type] [description]
     */
    private function get_dynamodb_table()
    {
        $table_name = "marketmax_comments";
        // if ($date) {
        //     $table_name = "marketmax_comments";
        // }
        $table_list = $this->aws_dynamodb->listTables();
        if (in_array($table_name, $table_list)) {
            return $table_name;
        }else{
            $params = [
                'TableName' => $table_name,
                'KeySchema' => [
                    [
                        'AttributeName' => 'comment_id',
                        'KeyType' => 'HASH'  //Partition key
                    ]
                ],
                'AttributeDefinitions' => [
                    [
                        'AttributeName' => 'comment_id',
                        'AttributeType' => 'S'
                    ]
                ],
                'ProvisionedThroughput' => [
                    'ReadCapacityUnits' => 200,
                    'WriteCapacityUnits' => 20
                ]
            ];
            $data = $this->aws_dynamodb->createTable($params);
            sleep(10);
        }
        return $table_name;
    }
 
    public function fetch_ad_comment($object_id, $account_id, $ad_id)
    {
        $this->load->model('user_model');
        $this->load->library('aws_dynamodb');

        $user_id = $this->get_token_user($account_id);
        $this->load->library('facebookapi', ['token'=>$user_id]);

        $data = $this->facebookapi->getComments($object_id);

        foreach ($data as $key => $value) {
            $value['message'] = $value['message']?$value['message']:' ';

            $fields = ['ad_id'=>$ad_id, 'created_time'=>strtotime($value['created_time']), 'message'=>$value['message']
                        , 'comment_id'=>$value['id'], 'user_name'=>$value['from']['name'], 'user_id'=>$value['from']['id'], 'featured'=>' '];
            
            $table_name = $this->get_dynamodb_table();
            $this->aws_dynamodb->putItem($table_name, json_encode($fields));
        }
    }
}