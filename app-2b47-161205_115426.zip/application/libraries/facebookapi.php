<?php

require_once __DIR__ . '/vendor/autoload.php';


use Facebook\Facebook;
use Facebook\Exceptions\FacebookResponseException;
use Facebook\Exceptions\FacebookSDKException;

use Facebook\FacebookRequest;
use Facebook\FacebookApp;


/**
 * facebook api
 */
class Facebookapi
{

    var $_fb;
    var $_app_id;
    var $_app_secret;
    var $_ci;
    var $_fb_exchange_token;
    var $_user_id;
    var $_token;

    var $_AdAccountFields;
    var $_CampaignFields;
    var $_AdSetFields;
    var $_AdFields;
    var $_AdUserFields;
    var $_AdCreativeFields;


    function __construct($params=[])
    {
        $this->_ci =& get_instance();
        $this->_app_id = config_item('APP_ID');
        $this->_app_secret = config_item('APP_SECRET');
        if ($params) {
            isset($params['user_id']) && $this->_user_id = $params['user_id'];
            isset($params['token']) && $this->_token = $params['token'];
        }
        

        $this->_ci->load->library('curl');

        //创建fb对象
        $this->_fb = new Facebook([
            'app_id' => $this->_app_id,
            'app_secret' => $this->_app_secret,
            'default_graph_version' => config_item('APP_VERSION'),
        ]);
    }

    /**
     * set Token
     * @param [type] $token [description]
     */
    public function setToken($token)
    {
        $this->_token = $token;
    }
    
    /**
     * 获取token
     * @return [type] [description]
     */
    public function getToken()
    {
        //return config_item('FACEBOOK_TOKEN');
        if ($this->_token) {
            return $this->_token;
        }else{
            $this->_ci->load->model('user_model');
            $tokenstr = $this->_ci->user_model->get_by_id($this->_user_id);
            if ($tokenstr) {
                if ($tokenstr['token_expires'] > time()) {
                    return $tokenstr['token'];
                }
            }
        }
        
        return 'Token Invalid';
    }

    //获取当前使用的token的用户是谁
    public function getMe($token = '')
    {
        if (!$token) {
            $token = $this->getToken();
        }
        $url = config_item('APP_URL').config_item('APP_VERSION')."/me?fields=gender,first_name,name,last_name,picture.type(large).redirect(false)&access_token=" . $token;
        $userinfo = $this->_ci->curl->simple_get($url);

        return $userinfo;
    }


    /**
     * 获取bm详情
     * 
     * @param  [type] $business_id [description]
     * @param  string $token       [description]
     * @return [type]              [description]
     */
    public function getBussiness($business_id)
    {
        $url = config_item('APP_URL').config_item('APP_VERSION')."/".$business_id."?fields=created_by,name,timezone_id,updated_by,userpermissions.limit(100),adaccounts.limit(1000)&access_token=" . $this->getToken();
        $info = $this->_ci->curl->simple_get($url);

        return $info;
    }


    /**
     * 获取token
     * @param  [type] $fb_exchange_token [临时token]
     * @return [type]                    [description]
     */
    public function createToken($fb_exchange_token)
    {
        $this->_ci->load->library('curl');

        $url = config_item('APP_URL')."oauth/access_token";

        $tokenstr = $this->_ci->curl->simple_post($url, array(
            'grant_type' => 'fb_exchange_token',
            'client_id' => $this->_app_id,
            'client_secret' => $this->_app_secret,
            'fb_exchange_token' => $fb_exchange_token
        ));
        $queryParts = explode('&', $tokenstr);

        $token = explode('=', $queryParts[0]);
        //$expires = explode('=', $queryParts[1]);
        $expires = 50 * 86500;//有效期为60天，直接搞成50天吧，到50天就在生成一次

        return [$token[1], time() + $expires];
    }


    //-----------------------------------------------------------
    //一下是同步所有账号信息

    /**
     * 通过对应的object_id，对应的方法
     * 获取facebook相应数据
     * @param  [type] $object_id [description]
     * @param  [type] $object    [description]
     * @return [type]            [description]
     */
    public function getDataByObject($object_id, $object='', $params='')
    {
        if ($object=='businesses' && !$params) {
            $params = "limit=100&fields=created_by,name,timezone_id,updated_by,userpermissions";
        }
        if ($object) {
            $response = $this->_fb->get('/' . $object_id . '/' .$object. '?' . $params, $this->getToken());
        }else{
            $response = $this->_fb->get('/' . $object_id .'?' . $params, $this->getToken());
        }
        
        $pagesEdge = $response->getGraphEdge();
        $data = [];
        foreach ($pagesEdge as $page) {
            $data[] = $page->asArray();
        }

        return $data;
    }

    /** 
     * 通过url获取facebook数据
     * @param  [type] $query  [description]
     * @param  string $params [description]
     * @return [type]         [description]
     */
    public function getFacebookData($query, $params="")
    {
        $url = config_item('APP_URL').config_item('APP_VERSION')."/".$query;
        if ($params) {
            $url .= "?".$params."&access_token=" . $this->getToken();
        }else{
            $url .= "?access_token=" . $this->getToken();
        }
        return  $this->_ci->curl->simple_get($url);

    }


    public function getDataByUrl($url)
    {
        $this->_ci->load->library('curl');
        $url .= "&access_token=".$this->getToken();
        return $this->_ci->curl->simple_get($url);
    }



    //获取所有账号【done】
    public function getAccounts()
    {

        $fields = "&fields=account_status,account_id,id,name,currency,min_daily_budget,balance,amount_spent,spend_cap,created_time,effective_status";
        $response = $this->_fb->get('/me/adaccounts?limit=100' . $fields, $this->getToken());
        $pagesEdge = $response->getGraphEdge();

        $data = [];
        foreach ($pagesEdge as $page) {
            $data[] = $page->asArray();
        }
        $next_data = $this->getNextData($pagesEdge);

        return array_merge($data, $next_data);;
    }

    /**
     * 获取adset信息
     * @param  [type] $adset_id [description]
     * @return [type]           [description]
     */
    public function getAdsetData($adset_id)
    {
        $fields = "id,name,account_id,campaign_id,budget_remaining,daily_budget,billing_event,promoted_object,targeting,effective_status,status";
        $url = config_item('APP_URL').config_item('APP_VERSION')."/" . $adset_id . "?access_token=" . $this->getToken() . "&debug=all&format=json&method=get&pretty=0&suppress_http_code=1&fields=".$fields;

        $data = $this->_ci->curl->simple_get($url);

        return json_decode($data, true);
    }

    /**
     * 获取campaign信息
     * @param  [type] $adset_id [description]
     * @return [type]           [description]
     */
    public function getCampaignData($campaign_id)
    {
        $fields = "id,name";
        $url = config_item('APP_URL').config_item('APP_VERSION')."/" . $campaign_id . "?access_token=" . $this->getToken() . "&debug=all&format=json&method=get&pretty=0&suppress_http_code=1&fields=".$fields;

        $data = $this->_ci->curl->simple_get($url);
        
        return json_decode($data, true);
    }

    //获取指定账号下所有campaigns【done】act_845102802254463
    public function accountToCampaigns($account_id)
    {
        $account_id = "act_" . $account_id;
        $response = $this->_fb->get('/' . $account_id .'/campaigns?limit=100&fields=name,account_id,id', $this->getToken());

        $pagesEdge = $response->getGraphEdge();
        $data = [];
        foreach ($pagesEdge as $page) {
            $data[] = $page->asArray();
        }
        $next_data = $this->getNextData($pagesEdge);

        return array_merge($data, $next_data);
    }


    /**
     * 获取下一页数据
     * @param  [type] $pagesEdge [description]
     * @return [type]            [description]
     */
    public function getNextData($pagesEdge)
    {
        
        $result = [];
        while ($pagesEdge = $this->_fb->next($pagesEdge)) {
            $data = [];
            foreach ($pagesEdge as $page) {
                $data[] = $page->asArray();
            }
            $result = array_merge($result, $data);
        }
        return $result;
    }


    /**
     * 获取应用的信息,只有在获取adset时才会有这个
     * @param  [type] $application_id [description]
     * @return [type]                 [description]
     */
    private function getApplaction($application_id)
    {
        $url = config_item('APP_URL').config_item('APP_VERSION')."/" . $application_id . "?access_token=" . $this->getToken() . "&debug=all&format=json&method=get&pretty=0&suppress_http_code=1&fields=logo_url,name,object_store_urls,namespace,id";

        $data = $this->_ci->curl->simple_get($url);
        return json_decode($data, true);
    }


    /**
     * 获取指定campaign下的adSet[done]6037310346835
     */
    public function campaignToAdSets($campaign_id)
    {
        $response = $this->_fb->get('/' . $campaign_id .'/adsets?limit=100&fields=name,account_id,id,promoted_object', $this->getToken());

        $pagesEdge = $response->getGraphEdge();
        $data = [];
        foreach ($pagesEdge as $page) {
            $data[] = $page->asArray();
        }
        $next_data = $this->getNextData($pagesEdge);

        return array_merge($data, $next_data);
    }


    //通过accountid 获取所有的adset【done】
    public function accountToAdset($account_id)
    {
        $account_id = "act_".$account_id;

        $fields = "&fields=id,name,account_id,account_name,campaign_id,campaign_name,objective,buying_type,offer_name,budget_remaining,daily_budget,billing_event,promoted_object,targeting,effective_status";
        $response = $this->_fb->get('/' . $account_id .'/adsets?limit=500' . $fields, $this->getToken());

        $pagesEdge = $response->getGraphEdge();
        $data = [];
        foreach ($pagesEdge as $page) {
            $data[] = $page->asArray();
        }
        $next_data = $this->getNextData($pagesEdge);

        return array_merge($data, $next_data);
    }

    //通过accountid 获取所有的ads【done】
    //添加抓取ad更新时间
    //,,,,
    public function getAccountToAds($account_id, $breakdowns, $start_date, $end_date, $limit=300)
    {
        $account_id = "act_".$account_id;

        $updated_since = strtotime("-60 day");

        $fields = "&fields=id,name,account_id,account_name,campaign_id,campaign_name,objective,buying_type,offer_name,budget_remaining,daily_budget,billing_event,promoted_object,targeting";
        $fields = "&fields=insights.breakdowns($breakdowns).time_range({'since':'$start_date','until':'$end_date'}).fields(relevance_score,actions,cost_per_action_type,date_start,date_stop,total_actions,total_unique_actions,total_action_value,impressions,social_impressions,clicks,social_clicks,unique_impressions,unique_social_impressions,unique_clicks,unique_social_clicks,spend,frequency,deeplink_clicks,app_store_clicks,website_clicks,cost_per_inline_post_engagement,inline_link_clicks,cost_per_inline_link_click,inline_post_engagement,unique_inline_link_clicks,cost_per_unique_inline_link_click,inline_link_click_ctr,unique_inline_link_click_ctr,reach,social_reach,ctr,unique_ctr,unique_link_clicks_ctr,cpc,cpm,cpp,cost_per_total_action,cost_per_unique_click,estimated_ad_recall_rate,estimated_ad_recall_rate_lower_bound,estimated_ad_recall_rate_upper_bound,cost_per_estimated_ad_recallers,canvas_avg_view_time,canvas_avg_view_percent,adset_id,campaign_id,account_id), configured_status, status, effective_status, ad_review_feedback, created_time, updated_time, id,name,adset_id,campaign_id,account_id,adcreatives.fields(object_story_spec,thumbnail_url,image_url,object_story_id,object_type)&updated_since=".$updated_since;
        
        $response = $this->_fb->get('/' . $account_id .'/ads?limit='.$limit . $fields, $this->getToken());

        $pagesEdge = $response->getGraphEdge();
        $data = $next_data = [];
        foreach ($pagesEdge as $page) {
            $data[] = $page->asArray();
        }
        //$next_data = $this->getNextData($pagesEdge);
        //return array_merge($data, $next_data);
        
        return [$data, $pagesEdge];
    }

    //获取下一页ad数据
    public function getNextAccountToAds($pagesEdge)
    {
        $result = [];
        $pagesEdge = $this->_fb->next($pagesEdge);
        $data = [];
        if ($pagesEdge) {
            foreach ($pagesEdge as $page) {
                $data[] = $page->asArray();
            }
        }
        return [$data, $pagesEdge];
    }

    /**
     * adset下广告信息
     */
    public function getAdsetToAds($adset_id, $updated_since='')
    {

        $fields = "&fields=insights{relevance_score,actions,cost_per_action_type,date_start,date_stop,total_actions,total_unique_actions,total_action_value,impressions,social_impressions,clicks,social_clicks,unique_impressions,unique_social_impressions,unique_clicks,unique_social_clicks,spend,frequency,deeplink_clicks,app_store_clicks,website_clicks,cost_per_inline_post_engagement,inline_link_clicks,cost_per_inline_link_click,inline_post_engagement,unique_inline_link_clicks,cost_per_unique_inline_link_click,inline_link_click_ctr,unique_inline_link_click_ctr,reach,social_reach,ctr,unique_ctr,unique_link_clicks_ctr,cpc,cpm,cpp,cost_per_total_action,cost_per_unique_click,estimated_ad_recall_rate,estimated_ad_recall_rate_lower_bound,estimated_ad_recall_rate_upper_bound,cost_per_estimated_ad_recallers,canvas_avg_view_time,canvas_avg_view_percent,adset_id,campaign_id,account_id}, configured_status, status, effective_status, ad_review_feedback, created_time, updated_time, id,name,adcreatives{object_story_spec,thumbnail_url,image_url,object_story_id,object_type}&updated_since=".$updated_since;
        $response = $this->_fb->get('/' . $adset_id .'/ads?limit=100' . $fields, $this->getToken());

        $pagesEdge = $response->getGraphEdge();
        $data = [];
        foreach ($pagesEdge as $page) {
            $data[] = $page->asArray();
        }
        $next_data = $this->getNextData($pagesEdge);

        return array_merge($data, $next_data);
    }


    /**
     * 获取视频路径
     * @param  [type] $video_id [description]
     * @return [type]           [description]
     */
    public function getVideo($video_id)
    {
        $url = config_item('APP_URL').config_item('APP_VERSION')."/" . $video_id . "?access_token=" . $this->getToken() . "&debug=all&format=json&method=get&pretty=0&suppress_http_code=1&fields=source";

        $data = $this->_ci->curl->simple_get($url);
        return json_decode($data, true);
    }

    public function getImages($account_id, $image_hash)
    {
        if (strpos($account_id, "act_")===false) {
            $account_id = "act_".$account_id;
        }
        $fields = "&fields=url,url_128,hash&hashes=".json_encode($image_hash);
        
        $response = $this->_fb->get('/' . $account_id .'/adimages?' . $fields, $this->getToken());

        $pagesEdge = $response->getGraphEdge();
        $data = [];
        foreach ($pagesEdge as $page) {
            $data[] = $page->asArray();
        }

        return $data;
    }

    /**
     * 获取广告创意[done]
     * @param  string $value [description]
     * @return [type]        [description]
     * act_845102802254463
     */
    public function adCreativesInfo($adCreative_id)
    {
        $creative = new AdCreative($adCreative_id);
        $data = $creative->read($this->_AdCreativeFields);

        return $data->getData();
    }


    /**
     * 获取统计数据
     * @param  [type] $object_id [description]
     * @param  [type] $params    [description]
     * @return [type]            [description]
     */
    public function getInsights($object_id, $params)
    {
        if ($params) {
            $params .= "&fields=actions,cost_per_action_type,date_start,date_stop,total_actions,total_unique_actions,total_action_value,impressions,social_impressions,clicks,social_clicks,unique_impressions,unique_social_impressions,unique_clicks,unique_social_clicks,spend,frequency,deeplink_clicks,app_store_clicks,website_clicks,cost_per_inline_post_engagement,inline_link_clicks,cost_per_inline_link_click,inline_post_engagement,unique_inline_link_clicks,cost_per_unique_inline_link_click,inline_link_click_ctr,unique_inline_link_click_ctr,reach,social_reach,ctr,unique_ctr,unique_link_clicks_ctr,cpc,cpm,cpp,cost_per_total_action,cost_per_unique_click,estimated_ad_recall_rate,estimated_ad_recall_rate_lower_bound,estimated_ad_recall_rate_upper_bound,cost_per_estimated_ad_recallers,canvas_avg_view_time,canvas_avg_view_percent,adset_id,campaign_id,account_id";
        }else
            $params = "fields=actions,cost_per_action_type,date_start,date_stop,total_actions,total_unique_actions,total_action_value,impressions,social_impressions,clicks,social_clicks,unique_impressions,unique_social_impressions,unique_clicks,unique_social_clicks,spend,frequency,deeplink_clicks,app_store_clicks,website_clicks,cost_per_inline_post_engagement,inline_link_clicks,cost_per_inline_link_click,inline_post_engagement,unique_inline_link_clicks,cost_per_unique_inline_link_click,inline_link_click_ctr,unique_inline_link_click_ctr,reach,social_reach,ctr,unique_ctr,unique_link_clicks_ctr,cpc,cpm,cpp,cost_per_total_action,cost_per_unique_click,estimated_ad_recall_rate,estimated_ad_recall_rate_lower_bound,estimated_ad_recall_rate_upper_bound,cost_per_estimated_ad_recallers,canvas_avg_view_time,canvas_avg_view_percent,adset_id,campaign_id,account_id";
        
        $params .= "&limit=500";
        $response = $this->_fb->get('/' . $object_id . '/insights?' . $params, $this->getToken());
        $pagesEdge = $response->getGraphEdge();
        $data = [];
        foreach ($pagesEdge as $page) {
            $data[] = $page->asArray();
        }

        return $data;
    }


    private function getCurlNextData($next_url)
    {
        $data = [];
        $nextstr = $this->_ci->curl->simple_get($next_url);
        $result = [];

        if ($nextstr) {
            $result = json_decode($nextstr, true);
        }

        if ($result) {
            if ($result['data']) {
                $data = array_merge($data, $result['data']);
            }

            while (isset($result['paging']['next']) && !empty($result['paging']['next'])) {

                $nextstr = $this->_ci->curl->simple_get($result['paging']['next']);
                $result = [];
                if ($nextstr) {
                    $result = json_decode($nextstr, true);
                }

                if ($result) {
                    $data = array_merge($data, $result['data']);
                } else {
                    break;
                }
            }
        }
        return $data;
    }


    /**
     * 获取评论数据
     * @param  [type] $object_id [description]
     * @return [type]            [description]
     */
    public function getComments($object_id)
    {
        $url = config_item('APP_URL').config_item('APP_VERSION')."/".$object_id."/comments?access_token=".$this->getToken();
        $url .= "&limit=1";
        $object = $this->_ci->curl->simple_get($url);
        $data = json_decode($object, true);


        $result = $data['data'];
        if (isset($data['paging']['next'])) {
            $nextdata = $this->getCurlNextData($data['paging']['next']);
            $result = array_merge($result, $nextdata);
        }
        
        return $result;
    }

} 