<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * CodeIgniter Redis
 *
 * A CodeIgniter library to interact with Redis
 *
 * @package         CodeIgniter
 * @category        Libraries
 * @author          Joël Cox
 * @version         v0.4
 * @link            https://github.com/joelcox/codeigniter-redis
 * @link            http://joelcox.nl
 * @license         http://www.opensource.org/licenses/mit-license.html
 */
class CI_Redis {

    private $redis;
    private $_ci;

    public function __construct($params = array()){

        $this->_ci = get_instance();
        $this->_ci->load->config('redis');
        $config = $this->_ci->config->item('redis_default');

        $this->redis = new Redis();

        $this->redis->connect($config['host'], $config['port']);

        $this->redis->select($config['select']);
    }


    public function set($key, $value)
    {
        $this->redis->set($key, $value);
    }

    public function get($key)
    {
        return $this->redis->get($key);
    }

    public function del($key)
    {
        $this->redis->del($key);
    }

    public function expire($key, $time=3600)
    {
        $this->redis->expire($key, $time);
    }

    public function sadd($key, $value)
    {
        return $this->redis->sAdd($key, $value);
    }

    public function spop($key)
    {
        return $this->redis->sPop($key);
    }
}