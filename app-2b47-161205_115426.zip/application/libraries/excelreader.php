    <?php
/**
 * Created by PhpStorm.
 * User: palmax
 * Date: 2016/5/4
 * Time: 14:09
 */
require_once __DIR__ . '/excel/php-excel-reader/excel_reader.php';
require_once __DIR__ . '/excel/SpreadsheetReader.php';
class ExcelReader
{
    /**
     * 处理excel导入
     * @param $filePath 文件路径
     * @return mixed 有数据返回数组,其他返回false
     */
    public function getExcelInfo($filePath)
    {
        $Reader = new SpreadsheetReader($filePath);
        if($Reader->status){
            $sheets = $Reader->Sheets();
            $temp = array();
            if(!empty($sheets)){
                foreach ($sheets as $index => $name) {
                    $Reader->ChangeSheet($index);
                    foreach ($Reader as $row) {
                        $temp['result'][] = $row;
                    }
                }
                //处理数据
                $cols = '';
                foreach ($temp['result'] as $key => $value) {
                    if ($key == 0) {
                        $temp['numCols'] = count($temp['result'][$key]);
                        //unset($temp['result'][$key]);
                    } else {
                        $temp['result'][$key][0] = $value[0];
                    }
                }
                $temp['result'] = array_values($temp['result']);
                $temp['numRows'] = count($temp['result']);
                return $temp;
            }else{
                //文件为空的情况
                return false;
            }
        }else{
            //文件读取错误，即文件损坏情况
            return false;
        }
    }
}