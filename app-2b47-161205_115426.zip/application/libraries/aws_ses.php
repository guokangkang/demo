<?php defined('BASEPATH') OR exit('No direct script access allowed');

require_once __DIR__ . '/vendor/autoload.php';
use Aws\Ses\SesClient;
use Aws\Credentials\CredentialProvider;


class Aws_ses {

    protected $_ci;  

    function __construct()
    {
        $this->_ci = & get_instance();
        log_message('debug', 'Library loaded: aws_ses');
    }

    public function send($address, $subject, $body)
    {
        log_message('debug', 'AWS SES Message: Send started');

        $profile = 'default';
        $path = APPPATH . 'config/aws_credentials.ini';

        $provider = CredentialProvider::ini($profile, $path);
        $provider = CredentialProvider::memoize($provider);

        $client = SesClient::factory(array(
            'credentials' => $provider,
            'region' => 'us-west-2',
            'version' => 'latest'
        ));

        $request = array();
        $request['Source'] = "no-reply@palmax.com";
        $request['Destination']['ToAddresses'] = $address;
        $request['Message']['Subject']['Data'] = $subject;
        $request['Message']['Body']['Html']['Data'] = $body;

        try {
            $result = $client->sendEmail($request);
            $messageId = $result->get('MessageId');
            log_message('debug', "Email sent! Message ID: $messageId");
            return $messageId;
        } catch (Exception $e) {
            log_message('error', "The email was not sent. Error message: ". $e->getMessage());
            return $e->getMessage();
        }
    }

}



?>