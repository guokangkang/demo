<?php
    
require_once __DIR__ . '/vendor/autoload.php';

use Aws\Credentials\CredentialProvider;
use Aws\Sts\StsClient;
use Aws\S3\S3Client;

/**
 * aws api
 * 产品图上传需要用美国节点，因为需要使用lambda
 * 其他上传如果不需要裁图，都直接用新加坡
 */
class Aws
{

    var $sdk;
    //var $region = "ap-southeast-1"; 

    function __construct($params=[]){

        $profile = 'default';
        $path    = APPPATH . 'config/aws_credentials.ini';

        $provider = CredentialProvider::ini($profile, $path);
        $provider = CredentialProvider::memoize($provider);
        if (!$params) {
            $region = 'ap-northeast-1';
        }else{
            $region = $params['region'];
        }

        // Use the us-west-2 region and latest version of each client.
        $sharedConfig = [
            //'region'  => 'us-east-1',//美国s3
            //'region'  => 'ap-southeast-1',//新加坡
            'region'    => $region,
            'version' => 'latest',//latest
            'credentials' => $provider
        ];

        // Create an SDK class used to share configuration across clients.
        $this->sdk = new Aws\Sdk($sharedConfig);
    }


    public function getContentType($filename)
    {
        if (strpos($filename, '.jpg') || strpos($filename, '.jpeg')) {
            return 'image/jpeg';
        }elseif(strpos($filename, '.png')){
            return 'image/png';
        }elseif(strpos($filename, '.bmp')){
            return 'image/bmp';
        }
        return 'image/jpeg';
    }

    /**
     * 通过文件二进制流上传
     * @param  [type] $bucket   [description]
     * @param  [type] $filename [description]
     * @param  array  $data     [description]
     * @return [type]           [description]
     */
    public function upload($bucket, $filename, $data=[])
    {
        $s3Client = $this->sdk->createS3();

        $info = $s3Client->putObject(array(
            'Bucket'       => $bucket,
            'Key'          => $filename,
            'Body'         => $data,
            'ContentType'  => $this->getContentType($filename),
            'ACL'          => 'public-read'
        ));

        $info = $info->toArray();
        return $info['ObjectURL'];
    } 

    /**
     * 通过文件路径上传
     * @param  [type] $bucket   [description]
     * @param  [type] $filename [description]
     * @param  array  $data     [description]
     * @return [type]           [description]
     */
    public function uploadPath($bucket, $filename, $data=[])
    {
        $s3Client = $this->sdk->createS3();

        $info = $s3Client->putObject(array(
            'Bucket'       => $bucket,
            'Key'          => $filename,
            'SourceFile'   => $data,
            'ContentType'  => $this->getContentType($filename),
            'ACL'          => 'public-read'
        ));

        $info = $info->toArray();
        return $info['ObjectURL'];
    } 


    /**
     * 
     * @param  [type] $bucket   [description]
     * @param  [type] $filename [description]
     * @param  array  $data     [description]
     * @return [type]           [description]
     */
    public function getPath($bucket, $filename)
    {
        $s3Client = $this->sdk->createS3();
        $new_file = "./uploads/".time().".csv";
        $info = $s3Client->getObject(array(
            'Bucket'       => $bucket,
            'Key'          => $filename,
            "SaveAs"       => $new_file
        ));

        //$info = $info->toArray();
        return $new_file;
    } 
}