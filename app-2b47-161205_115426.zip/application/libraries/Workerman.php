<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Workman Queue Class
 *
 * 向Workman队列服务器发送消息
 *
 * @package         CodeIgniter
 * @subpackage      Libraries
 * @category        Libraries
 */
class Workerman {

    var $client;

    function __construct()
    {
        log_message('debug', 'Queue Class Initialized');
    }


    public function connect($server = "0.0.0.0:1236")
    {
        log_message('debug', 'Connectting queue server');
        $server = 'tcp://'.$server; 

        $this->client = stream_socket_client($server, $err_no, $err_msg, 5);
        if(!$this->client)
        {
            log_message('error', 'Queue server connect failed.');
            return $err_msg;
        }
    }

    /*
    * 向对列添加一个任务，并立即返回结果
    * 数据包格式： {"class":"Mail", "method":"send", "args":["xiaoming","xiaowang","hello"]}
    */
    public function push($message)
    {
        // 数据末尾加一个换行，使其符合Text协议。使用json编码
        $message = json_encode($message)."\n";

        // 向队列发送任务，让队列慢慢去执行
        fwrite($this->client, $message);
        log_message('debug', 'Queue message: ' .json_encode($message) . ' is pushed');

        // 队列返回的结果，结果格式为JSON，这个结果是立即返回的
        return fread($this->client, 8192);
    }

}