<?php

/**
 * Created by PhpStorm.
 * User: palmax
 * Date: 2016-10-25
 * Time: 16:15
 */
require_once __DIR__ . '/vendor/autoload.php';
use Dompdf\Dompdf;
use Dompdf\Options;
use Dompdf\Canvas;
use Dompdf\Css;
use Dompdf\FontMetrics;

class Export_pdf
{
    protected $_pdf;

    public function __construct()
    {
        ini_set('xdebug.max_nesting_level', -1);
        $options=new Options();
        $options->set(['isUnicode'=>false,'defaultFont'=>'yahei', 'pdfBackend'=>'PDFLib', 'isHtml5ParserEnabled'=>true, 'isJavascriptEnabled'=>true, 'isFontSubsettingEnabled'=>true, 'isPhpEnabled'=>true, 'isRemoteEnabled'=>true]);
        $this->_pdf=new Dompdf($options);
        //var_dump($this->_pdf);die;
    }

    /**
     * 导出pdf
     * @param $url
     */
    public function export($html)
    {
        ob_start();
        $this->_pdf->getFontMetrics();
        $this->_pdf->loadHtml($html);
        $this->_pdf->setPaper('A4');
        $this->_pdf->render();
        ob_end_clean();
        return $this->_pdf->stream('invoice' . date('Y-m-d'), array("Attachment"=>true));
    }
}