<?php
require __DIR__ . '/ggpaly/playUp.php';
/**
 * google paly 市场采集
 * User: palmax
 * Date: 2016/5/3
 * Time: 15:02
 */
class playapi
{
    public $lang;
    public function __construct()
    {
        $this->lang=$_SERVER['HTTP_ACCEPT_LANGUAGE'];
        $this->lang=substr($this->lang, 0, strpos($this->lang, ','));
        return $this->lang;
    }

    /**
     * @param $package 安卓的包id ,如果传入为空返回false
     * @param string $lang 语言 默认en-us
     * @return bool 如果没有返回值返回false,反之返回名称相关联的图片
     */
    public function getPackage($package)
    {
        if ($package) {
            $PlayUp = new playUp();
            $res_curl = $PlayUp::packagecheck($package, 'en-US');
            if ($res_curl['status']>0) {
                //$data['name'] = $res_curl['data']['name'];
                //$data['image'] = $res_curl['data']['image'];
                return $res_curl['data'];
            }
            $res_curl = $PlayUp::packagecheck($package, $this->lang);
            return $res_curl;
        }
        return false;
    }

    /**
    * @param $package 安卓的包id ,如果传入为空返回false
    */
    public function package($package)
    {
        $PlayUp = new playUp();
        $res = $PlayUp::getPackage($package);
        $res = json_encode($res);
        return json_decode($res, true);
    }
}
