<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Review extends CI_Controller {


    var $adset_fields = [
            'account_id',
            'campaign_id',
            'name',
            'objective',
            'status',
            'buying_type',//竞价方式
            'created_time',
            'start_time',
            'offer_name',
            'budget_remaining',
            'daily_budget',
            'billing_event'
    ];

    public function __construct()
    {
        parent::__construct();

        $this->load->model('business_model');
        $this->load->model('adaccount_model');
        $this->load->model('ad_model');
        $this->load->model('ad_extend_model');
        $this->load->model('ad_insight_model');
        $this->load->model('product_model');
        $this->load->model('publisher_adaccount_model');
        $this->load->model('setting_model');
        $this->load->model('redshift_model');

        $this->load->library('Aws');

        $this->load->library('aws_dynamodb');

        $this->load->library('aws_sqs');
    }

    /**
     * 通过object store url 获取产品信息
     * @param  [type] $object_store_url [description]
     * @return [type]                   [description]
     */
    private function get_product_info($object_store_url){
        $app_id = get_app_id($object_store_url);
        if ($app_id) {
            return $this->product_model->get_by_fields(['app_id'=>$app_id]);
        }

        return [];
    }


    /**
     * 获取account_id 对应的流量主
     * @param  [type] $market_account_id [description]
     * @return [type]                    [description]
     */
    private function get_publisher_info($account_id)
    {
        $data = $this->publisher_adaccount_model->get_query("select * from publisher_offer where account_id=".$account_id." limit 1");
        
        return $data?$data[0]:[];
    }


    private function get_reports_table($table, $sort_key, $date='')
    {
        $table_name = $table."_".date('Y');
        if ($date) {
            $table_name = $table."_".date('Y', $date);
        }
        $table_list = $this->aws_dynamodb->listTables();
        if (in_array($table_name, $table_list)) {
            return $table_name;
        }
    }


    /**
     * 获取当前使用的表名称
     * 每个月都要创建一个新表
     * @return [type] [description]
     */
    private function get_insights_table($sort_key, $date='')
    {
        $table_name = "marketmax_reviews_insights_".date('Y');
        if ($date) {
            $table_name = "marketmax_reviews_insights_".date('Y', $date);
        }
        $table_list = $this->aws_dynamodb->listTables();
        if (in_array($table_name, $table_list)) {
            return $table_name;
        }else{
            $params = [
                'TableName' => $table_name,
                'KeySchema' => [
                    [
                        'AttributeName' => 'date',
                        'KeyType' => 'HASH'  //Partition key
                    ],
                    [
                        'AttributeName' => $sort_key,
                        'KeyType' => 'RANGE'  //Sort key
                    ]
                ],
                'AttributeDefinitions' => [
                    [
                        'AttributeName' => 'date',
                        'AttributeType' => 'N'
                    ],
                    [
                        'AttributeName' => $sort_key,
                        'AttributeType' => 'S'
                    ]
                ],
                'ProvisionedThroughput' => [
                    'ReadCapacityUnits' => 200,
                    'WriteCapacityUnits' => 50
                ]
            ];
            $data = $this->aws_dynamodb->createTable($params);
            sleep(10);
        }
        return $table_name;
    }



    /**
     * 获取当前使用的表名称
     * 每个月都要创建一个新表
     * @return [type] [description]
     */
    private function get_review_table($date='')
    {
        $table_name = "marketmax_reviews_".date('Y');
        if ($date) {
            $table_name = "marketmax_reviews_".date('Y', $date);
        }
        $table_list = $this->aws_dynamodb->listTables();
        if (in_array($table_name, $table_list)) {
            return $table_name;
        }else{
            $params = [
                'TableName' => $table_name,
                'KeySchema' => [
                    [
                        'AttributeName' => 'updated_time',
                        'KeyType' => 'HASH'  //Partition key
                    ],
                    [
                        'AttributeName' => "ad_id",
                        'KeyType' => 'RANGE'  //Sort key
                    ]
                ],
                'AttributeDefinitions' => [
                    [
                        'AttributeName' => 'updated_time',
                        'AttributeType' => 'N'
                    ],
                    [
                        'AttributeName' => "ad_id",
                        'AttributeType' => 'S'
                    ]
                ],
                'ProvisionedThroughput' => [
                    'ReadCapacityUnits' => 200,
                    'WriteCapacityUnits' => 150
                ]
            ];
            $data = $this->aws_dynamodb->createTable($params);
            sleep(10);
        }
        return $table_name;
    }


    private function ad_insights($vars, $insights)
    {
        if ($insights) {
            $data = $insights[0];

            foreach ($insights as $data) {
                $result = ['account_id'=>$vars['account_id'], 'campaign_id'=>$vars['campaign_id'], 'adset_id'=>$vars['adset_id'], 'agency_id'=>$vars['agency_id'], 'agency_name'=>$vars['agency_name']];

                $result['account_name']     = $vars['account_name'];
                $result['campaign_name']    = $vars['campaign_name'];
                $result['adset_name']       = $vars['adset_name'];
                $result['ad_name']          = $vars['name'];
                $result['ad_id']            = $vars['ad_id'];
                $result['product_id']       = $vars['product_id'];
                $result['product_name']       = $vars['product_name'];

                $result['publisher_id']       = $vars['publisher_id'];
                $result['publisher_name']       = $vars['publisher_name'];

                $result['advertiser_id']       = $vars['advertiser_id'];
                $result['advertiser_name']       = $vars['advertiser_name'];

                $fields = $this->ad_insight_model->fields;

                $result['results'] = 0;
                $result['link_clicks'] = 0;
                $result['ctr_link'] = 0;
                $result['cost'] = 0;
                $result['cvr']  = 0;
                $result['cpc_link'] = 0;
                $result['country'] = $data['country'];
                
                $result['comments'] = $result['shares'] = $result['likes'] = $result['relevance_score'] = 0;


                foreach ($data as $key => $value) {
                    if (in_array($key, $fields)) {
                        is_array($value) && $value = json_encode($value);
                        $result[$key] = $value;
                    }
                    if ($key=='actions') {
                        foreach ($value as $k => $v) {
                            if ($v['action_type'] == 'mobile_app_install') {
                                $result['results'] = $v['value'];
                            }
                            if ($v['action_type'] == 'link_click') {
                                $result['link_clicks'] = $v['value'];
                                $result['ctr_link'] = $data['impressions']>0?$v['value']/$data['impressions']*100:0;
                            }
                            if ($v['action_type'] == 'comment') {
                                $result['comments'] = $v['value'];
                            }
                            if ($v['action_type'] == 'post') {
                                $result['shares'] = $v['value'];
                            }
                            if ($v['action_type'] == 'post_like') {
                                $result['likes'] = $v['value'];
                            }
                        }
                    }
                    if ($key=='cost_per_action_type') {
                        foreach ($value as $k => $v) {
                            if ($v['action_type'] == 'mobile_app_install') {
                                $result['cost'] = $v['value'];
                            }
                            if ($v['action_type'] == 'link_click') {
                                $result['cpc_link'] = $v['value'];
                            }
                        }
                    }
                    if ($key=='relevance_score') {
                        $result['relevance_score'] = isset($value['score'])?$value['score']:0;
                    }
                }

                $result['date'] = strtotime($data['date_start']);

                $result['ad_id_country'] = $result['ad_id']."_".$result['country'];


                $table_name = $this->get_insights_table('ad_id_country', $result['date']);

                foreach ($result as $k => & $v) {
                    $v = $v?$v:' ';
                }
                if ($result['clicks']>0 && $result['results']>0) {
                    $result['cvr'] = $result['results']/$result['clicks'];
                }
                

                try{
                    $this->get_review_risk($result);
                    $this->aws_dynamodb->putItem($table_name, json_encode($result));
                }catch(Exception $e){
                    log_message('error', "aws_dynamodb:".$e->getMessage());
                }
                
            }
        }
    }

    /**
     * 获取抓取数据时所使用的token
     * @param string $value [description]
     */
    private function get_token_user($account_id)
    {
        $publisher_adaccount = $this->ad_model->get_query("select * from publisher_adaccount where publisher_id=10040 and account_id=".$account_id);
        if ($publisher_adaccount) {
            return config_item('FACEBOOK_TOKEN');
        }else{
            $other_account = $this->ad_model->get_query("select * from publisher_adaccount where account_id=".$account_id);
            if (!$other_account) {
                return "Token Invalid";
            }

            $userinfo = $this->ad_model->get_query("select * from user where user_id=".$other_account[0]['publisher_id']);
            if (!$userinfo) {
                return "Token Invalid";
            }
            return $userinfo[0]['token'];
        }
    }

    /**
     * 整合对象数据的字段
     * @param  [type] $fields [description]
     * @param  [type] $data   [description]
     * @return [type]         [description]
     */
    public function getFieldsData($fields, $data)
    {
        $return = [];
        foreach ($data as $key => $value) {
            if (in_array($key, $fields)) {
                $return[$key] = $value;
            }
        }
        return $return;
    }


    public function get_adset_data($account_id, $adset_id)
    {
        $adset_data = $this->redis->get($adset_id);
        if ($adset_data) {
            return json_decode($adset_data, true);
        }
        try{
            $value = $this->facebookapi->getAdsetData($adset_id);
            if ($value) {
                $campaign_name = $this->redis->get($value['campaign_id']);
                if (!$campaign_name) {
                    $campaign_info = $this->facebookapi->getCampaignData($value['campaign_id']);
                    if (!$campaign_info) {
                        continue;
                    }
                    $this->redis->set($campaign_info['id'], $campaign_info['name']);
                    $campaign_name = $campaign_info['name'];
                }

                $newdata['adset_id'] = intval($value['id']);
                $newdata['campaign_name'] = $campaign_name?$campaign_name:' ';
                if (!isset($value['promoted_object'])) {
                    continue;
                }
                $promoted_object = $value['promoted_object'];
                $newdata['object_store_url'] = $promoted_object['object_store_url'];
                $newdata['campaign_id'] = intval($value['campaign_id']);
                $newdata['adset_name'] = $value['name'];

                $this->redis->set($newdata['adset_id'], json_encode($newdata));

                return $newdata;
            }
            
            return [];
        }catch(Exception $e){
            fetch_exception($account_id, 'fetch_account_adset : '.$adset_id, $e->getMessage());

            log_message('error', "fetch_account_adset: ".$account_id."_".$adset_id." adset fetch faild ->".date('Y-m-d H:i:s') . " ".$e->getMessage());
        }
    }

    /**
     * 通过campaign找到对应的publisher
     * @param  [type] $campaign_name [description]
     * @return [type]                [description]
     */
    private function get_publisher_by_campaign($campaign_name)
    {
        $label = get_label_by_campaign($campaign_name);
        if ($label) {
            $publisher_info = $this->adaccount_model->get_query("select * from user where type=2 and label='".$label."'");
            if ($publisher_info) {
                $publisher_id = $publisher_info[0]['user_id'];
                $publisher_name = $publisher_info[0]['user_name'];

                return [$publisher_id, $publisher_name];
            }
        }
        return [];
    }


    public function sync_ad_data_to_redshift($publisher_info, $account_id, $data)
    {
        foreach ($data as $item) {
            $updated_time = (array)$item['updated_time'];
            $updated_time   = strtotime($updated_time['date']);

            $adset_data = $this->get_adset_data($account_id, $item['adset_id']);
            if (!$adset_data) {
                continue;
            }
            $product_info = $this->get_product_info($adset_data['object_store_url']);

            if (!$product_info) {
                continue;
            }

            // if ($item['id']!=23842521836790186) {
            //     continue;
            // }

            $agency_data = $this->publisher_adaccount_model->get_by_fields(['account_id'=>$account_id, 'publisher_type'=>2]);

            $table_name = $this->get_review_table($updated_time);
            $key = ['ad_id'=>$item['id'], 'updated_time'=>$updated_time];

            usleep(100000);//800毫秒
            $ad_info = $this->aws_dynamodb->getItem($table_name, json_encode($key));

            $vars = ['advertiser_id'=>$product_info['user_id'], 'advertiser_name'=>$product_info['user_name'], 'product_id'=>$product_info['product_id'],
                    'product_name'=>$product_info['name'], 'publisher_id'=>$publisher_info['publisher_id'], 'publisher_name'=>$publisher_info['publisher_name']];
        
            $vars['ad_id']          = $item['id'];
            $vars['name']           = $item['name'];
            $vars['adset_id']       = $adset_data['adset_id'];
            $vars['adset_name']     = $adset_data['adset_name'];
            $vars['campaign_id']    = $adset_data['campaign_id'];
            $vars['campaign_name']  = $adset_data['campaign_name'];

            $publisher_data = $this->get_publisher_by_campaign($vars['campaign_name']);
            if ($publisher_data) {
                $vars['publisher_id']   = $publisher_data[0];
                $vars['publisher_name'] = $publisher_data[1];
            }


            if ($agency_data) {
                $vars['agency_id'] = $agency_data['publisher_id'];
                $vars['agency_name'] = $agency_data['publisher_name'];

                $vars['account_id']     = $account_id;
                $vars['account_name']   = $agency_data['account_name'];
            }else{
                $vars['agency_id'] = $vars['agency_name'] = ' ';
                $account_info = $this->adaccount_model->get_by_fields(['account_id'=>$account_id]);

                $vars['account_id']     = $account_id;
                $vars['account_name']   = $account_info['name'];
            }


            $created_time = (array)$item['created_time'];
            $updated_time = (array)$item['updated_time'];

            $vars['updated_time']   = strtotime($updated_time['date']);
            $vars['created_time']   = strtotime($created_time['date']);

            if (!$item['adcreatives']) {
                continue;
            }

            $creatives = $item['adcreatives'][0];

            $vars['creatives'] = $creatives['id'];
            $vars['status'] = $item['status'];
            $vars['effective_status'] = $item['effective_status'];
            $vars['configured_status'] = $item['configured_status'];
                
            $vars['object_story_spec'] =  json_encode($creatives['object_story_spec']);
            $vars['object_story_id'] = isset($creatives['object_story_id'])?$creatives['object_story_id']:'';
            $vars['object_type'] = $creatives['object_type'];
            if ($ad_info) {
                if (isset($item['insights'])) {
                    $this->ad_insights($vars, $item['insights']);
                }
                continue;
            }


            $vars['thumbnail_url'] = $vars['org_thumbnail_url'] = $vars['video_url'] = $vars['image_url'] = $vars['org_image_url'] = $vars['more_image'] = ' ';

            //视频
            if ($vars['object_type'] == 'VIDEO') {
                if (isset($creatives['object_story_spec']['video_data'])) {
                    $vars['image_url'] = $creatives['object_story_spec']['video_data']['image_url'];
                    

                    $path = "image/" . time() . rand( 1 , 10000 ) . ".png";
                    $vars['image_url'] = str_replace("https", "http", $vars['image_url']);
                    
                    //$this->aws_sqs->deliver(['event'=>'fetch_to_s3', 'path'=>$path, 'url'=>$vars['image_url']]); 
                    $vars['org_image_url'] = $vars['image_url'];

                    $vars['image_url'] = $path;
                    
                    $vars['title'] = isset($creatives['object_story_spec']['video_data']['call_to_action']['value']['link_title'])?$creatives['object_story_spec']['video_data']['call_to_action']['value']['link_title']:'';
                    $vars['message'] = $creatives['object_story_spec']['video_data']['description'];
                
                    $video_data = $this->facebookapi->getVideo($creatives['object_story_spec']['video_data']['video_id']);
                    if ($video_data) {
                        $path = "video/" . time() . rand( 1 , 10000 ) . ".mp4";

                        $video_data['source'] = str_replace("https", "http", $video_data['source']);

                        //$this->aws_sqs->deliver(['event'=>'fetch_to_s3', 'path'=>$path, 'url'=>$video_data['source']]); 
                        $vars['video_url'] = $path;
                        $vars['org_video_url'] = $video_data['source'];
                    }
                }
            }

            if (isset($creatives['object_story_spec']['link_data'])) {
                $object_story_spec = $creatives['object_story_spec']['link_data'];
                $vars['message'] = isset($object_story_spec['message'])?$object_story_spec['message']:' ';
                isset($object_story_spec['call_to_action']['value']['link_title']) && $vars['title'] = $object_story_spec['call_to_action']['value']['link_title'];
                
                //多图
                if (isset($object_story_spec['child_attachments']) && $object_story_spec['child_attachments']) {
                    $hash = [];
                    $child_list = [];
                    foreach ($object_story_spec['child_attachments'] as $child) {
                        if (!isset($child['image_hash'])) {
                            continue;
                        }
                        $hash[] = $child['image_hash'];
                        $child_list[$child['image_hash']] = isset($child['name'])?$child['name']:'';
                        if (!isset($vars['title'])) {
                            $vars['title'] = isset($child['name'])?$child['name']:'';
                        }
                    }
                    if ($hash) {
                        $data = $this->facebookapi->getImages("act_".$vars['account_id'], $hash);
                    
                        $image_hash = [];
                        foreach ($data as $val) {
                            $image = ['name'=>$child_list[$val['hash']]];

                            $path = "image/" . time() . rand( 1 , 10000 ) . ".png";
                            $val['url'] = str_replace("https", "http", $val['url']);

                            //$this->aws_sqs->deliver(['event'=>'fetch_to_s3', 'path'=>$path, 'url'=>$val['url']]); 
                            $image['org_url'] = $val['url'];

                            $image['url'] = $path;
                            $image_hash[] = $image;
                        }
                    }
                    
                    $vars['more_image'] = json_encode($image_hash);
                    $vars['object_type'] = "MORE_SHARE";
                    if (!$image_hash) {
                        continue;
                    }
                    
                }
            }
            $width = 600;
            $height = 300;
            if ($vars['object_type'] == 'MORE_SHARE') {//600*600
                $width = $height = 600;
            }elseif ($vars['object_type'] == 'SHARE') {//1200*628
                $width = 600;
                $height = 314;
            }elseif ($vars['object_type'] == 'VIDEO') {//1200*675
                $width = 600;
                $height = 337;
            }

            
            
            if (isset($creatives['image_url'])) {
                $path = "image/" . time() . rand( 1 , 10000 ) . ".png";
                $creatives['image_url'] = str_replace("https", "http", $creatives['image_url']);
                //$this->aws_sqs->deliver(['event'=>'fetch_to_s3', 'path'=>$path, 'url'=>$creatives['image_url']]); 

                $vars['image_url'] = $path;

                $vars['org_image_url'] = $creatives['image_url'];
            }

            if (isset($creatives['thumbnail_url'])) {

                $thumbnail_url = $creatives['thumbnail_url'];

                $creatives['thumbnail_url']  = str_replace("https", "http", $creatives['thumbnail_url']); 
                $creatives['thumbnail_url']  = str_replace("w=64", "w=".$width, $creatives['thumbnail_url']); 
                $creatives['thumbnail_url']  = str_replace("h=64", "h=".$height, $creatives['thumbnail_url']); 

                $path = "image/" . time() . rand( 1 , 10000 ) . ".png";
                //$this->aws_sqs->deliver(['event'=>'fetch_to_s3', 'path'=>$path, 'url'=>$creatives['thumbnail_url']]); 

                $vars['thumbnail_url'] = $path;
                $vars['org_thumbnail_url'] = $creatives['thumbnail_url'];
            }


            foreach ($vars as $k=>& $v) {
                $v = $v?$v:' ';
            }
        
            $this->aws_dynamodb->putItem($table_name, json_encode($vars));
            
            if (isset($item['insights'])) {
                $this->ad_insights($vars, $item['insights']);
            }
        }
    }

    /**
     * 同步所有ad信息
     * @param  [type] $account_id [description]
     * @return [type]             [description]
     */
    public function sync_ad_data($account_id, $insights_start_date)
    {   
        //如果insightstable没有生成提前生成好
        $this->get_insights_table('ad_id_country', strtotime($insights_start_date));

        try{
            $publisher_info = $this->get_publisher_info($account_id);
            if (!$publisher_info) {
                return false;
            }

            list($data, $pagesEdge) = $this->facebookapi->getAccountToAds($account_id, 'country', $insights_start_date, $insights_start_date, 50);
            $this->sync_ad_data_to_redshift($publisher_info, $account_id, $data);

            while($data){
                list($data, $pagesEdge) = $this->facebookapi->getNextAccountToAds($pagesEdge);
                $data && $this->sync_ad_data_to_redshift($publisher_info, $account_id, $data);
            }
            
        }catch(Exception $e){
            fetch_exception($account_id, 'fetch_review', $e->getMessage());
            log_message('error', "queue_review_data: ".$account_id." fetch faild ->".date('Y-m-d H:i:s') . " ".$e->getMessage());
        }
    }

    /**
     * 计算出是否为警告广告
     * @param  [type] $ad_id [description]
     * @param  [type] $date  [description]
     * @return [type]        [description]
     */
    public function get_review_risk($ad_data)
    {
        $verify = $this->redshift_model->get_query("select * from marketmax_reviews_verify where ad_id='".$ad_data['ad_id']."'", false);
        if ($verify) {
            return false;//如果审核过就不计算了
        }


        $date = date('Y-m-d', $ad_data['date']);
        $config = ['ctr', 'cvr', 'clicks', 'cpi', 'roi', 'spend', 'results', 'likes', 'shares', 'comments'];
    
        $config_risk = $this->setting_model->get_all(['type'=>'risk', 'status'=>1]);
        if (!$config_risk) {
            return false;
        }

        foreach ($config_risk as $item) {
            $risk = json_decode($item['content'], true);

            $flag = false;
            foreach ($risk as $k => $v) {
                $k=='cvr' && $v=$v/100;
                if ($ad_data[$k]>=$v) {
                    $flag = true;
                }else{
                    $flag = false;
                    break;
                }
            }


            if ($flag) {
                $info = $this->redshift_model->get_query("select * from marketmax_reviews_risk where ad_id='".$ad_data['ad_id']."' and country='".$ad_data['country']."'", false);
                if ($info) {
                    $this->redshift_model->get_query("update marketmax_reviews_risk set risk='".$item['content']."', start_date=".$ad_data['date']." where ad_id='".$ad_data['ad_id']."' and country='".$ad_data['country']."'", false);
                }else{
                    $this->redshift_model->get_query("insert into marketmax_reviews_risk (ad_id, country, risk, start_date) values ('".$ad_data['ad_id']."', '".$ad_data['country']."', '".$item['content']."', ".$ad_data['date'].")", false);
                }
                break;
            }
            
        }

        return false;


        // $risk = json_decode($config_risk['content'], true);
        // $key_tmp = [];
        // $key = ['ad_id_country'=>$ad_data['ad_id_country']];

        // $flag = true;
        // if (isset($risk['rate'])) {
        //     foreach ($risk['rate'] as $k => $v) {
        //         if (!$v['enabled'] || $v['days']<=0 || $v['value']<=0) {//如果不符合条件跳过
        //             continue;
        //         }
        //         $key['date'] = strtotime("$date -".$v['days']." day");

        //         if (isset($key_tmp[md5(json_encode($key))])) {
        //             $data = $key_tmp[md5(json_encode($key))];
        //         }else{
        //             $data = $this->aws_dynamodb->getItem("marketmax_reviews_insights_".date('Y', $ad_data['date']), json_encode($key));
        //             $key_tmp[md5(json_encode($key))] = $data;
        //         }


        //         if (!$data) {//如果这一天没有数据跳过。
        //             continue;
        //         }
        //         $v_value = $v['value']/100;
        //         if ($k=='cpi') {
        //             if ($data['cost']>0 && $ad_data['cost']) {
        //                 if ($ad_data['cost']<$data['cost'] && abs($ad_data['cost']-$data['cost'])/$data['cost'] >= $v_value) {
        //                     $info = $this->redshift_model->get_query("select * from marketmax_reviews_risk where ad_id='".$ad_data['ad_id']."' and country='".$ad_data['country']."'");
        //                     if ($info) {
        //                         $this->redshift_model->get_query("update marketmax_reviews_risk set source='rate', fields='".$k."',value='".$v['value']."',last_modified_time=".$ad_data['date']." where ad_id='".$ad_data['ad_id']."' and country='".$ad_data['country']."'", false);
        //                     }else{
        //                         $this->redshift_model->get_query("insert into marketmax_reviews_risk (ad_id, country, fields, value, last_modified_time, source) values ('".$ad_data['ad_id']."', '".$ad_data['country']."', '".$k."', '".$v['value']."', ".$ad_data['date'].", 'rate')", false);
        //                     }
        //                     $flag = false;
        //                     continue;
        //                 }
        //             }
                    
        //         }else{
        //             if ($data[$k]>0) {
        //                 if ($ad_data[$k]>$data[$k] && abs($ad_data[$k]-$data[$k])/$data[$k] >= $v_value) {
        //                     $info = $this->redshift_model->get_query("select * from marketmax_reviews_risk where ad_id='".$ad_data['ad_id']."' and country='".$ad_data['country']."'");
        //                     if ($info) {
        //                         $this->redshift_model->get_query("update marketmax_reviews_risk set source='rate', fields='".$k."',value='".$v['value']."',last_modified_time=".$ad_data['date']." where ad_id='".$ad_data['ad_id']."' and country='".$ad_data['country']."'", false);
        //                     }else{
        //                         $this->redshift_model->get_query("insert into marketmax_reviews_risk (ad_id, country, fields, value, last_modified_time, source) values ('".$ad_data['ad_id']."', '".$ad_data['country']."', '".$k."', '".$v['value']."', ".$ad_data['date'].", 'rate')", false);
        //                     }
        //                     $flag = false;
        //                     continue;
        //                 }
        //             }
                    
        //         }
                
        //     }
        // }
        // if (isset($risk['abs']) && $flag) {
        //     foreach ($risk['abs'] as $k => $v) {
        //         if (!$v['enabled'] || $v['value']<=0) {//如果不符合条件跳过
        //             continue;
        //         }

        //         if ($k=='cpi') {
        //             if ($ad_data['cost'] && $ad_data['cost']<=$v['value']) {
        //                 $info = $this->redshift_model->get_query("select * from marketmax_reviews_risk where ad_id='".$ad_data['ad_id']."' and country='".$ad_data['country']."'");
        //                 if ($info) {
        //                     $this->redshift_model->get_query("update marketmax_reviews_risk set source='abs', fields='".$k."',value='".$v['value']."',last_modified_time=".$ad_data['date']." where ad_id='".$ad_data['ad_id']."' and country='".$ad_data['country']."'", false);
        //                 }else{
        //                     $this->redshift_model->get_query("insert into marketmax_reviews_risk (ad_id, country, fields, value, last_modified_time, source) values ('".$ad_data['ad_id']."', '".$ad_data['country']."', '".$k."', '".$v['value']."', ".$ad_data['date'].", 'abs')", false);
        //                 }
        //                 continue;
        //             }
                    
        //         }else{
        //             if ($ad_data[$k]>=$v['value']) {
        //                 $info = $this->redshift_model->get_query("select * from marketmax_reviews_risk where ad_id='".$ad_data['ad_id']."' and country='".$ad_data['country']."'");
        //                 if ($info) {
        //                     $this->redshift_model->get_query("update marketmax_reviews_risk set source='abs', fields='".$k."',value='".$v['value']."',last_modified_time=".$ad_data['date']." where ad_id='".$ad_data['ad_id']."' and country='".$ad_data['country']."'", false);
        //                 }else{
        //                     $this->redshift_model->get_query("insert into marketmax_reviews_risk (ad_id, country, fields, value, last_modified_time) values ('".$ad_data['ad_id']."', '".$ad_data['country']."', '".$k."', '".$v['value']."', ".$ad_data['date'].", 'abs')", false);
        //                 }
        //                 continue;
        //             }
        //         }
                
        //     }
        // }
        
    }



    /**
     * 抓取ad信息
     * @param  [type] $adset        [description]
     * @param  [type] $publisher_id [description]
     * @param  string $date         [description]
     * @return [type]               [description]
     */
    public function sync($account_id, $date)
    {
        $this->load->model('user_model');
        try{
            $token = $this->get_token_user($account_id);
            $this->load->library('facebookapi', ['token'=>$token]);

            $this->sync_ad_data($account_id, $date);
            
        }catch(Exception $e){

            fetch_exception($account_id, 'fetch_review', $e->getMessage());

            log_message('error', "queue_review_data: ".$account_id." fetch faild ->".date('Y-m-d H:i:s') . " ".$e->getMessage());
        }
    }


    /**
     * 获取当前使用的表名称
     * 每个月都要创建一个新表
     * @return [type] [description]
     */
    private function get_comment_table()
    {
        $table_name = "marketmax_comments";
        // if ($date) {
        //     $table_name = "marketmax_comments";
        // }
        $table_list = $this->aws_dynamodb->listTables();
        if (in_array($table_name, $table_list)) {
            return $table_name;
        }else{
            $params = [
                'TableName' => $table_name,
                'KeySchema' => [
                    [
                        'AttributeName' => 'comment_id',
                        'KeyType' => 'HASH'  //Partition key
                    ]
                ],
                'AttributeDefinitions' => [
                    [
                        'AttributeName' => 'comment_id',
                        'AttributeType' => 'S'
                    ]
                ],
                'ProvisionedThroughput' => [
                    'ReadCapacityUnits' => 200,
                    'WriteCapacityUnits' => 20
                ]
            ];
            $data = $this->aws_dynamodb->createTable($params);
            sleep(10);
        }
        return $table_name;
    }
 
    public function fetch_ad_comment($object_id, $account_id, $ad_id)
    {
        $this->load->model('user_model');
        $this->load->library('aws_dynamodb');

        $user_id = $this->get_token_user($account_id);
        $this->load->library('facebookapi', ['token'=>$user_id]);

        $data = $this->facebookapi->getComments($object_id);

        foreach ($data as $key => $value) {
            $value['message'] = $value['message']?$value['message']:' ';

            $fields = ['ad_id'=>$ad_id, 'created_time'=>strtotime($value['created_time']), 'message'=>$value['message']
                        , 'comment_id'=>$value['id'], 'user_name'=>$value['from']['name'], 'user_id'=>$value['from']['id'], 'featured'=>' '];
            
            $table_name = $this->get_comment_table();
            $this->aws_dynamodb->putItem($table_name, json_encode($fields));
        }
    }
}