<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Validation {

	function __construct(){
		$this->CI =& get_instance();
	}

	/*
    -----------------------------------------------------------
    功能：检查输入的是否为数字
    参数：string
    返回值：boolean
	作者：王彦庆
    -----------------------------------------------------------
    */
    function isNumber($val){
        if(preg_match("/^[0-9]+$/", $val)) return true;
			return false; 
    }
	
	/*
    -----------------------------------------------------------
    功能：检查是否为空
    参数：string
    返回值：boolean
	作者：王彦庆
    -----------------------------------------------------------
    */
    function isEmpty($val){
        if (!is_string($val))return false;
		if (empty($val)) return false;
		if ($val=='') return false;
	    return true;
    }

    /*
    -----------------------------------------------------------
    功能：检查输入的是否为固定电话
    参数：string
    返回值：boolean
	作者：王彦庆
    -----------------------------------------------------------
    */
    function isPhone($val){
        if(preg_match("/^((0\d{2,3})-)(\d{7,8})(-(\d{3,}))?$/",$val)) return true;
        return false;
    }

    /*
    -----------------------------------------------------------
    功能：检查输入的是否为手机号
	参数：string
    返回值：boolean
	作者：王彦庆
    -----------------------------------------------------------
    */
    function isMobile($val){
        if(preg_match("/^13[0-9]{1}[0-9]{8}$|15[0-9]{1}[0-9]{8}$|18[0-9][0-9]{8}$|14[57][0-9]{8}$/",$val)) return true;
        return false;
    }
    /*
    -----------------------------------------------------------
    功能：检查输入的是否为邮编
    参数：string
    返回值：boolean
	作者：王彦庆
    -----------------------------------------------------------
    */
    function isPostcode($val){
        if(preg_match("/^[0-9]{4,6}$/",$val)) return true;
        return false;
    }

    /*
    -----------------------------------------------------------
    功能：邮箱地址合法性检查
    参数：string
    返回值：boolean
	作者：王彦庆
    -----------------------------------------------------------
    */
    function isEmail($val,$domain=""){
        if(!$domain)
        {
            if( preg_match("/^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/", $val) )
            {
                return true;
            }
            else
                return false;
        }
        else
        {
            if( preg_match("/^[a-z0-9-_.]+@".$domain."$/", $val) )
            {
                return true;
            }
            else
                return false;
        }
    }//end func
	
    /*
    -----------------------------------------------------------
	功能：姓名昵称合法性检查，只能输入中文英文
    参数：string
    返回值：boolean
	作者：王彦庆
    -----------------------------------------------------------
    */
    function isName($val){
        if( preg_match("/^[\x80-\xffa-zA-Z0-9]{3,60}$/", $val) ) return true;
        return false;
    }//end func


    /*
    -----------------------------------------------------------
    功能:检查数字的字符串长度是否符合要求
    参数:(字符串，最小长度，最大长度)
	返回值:boolean
	作者：王彦庆
    -----------------------------------------------------------
    */
    function isNumLength($val, $min, $max){
        $theelement= trim($val);
        if(preg_match("/^[0-9]{".$min.",".$max."}$/",$val)) return true;
        return false;
    }

    /*
    -----------------------------------------------------------
    功能:检查字符串长度是否符合要求（下划线，英文字母，数字组成的串）
    参数:(字符串，最小长度，最大长度)
    返回值:boolean
	作者：王彦庆
    -----------------------------------------------------------
    */
    function isEngLength($val, $min, $max)
    {
        $theelement= trim($val);
        if(preg_match("/^[_a-zA-Z0-9]{".$min.",".$max."}$/",$theelement)) return true;
        return false;
    }

    /*
    -----------------------------------------------------------
    功能：检查输入是否为英文
    参数：string
    返回值：boolean
	作者：王彦庆
    -----------------------------------------------------------
    */
    function isEnglish($var){
        if( preg_match("/[\x80-\xff]./",$var) ) return false;
        return true;
    }

    /*
    -----------------------------------------------------------
    功能：检查是否输入为汉字
    参数：string
    返回值：boolean
	作者：王彦庆
    -----------------------------------------------------------
    */
    function isChinese($sInBuf){
        $iLen= strlen($sInBuf);
        for($i= 0; $i< $iLen; $i++)
        {
            if(ord($sInBuf{$i})>=0x80)
            {
                if( (ord($sInBuf{$i})>=0x81 && ord($sInBuf{$i})<=0xFE) && ((ord($sInBuf{$i+1})>=0x40 && ord($sInBuf{$i+1}) < 0x7E) || (ord($sInBuf{$i+1}) > 0x7E && ord($sInBuf{$i+1})<=0xFE)) )
                {
                    if(ord($sInBuf{$i})>0xA0 && ord($sInBuf{$i})<0xAA)
                    {
                        //有中文标点
                        return false;
                    }
                }
                else
                {
                    //有日文或其它文字
                    return false;
                }
                $i++;
            }
            else
            {
                return false;
            }
        }
        return true;
    }
	
	 /*
    -----------------------------------------------------------
    功能：检查是字符串是否在允许的范围内（并判断去除前后空格的比较）
    参数：string，min，max
    返回值：boolean
	作者：王彦庆
    -----------------------------------------------------------
    */
	function checkStringLength($str,$min,$max){
		$newStr = trim($str);
		if(strlen($str) != strlen($newStr)) return false;
		if(strlen($newStr)<$min) return false;
		if(strlen($newStr)>$max) return false;
		return true;
	}
	
	/*
    -----------------------------------------------------------
    功能：对插入的数据库的数据过滤
    参数：string或数组：如$_POST数组
    返回值：过滤后的字符串或数组
	作者：王彦庆()
    -----------------------------------------------------------
    */
	function filterSql($string) {
		$magic_quotes_gpc = get_magic_quotes_gpc();
		if(!$magic_quotes_gpc){
			if(is_array($string)) {
				foreach($string as $key => $val){					
					$string[$key] = $this->filterSql($val);
				}
			}else{
				$string = addslashes($string);
				//$string = mysql_escape_string($string);
				//$string = $this->checkSpecialString($string);
			}
		}
		return $string;
	}

	/*
    -----------------------------------------------------------
    功能：对url中整型参数的过滤
    参数：string
    返回值：成功返回过滤后的int否则返回false
	作者：王彦庆()
	注：在使用的过程中，如果返回false，则跳转到错误页面，可以用CI的show_error函数
    -----------------------------------------------------------
    */
	function checkInt($id) {      
		if (!$id) return false;
		elseif($this->sqlSpecial($id))   return false;
		elseif (!is_numeric($id)) return false;
		$id = intval($id);
		return  $id;
	}

	/*
    -----------------------------------------------------------
    功能：对url中字符串参数的过滤
    参数：string
    返回值：成功返回过滤后的string否则返回false
	作者：王彦庆()
	注：在使用的过程中，如果返回false，则跳转到错误页面，可以用CI的show_error函数
    -----------------------------------------------------------
    */
	function checkString($str) {
		if (!get_magic_quotes_gpc()) {
			$str = addslashes($str);
			$str = mysql_escape_string($str);
			$str = $this->checkSpecialString($str);
		}
		if($this->sqlSpecial($str)){
			return false;
		}else{
			return $str;
		}
	}
	
	/*
    -----------------------------------------------------------
    功能：过滤字符串中带sql的关键词
    参数：string
    返回值：bool
	作者：王彦庆()
    -----------------------------------------------------------
    */
	function sqlSpecial($str){
		$arrFilter = array('&',' ','*',',','<','>',"\r","\t","\n",'#','and','or','|','having','select','delete','update','insert','union','into','load_file','outfile');
		foreach ($arrFilter as $key=>$value){
			if (strpos($str,$value)){
				return true;
			}
		}
		return false;
	}

	/*
    -----------------------------------------------------------
    功能：转义特殊的字符串
    参数：string
    返回值：string
	作者：王彦庆()
    -----------------------------------------------------------
    */
	function checkSpecialString($str){
		$str = str_replace("_", "\_", $str);
		$str = str_replace("%", "\%", $str);
		$str = nl2br($str);
		$str = htmlspecialchars($str);
		return $str;
	}
	/*
    -----------------------------------------------------------
    功能：截取字符串
    参数：string
    返回值：string
	作者：王彦庆
    -----------------------------------------------------------
    */
   function cut_str($string, $sublen, $start = 0, $code = 'UTF-8'){
     if($code == 'UTF-8'){
        $pa =            "/[\x01-\x7f]|[\xc2-\xdf][\x80-\xbf]|\xe0[\xa0-\xbf][\x80-\xbf]|[\xe1-\xef][\x80-\xbf][\x80-\xbf]|\xf0[\x90-\xbf][\x80-\xbf][\x80-\xbf]|[\xf1-\xf7][\x80-\xbf][\x80-\xbf][\x80-\xbf]/";
        preg_match_all($pa, $string, $t_string); if(count($t_string[0]) - $start > $sublen) return join('', array_slice($t_string[0], $start, $sublen));
        return join('', array_slice($t_string[0], $start, $sublen));
     }else{
       $start = $start*2;
       $sublen = $sublen*2;
       $strlen = strlen($string);
       $tmpstr = ''; 
	   for($i=0; $i<$strlen; $i++){
		  if($i>=$start && $i<($start+$sublen)){
              if(ord(substr($string, $i, 1))>129){
                   $tmpstr.= substr($string, $i, 2);
			  }else{
                   $tmpstr.= substr($string, $i, 1);
			  }
		   }
           if(ord(substr($string, $i, 1))>129) 
		   $i++;
	   }
      return $tmpstr;
     }
    }
    function strLength($str,$charset='utf-8'){  
        if($charset=='utf-8') $str = iconv('utf-8','gb2312',$str);  
        $num = strlen($str);  
        $cnNum = 0;  
        for($i=0;$i<$num;$i++){  
            if(ord(substr($str,$i+1,1))>127){  
                $cnNum++;  
                $i++;  
            }  
        }  
        $enNum = $num-($cnNum*2);  
        $number = ($enNum/2)+$cnNum;  
        return ceil($number);  
    } 
  
    function cutstr_html($string, $sublen) {
      $string = strip_tags($string);

      $string = preg_replace ('/\n/is', '', $string);

      $string = preg_replace ('/ |　/is', '', $string);

      $string = preg_replace ('/&nbsp;/is', '', $string);

    	preg_match_all("/[\x01-\x7f]|[\xc2-\xdf][\x80-\xbf]|\xe0[\xa0-\xbf][\x80-\xbf]|[\xe1-\xef][\x80-\xbf][\x80-\xbf]|\xf0[\x90-\xbf][\x80-\xbf][\x80-\xbf]|[\xf1-\xf7][\x80-\xbf][\x80-\xbf][\x80-\xbf]/", $string, $t_string);   

      if(count($t_string[0]) - 0 > $sublen) $string = join('', array_slice($t_string[0], 0, $sublen))."…";   

      else $string = join('', array_slice($t_string[0], 0, $sublen));

    	return $string;
    }

    /**
     *    身份证
     *
     *    @param    string    $id
     *    @return   boolean
     */
    function is_idcard( $id ){
    	$id = strtoupper($id);
    	$regx = "/(^\d{15}$)|(^\d{17}([0-9]|X)$)/";
    	$arr_split = array();
    	if(!preg_match($regx, $id))
    	{
    		return FALSE;
    	}
    	if(15==strlen($id)) //检查15位
    	{
    		$regx = "/^(\d{6})+(\d{2})+(\d{2})+(\d{2})+(\d{3})$/";
     
    		@preg_match($regx, $id, $arr_split);
    		//检查生日日期是否正确
    		$dtm_birth = "19".$arr_split[2] . '/' . $arr_split[3]. '/' .$arr_split[4];
    		if(!strtotime($dtm_birth))
    		{
    			return FALSE;
    		} else {
    			return TRUE;
    		}
    	}
    	else           //检查18位
    	{
    		$regx = "/^(\d{6})+(\d{4})+(\d{2})+(\d{2})+(\d{3})([0-9]|X)$/";
    		@preg_match($regx, $id, $arr_split);
    		$dtm_birth = $arr_split[2] . '/' . $arr_split[3]. '/' .$arr_split[4];
    		if(!strtotime($dtm_birth))  //检查生日日期是否正确
    		{
    			return FALSE;
    		}
    		else
    		{
    			//检验18位身份证的校验码是否正确。
    			//校验位按照ISO 7064:1983.MOD 11-2的规定生成，X可以认为是数字10。
    			$arr_int = array(7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2);
    			$arr_ch = array('1', '0', 'X', '9', '8', '7', '6', '5', '4', '3', '2');
    			$sign = 0;
    			for ( $i = 0; $i < 17; $i++ )
    			{
    				$b = (int) $id{$i};
    				$w = $arr_int[$i];
    				$sign += $b * $w;
    			}
    			$n  = $sign % 11;
    			$val_num = $arr_ch[$n];
    			if ($val_num != substr($id,17, 1))
    			{
    				return FALSE;
    			}
    			else
    			{
    				return TRUE;
    			}
    		}
    	}
     
    }

    /**
     * 验证表单值
     */
    function checkInput($data)
    {
        if (is_array($data)) {
            foreach ($data as $key => $value) {
                if (is_array($value)) {
                    foreach ($value as $k => $v) {
                        $v = htmlspecialchars($v);
                        $data[$key][$k] = trim($v);
                    }
                }else{
                    $value = htmlspecialchars($value);
                    $data[$key] = trim($value);
                }
                
            }
            return $data;
        }
        $data = htmlspecialchars($data);
        return trim($data);
    }	  
}
?>