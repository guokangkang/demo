<?php
    
require_once __DIR__ . '/vendor/autoload.php';

use Aws\Credentials\CredentialProvider;
use Aws\DynamoDb\Exception\DynamoDbException;
use Aws\DynamoDb\Marshaler;
use Aws\Result;

/**
 * aws api
 * 产品图上传需要用美国节点，因为需要使用lambda
 * 其他上传如果不需要裁图，都直接用新加坡
 */
class Aws_dynamodb
{

    var $sdk;

    function __construct($params=[]){

        $profile = getenv('APP_ENVIRONMENT');

        $path    = APPPATH . 'config/aws_credentials.ini';

        $provider = CredentialProvider::ini($profile, $path);
        $provider = CredentialProvider::memoize($provider);

        switch ($profile) {
            case 'development':
                // $connect = [
                //     'endpoint'   => 'http://poggy-dynamodb:8000',
                //     'region'   => 'us-west-2',
                //     'version'  => 'latest',
                //     'credentials' => $provider
                // ];
                $connect = [
                    //'endpoint'   => 'http://127.0.0.1:8000',
                    'region'   => 'ap-northeast-1',
                    'version'  => 'latest',
                    'credentials' => $provider
                ];
                break;
            case 'testing':
                $connect = [
                    //'endpoint'   => 'http://127.0.0.1:8000',
                    'region'   => 'ap-northeast-1',
                    'version'  => 'latest',
                    'credentials' => $provider
                ];
                break;
            case 'production':
                $connect = [
                    'region'   => 'ap-northeast-1',
                    'version'  => 'latest',
                    'credentials' => $provider
                ];
                break;
        }  

        $this->sdk = new Aws\Sdk($connect);
    }


    /**
     * 写库
     * @param  [type] $tableName   [description]
     * @param  array  $data     [description]
     * @return [type]            200 | false
     */
    public function putItem($tableName, $data)
    {
        $dynamodb = $this->sdk->createDynamoDb();

        $marshaler = new Marshaler();

        $item = $marshaler->marshalJson($data);
        $params = [
            'TableName' => $tableName,
            'Item' => $item
        ];

        try {
            $result = $dynamodb->putItem($params);
            $result = $result->toArray();
        } catch (DynamoDbException $e) {
            log_message("error", "Aws put item message : ".$e->getMessage());
            log_message("error", "Aws put item error type : ".$e->getAwsErrorType());
            log_message("error", "Aws put item response : ".$e->getResponse());
            log_message("error", "Aws put item status code : ".$e->getStatusCode());
            log_message("error", "Aws put item error code : ".$e->getAwsErrorCode());
        }
        return isset($result['@metadata']['statusCode'])?$result['@metadata']['statusCode']:false;
    } 


    /**
     * 更新库
     * @param  [type] $tableName [description]
     * @param  [type] $query     [description]
     * @param  [type] $data      [description]
     * @param  [type] $key      [description]
     * @return [type]            200 | false
     */
    public function updateItem($tableName, $key, $data, $query)
    {
        $dynamodb = $this->sdk->createDynamoDb();
        $marshaler = new Marshaler();

        $key = $marshaler->marshalJson($key);

        $eav = $marshaler->marshalJson($data);

        $params = [
            'TableName' => $tableName,
            'Key' => $key,
            'UpdateExpression' => $query,
            'ExpressionAttributeValues'=> $eav,
            'ReturnValues' => 'UPDATED_NEW'
        ];

        try {
            $result = $dynamodb->updateItem($params);
            $result = $result->toArray();
        } catch (DynamoDbException $e) {
            echo $e->getMessage() . "\n";
            die();
        }
        return isset($result['@metadata']['statusCode'])?$result['@metadata']['statusCode']:false;
    }

    /**
     * 获取记录
     * @param  string $value [description]
     * @return [type]        [description]
     */
    public function getItem($tableName, $key)
    {
        $dynamodb = $this->sdk->createDynamoDb();
        $marshaler = new Marshaler();

        $key = $marshaler->marshalJson($key);

        $params = [
            'TableName' => $tableName,
            'Key' => $key
        ];

        try {
            $result = $dynamodb->getItem($params);
            if (isset($result["Item"])) {
                $data = $marshaler->unmarshalJson($result["Item"]);
                return json_decode($data, true);
            }
        } catch (DynamoDbException $e) {
            echo $e->getMessage() . "\n";
            die();
        }
        return [];
    }

    /**
     * 创建表结构
     * @param  [type] $params [description]
     * @return [type]         [description]
     */
    public function createTable($params)
    {
        $dynamodb = $this->sdk->createDynamoDb();

        try {
            $result = $dynamodb->createTable($params);
        } catch (DynamoDbException $e) {
            echo $e->getMessage() . "\n";
            die();
        }
        return $result;
    }


    public function listTables()
    {
        $dynamodb = $this->sdk->createDynamoDb();

        try {
            $result = $dynamodb->listTables();
            $result = $result->toArray();
        } catch (DynamoDbException $e) {
            echo $e->getMessage() . "\n";
            die();
        }
        return $result['TableNames'];
    }

    /**
     *  删除表结构
     * @param  [type] $params [description]
     * @return [type]         [description]
     */
    public function deleteTable($tableName)
    {
        $dynamodb = $this->sdk->createDynamoDb();

        $params = [
            'TableName' => $tableName
        ];
        try {
            $result = $dynamodb->deleteTable($params);
        } catch (DynamoDbException $e) {
            echo $e->getMessage() . "\n";
            die();
        }
        return $result;
    }


    /**
     * 删除数据
     * @param  string $value [description]
     * @return [type]        [description]
     */
    public function deleteItem($tableName, $key)
    {
        $dynamodb = $this->sdk->createDynamoDb();
        $params = [
            'TableName' => $tableName,
            'Key' => $key
        ];
        try {
            $result = $dynamodb->deleteItem ($params);
        } catch (DynamoDbException $e) {
            echo $e->getMessage() . "\n";
            die();
        }
        return $result;
    }


    /**
     * 删除数据
     * @param  string $value [description]
     * @return [type]        [description]
     */
    public function describeTable($tableName)
    {
        $dynamodb = $this->sdk->createDynamoDb();
        $params = [
            'TableName' => $tableName
        ];
        try {
            $result = $dynamodb->describeTable ($params);
        } catch (DynamoDbException $e) {
            echo $e->getMessage() . "\n";
            die();
        }
        return $result;
    }

    public function scan($tableName, $key, $val, $limit=10)
    {
        $dynamodb = $this->sdk->createDynamoDb();
        $marshaler = new Marshaler();

        $result = $dynamodb->scan([
                'TableName' => $tableName,
                //'ProjectionExpression' => 'date,adset_id_country',
                'ExpressionAttributeValues' => $key ,
                'FilterExpression' => $val,
                'limit' => $limit
        ]);
        $data = [];
        try {
            if (isset($result["Items"])) {
                foreach ($result["Items"] as $value) {
                    $tmp = $marshaler->unmarshalJson($value);
                    $data[] = json_decode($tmp, true);
                }
            }
        } catch (DynamoDbException $e) {
            echo $e->getMessage() . "\n";
            die();
        }
        return $data;
    }
}