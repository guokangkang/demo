<?php defined('BASEPATH') OR exit('No direct script access allowed');

require_once __DIR__ . '/vendor/autoload.php';
use Aws\Sqs\SqsClient;
use Aws\Credentials\CredentialProvider;

/**
 * 操作 Aws SQS 消息库
 *
 * @package         CodeIgniter
 * @subpackage      Libraries
 * @category        Libraries
 */
class Aws_sqs {

    protected $_ci;  

    function __construct()
    {
        $this->_ci = & get_instance();
        log_message('debug', 'Library loaded: aws_sqs');
    }

    //接收AWS SQS Message
    public function receive()
    {
        if( ! IS_POST ) {
            log_message('debug', 'AWS SQS Message: direct script access unallowed');
            $this->_ci->load->helper('common');
            show_error('No direct script access allowed',403);
        }
        log_message('debug', 'AWS SQS Message: start receiving message');

        $raw_request_values = file_get_contents('php://input');
        return $raw_request_values;
    }


    //发送AWS SQS Message
    public function deliver($message)
    {
        log_message('debug', 'AWS SQS Message: start sending message');

        $profile = 'default';
        $path = APPPATH . 'config/aws_credentials.ini';

        $provider = CredentialProvider::ini($profile, $path);
        $provider = CredentialProvider::memoize($provider);

        // Create a client that uses the us-west-1 region
        $sqs_client = SqsClient::factory(array(
            'credentials' => $provider,
            'region' => 'ap-northeast-1',
            'version' => 'latest'
        ));

        $query = $sqs_client->getQueueUrl(array('QueueName' => config_item('AWS_SQS_NAME') ));
        $queue_url = $query->get('QueueUrl');

        $MessageBody = json_encode($message);
        try{
            $result = $sqs_client->sendMessage(array(
                'QueueUrl' => $queue_url,
                'MessageBody' => $MessageBody,
                'DelaySeconds' => isset($message['delay'])?$message['delay']:0
            ));

            log_message('debug', 'AWS SQS Message: message body :' . $MessageBody);
            log_message('debug', 'AWS SQS Message: message was sent successfully.');
            return $result;
        }catch (Exception $e){
            log_message('error', 'AWS SQS Message: '. $e->getMessage());
            return $e->getMessage();
        }

    }


}