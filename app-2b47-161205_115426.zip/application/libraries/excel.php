<?php

/**
 * Created by PhpStorm.
 * User: palmax
 * Date: 2016/9/26
 * Time: 18:17
 */
require_once __DIR__ . '/excel/PHPExcel.php';

class Excel
{
    protected $_ci;
    private $_excel;

    public function __construct()
    {
        $this->_ci=&get_instance();
        $this->_excel=new PHPExcel();
        PHPExcel_Settings::setZipClass(PHPExcel_Settings::PCLZIP);
    }

    /**
     * @param string $name sheet 名称
     * @param array $head 列名称
     * @param $data 每列对应数据
     * @param $file_name   文件名称
     * @return mixed
     */
    public function get_excel($name='comments', $head=['UserId', 'UserName', 'FBlink'], $data, $file_name)
    {
        $letter=array('A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z');
        //设置lie名称['A1'=>'序号']
        $lie=[];
        //$this->_excel->setActiveSheetIndex(1);
        //$sheet=$this->_excel->getActiveSheet(0);
        foreach ($head as $k=>$item) {
            $lie[]=$letter[$k];
            $this->_excel->setActiveSheetIndex(0)->setCellValue($letter[$k] . '1', $item);
        }
        //写入数据
        foreach ($data as $k=>$item) {
            $k=$k + 2;
            for ($i=0; $i <= count($lie) - 1; $i++) {
                $reuslt=array_values($item);
                $this->_excel->getActiveSheet()->setCellValue($lie[$i] . $k, $reuslt[$i]);
            }
        }
        //die;
        //设置sheet名称
        $this->_excel->getActiveSheet()->setTitle($name);
        header("Content-type:application/vnd.ms-excel;");
        header("Content-Disposition:attachment;filename=Retention_" . $file_name);
        ob_end_clean();
        $objWriter=PHPExcel_IOFactory::createWriter($this->_excel, 'Excel5');
        return $objWriter->save('php://output');
    }
}