<?php

/**
 * Created by PhpStorm.
 * User: palmax
 * Date: 2016/9/19
 * Time: 11:16
 */
class Offer_service
{
    protected $_ci;

    public function __construct()
    {
        $this->_ci=&get_instance();
        $this->_ci->load->model('offer_model');
        $this->_ci->load->model('product_model');
        $this->_ci->load->model('offer_rpa_log_model');
        $this->_ci->load->config('country');
    }

    /**
     * @param $where
     * @return mixed
     */
    public function get_offers($where)
    {
        return $this->_ci->offer_model->get_data('*', $where, 0, 0);
    }


    /**
     * 处理数据
     * @param $data
     * @return array
     */
    public function do_offer_data($data, $user_id)
    {
        $results=[];
        if ($data) {
            $countries=config_item('country')['country'];
            foreach ($data as $key=>$value) {
                list($schedule, $current)=$this->_ci->offer_model->get_payouts($value['offer_id']);
                if (!$current) {
                    continue; //没有设置cpa价格
                }
                $value['specific_payout']=$this->_ci->offer_model->get_current_specific_payout($value['offer_id'], $user_id);
                $value['status']=$this->_ci->offer_model->get_offer_current_status($value['offer_id']);
                $value['next_status']=$this->_ci->offer_model->get_offer_next_status($value['offer_id']);
                $value['cap']=$this->do_cap_logs($value['offer_id']);
                if ($value['status'] == -1) {
                    continue; //处于删除状态
                }
                $value['schedules']=$schedule;
                $value['current']=$current;
                $value['country_size']=0;
                $value['country_info']=[];
                $value['countries_info']=[];
                list($value['choose_type'], $value['countries'])=$this->_ci->offer_model->get_current_country_log($value);
                if ($value['countries']) {
                    $value['country_size']=count($value['countries']);
                    foreach ($value['countries'] as $c) {
                        $value['countries_info'][]=[$c, array_key_exists($c, $countries)?$countries[$c]:''];
                        $value['country_info'][$c]=isset($country_list['country'][$c])?$country_list['country'][$c]:"Unknow";
                    }
                }
                $value['start_time']=date('m/d/Y h:i A', $value['start_time']);
                $value['end_time'] && $value['end_time']=date('m/d/Y h:i A', $value['end_time']);
                $results[]=$value;
            }
        }
        return $results;
    }

    /**
     * 根据产品获取产品进货价
     * @param $where
     * @return mixed
     */
    public function get_offer_rpa_logs($where)
    {
        $group='offer_id';
        $order=['start_time', 'desc'];
        return $this->_ci->offer_rpa_log_model->get_data('*', $where, 0, 0, '', $group, $order);
    }

    /**
     * 处理rpa_logs数据
     * @param $data
     * @return array
     */
    public function do_rpa_logs($data)
    {
        $countries=[];
        if ($data) {
            foreach ($data as $key=>$val) {
                if ($val['country']) {
                    $country=json_decode($val['country'], true);
                    $country['countries'] && $countries=array_merge($country['countries'], $countries);
                }
            }
        }
        return $countries;
    }

    /**
     * 处理cap日志
     * @param $offer_id
     * @param string $start_time
     * @return string
     */
    public function do_cap_logs($offer_id, $start_time='')
    {
        $data=$this->_ci->offer_model->get_current_cap_log($offer_id, $start_time);
        return $data?$data[0]['cap']:'';
    }
}