<?php
require __DIR__ . '/simple_html_dom.php';

/**
 * Created by PhpStorm.
 * User: palmax
 * Date: 2016/5/3
 * Time: 10:30
 */
class playUp
{
    public static function reviewscheck($package, $lang)
    {
        header('Content-Type: application/json; charset=utf-8');
        $header []="Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8";
        $header []="Content-Type: application/x-www-form-urlencoded;charset=utf-8";
        $header []="Host: play.google.com";
        $header []="Pragma: no-cache";
        $header []="Referer: https://play.google.com/store/apps/details?id=" . $package;
        $user_agent='User-Agent: Mozilla/5.0 (Windows NT 6.1; WOW64; rv:25.0) Gecko/20100101 Firefox/25.0';
        $ch=curl_init("https://play.google.com/store/getreviews?authuser=0");
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        curl_setopt($ch, CURLOPT_USERAGENT, $user_agent);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, "reviewType=0&pageNum=0&id=" . $package . "&reviewSortOrder=0&token=1&xhr=1&hl=" . $lang);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $return=curl_exec($ch);
        curl_close($ch);
        preg_match("/\"ecr\",[0-9],\"(.*)\",0/", $return, $data);

        $yorumlar=str_replace('\"', '', preg_replace_callback('/\\\\u([0-9a-f]{4})/i', function ($match) {
            return mb_convert_encoding(pack('H*', $match[1]), 'UTF-8', 'UCS-2BE');
        }, $data[1]));
        $html=str_get_html($yorumlar);
        $reviews=array();
        foreach ($html->find('.single-review') AS $veri) {
            $tekilyorum=str_get_html($veri);
            $kullaniciID=explode("?id=", $tekilyorum->find('a', 0)->href)[1];
            $kullaniciAdi=strip_tags($tekilyorum->find('.author-name', 0));
            $title=strip_tags($tekilyorum->find('.review-title', 0));
            $yorum=strip_tags(explode("<div class", explode("</span>", $tekilyorum->find('.review-body', 0))[1])[0]);
            $yildiz=explode("%;>", explode('width:', $tekilyorum->find('.current-rating', 0))[1])[0];
            if ($yildiz <= 100 && $yildiz >= 80)
                $yildiz=5;
            else if ($yildiz < 80 && $yildiz >= 60)
                $yildiz=4;
            else if ($yildiz < 60 && $yildiz >= 40)
                $yildiz=3;
            else if ($yildiz < 40 && $yildiz >= 20)
                $yildiz=2;
            else if ($yildiz < 20 && $yildiz >= 0)
                $yildiz=1;
            $reviews[]=array(
                "userID"=>trim($kullaniciID),
                "userName"=>trim($kullaniciAdi),
                "title"=>trim($title),
                "content"=>trim($yorum),
                "star"=>trim($yildiz)
            );

        }

        echo json_encode(array("status"=>1, "data"=>$reviews));
        exit;

    }

    public static function packagecheck($package, $lang)
    {

        header('Content-Type: application/json; charset=utf-8');
        $header []="Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8";
        $header []="Content-Type: application/x-www-form-urlencoded;charset=utf-8";
        $header []="Host: play.google.com";
        $header []="Pragma: no-cache";
        $header []="Referer: https://play.google.com/store/apps/details?id=" . $package . "&authuser=0&hl=tr";
        $user_agent='User-Agent: Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36';
        $ch=curl_init("https://play.google.com/store/apps/details?id=" . $package . "&authuser=0&hl=" . $lang);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        curl_setopt($ch, CURLOPT_USERAGENT, $user_agent);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $return=curl_exec($ch);
        curl_close($ch);
        $html=str_get_html($return);
        if ($html && !strpos(trim(strip_tags($html->find('.rounded', 0))), 'not found')) {
            $title=trim(strip_tags($html->find('.id-app-title', 0)));
            $total_count=trim(strip_tags($html->find('.rating-count', 0)));

            $resim=trim($html->find('.cover-image', 0)->src);
            if (strpos($resim, "https")===false) {
                $resim="https:" . trim($html->find('.cover-image', 0)->src);
            }
            
            $yapimci=trim(strip_tags($html->find('.left-info .primary', 0)));
            $kategori=trim(strip_tags($html->find('.left-info .category', 0)));
            $puanverentoplam=trim(strip_tags($html->find('.right-info .rating-count', 0)));
            $download=@trim(strip_tags($html->find('.details-section-contents .meta-info .content', 2)));
            $aciklama=@trim(strip_tags($html->find('.details-section-contents .show-more-content', 0)));
            $yildiz=@trim(explode("%;", explode('width:', @$html->find('.current-rating', 0))[1])[0]);
            $score=strip_tags($html->find('.score-container .score', 0));
            $score_info=[
                1=>strip_tags($html->find('.rating-bar-container .bar-number', 4)),
                2=>strip_tags($html->find('.rating-bar-container .bar-number', 3)),
                3=>strip_tags($html->find('.rating-bar-container .bar-number', 2)),
                4=>strip_tags($html->find('.rating-bar-container .bar-number', 1)),
                5=>strip_tags($html->find('.rating-bar-container .bar-number', 0)),
                'total_count'=>$total_count
            ];
            if ($yildiz <= 100 && $yildiz >= 80)
                $yildiz=5;
            else if ($yildiz < 80 && $yildiz >= 60)
                $yildiz=4;
            else if ($yildiz < 60 && $yildiz >= 40)
                $yildiz=3;
            else if ($yildiz < 40 && $yildiz >= 20)
                $yildiz=2;
            else if ($yildiz < 20 && $yildiz >= 0)
                $yildiz=1;

            $uygulama=array(
                "name"=>$title,
                "image"=>$resim,
                "developer"=>$yapimci,
                "category"=>$kategori,
                "star"=>$yildiz,
                "ratingCount"=>$puanverentoplam,
                "downloadCount"=>$download,
                "description"=>$aciklama,
                'score'=>$score,
                'score_info'=>$score_info
            );
            if ($uygulama) {
                return array('status'=>1, 'data'=>$uygulama);
            } else {
                return array('status'=>-1, 'data'=>'');
            }
        } else {
            return array('status'=>-1, 'data'=>'');
        }
    }

    public static function getPackage($package)
    {
        $times=1462348173492 + rand(0, 1000);
        $nums=rand(1000, 9999);
        $randNums=rand(1000000, 9999999);
        $rstr=$nums . '(';
        $url="https://www.googleapis.com/customsearch/v1element?key=AIzaSyCVAXiUzRYsML1Pv6RwSG1gunmMikTzQqY&rsz=filtered_cse&num=1&hl=en&prettyPrint=false&source=gcsc&gss=.com&sig=3aa157001604e3bc243e85b7344d5d15&cx=003180294307280873360:dqesv8pm9qu&q={$package}&sort=&googlehost=www.google.com&oq={$package}&gs_l=partner.12...{$randNums}.{$randNums}.2.{$randNums}.5.4.1.0.0.0.542.1533.2-1j2j0j1.4.0.gsnos%2Cn%3D13...0.64383j2151636579j7..1ac.1j4.25.partner..7.0.0.paCgQQzG4WM&callback=google.search.Search.apiary{$nums}&nocache={$times}";
        $header []="accept:text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8";
        $header []="Content-Type: text/javascript; charset=UTF-8";
        $header []="Referer: https://cse.google.com/cse/publicurl?cx=003180294307280873360:dqesv8pm9qu";
        $header []="accept-language:en-US,en;q=0.8";
        $header []="x-client-data:CKq1yQEIlrbJAQijtskBCMG2yQEIs5TKAQj9lcoBCOCYygE=";
        $user_agent='User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.94 Safari/537.36';
        $ch=curl_init($url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        curl_setopt($ch, CURLOPT_USERAGENT, $user_agent);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $data=curl_exec($ch);
        curl_close($ch);
        $data=trim(trim(substr($data, strpos($data, $rstr) + 5), ');'));
        $data=json_decode($data);
        $data=$data->results;
        $data=$data[0];
        $data=$data->richSnippet->mobileapplication;
        return $data;
    }
}
