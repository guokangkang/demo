<?php

/**
 * Created by PhpStorm.
 * User: palmax
 * Date: 2016/9/22
 * Time: 17:11
 */
require __DIR__ . '/simple_html_dom.php';

class store
{

    /**
     * 获取google play 数据
     * @param $html
     * @return array
     */
    public function get_google_play($html)
    {
        $uygulama=[];
        $html=str_get_html($html);
        if ($html && !strpos(trim(strip_tags($html->find('.rounded', 0))), 'not found')) {
            $title=trim(strip_tags($html->find('.id-app-title', 0)));
            $total_count=trim(strip_tags($html->find('.rating-count', 0)));
            $resim="https:" . trim($html->find('.cover-image', 0)->src);
            $yapimci=trim(strip_tags($html->find('.left-info .primary', 0)));
            $kategori=trim(strip_tags($html->find('.left-info .category', 0)));
            $puanverentoplam=trim(strip_tags($html->find('.right-info .rating-count', 0)));
            $download=@trim(strip_tags($html->find('.details-section-contents .meta-info .content', 2)));
            $aciklama=@trim(strip_tags($html->find('.details-section-contents .show-more-content', 0)));
            $yildiz=@trim(explode("%;", explode('width:', @$html->find('.current-rating', 0))[1])[0]);
            $score=strip_tags($html->find('.score-container .score', 0));
            $score_info=[
                1=>strip_tags($html->find('.rating-bar-container .bar-number', 4)),
                2=>strip_tags($html->find('.rating-bar-container .bar-number', 3)),
                3=>strip_tags($html->find('.rating-bar-container .bar-number', 2)),
                4=>strip_tags($html->find('.rating-bar-container .bar-number', 1)),
                5=>strip_tags($html->find('.rating-bar-container .bar-number', 0)),
                'total_count'=>$total_count
            ];
            if ($yildiz <= 100 && $yildiz >= 80)
                $yildiz=5;
            else if ($yildiz < 80 && $yildiz >= 60)
                $yildiz=4;
            else if ($yildiz < 60 && $yildiz >= 40)
                $yildiz=3;
            else if ($yildiz < 40 && $yildiz >= 20)
                $yildiz=2;
            else if ($yildiz < 20 && $yildiz >= 0)
                $yildiz=1;
            $uygulama=array(
                "name"=>$title,
                "image"=>$resim,
                "developer"=>$yapimci,
                "category"=>$kategori,
                "star"=>$yildiz,
                "ratingCount"=>$puanverentoplam,
                "downloadCount"=>$download,
                "description"=>$aciklama,
                'score'=>$score,
                'score_info'=>$score_info
            );
            if ($uygulama) {
                return $uygulama;
            }
        } else {
            return $uygulama;
        }
    }
}