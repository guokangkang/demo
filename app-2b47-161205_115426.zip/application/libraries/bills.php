<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Bills
{
    protected $_ci;

    function __construct()
    {
        $this->_ci= &get_instance();
        log_message('debug', 'Library loaded: bills');

        $this->_ci->load->model('reports_model');
        $this->_ci->load->model('product_model');
        $this->_ci->load->model('bills_model');
        $this->_ci->load->model('user_model');
    }

    /**
     * date
     * user_id
     * user_type
     * product_id
     * product_name
     * amount
     * results
     */

    /**
     * publisher bill
     * @param  [type] $publisher_id [description]
     * @param  [type] $date         [description]
     * @return [type]               [description]
     */
    public function add_bill($user_id, $date, $data)
    {
        foreach ($data as $item) {
            $info=$this->_ci->product_model->get_by_id($item['product_id']);
            if (!$info) {
                continue;
            }
            $bill_info=$this->_ci->bills_model->get_by_fields(['user_id'=>$user_id, 'date'=>strtotime($date), 'product_id'=>$item['product_id']]);
            $vars['product_category']=$info['category'];
            $vars['product_id']=$item['product_id'];
            $vars['product_name']=$item['product_name'];

            $vars['user_id']=$user_id;
            $vars['results']=$item['results'];
            $vars['date']=strtotime($date);
            $vars['amount']=$item['earning'] - $item['spend'];

            $user_info=$this->_ci->user_model->get_by_id($user_id);
            $vars['user_name']=$user_info['user_name'];
            $vars['user_type']=$user_info['type'];

            if ($bill_info) {
                $this->_ci->bills_model->update_row_by_id($bill_info['bill_id'], $vars);
            } else {
                $this->_ci->bills_model->add_one($vars);
            }
        }
    }


    public function sync($user_id, $user_type, $date)
    {
        try {
            $sql="select sum(results) as results,sum(expect_revenue) as earning,sum(real_earning) as real_earning,product_id,product_name,sum(spend) as spend from marketmax_reports";
            if ($user_type == 1) {
                $sql.=" where advertiser_id=" . $user_id;
            } else {
                $sql.=" where publisher_id=" . $user_id;
            }
            $sql.=" and date=" . strtotime($date);
            $sql.=" group by product_id,product_name";
            $data=$this->_ci->reports_model->get_report_data($sql);
            $this->add_bill($user_id, $date, $data);
            log_message('info','success');
        } catch (Exception $e) {
            log_message('error',$e->getMessage());
        }

    }
}