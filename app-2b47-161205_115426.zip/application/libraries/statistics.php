<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
    
class Statistics
{


    function __construct($params=[]){

        $this->_ci = &get_instance();

        $this->_ci->load->model('ad_model');
        $this->_ci->load->model('publisher_adaccount_model');
        $this->_ci->load->model('ad_statistics_extend_model');
    }

    public function sync()
    {
        $time = strtotime(date('Y-m-d'));

        $sql = "SELECT * FROM publisher_adaccount
                GROUP BY account_id";
        $list = $this->_ci->ad_model->get_query($sql);

        $data = [];
        $advertiser_id = $advertiser_name=  "";
        foreach ($list as $item) {
            
            $sql = "select * from ad where account_id=".$item['account_id']." and is_new=1";
            $ad_list = $this->_ci->ad_model->get_query($sql);

            $data = [];
            foreach ($ad_list as $row) {
                $advertiser_id = $row['advertiser_id'];
                $advertiser_name = $row['advertiser_name'];
                $data['adset_count'][$row['adset_id']] = $row['adset_id'];
                $data['ad_count'][$row['ad_id']] = $row['ad_id'];
                $data['campaign_count'][$row['campaign_id']] = $row['campaign_id'];
            
                if ($row['verify']==0) {
                    if (isset($data['pending_count'])) {
                        $data['pending_count'] += 1;
                    }else{
                        $data['pending_count'] = 1;
                    } 
                }elseif ($row['verify']==1) {
                    if (isset($data['approved_count'])) {
                        $data['approved_count'] += 1;
                    }else{
                        $data['approved_count'] = 1;
                    } 
                }elseif ($row['verify']==2) {
                    if (isset($data['suspected_count'])) {
                        $data['suspected_count'] += 1;
                    }else{
                        $data['suspected_count'] = 1;
                    } 
                }elseif ($row['verify']==3) {
                    if (isset($data['illegal_count'])) {
                        $data['illegal_count'] += 1;
                    }else{
                        $data['illegal_count'] = 1;
                    } 
                }

                if ($row['object_type']=='SHARE') {
                    if (isset($data['image_count'])) {
                        $data['image_count'] += 1;
                    }else{
                        $data['image_count'] = 1;
                    } 
                }elseif ($row['object_type']=='MORE_SHARE') {
                    if (isset($data['carousel_count'])) {
                        $data['carousel_count'] += 1;
                    }else{
                        $data['carousel_count'] = 1;
                    } 
                }elseif ($row['object_type']=='VIDEO') {
                    if (isset($data['video_count'])) {
                        $data['video_count'] += 1;
                    }else{
                        $data['video_count'] = 1;
                    } 
                }
            }
            if (!$data) {
                continue;
            }

            $vars = $this->_ci->ad_statistics_extend_model->get_by_fields(['account_id'=>$item['account_id']]);
            
            $vars['video_count'] = isset($data['video_count']) ? $data['video_count'] : 0;
            $vars['carousel_count'] = isset($data['carousel_count']) ? $data['carousel_count'] : 0;
            $vars['image_count'] = isset($data['image_count']) ? $data['image_count'] : 0;
            $vars['suspected_count'] = isset($data['suspected_count']) ? $data['suspected_count'] : 0;
            $vars['illegal_count'] = isset($data['illegal_count']) ? $data['illegal_count'] : 0;
            $vars['approved_count'] = isset($data['approved_count']) ? $data['approved_count'] : 0;
            $vars['pending_count'] = isset($data['pending_count']) ? $data['pending_count'] : 0;
            $vars['ad_count'] = count($data['ad_count']);
            $vars['adset_count'] = count($data['adset_count']);
            $vars['campaign_count'] = count($data['campaign_count']);

            if ($vars) {
                $this->_ci->ad_statistics_extend_model->update_row_by_fields(['account_id'=>$item['account_id']], $vars);
            }else{
                
                $vars['account_id'] = $item['account_id'];
                $vars['account_name'] = $item['account_name'];
                $vars['advertiser_id'] = $advertiser_id;
                $vars['advertiser_name'] = $advertiser_name;

                $agency_info = $this->_ci->publisher_adaccount_model->get_by_fields(['account_id'=>$item['account_id'], 'publisher_type'=>2]);
                if ($agency_info) {
                    $vars['agency_id'] = $agency_info['publisher_id'];
                    $vars['agency_name'] = $agency_info['publisher_name'];
                    $this->_ci->ad_statistics_extend_model->add_one($vars);
                }
                
            }
        }
    }
}