<?php

/**
 * Created by PhpStorm.
 * User: palmax
 * Date: 2016/9/22
 * Time: 17:08
 */
require __DIR__ . '/ggpaly/store.php';

class Store_api
{
    protected $_ci;

    public function __construct()
    {
        $this->_ci=&get_instance();
        $this->_ci->load->library('http');
    }

    /**
     * 获取苹果应用的数据
     * @param $package_name app名称
     * @return array
     */
    public function get_apple($package_name)
    {
        $url='http://itunes.apple.com/lookup?id=' . $package_name;
        $result=$this->_ci->http->request('get', $url);
        $result=json_decode($result, true);
        //'score'=>$tmp['averageUserRating'], 'score_info'=>[$tmp['userRatingCount']]
        $tmp=$result['results']?$result['results'][0]:[];
        $data = [];
        if($tmp&&array_key_exists('averageUserRating',$tmp)&&array_key_exists('userRatingCount',$tmp)){
            $data=['score'=>$tmp['averageUserRating'], 'score_info'=>$tmp['userRatingCount']];
        }
        return $data;
    }

    /**
     * 获取谷歌应用的信息
     * @param $obj_url
     * @return array
     */
    public function get_play($obj_url)
    {
        $obj_url = trim($obj_url);
        $result=$this->_ci->http->request('get', $obj_url);
        $store=new store();
        $data=$store->get_google_play($result);
        if($data&&array_key_exists('score',$data)&&array_key_exists('score_info',$data)){
            $data=['score'=>$data['score'], 'score_info'=>json_encode($data['score_info'])];
        }
        return $data;
    }
}