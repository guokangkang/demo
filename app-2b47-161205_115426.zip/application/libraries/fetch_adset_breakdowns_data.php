<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Fetch_adset_breakdowns_data extends CI_Controller {

    //数据更新间隔时间
    var $_synctime = 3600;//一个小时

    var $insight_fileds =  ['date_start', 'date_stop', 'impressions', 'website_clicks', 'ctr', 'cpm', 'cpp', 'website_ctr', 'comment', 'link_click', 'post_like', 'mobile_app_install'];

    var $adset_fields = [
            'account_id',
            'campaign_id',
            'name',
            'objective',
            'status',
            'buying_type',//竞价方式
            'created_time',
            'start_time',
            'offer_name',
            'budget_remaining',
            'daily_budget',
            'billing_event'
    ];
 
    var $fields = [
            'account_id',
            'market_account_id',
            'campaign_id',
            'market_campaign_id',
            'date_start',
            'date_stop',
            'results',
            'spend',
            'reach',
            'frequency',
            'cost',
            'spend',
            'clicks',
            'ctr',
            'cpc',
            'impressions',
            'cpm',
            'link_clicks',
            'cpc_link',
            'ctr_link',
            'country'
    ];
    var $_ci;
    /**
    * 初使化
    */ 
    public function __construct()
    {
        parent::__construct(); 

        $this->_ci = &get_instance();
        // 加载其他类库，可以是自定义类库，也可以是ci类库
        // 其他加载模型，helper都可以这样

        $this->_ci->load->model('offer_model');

        $this->_ci->load->library('aws_dynamodb');

        $this->_ci->load->library('facebookapi');

        $this->_ci->load->library('aws_sqs');

    }
    
    /**
     * 整合对象数据的字段
     * @param  [type] $fields [description]
     * @param  [type] $data   [description]
     * @return [type]         [description]
     */
    public function getFieldsData($fields, $data)
    {
        $return = [];
        foreach ($data as $key => $value) {
            if (in_array($key, $fields)) {
                $return[$key] = $value;
            }
        }
        //$return['backup'] = json_encode($data);
        return $return;
    }



    /**
     * 同步campaign
     * @param [type] $market_adaccount_id [adaccount 主键id]
     * @param [type] $account_id          [adaccount 元数据id]
     */
    public function setCampaign($publisher_id, $account_id, $date)
    {
        try{
            $result = $this->_ci->facebookapi->accountToCampaigns($account_id);
            if(!$result)
                return false;
            foreach ($result as $key => $value) {
                //$campaign = ['campaign_id'=>$value['id'], 'campaign_name'=>$value['name']];
                $this->redis->set($value['id'], $value['name']);
            }
        }catch(Exception $e){
            fetch_exception($account_id, 'fetch_account', $e->getMessage(), $date);
            log_message('error', "queue_adset_data: ".$account_id." campaign fetch faild ->".date('Y-m-d H:i:s') . " ".$e->getMessage());
        }
    }



    /**
     * 同步AdSet数据
     * 此方法可以放到同步campaign中，同步一个campaign后，马上同步对应的adset
     * 现在是针对account_id,然后漏出所有的campaign
     * 
     * @param [type] $market_adaccount_id [description]
     */
    public function setAdSet($publisher_id, $account_id, $account_name, $day, $breakdowns)
    {
        
        try{
            $result = $this->_ci->facebookapi->accountToAdset($account_id);
            if ($result) {
                //$fields = $this->adset_model->fields;
                $fields = $this->adset_fields;
                
                $i = 1;
                $total = count($result);
                foreach ($result as $key => $value) {
                    try{
                        
                        $campaign_name = $this->redis->get($value['campaign_id']);

                        if (!$campaign_name) {
                            $campaign_name = ' ';
                        }
 
                        $newdata = $this->getFieldsData($fields, $value);
                        $newdata['adset_id'] = intval($value['id']);
                        $newdata['campaign_name'] = $campaign_name;
                        $newdata['account_name'] = $account_name;
                        $promoted_object = $value['promoted_object'];
                        $newdata['application_id'] = isset($promoted_object['application_id'])?$promoted_object['application_id']:' ';
                        $newdata['object_store_url'] = isset($promoted_object['object_store_url'])?$promoted_object['object_store_url']:' ';
                        $newdata['targeting'] = json_encode($value['targeting']);
                        $newdata['app_id'] = isset($promoted_object['object_store_url'])?get_app_id($promoted_object['object_store_url']):' ';
                        $newdata['account_id'] = intval($newdata['account_id']);
                        $newdata['campaign_id'] = intval($newdata['campaign_id']);
                        
                        if (!$newdata['app_id']) {
                            continue;
                        }

                        if (!$day) {
                            $day = date('Y-m-d', strtotime("-1 day"));
                        }
                        

                        if ($total<100) {
                           $this->setAdSetBreakdownsInsight($publisher_id, $newdata, $breakdowns, $day);  
                        }else{
                            if ($i++<100) {
                                $message = array('publisher_id'=>$publisher_id, 'data'=>$newdata, 'date'=>$day, 'breakdowns'=>$breakdowns);
                                
                                $week = date('W', strtotime($day));
                                $key = "fetch_adset_breakdowns_insights_".$week;
                                $this->redis->sadd($key, json_encode($message));
                            }
                            if ($i>=100) {
                                log_message('debug', "queue_adset_breakdowns_data:  redis key week->".$week);

                                $this->aws_sqs->deliver(['event'=>"fetch_adset_breakdowns_insights_by_dynamodb_subtask", 'delay'=>300, 'week'=>$week, 'day'=>$day, 'account_id'=>$newdata['account_id']]);
                                $i = 1;
                                $total -= 100;
                            }

                        }


                        //$this->setAdSetBreakdownsInsightForQueue($publisher_id, $newdata, $breakdowns, $day); 

                        
                    }catch (Exception $e){
                        fetch_exception($value['id'], 'fetch_adset_insights', $e->getMessage(), $day);

                        log_message('error', "queue_adset_data: ".$day." ".$account_id.'_'.$value['id'] . " adset fetch faild ->".date('Y-m-d H:i:s') . " ".$e->getMessage());
                    }
                }
            }
        }catch(Exception $e){
            fetch_exception($account_id, 'fetch_account', $e->getMessage());

            log_message('error', "queue_adset_data: ".$account_id." adset fetch faild ->".date('Y-m-d H:i:s') . " ".$e->getMessage());
        }
        
    }


    /**
     * 整合统计数据需要的字段
     * @param  [type] $data   [获取的统计数据]
     * @param  [type] $result [初始值]
     * @param  [type] $fields [对应的字段]
     * @return [type]         [description]
     */
    private function getInsightsData($data, & $result, $fields)
    {
        $result['results'] = $result['comments'] = $result['likes'] = $result['shares'] = 0;
        $result['link_clicks'] = 0;
        $result['ctr_link'] = 0;
        $result['cost'] = '0';
        $result['cpc_link'] = '0';
        foreach ($data as $key => $value) {
            if (is_float($value)) {
                $value = strval($value);
            }
            if (in_array($key, $fields)) {
                is_array($value) && $value = json_encode($value);
                $result[$key] = $value;
            }
            if ($key=='actions') {
                foreach ($value as $k => $v) {
                    if ($v['action_type'] == 'mobile_app_install') {
                        $result['results'] = $v['value'];
                    }
                    if ($v['action_type'] == 'link_click') {
                        $result['link_clicks'] = $v['value'];
                        $result['ctr_link'] = $data['impressions']>0?strval($v['value']/$data['impressions']*100):'0';
                    }
                    if ($v['action_type'] == 'comment') {
                        $result['comments'] = $v['value'];
                    }
                    if ($v['action_type'] == 'like') {
                        $result['likes'] = $v['value'];
                    }
                    if ($v['action_type'] == 'post') {
                        $result['shares'] = $v['value'];
                    }
                }
            }
            if ($key=='cost_per_action_type') {
                foreach ($value as $k => $v) {
                    if ($v['action_type'] == 'mobile_app_install') {
                        $result['cost'] = strval($v['value']);
                    }
                    if ($v['action_type'] == 'link_click') {
                        $result['cpc_link'] = strval($v['value']);
                    }
                }
            }
        }
        $result['date'] = strtotime($result['date_start']);

        $result['account_id'] = intval($result['account_id']);
        $result['campaign_id'] = intval($result['campaign_id']);
        $result['impressions'] = intval($result['impressions']);

        return $result;
    }
    

    //返回几个breakdowns分组的字段值
    public function get_insights_fields($adsetdata, $value, $fields, $breakdowns)
    {
        $result = ['account_id'=>$adsetdata['account_id'], 'account_name'=>$adsetdata['account_name'], 'campaign_id'=>$adsetdata['campaign_id'], 'campaign_name'=>$adsetdata['campaign_name'], 'adset_id'=>$adsetdata['adset_id'], 'adset_name'=>$adsetdata['name']];
        $result['object_store_url'] = $adsetdata['object_store_url'];
        $result['app_id'] = $adsetdata['app_id'];

        $this->getInsightsData($value, $result, $fields);

        if ($breakdowns=='age_gender') {
            $result['adset_id_'.$breakdowns] = $result['adset_id']."_".$result['age']."_".$result['gender'];
        }else{
            $result['adset_id_'.$breakdowns] = $result['adset_id']."_".$result[$breakdowns];
        }
        
        
        $vars = ['comments'=>$result['comments'], 'shares'=>$result['shares'], 'likes'=>$result['likes'], 'date'=>$result['date'], 'results'=>$result['results'], 'spend'=>$result['spend'], 'reach'=>$result['reach'], 'frequency'=>$result['frequency'], 'cost'=>$result['cost'], 'clicks'=>$result['clicks'], 'clicks_link'=>$result['link_clicks'], 'ctr'=>$result['ctr'], 'cpc'=>$result['cpc'], 'impressions'=>$result['impressions'], 'cpm'=>$result['cpm'], 'adset_id'=>$result['adset_id'], 'campaign_id'=>$result['campaign_id'], 'account_id'=>$result['account_id']];

        if ($breakdowns=='age_gender') {
            $vars['age'] = $result['age'];
            $vars['gender'] = $result['gender'];
        }else{
            $vars[$breakdowns] = $result[$breakdowns];
        }


        $vars['app_id'] = $result['app_id'];
        $vars['object_store_url'] = $result['object_store_url'];


        $vars['adset_name'] = $result['adset_name'];
        $vars['campaign_name'] = $result['campaign_name'];
        $vars['account_name'] = $result['account_name'];

        $vars['date_year'] = date('Y', $vars['date']);
        $vars['date_month'] = date('M', $vars['date']);
        $vars['date_day'] = date('d', $vars['date']);
        $vars['date_week'] = date('W', $vars['date']);

        if ($breakdowns=='age_gender') {
            $vars['adset_id_'.$breakdowns] = $vars['adset_id']."_".$vars['age']."_".$vars['gender'];
        }else{
            $vars['adset_id_'.$breakdowns] = $vars['adset_id']."_".$vars[$breakdowns];
        }


        $advertiser_info = $this->offer_model->get_query("select advertiser_id,advertiser_name from publisher_offer where account_id=".$vars['account_id']." group by advertiser_id,advertiser_name");
        if ($advertiser_info) {
            $vars['advertiser_id'] = $advertiser_info[0]['advertiser_id'];
            $vars['advertiser_name'] = $advertiser_info[0]['advertiser_name'];
        }else{
            $vars['advertiser_id'] = 0;
            $vars['advertiser_name'] = ' ';
        }

        
        return $vars;
    }

    public function setAdSetBreakdownsInsightForQueue($publisher_id, $adsetdata, $breakdowns, $day='today')
    {
        $token = $this->get_token_user($adsetdata['account_id']);
        $this->_ci->facebookapi->setToken($token);

        $this->setAdSetBreakdownsInsight($publisher_id, $adsetdata, $breakdowns, $day);
    }

    /**
     * 按分组获取数据
     * age          年龄
     * gender       性别
     * region       省份/洲
     * impression_device    推广设备
     * placement
     * hourly_stats_aggregated_by_audience_time_zone 观看广告时间
     */
    public function setAdSetBreakdownsInsight($publisher_id, $adsetdata, $breakdowns, $day='today')
    {
        $start = time();
        log_message('debug', "queue_adset_data: fetch adset breakdowns -- ".$breakdowns." insights started -> " . date('Y-m-d H:i:s') . " Adset ID -> ".$adsetdata['adset_id'] );

        try{
            $publisherinfo = $this->offer_model->get_query("select * from publisher_adaccount where account_id=".$adsetdata['account_id']." and publisher_id=".$publisher_id);
            //$publisherinfo = $this->publisher_adaccount_model->get_by_fields(['account_id'=>$adsetdata['account_id'], 'publisher_id'=>$publisher_id]);
            if ($publisherinfo) {

                $account_id = $adsetdata['account_id'];
                $user_id = $this->get_token_user($account_id);

                $fields = $this->fields;
                if ($breakdowns=='age_gender') {
                    $fields[] = 'age';
                    $fields[] = 'gender';
                    $params = "time_range[since]=".$day."&time_range[until]=".$day."&breakdowns=age,gender";
                }else{
                    $fields[] = $breakdowns;
                    $params = "time_range[since]=".$day."&time_range[until]=".$day."&breakdowns=".$breakdowns;
                }

                $data = $this->_ci->facebookapi->getInsights($adsetdata['adset_id'], $params);
                if (!$data) {
                    return '';
                } 
                foreach ($data as $key => $value) {
                    $vars = $this->get_insights_fields($adsetdata, $value, $fields, $breakdowns);
                    $vars = $this->get_breakdown_fields($vars, $breakdowns);
                    
                    $table_name = $this->get_dynamodb_table('marketmax_'.$breakdowns.'_reports', 'adset_id_'.$breakdowns, $vars['date']);
                    $data = $this->aws_dynamodb->putItem($table_name, json_encode($vars));
                    if ($data!=200) {
                        fetch_exception($vars['account_id'], 'fetch_adset_'.$breakdowns.'_insights_by_dynamodb', "Dynamodb put data error");
                    }
                }
            }
            $end = time();
            log_message('debug', "queue_adset_data: fetch adset breakdowns insights completed -> " . date('Y-m-d H:i:s') . " Adset ID -> ".$adsetdata['adset_id'] .' Duration -> '. ($end - $start) );
        }catch(Exception $e){
            fetch_exception($adsetdata['account_id'], 'fetch_adset_'.$breakdowns.'_insights', $adsetdata['adset_id']."----".$e->getMessage(), $day);

            log_message('error', "queue_adset_data: ".$day." ".$adsetdata['account_id']." adset ".$breakdowns." insight fetch faild ->".date('Y-m-d H:i:s') . " ".$e->getMessage());
        }
    }



    public function get_breakdown_fields($vars, $field='age')
    {
        $fields = ['date'=>0, 'adset_id_'.$field=>' ', 'account_id'=>0, 'account_name'=>' ', 'adset_id'=>0, 'adset_name'=>' ',
                'campaign_id'=>0, 'campaign_name'=>' ', 'clicks'=>0, 'clicks_link'=>0, 'cost'=>' ', 
                'cpc'=>' ', 'cpm'=>' ', 'ctr'=>' ', 'date_day'=>0, 'date_week'=>0, 'date_month'=>0, 'date_year'=>0, 
                'frequency'=>' ', 'impressions'=>0, 'reach'=>' ', 'results'=>0, 'spend'=>'0'
        ];

        if ($field=='age_gender') {
            $fields['age'] = ' ';
            $fields['gender'] = ' ';
        }else{
            $fields[$field] = ' ';
        }

        foreach ($fields as $key => $value) {
            if (!isset($vars[$key])) {
                $vars[$key] = $value;
            }
        }

        return $vars;
    }


    /**
     * 获取当前使用的表名称
     * 每个月都要创建一个新表
     * @return [type] [description]
     */
    private function get_dynamodb_table($table, $sort_key, $date='')
    {
        $table_name = $table."_".date('Y');
        if ($date) {
            $table_name = $table."_".date('Y', $date);
        }
        $table_list = $this->aws_dynamodb->listTables();
        if (in_array($table_name, $table_list)) {
            return $table_name;
        }else{
            $params = [
                'TableName' => $table_name,
                'KeySchema' => [
                    [
                        'AttributeName' => 'date',
                        'KeyType' => 'HASH'  //Partition key
                    ],
                    [
                        'AttributeName' => $sort_key,
                        'KeyType' => 'RANGE'  //Sort key
                    ]
                ],
                'AttributeDefinitions' => [
                    [
                        'AttributeName' => 'date',
                        'AttributeType' => 'N'
                    ],
                    [
                        'AttributeName' => $sort_key,
                        'AttributeType' => 'S'
                    ]
                ],
                'ProvisionedThroughput' => [
                    'ReadCapacityUnits' => 200,
                    'WriteCapacityUnits' => 100
                ]
            ];
            $data = $this->aws_dynamodb->createTable($params);
            sleep(10);
        }
        return $table_name;
    }


    /**
     * 获取抓取数据时所使用的token
     * @param string $value [description]
     */
    private function get_token_user($account_id='')
    {
        $publisher_adaccount = $this->offer_model->get_query("select * from publisher_adaccount where publisher_id=10040 and account_id=".$account_id);
        if ($publisher_adaccount) {
            return config_item('FACEBOOK_TOKEN');
        }else{
            $other_account = $this->offer_model->get_query("select * from publisher_adaccount where account_id=".$account_id);
            if (!$other_account) {
                return "Token Invalid";
            }

            $userinfo = $this->offer_model->get_query("select * from user where user_id=".$other_account[0]['publisher_id']);
            if (!$userinfo) {
                return "Token Invalid";
            }
            return $userinfo[0]['token'];
        }
    }

 
    /**
     * 数据同步{昨天数据}
     * @return [type] [description]
     */
    public function sync($publisher_id, $account_id, $date, $breakdowns)
    {
        $token = $this->get_token_user($account_id);
        $this->_ci->facebookapi->setToken($token);

        if (!$date) {
            $date = date('Y-m-d', strtotime('-1 day'));
        }
        if ($account_id) {
            $publisherinfo = $this->offer_model->get_query("select * from publisher_adaccount where account_id=".$account_id." and publisher_id=".$publisher_id);
            //$publisherinfo = $this->publisher_adaccount_model->get_by_fields(['account_id'=>$account_id, 'publisher_id'=>$publisher_id]);
            if ($publisherinfo) {
                $publisherinfo = $publisherinfo[0];
                $user_id = $this->get_token_user($account_id);
                if (!$user_id) {
                    fetch_exception($account_id, 'fetch_account', 'account_id:'.$account_id.' 未找到Token', $date);
                    return ['success'=>false, 'message'=>'account_id:'.$account_id.' 未找到Token'];
                }
                
                $this->setCampaign($publisher_id, $account_id, $date);

                $this->setAdset($publisher_id, $account_id,$publisherinfo['account_name'], $date, $breakdowns);

                $this->db->close();
                return ['success'=>true, 'message'=>'account_id:'.$account_id.' 同步完成'];
            }
            return ['success'=>false, 'message'=>'account_id:'.$account_id." 数据库中没有找到"];
        }
        return ['success'=>false, 'message'=>'参数丢失'];
    }

    

}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */