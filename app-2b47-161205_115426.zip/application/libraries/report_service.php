<?php

/**
 * Created by PhpStorm.
 * User: palmax
 * Date: 2016/9/13
 * Time: 11:20
 */
class Report_service
{
    protected $_ci;

    public function __construct()
    {
        $this->_ci=&get_instance();
        $this->_ci->load->model('product_model');
        $this->_ci->load->model('adset_model');
        $this->_ci->load->model('publisher_offer_model');
        $this->_ci->load->config('country');
    }


    /**
     * 获取产品list
     * @param int $type
     * @param $user_id
     * @return mixed
     */
    public function get_product($type=0, $user_id='', $result_product_id=True)
    {
        $order=$join=$where=$group=[];
        switch ($type) {
            case 0:
                $where=[];
                //管理员
                break;
            case 1:
                //流量主
                $where=['product.user_id'=>$user_id];
                $group='publisher_offer.product_id';
                $join=['publisher_offer'=>'product.product_id = publisher_offer.product_id'];
                //$order=['product.product_id', 'desc'];
                break;
            case 2:
                //广告主
                $join=['publisher_offer'=>'product.product_id = publisher_offer.product_id'];
                $where=['publisher_offer.publisher_id'=>$user_id];
                $order=['publisher_offer.product_id', 'desc'];
                break;
        }
        $data=$this->_ci->product_model->get_data('product.product_id,product.user_id,product.name,product.app_id,product.score,product.object_store_url,product.logo,product.offer_count,product.play_category,product.retention_day,product.retention_updated_time', $where, 0, 0, $join, $group, $order);

        if ($result_product_id) {
            $data=$data?array_column($data, 'product_id'):[];
        }
        //var_dump($data);die;
        return $data;
    }

    /**
     * 获取asets信息
     * @param $where
     * @return array
     */
    public function get_adsets($where)
    {
        $select='product.product_id,product.category,product.user_id,product.name,product.app_id,product.score,product.object_store_url,product.logo,product.offer_count,product.play_category,product.retention_day,product.retention_updated_time,adset_country_month_log.`value`,sum(adset_country_month_log.day0) as day0,sum(adset_country_month_log.day1) as day1,adset_country_month_log.country,adset_country_month_log.set_retention';
        $group='adset_country_month_log.country,adset_country_month_log.product_id';
        $order=['product.product_id', 'desc'];
        $results=$this->_ci->product_model->get_data($select, $where, 0, 0, ['adset_country_month_log'=>'adset_country_month_log.product_id=product.product_id'], $group, $order);
        $data=[];
        if ($results) {
            $data=array_values(array_reduce($results, function ($v, $w) {
                $product_id=$w['product_id'];
                unset($w['product_id']);
                $v[$product_id]['product_id']=$product_id;
                $v[$product_id]['user_id']=$w['user_id'];
                $v[$product_id]['name']=$w['name'];
                $v[$product_id]['app_id']=$w['app_id'];
                $v[$product_id]['category']=$w['category'];
                $v[$product_id]['offer_count']=$w['offer_count'];
                $v[$product_id]['score']=$w['score'];
                $v[$product_id]['play_category']=$w['play_category'];
                $v[$product_id]['retention_day']=$w['retention_day'];
                $v[$product_id]['retention_updated_time']=$w['retention_updated_time'];
                $v[$product_id]['logo']=$w['logo'];
                $v[$product_id]['object_store_url']=$w['object_store_url'];
                //$w['country'] == 'US'?'United States of America':(array_key_exists($w['country'], config_item('country'))?config_item('country')[$w['country']]:'')
                $v[$product_id]['countries'][]=[
                    'country'=>$w['country'] == 'US'?'United States of America':(array_key_exists($w['country'], config_item('country'))?config_item('country')[$w['country']]:''),
                    'shortening'=>$w['country'],
                    'set_retention'=>$w['set_retention'],
                    'value'=>$w['value'],
                    'result'=>($w['value']>=$w['set_retention'])?'#c1e682':'#ff6477'
                ];
                return $v;
            }));
        }
        //var_dump($data[0]['countries']);die;
        return $data;
    }

    /**
     * 获取渠道
     * @param string $publisher
     * @return mixed
     */
    public function get_publishers($publisher='all')
    {
        $select='publisher_adaccount.publisher_id,publisher_adaccount.publisher_name';
        if ($publisher != 'all') {
            $where['publisher_offer.advertiser_id']=$publisher;
        } else {
            $where=[];
        }
        $where['publisher_adaccount.publisher_type']=2;
        $join=['publisher_adaccount'=>'publisher_offer.account_id = publisher_adaccount.account_id'];
        $group='publisher_adaccount.publisher_id';
        $order=['publisher_adaccount.publisher_id', 'desc'];
        return $this->_ci->publisher_offer_model->get_data($select, $where, 0, 0, $join, $group, $order);
    }

    /**
     * 根据条件获取产品id
     * @param $where
     * @return mixed
     */
    public function get_channels($where)
    {
        $select='publisher_offer.product_id';
        $join=['publisher_adaccount'=>'publisher_offer.account_id = publisher_adaccount.account_id'];
        $where['publisher_adaccount.publisher_type']=2;
        $group='publisher_offer.product_id';
        $order=['publisher_offer.product_id', 'desc'];
        $data=$this->_ci->publisher_offer_model->get_data($select, $where, 0, 0, $join, $group, $order);
        $data=$data?array_column($data, 'product_id'):[];
        return $data;
    }


    public function get_product_offers($product_ids, $like)
    {
        if ($product_ids) {
            $product_id=implode(',', $product_ids);
            if ($like) {
                $where_like=" AND product.name LIKE '%{$like}%'";
            } else {
                $where_like='';
            }
            $data=[];
            $sql="
                SELECT
                  `product`.`product_id`,
                  `product`.`category`,
                  `product`.`user_id`,
                  `product`.`name`,
                  `product`.`app_id`,
                  `product`.`score`,
                  `product`.`object_store_url`,
                  `product`.`logo`,
                  `product`.`offer_count`,
                  `product`.`play_category`,
                  `product`.`retention_day`,
                  `product`.`retention_updated_time`,
                  offer_country_log.country
                FROM (`product`)
                inner JOIN `offer` ON `offer`.`product_id` = `product`.`product_id`
                RIGHT JOIN `offer_country_log` ON `offer_country_log`.`offer_id` = `offer`.`offer_id`
                WHERE `product`.`product_id` IN ({$product_id}) AND `product`.`status` = 1 {$where_like}
                GROUP BY `offer_country_log`.`country`
                ORDER BY `product`.`product_id` DESC";
            $result=$this->_ci->product_model->get_query($sql);
            if($result){
                $data=array_values(array_reduce($result, function ($v, $w) {
                    $product_id=$w['product_id'];
                    unset($w['product_id']);
                    $v[$product_id]['product_id']=$product_id;
                    $v[$product_id]['user_id']=$w['user_id'];
                    $v[$product_id]['name']=$w['name'];
                    $v[$product_id]['app_id']=$w['app_id'];
                    $v[$product_id]['category']=$w['category'];
                    $v[$product_id]['offer_count']=$w['offer_count'];
                    $v[$product_id]['score']=$w['score'];
                    $v[$product_id]['play_category']=$w['play_category'];
                    $v[$product_id]['retention_day']=$w['retention_day'];
                    $v[$product_id]['retention_updated_time']=$w['retention_updated_time'];
                    $v[$product_id]['logo']=$w['logo'];
                    $v[$product_id]['object_store_url']=$w['object_store_url'];
                    $shortening='';
                    if ($w['country']) {
                        $country=json_decode($w['country'], true);
                        $shortening=$country[0];
                    }
                    $v[$product_id]['countries'][]=[
                        'country'=>$w['country'] == 'US'?'United States of America':(array_key_exists($w['country'], config_item('country'))?config_item('country')[$w['country']]:''),
                        'shortening'=>$shortening,
                        'set_retention'=>'',
                        'value'=>'',
                        'result'=>''
                    ];
                    return $v;
                }));
            }
            return $data;
        }
    }

}