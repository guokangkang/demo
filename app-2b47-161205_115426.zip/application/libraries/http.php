<?php
/**
 * Created by PhpStorm.
 * User: palmax
 * Date: 2016/9/6
 * Time: 11:18
 */

require_once __DIR__ . '/vendor/autoload.php';

use GuzzleHttp\Client;
use GuzzleHttp\Pool;
use GuzzleHttp\Promise;
use Psr\Http\Message\ResponseInterface;

class Http
{

    public $_http;

    /**
     * 初始化
     * Http constructor.
     */
    public function __construct()
    {
        $this->_http=new Client([
            'timeout'=>'5.0',
            'headers'=>[
                'Referer'=>'https://www.google.com',
                'User-Agent'=>'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36'
            ]]);
    }

    /**
     * 处理数
     * @param $method ['post','get','put]
     * @param $url
     * @param array $data ,post data ['form_params'=>$data],get ['auth'=>$data]
     * @return array|string
     */
    public function request($method, $url, $data=[])
    {
        try {
            $response=$this->_http->request($method, $url, $data);
            $data=$response->getBody()->getContents();
            return $data;
        } catch (Exception $e) {
            log_message('error', $e->getMessage());
        }

    }
}