<?php defined('BASEPATH') OR exit('No direct script access allowed');

require_once __DIR__ . '/vendor/autoload.php';
use Aws\Sns\Message;
use Aws\Sns\MessageValidator;
use Aws\Sns\Exception\InvalidSnsMessageException;
use Aws\Sns\SnsClient;
use Aws\Credentials\CredentialProvider;

/**
 * 操作 Aws SNS 消息库
 *
 * @package         CodeIgniter
 * @subpackage      Libraries
 * @category        Libraries
 */
class Aws_sns {

    protected $_ci;  

    function __construct()
    {
        $this->_ci = & get_instance();
        log_message('debug', 'Library loaded: aws_sns');
    }

    //接收AWS SNS Message
    public function subscribe()
    {

        if( ! IS_POST ) {
            log_message('debug', 'AWS SNS Message: direct script access unallowed');
            $this->_ci->load->helper('common');
            show_error('No direct script access allowed',403);
        }

        log_message('debug', 'AWS SNS Message: subscribe started');


        // Instantiate the Message and Validator
        $message = Message::fromRawPostData();
        $validator = new MessageValidator();

        // Validate the message and log errors if invalid.
        try {
            $validator->validate($message);
        } catch (InvalidSnsMessageException $e) {
            // Pretend we're not here if the message is invalid.
            $this->_ci->output->set_status_header(404);
            log_message('error','AWS SNS Message Validation Error: ' . $e->getMessage);
            return FALSE;
        }

        // Check the type of the message and handle the subscription.
        if ($message['Type'] === 'SubscriptionConfirmation') {
            log_message('debug', 'AWS SNS Message Recevied: SubscriptionConfirmation');
            // Confirm the subscription by sending a GET request to the SubscribeURL
            return file_get_contents($message['SubscribeURL']);
        }

        //Receiving a Notification
        if ($message['Type'] === 'Notification') {
           // Do whatever you want with the message body and data.
            log_message('debug', 'AWS SNS Message Recevied: Notification');
            return $message;
        }

        //Unsubscribing
        if ($message['Type'] === 'UnsubscribeConfirmation') {
            log_message('debug', 'AWS SNS Message Recevied: UnsubscribeConfirmation');
            return file_get_contents($message['SubscribeURL']);
        }

    }



    //发布AWS SNS Message
    public function publish($message, $subject="facebook_account")
    {
        log_message('debug', 'AWS SNS Message: publish started');

        $profile = 'default';
        $path = APPPATH . 'config/aws_credentials.ini';

        $provider = CredentialProvider::ini($profile, $path);
        $provider = CredentialProvider::memoize($provider);

        // Create a client that uses the us-west-1 region
        $client = SnsClient::factory(array(
            'credentials' => $provider,
            'region' => 'ap-northeast-1',
            'version' => 'latest'
        ));
        $message = json_encode($message);

        try{
            $result = $client->publish([
                'TopicArn' => config_item('AWS_SNS_ARN'),  // 消息目标
                'Message' => $message, //消息主体内容
                'Subject' => $subject //消息主题
            ]);
            log_message('debug', 'AWS SNS Message Subject :' . $subject);
            log_message('debug', 'AWS SNS Message Text :' . $message);
            log_message('debug', 'AWS SNS Message: message published');
            return $result;
        }catch (Exception $e){
            log_message('error', 'AWS SNS Message: '. $e->getMessage());
            return $e->getMessage();
        }

    }


}