<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Fetch_adset_data extends CI_Controller {

    //数据更新间隔时间
    var $_synctime = 3600;//一个小时

    var $insight_fileds =  ['date_start', 'date_stop', 'impressions', 'website_clicks', 'ctr', 'cpm', 'cpp', 'website_ctr', 'comment', 'link_click', 'post_like', 'mobile_app_install'];

    var $facebookapi;
    /**
    * 初使化
    */ 
    public function __construct()
    {
        parent::__construct(); 

        $this->ci = &get_instance();
        // 加载其他类库，可以是自定义类库，也可以是ci类库
        // 其他加载模型，helper都可以这样

        $this->ci->load->model('user_model');
        $this->ci->load->model('adaccount_model');
        $this->ci->load->model('adaccount_insight_model');
        $this->ci->load->model('ad_model');
        $this->ci->load->model('ad_insight_model');
        $this->ci->load->model('adcreative_model');
        $this->ci->load->model('adset_insight_model');
        $this->ci->load->model('adset_country_insight_model');
        $this->ci->load->model('adset_model');
        $this->ci->load->model('campaign_insight_model');
        $this->ci->load->model('campaign_model');
        $this->ci->load->model('offer_model');
        $this->ci->load->model('publisher_adaccount_model');
        $this->ci->load->model('adset_country_log_model');

        $this->ci->load->model('publisher_offer_model');
        $this->ci->load->model('offer_country_log_model');

        $this->ci->load->model('offer_effective_log_model');
        $this->ci->load->model('business_model');

        $this->ci->load->model('offer_cpa_log_model');
        $this->ci->load->model('adset_retention_model');
        $this->ci->load->model('adset_country_month_log_model');

        $this->load->library('aws_dynamodb');

    }
    
    /**
     * 整合对象数据的字段
     * @param  [type] $fields [description]
     * @param  [type] $data   [description]
     * @return [type]         [description]
     */
    public function getFieldsData($fields, $data)
    {
        $return = [];
        foreach ($data as $key => $value) {
            if (in_array($key, $fields)) {
                $return[$key] = $value;
            }
        }
        $return['backup'] = json_encode($data);
        return $return;
    }


    /**
     * 整合统计数据需要的字段
     * @param  [type] $data   [获取的统计数据]
     * @param  [type] $result [初始值]
     * @param  [type] $fields [对应的字段]
     * @return [type]         [description]
     */
    private function getInsightsData($data, & $result, $fields)
    {
        $result['results'] = $result['comments'] = $result['likes'] = $result['shares'] = 0;
        $result['link_clicks'] = 0;
        $result['ctr_link'] = 0;
        $result['cost'] = '0';
        $result['cpc_link'] = '0';
        foreach ($data as $key => $value) {
            if (is_float($value)) {
                $value = strval($value);
            }
            if (in_array($key, $fields)) {
                is_array($value) && $value = json_encode($value);
                $result[$key] = $value;
            }
            if ($key=='actions') {
                foreach ($value as $k => $v) {
                    if ($v['action_type'] == 'mobile_app_install') {
                        $result['results'] = $v['value'];
                    }
                    if ($v['action_type'] == 'link_click') {
                        $result['link_clicks'] = $v['value'];
                        $result['ctr_link'] = $data['impressions']>0?strval($v['value']/$data['impressions']*100):'0';
                    }
                    if ($v['action_type'] == 'comment') {
                        $result['comments'] = $v['value'];
                    }
                    if ($v['action_type'] == 'like') {
                        $result['likes'] = $v['value'];
                    }
                    if ($v['action_type'] == 'post') {
                        $result['shares'] = $v['value'];
                    }
                }
            }
            if ($key=='cost_per_action_type') {
                foreach ($value as $k => $v) {
                    if ($v['action_type'] == 'mobile_app_install') {
                        $result['cost'] = strval($v['value']);
                    }
                    if ($v['action_type'] == 'link_click') {
                        $result['cpc_link'] = strval($v['value']);
                    }
                }
            }
        }
        $result['date'] = strtotime($result['date_start']);
        $result['backup'] = json_encode($data);

        $result['account_id'] = intval($result['account_id']);
        $result['campaign_id'] = intval($result['campaign_id']);
        $result['impressions'] = intval($result['impressions']);

        return $result;
    }

    /**
     * 同步campaign
     * @param [type] $market_adaccount_id [adaccount 主键id]
     * @param [type] $account_id          [adaccount 元数据id]
     */
    public function setCampaign($publisher_id, $account, $date)
    {
        try{
            $result = $this->facebookapi->accountToCampaigns($account['account_id']);
            if(!$result)
                return false;
            foreach ($result as $key => $value) {
                //$campaign = ['campaign_id'=>$value['id'], 'campaign_name'=>$value['name']];
                $this->redis->set($value['id'], $value['name']);
            }
        }catch(Exception $e){
            fetch_exception($account['account_id'], 'fetch_account', $e->getMessage(), $date);
            log_message('error', "queue_adset_data: ".$account['account_id']." campaign fetch faild ->".date('Y-m-d H:i:s') . " ".$e->getMessage());
        }
    }



    /**
     * 同步AdSet数据
     * 此方法可以放到同步campaign中，同步一个campaign后，马上同步对应的adset
     * 现在是针对account_id,然后漏出所有的campaign
     * 
     * @param [type] $market_adaccount_id [description]
     */
    public function setAdSet($publisher_id, $account, $day='')
    {
        $this->ci->load->library('aws_sqs');
        try{
            $result = $this->facebookapi->accountToAdset($account['account_id']);
            if ($result) {
                $fields = $this->adset_model->fields;

                foreach ($result as $key => $value) {
                    try{
                        log_message('debug', "queue_adset_data: ".$account['account_id'].'_'.$value['id'] ." adset fetch start ->".date('Y-m-d H:i:s'));
                        
                        $campaign_name = $this->redis->get($value['campaign_id']);

                        $newdata = $this->getFieldsData($fields, $value);
                        $newdata['adset_id'] = intval($value['id']);
                        $newdata['campaign_name'] = $campaign_name;
                        $newdata['account_name'] = $account['name'];
                        $newdata['created_time'] = strtotime($newdata['created_time']);
                        $newdata['start_time'] = strtotime($newdata['start_time']);
                        $promoted_object = $value['promoted_object'];
                        $newdata['application_id'] = $promoted_object['application_id'];
                        $newdata['object_store_url'] = $promoted_object['object_store_url'];
                        $newdata['targeting'] = json_encode($value['targeting']);
                        $newdata['app_id'] = get_app_id($promoted_object['object_store_url']);
                        $newdata['account_id'] = intval($newdata['account_id']);
                        $newdata['campaign_id'] = intval($newdata['campaign_id']);
                        
                        if (!$day) {
                            $day = date('Y-m-d', strtotime("-1 day"));
                        }

                        //发送队列{获取adset 按国家分组的统计信息}
                        $message = array('publisher_id'=>$publisher_id, 'data'=>$newdata, 'date'=>$day, 'event'=>'fetch_adset_country_insights_by_dynamodb');
                        $this->aws_sqs->deliver($message);                        

                        //$this->setAdSetCountryInsight($publisher_id, $newdata, $day);

                        log_message('debug', "queue_adset_data: ".$day." ".$account['account_id'].'_'.$value['id'] . " adset fetch done ->".date('Y-m-d H:i:s'));
                    }catch (Exception $e){
                        fetch_exception($value['id'], 'fetch_adset_insights', $e->getMessage(), $day);

                        log_message('error', "queue_adset_data: ".$day." ".$account['account_id'].'_'.$value['id'] . " adset fetch faild ->".date('Y-m-d H:i:s') . " ".$e->getMessage());
                    }
                }
            }
        }catch(Exception $e){
            fetch_exception($account['account_id'], 'fetch_account', $e->getMessage());

            log_message('error', "queue_adset_data: ".$account['account_id']." adset fetch faild ->".date('Y-m-d H:i:s') . " ".$e->getMessage());
        }
        
    }


    /**
     * 设置adset的统计信息国家分组
     * @param [type] $market_adset_id [description]
     * @param [type] $data            [description]
     */
    public function setAdSetCountryInsight($publisher_id, $adsetdata, $day='today')
    {
        try{
            $publisherinfo = $this->publisher_adaccount_model->get_by_fields(['account_id'=>$adsetdata['account_id'], 'publisher_id'=>$publisher_id]);
            if ($publisherinfo) {
                
                $account_id = $adsetdata['account_id'];
                $user_id = $this->get_token_user($account_id);

                if (!$user_id) {
                    fetch_exception($account_id, 'fetch_account', 'account_id:'.$account_id.' 未找到Token', $day);
                    return ['success'=>false, 'message'=>'account_id:'.$account_id.' 未找到Token'];
                }
                if (is_numeric($user_id)) {
                    $user_info = $this->user_model->get_by_id($user_id);
                    if (!$user_info) {
                        fetch_exception($account_id, 'fetch_account', 'account_id:'.$account_id.' 未找到Token', $day);
                        return ['success'=>false, 'message'=>'account_id:'.$account_id.' 未找到Token'];
                    }
                    if (!$user_info['token']) {
                        fetch_exception($account_id, 'fetch_account', 'account_id:'.$account_id.' 未找到Token', $day);
                        return ['success'=>false, 'message'=>'account_id:'.$account_id.' 未找到Token'];
                    }

                    $this->load->library('facebookapi', ['user_id'=>$user_id]);
                }else{
                    $this->load->library('facebookapi', ['token'=>$user_id]);
                }



                $fields = $this->adset_country_insight_model->fields;

                $params = "time_range[since]=".$day."&time_range[until]=".$day."&breakdowns=country";

                $data = $this->facebookapi->getInsights($adsetdata['adset_id'], $params);
                if (!$data) {
                    return '';
                } 
                foreach ($data as $key => $value) {

                    $result = ['account_id'=>$adsetdata['account_id'], 'account_name'=>$adsetdata['account_name'], 'campaign_id'=>$adsetdata['campaign_id'], 'campaign_name'=>$adsetdata['campaign_name'], 'adset_id'=>$adsetdata['adset_id'], 'adset_name'=>$adsetdata['name']];
                    $result['object_store_url'] = $adsetdata['object_store_url'];
                    $result['app_id'] = $adsetdata['app_id'];

                    $this->getInsightsData($value, $result, $fields);
                    $result['adset_id_country'] = $result['adset_id']."_".$result['country'];
                    
                    //添加报告日志
                    $this->setAdSetCountryLogInsight($result);
                }
            }
        }catch(Exception $e){
            fetch_exception($adsetdata['account_id'], 'fetch_adset_country_insights', $adsetdata['adset_id']."----".$e->getMessage(), $day);

            log_message('error', "queue_adset_data: ".$day." ".$adsetdata['account_id']." adset country insight fetch faild ->".date('Y-m-d H:i:s') . " ".$e->getMessage());
        }
        
    }


    public function getRevenue($product_info, $info, $result)
    {
        $publisher_id = $info['publisher_id'];
        $offer_id  = $info['offer_id'];

        //获取用户针对offer是否有特殊价格
        $specific_data = $this->offer_model->get_current_specific_payout($offer_id, $publisher_id, $result['date']);

        $revenue = $retention = $expect_revenue = $origin_cpa = $rpa = $day0 = $day1 = 0;
        
        $retention_data = $this->adset_retention_model->get_by_fields(['date'=>$result['date'], 'adset_id'=>$result['adset_id'], 'country'=>$result['country']]);
        if ($retention_data) {
            $retention = $retention_data['retention'];
            $day0 = $retention_data['day0'];
            $day1 = $retention_data['day1'];
        }
 
        $retention_info = [];

        if ($specific_data) {//如果有特殊价格
            $revenue = $specific_data['payout']*$result['results'];

            $retention_info = ['offer_id'=>$offer_id, 'user_id'=>$publisher_id, 'cpa'=>$specific_data['payout'],
                            'type'=>'specific', 'retention'=>''];

            $origin_cpa = $cpa = $specific_data['payout'];
            $expect_revenue = $cpa*$result['results'];//预计收入
        }else{//没有特殊价格
            $cpa_data = $this->offer_model->get_current_cpa_log($offer_id, $result['date']);
 
            if ($cpa_data) {
                $origin_cpa = $cpa = $cpa_data['cpa'];
                $expect_revenue = $cpa*$result['results'];//预计收入

                if ($cpa_data['category']==1) {//固定价格，预计收入结算
                    $revenue = $expect_revenue;
                }elseif ($cpa_data['category']==2 && $retention_data){//阶梯价{必须要有留存数}
                    $retention_rate = $retention_data['retention'];
                    foreach ($cpa_data['value'] as $key => $value) {
                        $set_retention_rate[$value['retention_rate']] = $value['payout_rate'];
                    }
                    $set_cpa = 0;
                    krsort($set_retention_rate);
                    foreach ($set_retention_rate as $k => $v) {
                        if ($retention_rate>=$k/100) {//假如留存率大于指定值，就按指定值算，如果匹配不上则，直接收入为0
                            //$set_cpa = $cpa*$v/100;
                            $revenue = $expect_revenue*$v/100;
                            break;
                        }
                    }
                }elseif ($cpa_data['category']==3 && $retention_data){//等比例价格{必须要有留存数}
                    $retention_rate = $retention_data['retention'];
                    if ($retention_rate<($cpa_data['value']/100)) {
                        $retention_value = $cpa_data['value']/100;//后台设置的留存值
                        //$cpa = (1-($retention_value-$retention_rate)/$retention_value)*$cpa;
                        
                        $result['results'] = (1-($retention_value-$retention_rate)/$retention_value)*$result['results'];
                    }
                    $revenue = $cpa*$result['results'];
                }
            }

            $retention_info['retention'] = $cpa_data;
            $retention_info['user_id'] = $publisher_id;
            $retention_info['type'] = 'retention';
            $retention_info['cpa'] = $origin_cpa;
            $retention_info['offer_id'] = $offer_id;
        }

        //更新月平均留存-----------测试临时关掉-------------
        $this->set_adset_country_month_avg($product_info['user_id'], $info['publisher_id'], $product_info['product_id'], $result['country'], $result['date'], $day0, $day1);

        return [json_encode($retention_info), $revenue, $expect_revenue, $retention, $origin_cpa, $day0, $day1];
    }


    private function get_product_info($object_store_url)
    {
        $this->load->model('product_model');
        $app_id = get_app_id($object_store_url);
        return $app_id?$this->product_model->get_by_fields(['app_id'=>$app_id]):[];
    }


    /**
     * 返回月平均值
     * @param  [type] $retention_info [description]
     * @return [type]                 [description]
     */
    private function get_payment_ratio($retention_info, $month_ratio, $retention)
    {
        $payment_ratio = 0;
        if ($retention_info['type']=='retention' && $retention_info['retention']) {
            if ($retention_info['retention']['category']==3) {
                //$payment_ratio = sprintf("%.2f", $month_ratio/$retention_info['retention']['value']);
                $payment_ratio = $month_ratio/$retention_info['retention']['value'];
                
            }elseif($retention_info['retention']['category']==2){

                foreach ($retention_info['retention']['value'] as $key => $value) {
                    $set_retention_rate[$value['retention_rate']] = $value['payout_rate'];
                }
                $set_cpa = 0;
                krsort($set_retention_rate);
                foreach ($set_retention_rate as $k => $v) {
                    if ($retention>=$k/100) {
                        //$payment_ratio = sprintf("%.2f", $month_ratio/$k);
                        $payment_ratio = $month_ratio/$k;
                        break;
                    }
                }
            }else{
                $payment_ratio = 100;
            }
        }else{
            $payment_ratio = 100;
        }
        return $payment_ratio;
    }


    /**
     * 设置报告信息
     * @param [type] $result [description]
     */
    public function setAdSetCountryLogInsight($result)
    {                
        $vars = ['date'=>$result['date'], 'country'=>$result['country'], 'results'=>$result['results'], 'spend'=>$result['spend'], 'reach'=>$result['reach'], 'frequency'=>$result['frequency'], 'cost'=>$result['cost'], 'clicks'=>$result['clicks'], 'clicks_link'=>$result['link_clicks'], 'ctr'=>$result['ctr'], 'cpc'=>$result['cpc'], 'impressions'=>$result['impressions'], 'cpm'=>$result['cpm'], 'adset_id'=>$result['adset_id'], 'campaign_id'=>$result['campaign_id'], 'account_id'=>$result['account_id']];

        $vars['comments'] = $result['comments'];
        $vars['likes'] = $result['likes'];
        $vars['shares'] = $result['shares'];

        $vars['app_id'] = $result['app_id'];
        $vars['object_store_url'] = $result['object_store_url'];

        //通过appcation_id得到对应的产品
        $product_info = $this->get_product_info($result['object_store_url']);

        $offer_info = [];
        if ($product_info) {
            //获取对应的所有offer信息
            $offer_sql = "SELECT
                            *
                        FROM
                            publisher_offer
                        WHERE
                            account_id = ".$result['account_id']."
                        AND publisher_offer.product_id = ".$product_info['product_id'];
            $offer_list = $this->publisher_offer_model->get_query($offer_sql);
            
            //如果没有申请offer就直接跑数据了，不计费
            if ($offer_list) {
                foreach ($offer_list as $key => $info) {

                    $country_sql = "select * from offer_country_log
                                    where offer_id=".$info['offer_id']." and start_time<=".$result['date']."
                                    ORDER BY offer_country_log.start_time desc,offer_country_log.addtime desc limit 1";
                    $country_data = $this->offer_country_log_model->get_query($country_sql);

                    if (!$country_data) {
                        continue;//如果没有相应的推广国家
                    }else{
                        $country_data = $country_data[0];
                    }
                    //验证当前时间的offer是否是可以开放的状态
                    $sql = "select * from offer_effective_log where offer_id=".$info['offer_id']." and effective_time<=".$result['date']." and status=1";
                    $effective = $this->offer_effective_log_model->get_query($sql);

                    if (!$effective) {
                        continue;
                    }
                    //1、验证当前国家是否在当前这个offer包含的国家中{必须当期那时间段}，如果没有直接跳过，不算收入
                    if ($info['status'] != 1) {//如果没有审核通过，直接跳过
                        continue;
                    }

                    //a  验证是否推广全部国家
                    if ($country_data['country']=='') {
                        $offer_info = $info;
                        list($vars['retention_info'], $vars['revenue'], $vars['expect_revenue'], $vars['retention'], $vars['cpa'], $vars['day0'], $vars['day1']) = $this->getRevenue($product_info, $info, $result);
                        break;
                    }


                    $country = json_decode($country_data['country'], true);
                    //b 验证在不在包含国家里
                    if (in_array($result['country'], $country)  && $country_data['choose_type']=='include') {
                        $offer_info = $info;
                        list($vars['retention_info'], $vars['revenue'], $vars['expect_revenue'], $vars['retention'], $vars['cpa'], $vars['day0'], $vars['day1']) = $this->getRevenue($product_info, $info, $result);
                        break;
                    }
                }

                //先看下是否在包含国家了，如果包含国家里没有，再看排除国家
                if (!$offer_info) {
                    foreach ($offer_list as $key => $info) {

                        $country_sql = "select * from offer_country_log
                                    where offer_id=".$info['offer_id']." and start_time<=".$result['date']."
                                    ORDER BY offer_country_log.start_time desc,offer_country_log.addtime desc limit 1";
                        $country_data = $this->offer_country_log_model->get_query($country_sql);

                        if (!$country_data) {
                            continue;//如果没有相应的推广国家
                        }else{
                            $country_data = $country_data[0];
                        }

                        //验证当前时间的offer是否是可以开放的状态
                        $sql = "select * from offer_effective_log where offer_id=".$info['offer_id']." and effective_time<=".$result['date']." and status=1";
                        $effective = $this->offer_effective_log_model->get_query($sql);
                        if (!$effective) {
                            continue;
                        }

                        $country = json_decode($country_data['country'], true);

                        //c  验证是否在排除的国家里
                        if (in_array($result['country'], $country) && $country_data['choose_type']=='exclude') {
                            //不执行
                        }else{
                            $offer_info = $info;
                            list($vars['retention_info'], $vars['revenue'], $vars['expect_revenue'], $vars['retention'], $vars['cpa'], $vars['day0'], $vars['day1']) = $this->getRevenue($product_info, $info, $result);
                            break;
                        }
                    }
                }
            }

            $vars['product_id'] = $product_info['product_id'];
            $vars['product_name'] = $product_info['name'];

            $vars['advertiser_id'] = $product_info['user_id'];
            $vars['advertiser_name'] = $product_info['user_name'];
               
        }

        $vars['adset_name'] = $result['adset_name'];
        $vars['campaign_name'] = $result['campaign_name'];
        $vars['account_name'] = $result['account_name'];

        

        if ($offer_info) {
            $vars['publisher_id'] = $offer_info['publisher_id'];
            $vars['publisher_name'] = $offer_info['publisher_name'];
            
            $vars['offer_id'] = $offer_info['offer_id'];

            $offer_info = $this->offer_model->get_by_id($vars['offer_id']);
            $vars['rpa'] = $offer_info['rpa'];
        }

        if (isset($vars['product_id']) && $vars['product_id'] && isset($vars['publisher_id'])) {
            $date = strtotime(date('Y-m', $vars['date']));
            $month_info = $this->adset_country_month_log_model->get_by_fields(['publisher_id'=>$vars['publisher_id'], 'product_id'=>$vars['product_id'], 'country'=>$vars['country'], 'date'=>$date]);
            if ($month_info && isset($vars['retention_info'])&&$vars['retention_info']) {
                $retention_info = json_decode($vars['retention_info'], true);
                $payment_ratio = $this->get_payment_ratio($retention_info, $month_info['value'], $vars['retention']);

                $payment_ratio = $payment_ratio>1?1:$payment_ratio;
                $vars['real_earning'] = $payment_ratio*$vars['expect_revenue'];
                $vars['payment_ratio'] = sprintf("%.2f", $payment_ratio*100);
            }
        }

        //如果为fix价格，直接生成收入
        if (isset($vars['retention_info'])&&$vars['retention_info']) {
            $retention_info = json_decode($vars['retention_info'], true);
            if ($retention_info['type']=='retention' && $retention_info['retention']['category']==1) {
                $vars['real_earning'] = $vars['revenue'];
            }
        }


        $vars['date_year'] = date('Y', $vars['date']);
        $vars['date_month'] = date('M', $vars['date']);
        $vars['date_day'] = date('d', $vars['date']);
        $vars['date_week'] = date('W', $vars['date']);
        $vars['adset_id_country'] = $vars['adset_id']."_".$vars['country'];

        $vars = $this->get_fields($vars);

        $table_name = $this->get_dynamodb_table('marketmax_reports', 'adset_id_country', $vars['date']);
        $data = $this->aws_dynamodb->putItem($table_name, json_encode($vars));
        if ($data!=200) {
            fetch_exception($vars['account_id'], 'fetch_adset_country_insights_by_dynamodb', "Dynamodb put data error");
        }
    }

    public function get_fields($vars)
    {
        $fields = ['date'=>0, 'adset_id_country'=>' ', 'account_id'=>0, 'account_name'=>' ', 'adset_id'=>0, 'adset_name'=>' ',
                'campaign_id'=>0, 'campaign_name'=>' ', 'clicks'=>0, 'clicks_link'=>0, 'cost'=>' ', 'country'=>' ', 
                'cpa'=>'0', 'cpc'=>' ', 'cpm'=>' ', 'ctr'=>' ', 'date_day'=>0, 'date_week'=>0, 'date_month'=>0, 'date_year'=>0, 
                'day0'=>0, 'day1'=>0, 'expect_revenue'=>'0', 'frequency'=>' ', 'impressions'=>0, 'offer_id'=>0,
                'payment_ratio'=>'0', 'product_id'=>0, 'product_name'=>' ','publisher_id'=>0, 'publisher_name'=>' ','advertiser_id'=>0, 'advertiser_name'=>' ',
                'reach'=>' ', 'real_earning'=>'0', 'results'=>0, 'retention'=>'0', 'retention_info'=>' ', 'revenue'=>'0', 'rpa'=>'0', 'spend'=>'0'
        ];

        foreach ($fields as $key => $value) {
            if (!isset($vars[$key])) {
                $vars[$key] = $value;
            }
        }

        return $vars;
    }


    /**
     * 获取当前使用的表名称
     * 每个月都要创建一个新表
     * @return [type] [description]
     */
    private function get_dynamodb_table($table, $sort_key, $date='')
    {
        $table_name = $table."_".date('Y-m');
        if ($date) {
            $table_name = $table."_".date('Y-m', $date);
        }
        $table_list = $this->aws_dynamodb->listTables();
        if (in_array($table_name, $table_list)) {
            return $table_name;
        }else{
            $params = [
                'TableName' => $table_name,
                'KeySchema' => [
                    [
                        'AttributeName' => 'date',
                        'KeyType' => 'HASH'  //Partition key
                    ],
                    [
                        'AttributeName' => $sort_key,
                        'KeyType' => 'RANGE'  //Sort key
                    ]
                ],
                'AttributeDefinitions' => [
                    [
                        'AttributeName' => 'date',
                        'AttributeType' => 'N'
                    ],
                    [
                        'AttributeName' => $sort_key,
                        'AttributeType' => 'S'
                    ]
                ],
                'ProvisionedThroughput' => [
                    'ReadCapacityUnits' => 200,
                    'WriteCapacityUnits' => 20
                ]
            ];
            $data = $this->aws_dynamodb->createTable($params);
            sleep(10);
        }
        return $table_name;
    }


    /**
     * 获取抓取数据时所使用的token
     * @param string $value [description]
     */
    private function get_token_user($account_id)
    {
        return config_item('FACEBOOK_TOKEN');
        $publisherinfo = $this->publisher_adaccount_model->get_all(['account_id'=>$account_id, 'publisher_type'=>1]);
        if ($publisherinfo) {
            foreach ($publisherinfo as $value) {
                if ($value['business_id']) {
                    $business_info = $this->business_model->get_by_id($value['market_business_id']);
                    if ($business_info && $business_info['token']) {
                        return $business_info['token'];
                    }else{
                        return $value['publisher_id'];
                    }
                }else{
                    return $value['publisher_id'];
                }
                
            }
        }
    }

 
    /**
     * 数据同步{昨天数据}
     * @return [type] [description]
     */
    public function sync($publisher_id, $account_id, $date='')
    {
        if (!$date) {
            $date = date('Y-m-d', strtotime('-1 day'));
        }
        if ($account_id) {
            $publisherinfo = $this->publisher_adaccount_model->get_by_fields(['account_id'=>$account_id, 'publisher_id'=>$publisher_id]);
            if ($publisherinfo) {
                $user_id = $this->get_token_user($account_id);
                if (!$user_id) {
                    fetch_exception($account_id, 'fetch_account', 'account_id:'.$account_id.' 未找到Token', $date);
                    return ['success'=>false, 'message'=>'account_id:'.$account_id.' 未找到Token'];
                }
                if (is_numeric($user_id)) {
                    $user_info = $this->user_model->get_by_id($user_id);
                    if (!$user_info) {
                        fetch_exception($account_id, 'fetch_account', 'account_id:'.$account_id.' 未找到Token', $date);
                        return ['success'=>false, 'message'=>'account_id:'.$account_id.' 未找到Token'];
                    }
                    if (!$user_info['token']) {
                        fetch_exception($account_id, 'fetch_account', 'account_id:'.$account_id.' 未找到Token', $date);
                        return ['success'=>false, 'message'=>'account_id:'.$account_id.' 未找到Token'];
                    }

                    $this->load->library('facebookapi', ['user_id'=>$user_id]);
                }else{
                    $this->load->library('facebookapi', ['token'=>$user_id]);
                }
                
                $accountinfo = $this->adaccount_model->get_by_fields(['account_id'=>$account_id]);
                $this->setCampaign($publisher_id, $accountinfo, $date);

                $this->setAdset($publisher_id, $accountinfo, $date);

                //测试临时关掉
                $this->adaccount_model->update_row_by_fields(['account_id'=>$account_id], ['lasttime'=>strtotime('Y-m-d')]);
                return ['success'=>true, 'message'=>'account_id:'.$account_id.' 同步完成'];
            }
            return ['success'=>false, 'message'=>'account_id:'.$account_id." 数据库中没有找到"];
        }
        return ['success'=>false, 'message'=>'参数丢失'];
    }


    /**
     * 在设置月留存时，获取广告主要求的留存进行设置
     * @param  string $value [description]
     * @return [type]        [description]
     */
    public function get_require_rentention($product_id, $country, $date)
    {
        $start  = strtotime(date('Y-m', $date));
        $end    = strtotime(date('Y-m', $date)." +1 month"); 
        $sql = "SELECT payout.value
                FROM offer 
                RIGHT JOIN payout ON offer.offer_id = payout.offer_id
                where offer.countries like '%".$country."%' and offer.product_id=".$product_id."
                order by payout.start_time desc
                limit 1
                ";
        $payout = $this->adset_model->get_query($sql);
        if ($payout) {
            return $payout[0]['value']?$payout[0]['value']:0;
        }
        return 0;
    }



    /**
     * 更新月留存的平均值
     * @param string $value [description]
     */ 
    public function set_adset_country_month_avg($advertiser_id, $publisher_id, $product_id, $country, $date, $day0, $day1)
    { 
        $this->load->model('adset_country_month_log_model');

        $sql = "select * from adset_country_month_log where publisher_id=".$publisher_id." and product_id=".$product_id." and country='".$country."' and date=".strtotime(date('Y-m', $date));

        $month_info = $this->adset_country_month_log_model->get_query($sql);

        $date_d = date('Y-m',$date);
        $start = strtotime(date('Y-m', $date));
        $end = strtotime(date('m/d/Y', strtotime("$date_d +1 month -1 day")));

        $retention_sql = "select sum(`day0`) as day0, sum(`day1`) as day1 from adset_retention where publisher_id=".$publisher_id." and product_id=".$product_id." and country='".$country."' and date>=".$start." and date<=".$end;

        $adset_retention = $this->adset_retention_model->get_query($retention_sql);

        $retention = $this->get_require_rentention($product_id, $country, $date);

        //var_dump($adset_retention);die();
        if ($adset_retention) {
            if ($month_info) {
                //log_message("debug", var_export($month_info, true));

                $vars['set_retention'] = $retention;
                $vars['day0'] = $adset_retention[0]['day0'];
                $vars['day1'] = $adset_retention[0]['day1'];
                $vars['value'] = $vars['day0']>0?sprintf("%.2f", $vars['day1']/$vars['day0']*100):0;
                
                //$vars['value'] = $vars['value']>100?100:$vars['value'];

                $this->adset_country_month_log_model->update_row_by_id($month_info[0]['log_id'], $vars);
            }else{
                $vars = ['publisher_id'=>$publisher_id, 'product_id'=>$product_id, 'country'=>$country, 'date'=>strtotime(date('Y-m', $date))];
                $vars['set_retention'] = $retention;
                $vars['day0'] = $day0 = $adset_retention[0]['day0'];
                $vars['day1'] = $day1 = $adset_retention[0]['day1'];
                $vars['advertiser_id'] = $advertiser_id;
                $vars['value'] = $day0>0?sprintf("%.2f", $day1/$day0*100):0;

                //$vars['value'] = $vars['value']>100?100:$vars['value'];

                $this->adset_country_month_log_model->add_one($vars);
            }
        }
        
    }



    /**
     * 如果更新留存率，直接将对应的收入报表更新
     * @param  [type] $date      [description]
     * @param  [type] $adset_id  [description]
     * @param  [type] $country   [description]
     * @param  [type] $day0      [description]
     * @param  [type] $day1      [description]
     * @param  [type] $retention [description]
     * @return [type]            [description]
     */ 
    public function update_revenue_by_retention($date, $adset_id, $country, $day0, $day1, $retention)
    {
        $table_name = 'marketmax_reports_'.date('Y', $date);
        $key = ['adset_id_country'=>$adset_id."_".$country, 'date'=>$date];

        $report_info = $this->aws_dynamodb->getItem($table_name, json_encode($key));
        if (!$report_info) {
            return false;
        }

        if ($report_info && $report_info['offer_id']) {
            //找到对应的offer
            $offer_info = $this->publisher_offer_model->get_by_fields(['status'=>1, 'offer_id'=>$report_info['offer_id'], 'publisher_id'=>$report_info['publisher_id']]);
            if (!$offer_info) {
                return '';
            }
            $offer_id = $offer_info['offer_id'];
            $publisher_id = $offer_info['publisher_id'];

            $retention_data = $this->adset_retention_model->get_by_fields(['date'=>$date, 'adset_id'=>$adset_id, 'country'=>$country]);
            if ($retention_data) {
                $retention = $retention_data['retention'];
                $day0 = $retention_data['day0'];
                $day1 = $retention_data['day1'];
            }

            $revenue = 0;

            $specific_data = $this->offer_model->get_current_specific_payout($offer_info['offer_id'], $offer_info['publisher_id'], $date);

            if ($specific_data) {//如果有特殊价格
                $revenue = $specific_data['payout']*$report_info['results'];

                $cpa_data = ['offer_id'=>$offer_id, 'user_id'=>$publisher_id, 'cpa'=>$specific_data['payout'],
                                'type'=>'specific', 'retention'=>''];

                $origin_cpa = $cpa = $specific_data['payout'];
                $expect_revenue = $cpa*$report_info['results'];//预计收入
            }else{//没有特殊价格
                $cpa_data = $this->offer_model->get_current_cpa_log($offer_id, $date);

                $cpa_data['retention'] = $cpa_data;
                $cpa_data['user_id'] = $publisher_id;
                $cpa_data['type'] = 'retention';
                if ($cpa_data) {
                    $origin_cpa = $cpa = $cpa_data['cpa'];
                    $expect_revenue = $cpa*$report_info['results'];//预计收入

                    if ($cpa_data['category']==1) {//固定价格，预计收入结算
                        $revenue = $expect_revenue;
                    }elseif ($cpa_data['category']==2 && $retention_data){//阶梯价{必须要有留存数}
                        $retention_rate = $retention_data['retention'];
                        foreach ($cpa_data['value'] as $key => $value) {
                            $set_retention_rate[$value['retention_rate']] = $value['payout_rate'];
                        }
                        $set_cpa = 0;
                        krsort($set_retention_rate);
                        foreach ($set_retention_rate as $k => $v) {
                            if ($retention_rate>=$k/100) {//假如留存率大于指定值，就按指定值算，如果匹配不上则，直接收入为0
                                //$set_cpa = $cpa*$v/100;
                                $revenue = $expect_revenue*$v/100;
                                break;
                            }
                        }
                    }elseif ($cpa_data['category']==3 && $retention_data){//等比例价格{必须要有留存数}
                        $retention_rate = $retention_data['retention'];
                        $results = $report_info['results'];
                        if ($retention_rate<($cpa_data['value']/100)) {
                            $retention_value = $cpa_data['value']/100;//后台设置的留存值
                            //$cpa = (1-($retention_value-$retention_rate)/$retention_value)*$cpa;
                            
                            $results = (1-($retention_value-$retention_rate)/$retention_value)*$report_info['results'];
                        }
                        $revenue = $cpa*$results;
                    }
                }
            }

            $report_info['revenue'] = $revenue;
            $report_info['day0'] = $day0;
            $report_info['day1'] = $day1;
            $report_info['retention'] = $retention;
            $report_info['retention_info'] = json_encode($cpa_data);

            //更新月平均留存
            $this->set_adset_country_month_avg($report_info['advertiser_id'], $report_info['publisher_id'], $report_info['product_id'], $report_info['country'], $report_info['date'], $report_info['day0'], $report_info['day1']);

            if ($report_info['product_id']) {
                $date = strtotime(date('Y-m', $report_info['date']));
                $month_info = $this->adset_country_month_log_model->get_by_fields(['publisher_id'=>$report_info['publisher_id'], 'product_id'=>$report_info['product_id'], 'country'=>$report_info['country'], 'date'=>$date]);
                if ($month_info && isset($report_info['retention_info'])&&$report_info['retention_info']) {
                    $retention_info = json_decode($report_info['retention_info'], true);
                    $payment_ratio = $this->get_payment_ratio($retention_info, $month_info['value'], $report_info['retention']);

                    $payment_ratio = $payment_ratio>1?1:$payment_ratio;
                    $report_info['real_earning'] = $payment_ratio*$report_info['expect_revenue'];
                    $report_info['payment_ratio'] = sprintf("%.2f", $payment_ratio*100);

                }
            }

            $this->aws_dynamodb->putItem($table_name, json_encode($report_info));
        }
        
    }

    

}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */