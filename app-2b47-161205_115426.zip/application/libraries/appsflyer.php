<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Appsflyer {

    //数据更新间隔时间
    var $_synctime = 3600;//一个小时

    var $api_token = "8ebdd420-64b6-457b-b31a-49ca50ae72d2";
    /**
    * 初使化
    */ 
    public function __construct()
    {       
        $this->_ci =& get_instance();

        $this->_ci->load->model('product_model');
    }


    //模拟登录 
    function login_post($url, $cookie, $post) { 
        $curl = curl_init();//初始化curl模块 
        curl_setopt($curl, CURLOPT_URL, $url);//登录提交的地址 
        curl_setopt($curl, CURLOPT_HEADER, 0);//是否显示头信息 
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 0);//是否自动显示返回的信息 
        curl_setopt($curl, CURLOPT_COOKIEJAR, $cookie); //设置Cookie信息保存在指定的文件中 
        curl_setopt($curl, CURLOPT_POST, 1);//post方式提交 
        curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($post));//要提交的信息 
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($curl, CURLOPT_FOLLOWLOCATION,1);

        curl_exec($curl);//执行cURL 
        $info = curl_getinfo($curl,CURLINFO_EFFECTIVE_URL);
        
        var_dump($info);
        curl_setopt($curl, CURLOPT_URL, $info); 
        curl_setopt($curl, CURLOPT_HEADER, 0); 
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1); 
        curl_setopt($curl, CURLOPT_COOKIEFILE, $cookie); //读取cookie 
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
        $rs = curl_exec($curl); //执行cURL抓取页面内容 

        curl_close($curl);//关闭cURL资源，并且释放系统资源 
        return $rs;
    } 

 
    public function sync($product, $start_date, $end_date, $retention_day)
    {
        $this->_ci->load->model('adset_retention_model');
        $this->_ci->load->model('reports_model');
        $this->_ci->load->model('publisher_offer_model');
        $this->_ci->load->library('aws_sqs');

        $this->_ci->load->library('aws_dynamodb');
        $this->_ci->load->library('fetch_adset_data');

        //$start_date = $start_date;
        //$end_date   = $end_date;
        //$product = "com.ss.android.article.mynews.br";
        //$product = "com.ss.android.article.master";

        $post = array ( 
            'username' => 'lucas@palmax.com', 
            'password' => 'qlbfwlxp306',
            'googletoken' => '',
            'googleaccesstoken'=>''
        ); 
        log_message('debug','fetch_appsflyer_data. Starting.-> Product : ' . $product. ' Start : '.$start_date.' End : '.$end_date);
        //登录地址 
        $url = "https://hq1.appsflyer.com/auth?devmode=False&next=".urlencode("https://hq1.appsflyer.com/retention/data/".$product."/daily/".$start_date."/".$end_date."/?filters=[]&grouping=[:fb_adset%20:geo%20:cohort_day]&install_amount=10&limit=1000"); 
        $url = "https://hq1.appsflyer.com/auth?devmode=False&next=".urlencode("https://hq1.appsflyer.com/retention/data/".$product."/daily/".$start_date."/".$end_date."/?filters=%5B%5D&install_amount=10&grouping=%5B:cohort_day%20:geo%20:fb_adset%20:campaign%5D&csv=true"); 
        $cookie = './uploads/cookie_oschina.txt'; 

        $data = $this->login_post($url, $cookie, $post); 
        if (!$data) {
            log_message('debug','fetch_appsflyer_data. retention is empty.-> Product : ' . $product. ' Start : '.$start_date.' End : '.$end_date);
            return false;
        }
        $product_id = "";

        foreach (explode("\n", $data) as $key=>$row) {
            if ($key==0) {
                continue;
            }

            $item = explode(',', $row);

            if (!isset($item[2])) {
                continue;
            }

            $adset_name = $item[2];

            if ($s = strpos($item[2], "_Instagram")) {
                $adset_name = substr($item[2], 0, $s);
            }

            
            if ($s = strpos($item[2], "_AudienceNetwork")) {
                $adset_name = substr($item[2], 0, $s);
            }

            if (!isset($item[3])) {
                continue;
            }


            $campaign_name = $item[3];

            if ($s = strpos($campaign_name, "_Instagram")) {
                $campaign_name = substr($campaign_name, 0, $s);
            }

            
            if ($s = strpos($campaign_name, "_AudienceNetwork")) {
                $campaign_name = substr($campaign_name, 0, $s);
            }

            $adset_info = $this->_ci->reports_model->get_report_data("select adset_id,adset_name,product_id,advertiser_id,app_id,account_id,account_name,campaign_id,campaign_name from marketmax_reports where campaign_name='".$campaign_name."' and adset_name='".$adset_name."' limit 1");
            
            if (!$adset_info) {
                continue;
            }
            $adset_id = $adset_info[0]['adset_id'];
            $country = $item[1];
            $date = $item[0];
            $retention = 0;
            if (isset($item[4+$retention_day])) {
                $retention = $item[4]?sprintf("%.4f", $item[4+$retention_day]/$item[4]):0;
            }
            

            $vars = ['adset_id'=>$adset_id, 'adset_name'=>$item[2], 'country'=>strtoupper($country), 'date'=>strtotime($date), 'day0'=>intval($item[4]), 'retention'=>$retention];

            $product_id = $vars['product_id'] = $adset_info[0]['product_id'];
            $vars['advertiser_id'] = $adset_info[0]['advertiser_id'];
            $vars['account_id'] = $adset_info[0]['account_id'];
            $vars['account_name'] = $adset_info[0]['account_name'];
            $vars['campaign_name'] = $adset_info[0]['campaign_name'];
            $vars['campaign_id'] = $adset_info[0]['campaign_id'];

            $j=1;
            for ($i=5; $i <= 30; $i++) { 
                if (isset($item[$i])) {
                    $vars['day'.$j] = intval($item[$i]);
                    $j++;
                }
            }

            if ($product_id) {
                $this->_ci->product_model->update_row_by_id($product_id, ['retention_updated_time'=>time()]);
            }


            $info = $this->_ci->adset_retention_model->get_by_fields(['adset_name'=>$item[2], 'adset_id'=>$adset_id, 'country'=>strtoupper($country), 'date'=>strtotime($date)]);
            if ($info) {
                $this->_ci->adset_retention_model->update_row_by_id($info['retention_id'], $vars);
            }else{
                $this->_ci->adset_retention_model->add_one($vars);
            }


            
            //更新报表数据
            $this->_ci->fetch_adset_data->update_revenue_by_retention($vars['date'], $vars['adset_id'], $vars['country']);
        }
        
        log_message('debug','fetch_appsflyer_data. End.-> Product : ' . $product. ' Start : '.$start_date.' End : '.$end_date);
        
    }
}