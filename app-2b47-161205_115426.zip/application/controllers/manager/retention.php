<?php if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

/**
 *
 * Created by PhpStorm.
 * User: palmax
 * Date: 2016/4/26
 * Time: 15:10
 */
class Retention extends Web_Controller
{
    public function __construct()
    {
        parent::__construct();

        $this->load->library('validation');
        $this->load->model('user_model');
        $this->load->model('company_model');
        $this->load->model('offer_model');
        $this->load->model('publisher_adaccount_model');
        $this->load->library('validation');
        $this->load->library('pagination');

        $this->data['top_menu']=$this->load->view('web/top_menu_manager', '', TRUE);
    }

    public function import()
    {
        $template='manager_retention_import';
        $this->template->build($template, $this->data);
    }

    public function upload()
    {
        if ($this->input->is_ajax_request()) {

            if (!$_FILES) {
                $response=['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
            } else {
                $file=upload_aws();

                if (!$file['error']) {

                    $this->load->library('aws_sqs');
                    $this->load->library('aws');
                    $this->load->library('excelreader');
                    $filename=$this->aws->getPath(config_item('Marketmax_Generalfile'), $file['message']);
                    $data=$this->excelreader->getExcelInfo($filename);

                    if ($data && $data['result']) {
                        $date_data=[];
                        foreach ($data['result'] as $key=>$row) {
                            if (!in_array($row[0], $date_data)) {
                                $date_data[]=$row[0];

                                $message=array('filename'=>$file['message'], 'event'=>'upload_retention', 'bucket'=>config_item('Marketmax_Generalfile'), 'date'=>$row[0]);
                                log_message("debug", "queue_upload_retention: Push Filename:" . $message['filename'] . " ---date:" . $row[0]);
                                $this->aws_sqs->deliver($message);
                            }
                        }
                    }

                    $response=['success'=>true, 'msg'=>$this->lang->line('success_done'), 'data'=>$file['message']];
                } else {
                    log_message("debug", "queue_upload_retention: Push Filename Failed");
                    $response=['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
                }
            }

        } else {
            $response=['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
        }
        $this->output->set_content_type('applicaion/json')->set_output(json_encode($response));
    }


    public function upload_appsflyer()
    {
        if ($this->input->is_ajax_request()) {

            if (!$_FILES) {
                $response=['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
            } else {
                $file=upload_aws();

                if (!$file['error']) {

                    $this->load->library('aws_sqs');
                    $this->load->library('aws');
                    $this->load->library('excelreader');
                    $filename=$this->aws->getPath(config_item('Marketmax_Generalfile'), $file['message']);
                    $data=$this->excelreader->getExcelInfo($filename);

                    if ($data && $data['result']) {
                        $date_data=[];
                        foreach ($data['result'] as $key=>$row) {
                            if ($key == 0) {
                                continue;
                            }
                            if (!in_array($row[0], $date_data)) {
                                $date_data[]=$row[0];

                                $message=array('filename'=>$file['message'], 'event'=>'upload_retention_appsflyer', 'bucket'=>config_item('Marketmax_Generalfile'), 'date'=>$row[0]);
                                log_message("debug", "queue_upload_retention_appsflye: Push Filename:" . $message['filename'] . " ---date:" . $row[0]);
                                $this->aws_sqs->deliver($message);
                            }
                        }
                    }

                    $response=['success'=>true, 'msg'=>$this->lang->line('success_done'), 'data'=>$file['message']];
                } else {
                    log_message("debug", "queue_upload_retention: Push Filename Failed");
                    $response=['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
                }
            }

        } else {
            $response=['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
        }
        $this->output->set_content_type('applicaion/json')->set_output(json_encode($response));
    }

    public function upload_go()
    {
        
        if ($this->input->is_ajax_request()) {
            if (!$_FILES) {
                $response=['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
            } else {
                $file=upload_aws();

                if (!$file['error']) {

                    $this->load->library('aws_sqs');
                    $this->load->library('aws');
                    $this->load->library('excelreader');
                    $filename=$this->aws->getPath(config_item('Marketmax_Generalfile'), $file['message']);
                    $data=$this->excelreader->getExcelInfo($filename);

                    if ($data && $data['result']) {
                        $date_data=[];
                        foreach ($data['result'] as $key=>$row) {
                            if ($key == 0) {
                                continue;
                            }
                            if (!in_array($row[0], $date_data)) {
                                $date_data[]=$row[0];

                                $message=array('filename'=>$file['message'], 'event'=>'upload_retention_go', 'bucket'=>config_item('Marketmax_Generalfile'), 'date'=>$row[0]);
                                log_message("debug", "queue_upload_retention_go: Push Filename:" . $message['filename'] . " ---date:" . $row[0]);
                                $this->aws_sqs->deliver($message);
                            }
                        }
                    }

                    $response=['success'=>true, 'msg'=>$this->lang->line('success_done'), 'data'=>$file['message']];
                } else {
                    log_message("debug", "queue_upload_retention: Push Filename Failed");
                    $response=['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
                }
            }

        } else {
            $response=['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
        }
        $this->output->set_content_type('applicaion/json')->set_output(json_encode($response));
    }
}