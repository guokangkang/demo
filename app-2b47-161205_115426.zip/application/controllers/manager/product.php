<?php if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

/**
 *
 * Created by PhpStorm.
 * User: palmax
 * Date: 2016/4/26
 * Time: 15:10
 */
class Product extends Web_Controller
{
    public function __construct()
    {
        parent::__construct();

        $this->load->model('product_model');
        $this->load->model('user_model');

        $this->load->library('pagination');

        $this->data['top_menu']=$this->load->view('web/top_menu_manager', '', TRUE);
    }

    public function listview()
    {
        $where = "1 = 1";
        
        $config['base_url'] = site_url('manager/product/listview?');
        if ($this->input->get('q')) {
            $q = trim($this->input->get('q'));
            $q && $where .= " and name like '%$q%'";
            $config['base_url'] = site_url('manager/product/listview?q='.$q);
        }
        if (is_numeric($this->input->get('status')) && $this->input->get('status')) {
            $where .= " and status = ".$this->input->get('status');
            $config['base_url'] .= "&status=".$this->input->get('status');
        }

        $total_rows = $this->product_model->get_one("select count(*) as count from product where ".$where);
        
        $config = get_web_page($config, $total_rows['count'], 4);
        $page = 1;
        if ($this->input->get('page'))
            $page = $this->input->get('page');

        $limit = $config['per_page'] = 10;

        $this->pagination->initialize($config);
        $this->data['page_links'] = $this->pagination->create_links();

        $sql = "select * from product where ".$where." order by addtime desc LIMIT ".($page - 1) * $limit.", ".$limit;
        
        $listview = $this->product_model->get_query($sql);

        foreach ($listview as $key => & $item) {
            if ($item['category']=='android') {
                $item['score_info'] = json_decode($item['score_info'], true);
                if ($item['score_info']) {
                    foreach ($item['score_info'] as $k => &$v) {
                        $v = str_replace(',', '', $v);
                    }
                }
            }
            if (!$item['score']) {
                $item['score'] = 4.5;
            }
        }
        $this->data['listview'] = $listview;

        $template='manager_product_listview';
        $this->template->build($template, $this->data);
    }


    /**
     * 删除产品信息
     * @return [type] [description]
     */
    public function del_product_action()
    {
        if ($this->input->is_ajax_request()) {
            $userInfo=$this->userinfo;
            $prouduct_id=$this->input->post('product_id', true);
            if ($prouduct_id) {
                $where=array('product_id'=>$prouduct_id);
                $res=$this->product_model->update_row_by_fields($where, ['status'=>-1]);
                if ($res) {
                    $response=['success'=>true, 'msg'=>$this->lang->line('success_delete')];
                } else {
                    $response=['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
                }
            } else {
                $response=['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
            }
        } else {
            $response=['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
        }
        $this->output->set_content_type('applicaion/json')->set_output(json_encode($response));

    }

    public function find()
    {
        $template='manager_product_find';
        $this->template->build($template, $this->data);
    }


    /**
     * 确认完成产品
     * @param  string $value [description]
     * @return [type]        [description]
     */
    public function confirm($value='')
    {
        if (!$this->input->get('product')) {
            redirect('manager/product/listview');
            die();
        }
        $product_id=intval($this->input->get('product'), 0);
        if (!isset($product_id)) {
            redirect('manager/product/listview');
            die();
        }
        $product=$this->product_model->get_by_id($product_id);
        if (!$product) {
            redirect('manager/product/listview');
            die();
        }
        $this->data['info']=$product;
        //var_dump($product);die();

        $sql="select * from user where type=1";
        $this->data['advertiserlist']=$this->user_model->get_query($sql);

        $template='manager_product_confirm';
        $this->template->build($template, $this->data);
    }

    public function form_confirm_action($value='')
    {
        if (IS_POST) {
            if (!$this->input->post('product_id')) {
                $this->error($this->lang->line('notice_bad_request'));
            }
            $product_id=$this->input->post('product_id');
            $product_name=$this->input->post('input_product_name');
            $retention_days=$this->input->post('retention_days');
            $retention_source=$this->input->post('retention_source');

            
            if (!is_numeric($retention_days)) {
                $this->error($this->lang->line('notice_bad_request'));
            }

            $info=$this->product_model->get_by_id($product_id);
            if (!$info) {
                $this->error($this->lang->line('notice_bad_request'));
            }

            $advertiser_info=[];
            if ($this->input->post('select_advertiser')) {
                $advertiser_id=$this->input->post('select_advertiser');
                $advertiser_info=$this->user_model->get_by_id($advertiser_id);
                if (!$advertiser_info) {
                    $this->error($this->lang->line('notice_bad_request'));
                }
            }


            $desc=$this->input->post('input_desc');
            $this->load->library('validation');
            $desc=$this->validation->checkInput($desc);
            $name=$this->validation->checkInput($product_name);
            $retention_day=$this->validation->checkInput($retention_days);

            $vars=['description'=>$desc, 'status'=>1, 'name'=>$name, 'retention_day'=>$retention_day];
            $vars['retention_source'] = $retention_source;
            
            if ($advertiser_info) {
                $vars['user_id']=$advertiser_id;
                $vars['user_name']=$advertiser_info['user_name'];
            }
            $this->product_model->update_row_by_id($product_id, $vars);

            $this->success($this->lang->line('success_done'), 'manager/product/listview');
        } else {
            $this->error($this->lang->line('notice_bad_request'));
        }
    }


    /**
     * 获取产品信息
     * @return [type] [description]
     */
    public function app_item()
    {
        if ($this->input->is_ajax_request()) {
            $this->load->model('product_model');
            if (!$this->input->get('item_id')) {
                $response=['success'=>false, 'msg'=>$this->lang->line('notice_params_empty')];
                $this->output->set_content_type('applicaion/json')->set_output(json_encode($response));
                die();
            }
            $item_id=$this->input->get('item_id');
            if (strpos($item_id, "google") !== false) {
                $category="android";
            } elseif (strpos($item_id, "itunes") !== false) {
                $category="ios";
            } else {
                $response=['success'=>false, 'msg'=>$this->lang->line('notice_not_find')];
                $this->output->set_content_type('applicaion/json')->set_output(json_encode($response));
                die();
            }

            if ($category == 'android') {
                //$url = "http://search.voga360.com/api/search.htm?q=".$item_id;
                //获取app信息
                if ($index=strpos($item_id, "=")) {
                    $app_id=$play_id=substr($item_id, $index + 1);
                    $this->load->library('playapi');
                    $data=$this->playapi->getPackage($play_id);
                } else {
                    $response=['success'=>false, 'msg'=>$this->lang->line('notice_not_find')];
                    $this->output->set_content_type('applicaion/json')->set_output(json_encode($response));
                    die();
                }

            } elseif ($category == 'ios') {
                //获取app信息
                $index=strpos($item_id, "/id");
                if ($index=strpos($item_id, "/id")) {
                    //$app_id = $itunes_id = substr($item_id, $index+3, 9);
                    if (strpos($item_id, '?') === false) {
                        $app_id=$itunes_id=substr($item_id, $index + 3);
                    } else {
                        $end=strpos($item_id, '?');
                        $app_id=$itunes_id=substr($item_id, $index + 3, $end - ($index + 3));
                    }
                    $url="http://itunes.apple.com/lookup?id=" . $itunes_id;
                    $this->load->library('curl');
                    $data=$this->curl->simple_get($url);
                    $data=json_decode($data, true);
                } else {
                    $response=['success'=>false, 'msg'=>$this->lang->line('notice_not_find')];
                    $this->output->set_content_type('applicaion/json')->set_output(json_encode($response));
                    die();
                }
            }

            $result=[];
            if ($data) {
                if ($category == 'android') {
                    $googleurl=$item_id;
                    $result=['name'=>$data['name'], 'desc'=>$data['description'], 'app_id'=>$app_id, 'object_store_url'=>$googleurl, 'logo'=>$data['image'], 'category'=>$category, 'play_category'=>$data['category'], 'score'=>$data['score'], 'score_info'=>$data['score_info']];
                } else {
                    $tmp=$data['results']?$data['results'][0]:[];
                    $tmp && $result=['name'=>$tmp['trackCensoredName'], 'desc'=>$tmp['description'], 'app_id'=>$tmp['trackId'], 'object_store_url'=>$tmp['trackViewUrl'], 'logo'=>$tmp['artworkUrl512'], 'category'=>$category, 'play_category'=>$tmp['wrapperType'], 'score'=>isset($tmp['averageUserRating'])?$tmp['averageUserRating']:0, 'score_info'=>isset($tmp['userRatingCount'])?$tmp['userRatingCount']:0];
                }
                if (!$result) {
                    $response=['success'=>false, 'msg'=>$this->lang->line('notice_not_find')];
                    $this->output->set_content_type('applicaion/json')->set_output(json_encode($response));
                    die();
                }

                $product=$this->product_model->get_by_fields(['category'=>$category, 'app_id'=>$result['app_id']]);

                // if ($product && $product['user_id']!=$this->userinfo['user_id']) {
                //     $response = ['success'=>false, 'msg'=>$this->lang->line('notice_product_exists')];
                //     $this->output->set_content_type('applicaion/json')->set_output(json_encode($response));
                //     die();
                // }

            } else {
                $response=['success'=>false, 'msg'=>$this->lang->line('notice_not_find')];
                $this->output->set_content_type('applicaion/json')->set_output(json_encode($response));
                die();
            }
            $response=['success'=>true, 'msg'=>"success", 'data'=>$result];
        } else {
            $this->output->set_status_header('403');
            $response=['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
        }
        $this->output->set_content_type('applicaion/json')->set_output(json_encode($response));


    }

    /**
     * 下一步
     */
    public function add_product_action()
    {
        if ($this->input->is_ajax_request()) {
            $user_id=$this->userinfo['user_id'];
            $vars['user_id']=$user_id;
            $vars['category']=$this->input->post('category', true);
            $vars['play_category']=$this->input->post('play_category', true);
            $vars['app_id']=$this->input->post('app_id', true);
            $vars['app_desc']=$this->input->post('desc', true);
            $vars['name']=$this->input->post('name', true);
            $vars['object_store_url']=$this->input->post('object_store_url', true);
            $vars['logo']=$this->input->post('logo', true);
            $vars['score']=$this->input->post('score', true);
            $vars['score_info']=$this->input->post('score_info', true);

            $product=$this->product_model->get_by_fields(['category'=>$vars['category'], 'app_id'=>$vars['app_id']]);
            if (!$product) {
                $vars['status']=0;
                $product_id=$this->product_model->add_one($vars);
            } else {
                $this->product_model->update_row_by_id($product['product_id'], $vars);
                $product_id=$product['product_id'];
            }
            $response=['success'=>true, 'msg'=>"success", 'url'=>site_url('manager/product/confirm?product=' . $product_id)];

        } else {
            $this->output->set_status_header('403');
            $response=['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
        }
        $this->output->set_content_type('applicaion/json')->set_output(json_encode($response));
    }

}