<?php if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

/**
 *
 * Created by PhpStorm.
 * User: palmax
 * Date: 2016/4/26
 * Time: 15:10
 */
class User extends Web_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->library('validation');
        $this->load->model('user_model');
        $this->load->model('adaccount_model');
        $this->load->model('company_model');
        $this->load->model('offer_model');
        $this->load->model('publisher_adaccount_model');
        $this->load->library('validation');
        $this->load->library('pagination');

        //$this->data['top_menu']=$this->load->view('web/top_menu_setup', '', TRUE);
        $this->data['top_menu']=$this->load->view('web/top_menu_manager', '', TRUE);
    }

    /**
     * 添加系统管理员
     * @return [type] [description]
     */
    public function index()
    {
        $q=$this->input->get('q', true);
        $like=[];
        if ($q) {
            $like=['user_name'=>$q];
        }
        $this->load->model('manager_model');
        $data=$this->manager_model->get_all(['status'=>1, 'like'=>$like]);
        foreach ($data as $key=>& $value) {
            $value['head']='';
            $value['role']=json_decode($value['role'], true);
            $temps=explode(' ', $value['user_name']);
            if (count($temps) > 1) {
                foreach ($temps as $temp) {
                    $value['head'].=get_first_letters($temp);
                }
            } else {
                $value['head']=substr($value['user_name'], 0, 2);
            }
        }
        $this->data['data']=$data;
        $template='manager_user_index';
        $this->template->build($template, $this->data);
    }

    public function manager_info()
    {
        $this->load->model('manager_model');
        if ($this->input->is_ajax_request()) {
            if (!$this->input->get('manager_id')) {
                $response=['success'=>false, 'msg'=>$this->lang->line('notice_params_empty')];
            } else {
                $manager_id=$this->input->get('manager_id');
                $manager_info=$this->manager_model->get_by_id($manager_id);
                if (!$manager_info) {
                    $response=['success'=>false, 'msg'=>$this->lang->line('notice_params_empty')];
                } else {
                    $manager_info['role']=json_decode($manager_info['role'], true);
                    unset($manager_info['password']);
                    $response=['success'=>true, 'msg'=>"success", 'data'=>$manager_info];
                }
            }
        } else {
            $response=['success'=>false, 'msg'=>$this->lang->line('notice_params_empty')];
        }
        $this->output->set_content_type('applicaion/json')->set_output(json_encode($response));
    }


    /**
     * 添加管理员数据提交
     * @param string $value [description]
     */
    public function add_manager_action()
    {
        $this->load->model('manager_model');
        if (IS_POST) {
            if (!$this->input->post('select_role')) {
                $this->error($this->lang->line('notice_bad_request'), 'manager/user/index');
            }
            $role=$this->input->post('select_role');
            $name=trim($this->input->post('input_first_name'));
            $email=trim($this->input->post('input_email'));

            $vars['user_name']=$name;
            $vars['email']=$email;
            $vars['role']=json_encode($role);
            if ($this->input->post('manager')) {
                $info=$this->manager_model->get_by_fields(['email'=>$email]);
                if ($info && $info['manager_id'] != $this->input->post('manager')) {
                    $this->error("注册邮箱已经存在！！！", 'manager/user/index');
                }
                $this->manager_model->update_row_by_id($this->input->post('manager'), $vars);
            } else {
                $info=$this->manager_model->get_by_fields(['email'=>$email]);
                if ($info) {
                    $this->error("注册邮箱已经存在！！！", 'manager/user/index');
                }
                $vars['password']=password_hash('123456', PASSWORD_DEFAULT);
                $this->manager_model->add_one($vars);
            }
            $this->success($this->lang->line('success_done'), 'manager/user/index');
        } else {
            $this->error($this->lang->line('notice_bad_request'), 'manager/user/index');
        }
    }

    /**
     * 删除bucket
     * @return [type] [description]
     */
    public function del_manager_action()
    {
        $this->load->model('manager_model');
        if ($this->input->is_ajax_request()) {
            if ($this->input->post('manager_id')) {
                $manager_id=$this->input->post('manager_id');
                $this->manager_model->update_row_by_id($manager_id, ['status'=>-1]);
                $response=['success'=>true, 'msg'=>$this->lang->line('success_delete')];
            } else {
                $response=['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
            }
        } else {
            $response=['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
        }
        $this->output->set_content_type('applicaion/json')->set_output(json_encode($response));
    }

    /**
     * 广告主管理
     */
    public function advertiser()
    {
        //配置分页地址
        $config['base_url']=site_url('manager/user/advertiser?');
        $page=$this->input->get('page', true);
        $q=$this->input->get('q', true);
        if (!$page) {
            $page=1;
        }
        $like='';
        if ($q) {
            $like=" AND user_name like '%{$q}%'";
        }
        $count_sql="select user_id,first_name,last_name,user_name,email,head from user where type=1 AND status=1 $like";
        $total_rows=$this->user_model->get_query_count($count_sql);
        //分页开始
        $this->data['total_rows']=$total_rows;
        $config=get_web_page($config, $total_rows, 3);
        $limit=$config['per_page']=15;
        $this->pagination->initialize($config);
        $this->data['page_links']=$this->pagination->create_links();
        //加载国家
        $this->config->load('product', TRUE);
        $this->data['config_product']=$this->config->item('product');
        //获取数据
        $pages=($page - 1) * $limit;
        $sql="select user_id,first_name,last_name,user_name,email,head from user where type=1 AND status=1 $like LIMIT {$pages},{$limit}";
        $data=$this->user_model->get_query($sql);
        //处理数据
        if ($data) {
            // $letters='';
            foreach ($data as &$item) {
                $temps=explode(' ', $item['user_name']);
                if (count($temps) > 1) {
                    foreach ($temps as $temp) {
                        $item['head'].=get_first_letters($temp);
                    }
                } else {
                    $item['head']=substr($item['user_name'], 0, 2);
                }

            }
        }
        $this->data['data']=$data;
        $template='manager_user_advertiser';
        $this->template->build($template, $this->data);
    }

    /**
     * 编辑广告主信息
     * @return mixed
     */
    public function advertiser_edit_action()
    {
        if (IS_POST) {
            $post_data=$this->input->post(null, true);
            if (!$post_data) {
                redirect($this->input->server('HTTP_REFERER'));
            }
            $user_id=$post_data['user_id'];
            unset($post_data['user_id']);
            $update['email']=$post_data['input_email'];
            $update['user_name']=$post_data['input_user_name'];
            $update['first_name']=$post_data['input_user_name'];
            $update['company']=$post_data['input_company']?$post_data['input_company']:'';
            $update['country']=$post_data['select_country'];
            $update['type']=$post_data['input_type'];
            $update['contact']=$post_data['input_contact'];
            $update['invoice_payto']=$post_data['input_payto'];
            $update['invoice_company_name']=$post_data['input_company_name'];
            $update['invoice_phone']=$post_data['input_phone'];
            $update['invoice_address']=$post_data['input_address'];
            $update['invoice_pay_period']=$post_data['select_pay_period'];
            if ($user_id) {
                $this->user_model->update_row_by_id($user_id, $update);
                redirect($this->input->server('HTTP_REFERER'));
            } else {
                redirect($this->input->server('HTTP_REFERER'));
            }
        } else {
            $user_id=$this->input->get('user_id', true);
            if ($user_id) {
                $sql="select user_id,first_name,score,tags,last_name,user_name,email,company,country,contact,invoice_company_name,invoice_payto,invoice_address,invoice_phone,invoice_pay_period from user where user_id={$user_id} AND status=1";
                $data=$this->user_model->get_query($sql);
                $data=$data?$data[0]:[];
                return $this->output
                    ->set_content_type('application/json')
                    ->set_output(json_encode($data));
            }
        }
    }

    /**
     * advertiser 删除
     * @return mixed
     */
    public function del_advertiser_action()
    {
        if (IS_AJAX) {
            $user_id=$this->input->post('user_id', true);
            if ($user_id) {
                $result=$this->user_model->update_row_by_id($user_id, ['status'=>-1]);
                if ($result) {
                    $response=['success'=>true, 'msg'=>$this->lang->line('success_done')];
                } else {
                    $response=['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
                }
            } else {
                $response=['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
            }
            return $this->output->set_content_type('applicaion/json')->set_output(json_encode($response));
        }
    }

    /**
     * 流量主管理
     */
    public function publisher()
    {
        $this->config->load('product', TRUE);
        $this->data['config_product']=$this->config->item('product');
        $page=$this->input->get('page', true);
        $q=$this->input->get('q', true);
        //分页
        if (!$page) {
            $page=1;
        }
        //搜索
        $like='';
        if ($q) {
            $like=" AND `user`.user_name like '%{$q}%'";
        }
        $count_sql="SELECT user.*, company.name as company_name FROM `user` LEFT JOIN company ON `user`.company_id = company.company_id where `user`.type=2 AND `user`.status=1 and user.label !='' $like";
        $total_rows=$this->user_model->get_query_count($count_sql);
        //分页开始
        $config['base_url']=site_url('manager/user/publisher?');
        $this->data['total_rows']=$total_rows;
        $config=get_web_page($config, $total_rows, 3);
        $limit=$config['per_page']=15;
        $this->pagination->initialize($config);
        $this->data['page_links']=$this->pagination->create_links();
        //获取数据
        $pages=($page - 1) * $limit;
        $sql="SELECT user.*, company.name as company_name FROM `user` LEFT JOIN company ON `user`.company_id = company.company_id where `user`.type=2  AND `user`.status=1  and user.label !='' $like LIMIT {$pages},{$limit}";
        $data=$this->user_model->get_query($sql);
        if ($data) {
            foreach ($data as &$item) {
                $temps=explode(' ', $item['user_name']);
                if (count($temps) > 1) {
                    $item['head']='';
                    foreach ($temps as $temp) {
                        $item['head'].=get_first_letters($temp);
                    }
                } else {
                    $item['head']=substr($item['user_name'], 0, 2);
                }
            }
        }
        $this->data['data']=$data;
        $sql="select  * from company";
        $this->data['company_data']=$this->user_model->get_query($sql);
        $template='manager_user_publisher';
        $this->template->build($template, $this->data);
    }

    /**
     * publisher 编辑
     * @return mixed
     */
    public function publisher_edit_action()
    {
        if (IS_POST) {
            $post_data=$this->input->post(null, true);
            if (!$post_data) {
                redirect($this->input->server('HTTP_REFERER'));
            }
            $user_id=$post_data['user_id'];
            unset($post_data['user_id']);
            //处理公司
            $update['company']=$post_data['select_company'];
            $update['company_id']=$post_data['select_company'];
            $update['email']=$post_data['input_email'];
            $update['user_name']=$post_data['input_user_name'];
            $update['first_name']=$post_data['input_user_name'];
            $update['country']=$post_data['select_country'];
            $update['type']=$post_data['input_type'];
            $update['contact']=$post_data['input_contact'];
            $update['label']=$post_data['input_label'];
            $update['score']=$this->input->post('score', true);

            if ($update['score'] > 5) {
                $this->error('score master than 5', redirect($this->input->server('HTTP_REFERER')));
            }

            $update['tags']=$this->input->post('tags', true);
            $update['agency_chart']=$this->input->post('chart', true);
            $update=$this->validation->checkInput($update);
            $update['agency_chart']=json_encode($update['agency_chart']);
            if ($user_id) {
                $this->user_model->update_row_by_id($user_id, $update);
                redirect($this->input->server('HTTP_REFERER'));
            } else {
                redirect($this->input->server('HTTP_REFERER'));
            }
        } else {
            $user_id=$this->input->get('user_id', true);
            if ($user_id) {
                $sql="SELECT user.*, company.name as company_name FROM `user` LEFT JOIN company ON `user`.company_id = company.company_id where `user`.type=2  AND `user`.status=1 AND `user`.user_id='{$user_id}'";
                $data=$this->user_model->get_query($sql);
                $data=$data?$data[0]:[];
                //var_dump($data);die;
                return $this->output
                    ->set_content_type('application/json')
                    ->set_output(json_encode($data));
            }
        }
    }

    /**
     * publisher 删除
     * @return mixed
     */
    public function del_publisher_action()
    {
        if (IS_AJAX) {
            $user_id=$this->input->post('user_id', true);
            if ($user_id) {
                $result=$this->user_model->update_row_by_id($user_id, ['status'=>-1]);
                if ($result) {
                    $response=['success'=>true, 'msg'=>$this->lang->line('success_done')];
                } else {
                    $response=['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
                }
            } else {
                $response=['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
            }
            return $this->output->set_content_type('applicaion/json')->set_output(json_encode($response));
        }
    }

    /**
     * 添加管理员、广告主
     */
    public function add_advertiser_action()
    {
        if (IS_POST) {
            $vars['user_name']=$vars['first_name']=$this->input->post('input_first_name', true);
            $vars['email']=$this->input->post('input_email', true);
            $vars['country']=$this->input->post('select_country', true);
            $vars['invoice_pay_period']=$this->input->post('select_pay_period', true);
            $vars['contact']=$this->input->post('input_contact', true);
            $vars['label']=$this->input->post('input_label', true);
            $vars['invoice_payto']=$this->input->post('input_payto', true);
            $vars['invoice_company_name']=$this->input->post('input_company_name', true);
            $vars['invoice_phone']=$this->input->post('input_phone', true);
            $vars['invoice_address']=$this->input->post('input_address', true);
            if ($this->input->post('select_company')) {
                $vars['company_id']=$this->input->post('select_company');
                $company_info=$this->company_model->get_by_id($vars['company_id']);
                $vars['company_account']=$company_info['account'];
                $vars['company']='';
            } else {
                $vars['company']=$this->input->post('input_company');
            }

            $vars=$this->validation->checkInput($vars);
            $url="manager/user/advertiser";
            if ($this->input->post('input_type') == 2) {
                $url="manager/user/publisher";
            }

            $info=$this->user_model->get_by_fields(['email'=>$vars['email']]);
            if ($info) {
                $this->error($this->lang->line('notice_bad_request'), $url);
            }

            $vars['password']=password_hash('123456', PASSWORD_DEFAULT);

            $vars['type']=$this->input->post('input_type');

            $this->user_model->add_one($vars);

            $this->success($this->lang->line('success_done'), $url);
        } else {
            $this->error($this->lang->line('notice_bad_request'));
        }
    }

    /**
     * 添加管理员、广告主
     */
    public function add_publisher_action()
    {
        if (IS_POST) {
            $vars['user_name']=$vars['first_name']=$this->input->post('input_first_name', true);
            $vars['email']=$this->input->post('input_email', true);
            $vars['country']=$this->input->post('select_country', true);
            $vars['contact']=$this->input->post('input_contact', true);
            $vars['label']=$this->input->post('input_label', true);
            $vars['tags']=$this->input->post('tags', true);
            $vars['score']=$this->input->post('score', true);
            if ($vars['score'] > 5) {
                $this->error('score master than 5', redirect('manager/user/publisher'));
            }
            $vars['agency_chart']=$this->input->post('chart', true);
            if ($this->input->post('select_company')) {
                $vars['company_id']=$this->input->post('select_company');
                $company_info=$this->company_model->get_by_id($vars['company_id']);
                $vars['company_account']=$company_info['account'];
                $vars['company']='';
            } else {
                $vars['company']=$this->input->post('input_company');
            }
            $vars=$this->validation->checkInput($vars);
            foreach ($vars['agency_chart'] as $item){
                if($item>100){
                    $this->error('rote master more 100', redirect('manager/user/publisher'));
                }
            }
            $vars['agency_chart']=json_encode($vars['agency_chart']);
            $vars['score']=intval($vars['score']);
            $url="manager/user/advertiser";
            if ($this->input->post('input_type') == 2) {
                $url="manager/user/publisher";
            }

            $info=$this->user_model->get_by_fields(['email'=>$vars['email']]);
            if ($info) {
                $this->error($this->lang->line('notice_bad_request'), $url);
            }

            $vars['password']=password_hash('123456', PASSWORD_DEFAULT);

            $vars['type']=$this->input->post('input_type');

            $this->user_model->add_one($vars);

            $this->success($this->lang->line('success_done'), $url);
        } else {
            $this->error($this->lang->line('notice_bad_request'));
        }
    }

    /**
     *团队或者机构管理
     */
    public function agency()
    {
        $this->config->load('product', TRUE);
        $this->data['config_product']=$this->config->item('product');
        $q=$this->input->get('q', true);
        $this->load->model('offer_model');
        $this->load->model('publisher_adaccount_model');
        $like='';
        if ($q) {
            $like=" AND user_name like '%{$q}%'";
        }
        $data=$this->user_model->get_query("select * from user where type=2 and publisher_type=2 {$like}");

        foreach ($data as $key=>& $value) {
            $account=[];
            $account_list=$this->publisher_adaccount_model->get_query("select * from publisher_adaccount where publisher_id=" . $value['user_id']);
            foreach ($account_list as $item) {
                $account[]=$item['account_id'];
            }

            if ($account) {
                $advertiser_sql="select advertiser_id,advertiser_name from publisher_offer where account_id in (" . implode(',', $account) . ") group by advertiser_id";
                $value['advertiser']=$this->offer_model->get_query($advertiser_sql);

                $product_sql="select product_id,product_name from publisher_offer where account_id in (" . implode(',', $account) . ") group by product_id";
                $value['product']=$this->offer_model->get_query($product_sql);

                $account_sql="select account_id,account_name from publisher_adaccount where publisher_id=" . $value['user_id'];
                $value['account']=$this->offer_model->get_query($account_sql);
            } else {
                $value['advertiser']=$value['product']=$value['account']=[];
            }
        }

        $this->data['account']=$this->user_model->get_query("select * from adaccount");

        $this->data['data']=$data;
        $template='manager_user_agencies';
        $this->template->build($template, $this->data);
    }

    /**
     * 团队或者机构添加
     */
    public function add_agency_action()
    {
        $this->load->model('agency_model');
        if (IS_POST) {
            if (!$this->input->post('input_name')) {
                $this->error($this->lang->line('notice_params_empty'));
            }

            $vars['user_name']=$vars['first_name']=$this->input->post('input_name');

            $vars['email']=$this->input->post('input_email');
            if ($this->input->post('tags', true)) {
                $vars['tags']=$this->input->post('tags', true);
            }
            if ($this->input->post('score', true)) {
                $vars['score']=$this->input->post('score', true);
                if ($vars['score'] > 5) {
                    $this->error('score more 5', redirect('manager/user/agency'));
                }
            }
            $vars['country']=$this->input->post('select_country');
            $vars['company']='';
            $vars['publisher_type']=2;

            $vars=$this->validation->checkInput($vars);
            $vars['agency_chart']=json_encode($this->input->post('chart'));

            $info=$this->user_model->get_by_fields(['email'=>$vars['email']]);
            if ($info) {
                $this->error($this->lang->line('notice_bad_request'));
            }

            $vars['password']=password_hash('123456', PASSWORD_DEFAULT);

            $vars['type']=2;

            $this->user_model->add_one($vars);

            $this->success($this->lang->line('success_done'), 'manager/user/agency');
        } else {
            $this->error($this->lang->line('notice_bad_request'));
        }
    }

    /**
     * agency设置
     */
    public function add_agency_account_action()
    {
        $this->load->model('publisher_adaccount_model');
        $this->load->model('adaccount_model');
        if (IS_POST) {

            $select_account=$this->input->post('select_account');
            $vars['publisher_id']=$this->input->post('agency_id');
            $vars['publisher_name']=$this->input->post('agency_name');
            $vars['publisher_type']=2;
            $account_list=$this->adaccount_model->get_query("select * from adaccount where account_id in (" . implode(',', $select_account) . ")");
            foreach ($account_list as $item) {
                $vars['market_account_id']=$item['market_account_id'];
                $vars['account_id']=$item['account_id'];
                $vars['account_name']=$item['name'];


                $is_exists=$this->publisher_adaccount_model->get_by_fields(['account_id'=>$item['account_id'], 'publisher_id'=>$vars['publisher_id'], 'publisher_type'=>2]);
                if (!$is_exists) {
                    $this->publisher_adaccount_model->add_one($vars);
                } else {
                    $this->publisher_adaccount_model->update_row_by_id($is_exists['relation_id'], $vars);
                }
            }
            $this->success($this->lang->line('success_done'), 'manager/user/agency');
        } else {
            $this->error($this->lang->line('notice_bad_request'));
        }
    }


    /**
     * 删除产品信息
     * @return [type] [description]
     */
    public function del_account_action()
    {
        if ($this->input->is_ajax_request()) {
            $userInfo=$this->userinfo;
            $account_id=$this->input->post('account_id', true);
            if ($account_id) {
                $where=array('account_id'=>$account_id);
                $res=$this->adaccount_model->update_row_by_fields($where, ['status'=>-1]);
                if ($res) {
                    $response=['success'=>true, 'msg'=>$this->lang->line('success_delete')];
                } else {
                    $response=['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
                }
            } else {
                $response=['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
            }
        } else {
            $response=['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
        }
        $this->output->set_content_type('applicaion/json')->set_output(json_encode($response));
    }

}