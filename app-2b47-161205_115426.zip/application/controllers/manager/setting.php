<?php

/**
 * Created by PhpStorm.
 * User: palmax
 * Date: 2016-10-24
 * Time: 11:12
 */
class Setting extends Web_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('user_model');
        $this->load->model('bills_extend_model');
        $this->load->model('setting_model');
        $this->load->library('pagination');
        $this->data['top_menu']=$this->load->view('web/top_menu_manager', '', TRUE);
    }

    private function _save($name, $value)
    {
        $this->config->load('setting', TRUE);
        $data=$this->config->item('setting');

        $data[$name]=$value;
        $this->config->set_item('REVIEW_RISK', $data);
        return $this->config->save('setting');
    }

    /**
     * Review 的报警数据配置
     * @return [type] [description]
     */
    public function risk()
    {
        $result=$this->setting_model->get_all(['type'=>'risk', 'status'=>1]);

        $data = [];
        foreach ($result as & $item) {
            $item['content'] = json_decode($item['content'], true);
        }
        $this->data['result'] = $result;

        $this->data['fields'] = ['ctr'=>'CTR', 'cvr'=>'CVR', 'clicks'=>'Clicks', 'spend'=>'Spend', 'results'=>'Results', 'comments'=>'Comments', 'likes'=>'Likes', 'shares'=>'Shares'];
        
        $template='manager_setting_risk';
        $this->template->build($template, $this->data);
    }

    public function del_setting_action()
    {
        if ($this->input->is_ajax_request()) {
            if (!$this->input->post('setting_id')) {
                $response=['success'=>false, 'msg'=>$this->lang->line('notice_params_empty')];
            } else {
                $offer=[];

                $setting_id=$this->input->post('setting_id');
                $this->setting_model->update_row_by_id($setting_id, ['status'=>0]);

                $response=['success'=>true, 'msg'=>"success", 'data'=>$offer];
            }
        } else {
            $response=['success'=>false, 'msg'=>$this->lang->line('notice_params_empty')];
        }
        $this->output->set_content_type('applicaion/json')->set_output(json_encode($response));
    }

    public function risk_save()
    {
        $post_data=$this->input->post(null, true);

        $data = [];
        foreach ($post_data as $k=>&$item) {
            if ($item['value']<=0) {
                continue;
            }

            $item['value']  = floatval($item['value']);
            $data[$k] = $item['value'];
        }
        $add_data['type']               = 'risk';
        $add_data['last_modified_time'] = time();
        $add_data['content']            = json_encode($data);

        $res=$this->setting_model->add_one($add_data);

        if ($res) {
            $this->success('恭喜您,操作成功!', 'manager/setting/risk');
        } else {
            $this->error('系统错误,请稍后重试!', 'manager/setting/risk');
        }
    }


    /**
     * 账单调整数据
     */
    public function adjust()
    {
        $page=$this->input->get('page', true);
        if (!$page) {
            $page=1;
        }
        $config['base_url']=site_url('manager/setting/adjust?');
        $counts=$this->bills_extend_model->get_total();
        $this->data['total_rows']=$counts;
        $config=get_web_page($config, $counts, 3);
        $limit=$config['per_page']=15;
        $this->pagination->initialize($config);
        $this->data['page_links']=$this->pagination->create_links();
        $this->data['list']=$this->bills_extend_model->get_all([], $page, 15);
        //获取广告主用户id
        $this->data['users']=$user_ids=$this->user_model->get_all(['type'=>1]);
        $template='manager_setting_adjust';
        $this->template->build($template, $this->data);

    }

    /**
     * 获取用户的记录
     * @return mixed
     */
    public function get_user_id_action()
    {
        $type=$this->input->get('type', true);
        if ($type) {
            //获取user_Id信息
            $user_ids=$this->user_model->get_all(['type'=>$type]);
            if ($user_ids) {
                $user_id_arr=array_column($user_ids, 'user_id', 'user_name');
                return $this->output
                    ->set_content_type('application/json')
                    ->set_output(json_encode(array('msg'=>$user_id_arr, 'code'=>1)));
            }
        }
    }

    /**
     * 添加调整记录
     */
    public function add_bills_extend()
    {
        $post_data=$this->input->post('data', true);
        if (!$post_data) {
            redirect($this->inout->server('HTTP_REFERER'));
        }

        if ($post_data['money_type'] == 1) {
            $post_data['money']=$post_data['money'] * -1;
        }

        $post_data['user_id']=trim($post_data['user_id'], ',');
        $users=explode(',', $post_data['user_id']);
        unset($post_data['user_id']);
        //验证字段
        if (!$post_data['user_type'] || !$post_data['extend_date'] || !$post_data['money'] || !$post_data['money_type']) {
            redirect($this->inout->server('HTTP_REFERER'));
        }
        $post_data['extend_date']=strtotime($post_data['extend_date']);
        foreach ($users as &$user) {
            $userinfo=$this->user_model->get_by_id($user);
            $post_data['user_name']=$userinfo['user_name'];
            $post_data['user_id']=$user;
            $this->bills_extend_model->add_one($post_data);
        }
        $this->success('恭喜您,操作成功!', 'manager/setting/adjust');
    }


    public function daily()
    {
        $list = [];
        $d = date('Y-m-d');
        for ($i=0; $i <= 30; $i++) { 
            $date = date('M d Y', strtotime("$d -$i day"));
            $encode = str_replace(array('+', '/', '='), array('-', '_', ''), base64_encode(serialize($date)));
        
            $list[$date] = 'http://addigger.palmax.com/advertiser/daily/'.$encode;
        }

        $this->data['list'] = $list;
        $template='manager_setting_daily';
        $this->template->build($template, $this->data);
    }
}