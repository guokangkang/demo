<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Privacy extends MY_Controller {

    /**
    * 初使化
    */
    public function __construct()
    {
        parent::__construct();
    }

    public function index($value='')
    {
        //redirect('account/listview');
        $this->template
                ->set_template('web/privacy_index')
                ->set_view_dir('web');

        $this->template->build('privacy_index',$this->data);
    }



}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */