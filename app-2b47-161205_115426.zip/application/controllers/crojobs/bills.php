<?php

/**
 * Created by PhpStorm.
 * User: palmax
 * Date: 2016-11-02
 * Time: 15:50
 */
class Bills extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
    }

    /**
     *账单生成
     */
    public function generate()
    {
        try {
            $date=date('Y-m-d', strtotime('-1 days'));
            $this->load->library('bills');
            $this->load->model('user_model');
            $sql="SELECT * FROM user WHERE STATUS = 1";
            $user_list=$this->user_model->get_query($sql);
            foreach ($user_list as $item) {
                $this->bills->sync($item['user_id'], $item['type'], $date);
            }
        } catch (Exception $e) {
            log_message('error', $e->getMessage());
        }

    }

}