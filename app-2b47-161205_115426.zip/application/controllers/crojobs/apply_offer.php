<?php if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

/**
 * 
 * 系统自动领取offer(临时用的)
 */
class Apply_offer extends CI_Controller
{
    public function __construct() {
        parent::__construct();

        $this->load->model('user_model');
        $this->load->model('adaccount_model');
        $this->load->model('product_model');
        $this->load->model('offer_model');
        $this->load->model('publisher_offer_model');
        $this->load->model('publisher_adaccount_model');
        $this->load->model('offer_cpa_log_model');
        $this->load->model('payout_model');
        $this->load->model('specific_payout_model');
    }



    /**
     * 获取当前的留存价格，并添加日志表
     * @param  [type] $offer_id [description]
     * @param  [type] $user_id  [description]
     * @return [type]           [description]
     */
    private function getCurrentPayout($offer_id, $user_id){
        //获取当前offer的留存价格
        $date = strtotime(date('2016-05-01'));
        $sql = "select * from payout where offer_id=".$offer_id." and status=1 and start_time<=".$date." order by start_time desc limit 1";

        $retention = $this->payout_model->get_query($sql);

        echo $sql;
        dump($retention);die();
        if ($retention) {
            $retention[0]['value'] = json_decode($retention[0]['value'], true);

            $this->offer_cpa_log_model->add_one(['user_id'=>$user_id, 'offer_id'=>$offer_id, 'cpa'=>$retention[0]['cpa'], 'start_time'=>$retention[0]['start_time'], 'type'=>'retention', 'retention'=>json_encode($retention[0])]);

            //更新用户申请的offer记录的当前价格
            //这是冗余字段，为了方便查询
            $this->publisher_offer_model->update_row_by_fields(['publisher_id'=>$user_id, 'offer_id'=>$offer_id], ['cpa'=>$retention[0]['cpa']]);
            return $retention[0]['cpa'];
        }
        return 0;
    }

   
    private function apply_offer_action($userinfo, $product_id, $offer_id, $apply_account)
    { 
        $this->load->model('adaccount_model');
        $this->load->model('publisher_offer_model');
        //if (IS_POST) {
            // if (!$this->input->post('offer_id') || !$this->input->post('apply_account')) {
            //     $this->error($this->lang->line('notice_bad_request'), 'product/detail/'.$product_id);
            //     die();
            // }
            $offer_info = $this->offer_model->get_by_id($offer_id);
            $vars['product_id'] = $offer_info['product_id'];
            $vars['product_name'] = $offer_info['product_name'];
            $vars['advertiser_id'] = $offer_info['user_id'];
            $vars['advertiser_name'] = $offer_info['user_name'];

            $vars['publisher_id'] = $userinfo['user_id'];
            $vars['publisher_name'] = $userinfo['user_name'];
            $vars['offer_id'] = $offer_id;
            $vars['note'] = "";


            // //判断用户是否有特殊价格，如果没有应该创建offer_cpa_log日志
            // $specific_payout = $this->specific_payout_model->get_all(['user_id'=>$userinfo['user_id'], 'offer_id'=>$vars['offer_id'], 'type'=>'add'], 1, 1);
            
            // if ($specific_payout) {//如果有特殊价格，则标示此人申请的这个offer有指定的特殊价格
            //     $vars['is_specific_payout'] = 1;
            //     $vars['cpa'] = $specific_payout[0]['payout'];
            //     $this->getCurrentPayout($vars['offer_id'], $userinfo['user_id']);
            // }else{//没有特殊价格，需要设置当前offer的留存价格
            //     $vars['cpa'] = $this->getCurrentPayout($vars['offer_id'], $userinfo['user_id']);
            // }

            
            $account = $apply_account;
            //foreach ($account as $key => $market_account_id) {
                $accountinfo = $this->adaccount_model->get_by_fields(['account_id'=>$apply_account]);
                $vars['account_id'] = $accountinfo['account_id'];
                $vars['market_account_id'] = $accountinfo['market_account_id'];
                $vars['account_name'] = $accountinfo['name'];

                //验证账号是否有其他人申请已经申请过offer
                $sql = "select publisher_id from publisher_offer 
                        where market_account_id=".$vars['market_account_id']." and publisher_id != ".$userinfo['user_id'];
                if($this->publisher_offer_model->get_query_count($sql)){
                    return '';
                }
                $vars['status'] = 1;
                //判断之前是否申请过
                $publisher_offer = $this->publisher_offer_model->get_by_fields(['publisher_id'=>$userinfo['user_id'], 'offer_id'=>$vars['offer_id'], 'market_account_id'=>$vars['market_account_id']]);
                if ($publisher_offer) {
                    //$this->publisher_offer_model->update_row_by_id($publisher_offer['relation_id'], $vars);
                }else{
                    $publisher_offer = $this->publisher_offer_model->get_by_fields(['market_account_id'=>$vars['market_account_id']]);
                    if (!$publisher_offer || $publisher_offer['publisher_id']==$userinfo['user_id']) {
                        $this->publisher_offer_model->add_one($vars);
                    }
                    
                }
                
            //}

           

            //$this->success($this->lang->line('success_done'), 'product/detail/'.$vars['product_id']);
            
        //}else
        //    $this->error($this->lang->line('notice_bad_request'), 'product/detail/'.$product_id);
    }


    private function add_user($user_name, $label)
    {
        $name = explode(' ', $user_name);

        if (count($name)>1) {
            $vars['first_name'] = $name[1];
            $vars['last_name'] = $name[0];
            $vars['user_name'] = $name[0]." ".$name[1];
        }else{
            $vars['user_name'] = $vars['first_name'] = $name[0];
        }
        $user_name = str_replace(" ", "", $user_name);
        $vars['email'] = strtolower($user_name)."@marketmax.com";

        $vars['company'] = 'Palmax';
        $vars['country'] = "CN";
        $vars['label']   = $label;
        $vars['password'] = password_hash('123456', PASSWORD_DEFAULT);

        $vars['token'] = "EAAHUoMANECMBALZCoYbdSWmvFvwcFm4TXSNlb0njhEI7QSyukYAjfxrogADwaRt8SRLMnZAX5DKeIle17cLluQOhItxUwdCNrHT5eDtQUXNqDUxFB6jz8tLRGXMZBUmtI4084JrNZBevZCPjn9SWLIVLZCeXrPG7qY6yJhd1VccwZDZD";
        $vars['token_expires'] = 1468746570;
        $s = $this->user_model->get_by_fields(['email'=>$vars['email']]);
        if ($s) {
            $this->user_model->update_row_by_id($s['user_id'], $vars);
            return $s['user_id'];
        }else{
            return $this->user_model->add_one($vars);
        }
        
    }


    private function add_account($userinfo, $account_id)
    {
        $account_info = $this->adaccount_model->get_by_fields(['account_id'=>$account_id]);
        if (!$account_info) {
            $account_name = "None";
            $market_account_id = $this->adaccount_model->add_one(['account_id'=>$account_id, 'name'=>'None', 'currency'=>'USD', 'min_daily_budget'=>100, 'owner_business'=>'', 'balance'=>'', 'amount_spent'=>'', 'spend_cap'=>0, 'created_time'=>'', 'lasttime'=>time(), 'backup'=>'', 'status'=>1]);   
        }else{
            $market_account_id = $account_info['market_account_id'];
            $account_name = $account_info['name'];
            //$this->adaccount_model->update_row_by_id($market_account_id, ['is_more'=>1]);
        }

        $publisher_account = $this->publisher_adaccount_model->get_by_fields(['publisher_id'=>$userinfo['user_id'], 'account_id'=>$account_id]);
        if (!$publisher_account) {
            $this->publisher_adaccount_model->add_one(['publisher_id'=>$userinfo['user_id'], 'publisher_name'=>$userinfo['user_name'], 'market_account_id'=>$market_account_id, 'account_id'=>$account_id, 'account_name'=>$account_name]);
        }else{
            $this->publisher_adaccount_model->update_row_by_fields(['publisher_id'=>$userinfo['user_id'], 'account_id'=>$account_id], ['account_name'=>$account_name]);
        }
    }


    /**
     * 1、先申请offer
     * @param  string $value [description]
     * @return [type]        [description]
     */
    public function step1($value='')
    {
        $product_data = [
            'go'        => [10002, 10003, 10013, 10014],
            'kika'      => [10001],
            'cot'       => [10007],
            '7nujoom'   => [10009, 10011],
            'hitap'     => [10004, 10005],
            'applocker' => [10006],
            'ireader'   => [10010, 10012],
            'the voyage'=> [10008]
        ];

        $data = file_get_contents("./publisher.csv");

        $account_list = [];
        foreach (explode("\n", $data) as $line) {
            if(empty($line))
                break;

            $d = explode(',', $line);
            $account_id = trim($d[0]);
            $label = trim($d[1]);
            $user_id = trim($d[2]);
            $product_name = trim($d[4]);
            $user_name = trim($d[3]);

            if (!$user_id) {
                $user_id = $this->add_user($user_name, $label);
            }else{
                $this->user_model->update_row_by_id($user_id, ['label'=>$label]);
            }

            $product_name = strtolower($product_name);
            

            $product = $product_data[$product_name];


            foreach ($product as $k => $product_id) {
                $offer_list = $this->offer_model->get_all(['product_id'=>$product_id]);
                foreach ($offer_list as $offer) {
                    $account_list[$product_id][$offer['offer_id']][] = ['account_id'=>$account_id, 'user_id'=>$user_id];
                }
            }
        }


        foreach ($account_list as $product_id => $product) {
            foreach ($product as $offer_id => $offer) {
                foreach ($offer as $k => $v) {
                    $userinfo = $this->user_model->get_by_id($v['user_id']);
                    $this->add_account($userinfo, $v['account_id']);
                    $this->apply_offer_action($userinfo, $product_id, $offer_id, $v['account_id']);
                }
                
            }
        }
    }


    /**
     * 2、给申请的offer设置价格{set_payout}
     * @param string $value [description]
     */
    public function step2($value='')
    {
        $payout_list = $this->payout_model->get_all([], 1, 200, ['start_time', 'asc']);

        foreach ($payout_list as $key => $payout) {
            
            $payout['value'] = json_decode($payout['value'], true);

            $publisher_list = $this->publisher_offer_model->get_all(['offer_id'=>$payout['offer_id']]);
            foreach ($publisher_list as $key => $value) {
                $is_exists = $this->offer_cpa_log_model->get_by_fields(['user_id'=>$value['publisher_id'], 'offer_id'=>$payout['offer_id'], 'start_time'=>$payout['start_time'], 'type'=>'retention']);
                if (!$is_exists) {
                    $this->offer_cpa_log_model->add_one(['user_id'=>$value['publisher_id'], 'offer_id'=>$payout['offer_id'], 'cpa'=>$payout['cpa'], 'start_time'=>$payout['start_time'], 'type'=>'retention', 'retention'=>json_encode($payout)]);
                }
                
            }
            //更新用户申请的offer记录的当前价格
                //这是冗余字段，为了方便查询
            $this->publisher_offer_model->update_row_by_fields(['offer_id'=>$payout['offer_id']], ['cpa'=>$payout['cpa']]);
        }
    }

}