<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Business extends CI_Controller {

    public function __construct()
    {
        parent::__construct(); 
        $this->load->model('business_model');
        $this->load->model('user_model');
        $this->load->model('adaccount_model');
        $this->load->model('publisher_adaccount_model');
        $this->load->model('business_permissions_model');
        $this->load->model('publisher_business_model');

        $this->load->library('curl');

    }

    public function sync()
    {
        $business_list = $this->business_model->get_query("select * from business where business_id=1726344267583847");
        foreach ($business_list as $item) {
            $sql = "select * from business_permissions where user_id !='' and role='ADMIN' and market_business_id=".$item['market_business_id'];
            $admin_list = $this->business_permissions_model->get_query($sql);

            if ($admin_list && $item['token']) {//验证是否有管理员注册
                $business_info = $this->getBussiness($item['business_id'], $item['token']);
                if ($business_info) {
                    $business_info = json_decode($business_info, true);
                    $vars = ['name'=>$business_info['name'], 'created_by'=>json_encode($business_info['created_by']), 'timezone_id'=>$business_info['timezone_id'], 'updated_by'=>json_encode($business_info['updated_by']), 'userpermissions'=>json_encode($business_info['userpermissions'])];
                    
                    $this->business_model->update_row_by_id($item['market_business_id'], $vars);
                    $business_info['market_business_id'] = $item['market_business_id'];
                    $business_info['business_id'] = $item['business_id'];

                    $this->set_user_permission($business_info, $admin_list[0]['user_id'], $item['token']);
                
                }
            }
        }
        echo "done";die();
    }


    /**
     * 获取bm详情
     * 
     * @param  [type] $business_id [description]
     * @param  string $token       [description]
     * @return [type]              [description]
     */
    public function getBussiness($business_id, $token)
    {
        $url = config_item('APP_URL').config_item('APP_VERSION')."/".$business_id."?fields=created_by,name,timezone_id,updated_by,userpermissions.limit(100),adaccounts.limit(1000)&access_token=" . $token;
        $info = $this->curl->simple_get($url);

        return $info;
    }

    /**
     * 获取account详情
     * 
     * @param  [type] $business_id [description]
     * @param  string $token       [description]
     * @return [type]              [description]
     */
    public function getAccount($account_id, $token)
    {
        $url = config_item('APP_URL').config_item('APP_VERSION')."/".$account_id."?fields=name,id,account_id,currency,min_daily_budget,owner_business,balance,amount_spent,spend_cap,created_time,account_status&access_token=" . $token;
        $info = $this->curl->simple_get($url);
        $info = json_decode($info, true);

        $vars['backup'] = json_encode($info);
        $vars['created_time'] = strtotime($info['created_time']);
        $vars['owner_business'] = json_encode($info['owner_business']);
        $vars['name'] = $info['name'];
        $vars['account_id'] = $info['account_id'];
        $vars['currency'] = $info['currency'];
        $vars['min_daily_budget'] = $info['min_daily_budget'];
        $vars['balance'] = $info['balance'];
        $vars['amount_spent'] = $info['amount_spent'];
        $vars['spend_cap'] = $info['spend_cap'];
        $vars['lasttime'] = time();
        $vars['status'] = $info['account_status'];

        $market_account_id = $this->adaccount_model->add_one($vars);
        $vars['market_account_id'] = $market_account_id;

        return $vars;
    }



    /**
     * 设置用户权限关系
     * @param [type] $business_info [description]
     */
    public function set_user_permission($business_info, $publisher_id, $token)
    {
        //添加权限关系 
        if ($business_info['userpermissions']) {
            $publisher_info = $this->user_model->get_by_id($publisher_id);

            $list = $this->business_permissions_model->get_query("select * from business_permissions where market_business_id=".$business_info['market_business_id']);
            $facebook_ids = [];
            foreach ($list as $key => $value) {
                $value['user_id'] && $facebook_ids[$value['facebook_id']] = $value['user_id'];
            }
            foreach ($business_info['userpermissions']['data'] as $role) {
                if (isset($facebook_ids[$role['user']['id']])) {//删除包含的元素，为了找到business中已经删除掉得权限对应的用户
                    unset($facebook_ids[$role['user']['id']]);
                }
                $permissions = $this->business_permissions_model->get_by_fields(['market_business_id'=>$business_info['market_business_id'], 'facebook_id'=>$role['user']['id']]);
                $user_info = $this->user_model->get_by_fields(['facebook_id'=>$role['user']['id'], 'company_id'=>$publisher_info['company_id']]);
                if (!$permissions) {
                    $vars = ['market_business_id'=>$business_info['market_business_id'], 'business_id'=>$business_info['business_id'], 'business_name'=>$business_info['name'], 'business_persona'=>json_encode($role['business_persona']), 'role'=>$role['role'], 'status'=>$role['status'], 'facebook_id'=>$role['user']['id'], 'facebook_name'=>$role['user']['name']];
                    if (isset($role['email'])) {
                        $vars['email'] = $role['email'];
                    }
                    
                    if ($user_info) {
                        $vars['user_id'] = $user_info['user_id'];
                        $vars['user_name'] = $user_info['user_name'];
                        if ($role['role']=='ADMIN') {
                            $this->business_model->update_row_by_id($business_info['market_business_id'], ['token'=>$user_info['token']]);
                        }
                    }
                    $this->business_permissions_model->add_one($vars);
                    
                }else{
                    $vars = ['role'=>$role['role'], 'status'=>$role['status']];
                    if ($user_info){
                        $vars['user_id'] = $user_info['user_id'];
                        $vars['user_name'] = $user_info['user_name'];
                    }
                    $this->business_permissions_model->update_row_by_id($permissions['permissions_id'], $vars);
                    if ($user_info) {
                        if ($role['role']=='ADMIN') {
                            $this->business_model->update_row_by_id($business_info['market_business_id'], ['token'=>$user_info['token']]);
                        }
                    }
                }

            }
            if ($facebook_ids) {
                foreach ($facebook_ids as $facebook_id=>$user_id) {
                    $this->business_permissions_model->get_query("delete from business_permissions where market_business_id=".$business_info['market_business_id']." and facebook_id=".$facebook_id);
                }
            }
        }else{
            $this->business_permissions_model->get_query("delete from business_permissions where market_business_id=".$business_info['market_business_id']);
        }
        
    }

}