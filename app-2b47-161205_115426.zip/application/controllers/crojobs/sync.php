<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Sync extends CI_Controller {

    public function __construct()
    {
        parent::__construct();

        $this->load->model('adaccount_model');
        $this->load->model('product_model');
        $this->load->model('user_model');
        $this->load->model('business_model');
        $this->load->model('publisher_adaccount_model');
        $this->load->model('business_permissions_model');

        $this->load->library('curl');
    }


    public function sync_agency_account()
    {
        $this->load->library('excelreader');
        $data = file_get_contents("./agency.csv");

        $this->load->model('user_model');
        $this->load->model('adaccount_model');
        $this->load->model('publisher_adaccount_model');
        foreach (explode("\n", $data) as $line) {
            if(empty($line))
                break;

            $d = explode(',', $line);
            $account_id = trim($d[0]);
            $agency = trim($d[1]);

            $user_info = $this->user_model->get_by_fields(['user_name'=>$agency]);
            $account_info = $this->adaccount_model->get_by_fields(['account_id'=>$account_id]);

            if (!$account_info) {
                echo $account_id."<br>";
                continue;
            }
            $vars['publisher_id'] = $user_info['user_id'];
            $vars['publisher_name'] = $user_info['user_name'];
            $vars['publisher_type'] = 2;
            $vars['market_account_id'] = $account_info['market_account_id'];
            $vars['account_id'] = $account_info['account_id'];
            $vars['account_name'] = $account_info['name'];

            $info = $this->publisher_adaccount_model->get_by_fields(['account_id'=>$account_id, 'publisher_id'=>$vars['publisher_id'], 'publisher_type'=>2]);
            if (!$info) {
                $this->publisher_adaccount_model->add_one($vars);
            }else{
                $this->publisher_adaccount_model->update_row_by_id($info['relation_id'], $vars);
            }

        }
    }

    public function get_paging($url, $result=[])
    {
        $data = [];
        $new_data = $this->curl->simple_get($url);
        $new_data = json_decode($new_data, true);
        if ($new_data['data']) {
            $data = array_merge($new_data['data'], $result);
            while (isset($new_data['paging']['next']) && !empty($new_data['paging']['next'])) {

                $nextstr = $this->_ci->curl->simple_get($new_data['paging']['next']);
                $result = [];
                if ($nextstr) {
                    $result = json_decode($nextstr, true);
                }

                if ($result) {
                    $data = array_merge($data, $result['data']);
                } else {
                    break;
                }
            }
        }else{
            $data = $result;
        }
        return $data;
    }


    public function index_bak()
    {
        $this->load->library('facebookapi', ['user_id'=>10001]);
        $account_list = $this->adaccount_model->get_query("select * from adaccount");
        foreach ($account_list as $item) {
            $data = $this->facebookapi->getFacebookData("act_".$item['account_id'], "fields=userpermissions");
            if ($data) {
                $data = json_decode($data, true);
                $data = $this->get_paging($data['userpermissions']['paging']['next'], $data['userpermissions']['data']);
                var_dump($data);die();
            }
            
        }
    }

    /**
     * 获取bm详情
     * 
     * @param  [type] $business_id [description]
     * @param  string $token       [description]
     * @return [type]              [description]
     */
    public function getBussiness($business_id, $token)
    {
        $url = config_item('APP_URL').config_item('APP_VERSION')."/".$business_id."?fields=created_by,name,timezone_id,updated_by,userpermissions.limit(100),adaccounts.limit(1000)&access_token=" . $token;
        $info = $this->curl->simple_get($url);

        return $info;
    }


    public function index()
    {

        $business_ids = ['1010723705679872'];
        $business_ids = ['1726344267583847', '180286635699797', '1010723705679872'];
        //var_dump($business_ids);die();
        $token = "EAAHUoMANECMBALZCoYbdSWmvFvwcFm4TXSNlb0njhEI7QSyukYAjfxrogADwaRt8SRLMnZAX5DKeIle17cLluQOhItxUwdCNrHT5eDtQUXNqDUxFB6jz8tLRGXMZBUmtI4084JrNZBevZCPjn9SWLIVLZCeXrPG7qY6yJhd1VccwZDZD";
        foreach ($business_ids as $business_id) {
            $business_data = $this->getBussiness($business_id, $token);

            if ($business_data) {
                $business_data = json_decode($business_data, true);


                $vars = ['name'=>$business_data['name'], 'created_by'=>json_encode($business_data['created_by']), 'timezone_id'=>$business_data['timezone_id'], 'updated_by'=>json_encode($business_data['updated_by']), 'userpermissions'=>json_encode($business_data['userpermissions']), 'business_id'=>$business_id];

                $business_info = $this->business_model->get_by_fields(['business_id'=>$business_data['id']]);
                if ($business_info) {
                    $market_business_id = $business_info['market_business_id'];
                    $this->business_model->update_row_by_id($business_info['market_business_id'], $vars);
                }else{
                    $market_business_id = $this->business_model->add_one($vars);
                }
                    
                $business_data['market_business_id'] = $market_business_id;
                $business_data['business_id'] = $business_id;

                $this->set_user_permission($business_data);
            
            }
        }

        echo "done";die();
    }


    /**
     * 设置用户权限关系
     * @param [type] $business_info [description]
     */
    public function set_user_permission($business_info)
    {
        $userpermissions = $business_info['userpermissions']['data'];

        $list = $this->business_permissions_model->get_query("select * from business_permissions where market_business_id=".$business_info['market_business_id']);
        $facebook_ids = [];
        foreach ($list as $key => $value) {
            $value['user_id'] && $facebook_ids[$value['facebook_id']] = $value['user_id'];
        }

        foreach ($userpermissions as $role) {
            if (isset($facebook_ids[$role['user']['id']])) {//删除包含的元素，为了找到business中已经删除掉得权限对应的用户
                unset($facebook_ids[$role['user']['id']]);
            }
            $permissions = $this->business_permissions_model->get_by_fields(['market_business_id'=>$business_info['market_business_id'], 'facebook_id'=>$role['user']['id']]);
            $user_info = $this->user_model->get_by_fields(['facebook_id'=>$role['user']['id']]);
            if (!$permissions) {
                $vars = ['market_business_id'=>$business_info['market_business_id'], 'business_id'=>$business_info['business_id'], 'business_name'=>$business_info['name'], 'business_persona'=>json_encode($role['business_persona']), 'role'=>$role['role'], 'status'=>$role['status'], 'facebook_id'=>$role['user']['id'], 'facebook_name'=>$role['user']['name']];
                if (isset($role['email'])) {
                    $vars['email'] = $role['email'];
                }
                
                if ($user_info) {
                    $vars['user_id'] = $user_info['user_id'];
                    $vars['user_name'] = $user_info['user_name'];
                    if ($role['role']=='ADMIN' && $user_info['token']) {
                        $this->business_model->update_row_by_id($business_info['market_business_id'], ['token'=>$user_info['token']]);
                    }
                    //如果为新的用户关系，创建账号关系
                    $this->set_business_adaccount($user_info, $business_info, $role['role']);
                }
                $this->business_permissions_model->add_one($vars);
                
            }else{
                $vars = ['role'=>$role['role'], 'status'=>$role['status']];
                $this->business_permissions_model->update_row_by_id($permissions['permissions_id'], $vars);
                if ($user_info) {
                    if ($role['role']=='ADMIN' && $user_info['token']) {
                        $this->business_model->update_row_by_id($business_info['market_business_id'], ['token'=>$user_info['token']]);
                    }
                    $this->publisher_adaccount_model->update_row_by_fields(['publisher_id'=>$user_info['user_id'], 'market_business_id'=>$business_info['market_business_id']], ['role'=>$role['role']]);
                    //如果为新的用户关系，创建账号关系
                    $this->set_business_adaccount($user_info, $business_info, $role['role']);
                }
                
            }

        }

        if ($facebook_ids) {
            foreach ($facebook_ids as $facebook_id=>$user_id) {
                $this->business_permissions_model->get_query("delete from business_permissions where market_business_id=".$business_info['market_business_id']." and facebook_id=".$facebook_id);
                $this->publisher_adaccount_model->update_row_by_fields(['publisher_id'=>$user_id, 'market_business_id'=>$business_info['market_business_id']], ['status'=>0]);
            }
        }
    }

    /**
     * 添加账号与
     * @param [type] $business_info [description]
     * @param [type] $accounts      [description]
     */
    private function set_business_adaccount($user_info, $business_info, $role)
    {

        $accounts = [];
        foreach ($business_info['adaccounts']['data'] as $key => $value) {
            $accounts[$value['account_id']] = $value['account_id'];
        }
        
        $role = "";
        $userpermissions = $business_info['userpermissions']['data'];
        foreach ($userpermissions as $key => $value) {
            if ($value['user']['id'] == $user_info['facebook_id']) {
                $role = $value['role'];
                break;
            }
        }

        $this->adaccount_model->addAccount($user_info['user_id'], $user_info['user_name'], $user_info['facebook_id'], $accounts, $business_info['business_id'], $role);
    }


    public function sync_review_ad()
    {
        $this->load->library('review');
        $sql = "select * from ad";
        $list = $this->adaccount_model->get_query($sql);
        foreach ($list as $key => $value) {
            $info = $this->product_model->get_by_id($value['product_id']);
            if (!$info) {
                continue;
            }
            $value['object_store_url'] = $info['object_store_url'];
            $this->review->sync($value, $value['publisher_id']);
        }
    }


    public function sync_dynamodb_product_empty()
    {
        
    }



}