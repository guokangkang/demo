<?php

/**
 * Created by PhpStorm.
 * User: palmax
 * Date: 2016/9/22
 * Time: 16:48
 */
class App_score extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('product_model');
        $this->load->library('store_api');
    }

    public function index()
    {
        show_404();
    }

    /**
     * 采集app的分数
     */
    public function spider()
    {
        try {
            //所有没有评分的记录
            $data=$this->product_model->get_data('*', ['score'=>0], 0, 0);
            if ($data) {
                foreach ($data as $item) {
                    //分类
                    if ($item['category'] == 'ios') {
                        //苹果处理
                        $data=$this->store_api->get_apple($item['app_id']);
                        //更新数据
                        $data && $this->product_model->update_row_by_id($item['product_id'], $data);
                    } else {
                        //安卓处理
                        $data=$this->store_api->get_play($item['object_store_url']);
                        //更新数据
                        $data && $this->product_model->update_row_by_id($item['product_id'], $data);
                    }
                }
                log_message('info', 'collection app score successful');
            }
        } catch (Exception $e) {
            echo $e->getMessage();
            log_message('error', 'collection app score ' . $e->getMessage());
        }
    }
}