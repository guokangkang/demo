<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Review extends CI_Controller {

    public function __construct()
    {
        parent::__construct();

        $this->load->model('adaccount_model');
        $this->load->model('adset_model');
        $this->load->model('ad_model');
        $this->load->model('ad_insight_model');
        $this->load->model('product_model');
        $this->load->model('adset_country_log_model');
        $this->load->model('publisher_adaccount_model');
    }

    /**
     * 通过object store url 获取产品信息
     * @param  [type] $object_store_url [description]
     * @return [type]                   [description]
     */
    private function get_product_info($object_store_url){
        $app_id = '';
        if (strpos($object_store_url, "google")!==false) {
            if ($index=strpos($object_store_url, "=")) {
                $app_id = $play_id = substr($object_store_url, $index+1);
            }
        }elseif (strpos($object_store_url, "itunes")!==false) {
            if ($index=strpos($object_store_url, "/id")) {
                $app_id = $itunes_id = substr($object_store_url, $index+3, 9);
            }
        }
        if ($app_id) {
            return $this->product_model->get_by_fields(['app_id'=>$app_id]);
        }

        return [];
    }


    /**
     * 获取account_id 对应的流量主
     * @param  [type] $market_account_id [description]
     * @return [type]                    [description]
     */
    private function get_publisher_info($market_account_id)
    {
        return $this->publisher_adaccount_model->get_by_fields(['market_account_id'=>$market_account_id]);
    }


    private function ad_insights($vars, $insights)
    {
        if ($insights['data']) {
            $data = $insights['data'][0];

            $result = ['market_account_id'=>$vars['market_account_id'], 'account_id'=>$vars['account_id'], 'campaign_id'=>$vars['campaign_id'], 'market_campaign_id'=>$vars['market_campaign_id'], 'adset_id'=>$vars['adset_id'], 'market_adset_id'=>$vars['market_adset_id']];

            $result['account_name']     = $vars['account_name'];
            $result['campaign_name']    = $vars['campaign_name'];
            $result['adset_name']       = $vars['adset_name'];
            $result['ad_name']          = $vars['name'];
            $result['ad_id']            = $vars['ad_id'];
            $result['market_ad_id']     = $vars['market_ad_id'];

            $fields = $this->ad_insight_model->fields;

            $result['results'] = 0;
            $result['link_clicks'] = 0;
            $result['ctr_link'] = 0;
            $result['cost'] = 0;
            $result['cpc_link'] = 0;
            foreach ($data as $key => $value) {
                if (in_array($key, $fields)) {
                    is_array($value) && $value = json_encode($value);
                    $result[$key] = $value;
                }
                if ($key=='actions') {
                    foreach ($value as $k => $v) {
                        if ($v['action_type'] == 'mobile_app_install') {
                            $result['results'] = $v['value'];
                        }
                        if ($v['action_type'] == 'link_click') {
                            $result['link_clicks'] = $v['value'];
                            $result['ctr_link'] = $data['impressions']>0?$v['value']/$data['impressions']*100:0;
                        }
                        if ($v['action_type'] == 'comment') {
                            $result['comments'] = $v['value'];
                        }
                        if ($v['action_type'] == 'post') {
                            $result['shares'] = $v['value'];
                        }
                        if ($v['action_type'] == 'post_like') {
                            $result['likes'] = $v['value'];
                        }
                    }
                }
                if ($key=='cost_per_action_type') {
                    foreach ($value as $k => $v) {
                        if ($v['action_type'] == 'mobile_app_install') {
                            $result['cost'] = $v['value'];
                        }
                        if ($v['action_type'] == 'link_click') {
                            $result['cpc_link'] = $v['value'];
                        }
                    }
                }
                if ($key=='relevance_score') {
                    $result['relevance_score'] = isset($value['score'])?$value['score']:0;
                }
            }

            $result['date_start'] = strtotime($result['date_start']);
            $result['date_stop'] = strtotime($result['date_stop']);
            $result['backup'] = json_encode($data);

            $insightinfo = $this->ad_insight_model->get_by_fields(['market_ad_id'=>$result['market_ad_id'], 'date_start'=>$result['date_start'], 'date_stop'=>$result['date_stop']]);
            if($insightinfo){
                $this->ad_insight_model->update_row_by_id($insightinfo['insight_id'], $result);
            }else{
                $this->ad_insight_model->add_one($result);
            }
        }
    }


    public function sync($value='')
    {
        $sql = "SELECT * FROM publisher_adaccount
                where account_id='587771568071339'
                GROUP BY account_id";
        $accountlist = $this->adaccount_model->get_query($sql);

        echo "\r\n\r\n\r\n\r\n\r\n";
        echo "sync yesterday  start:".date('Y-m-d H:i:s')."\r\n";
        echo "adaccount\r\n";

        foreach ($accountlist as $data) {

            $publsihinfo = $this->publisher_adaccount_model->get_by_fields(['market_account_id'=>$data['market_account_id']]);
            if (!$publsihinfo) {
                continue;
            }

            $this->load->library('facebookapi', ['user_id'=>$publsihinfo['publisher_id']]);

            $adset_sql = "select * from adset where market_account_id=".$data['market_account_id'];
            $adset_list = $this->adset_model->get_query($adset_sql);

            foreach ($adset_list as $adset) {
                $data = $this->facebookapi->getAdsetToAds($adset['adset_id']);
                    
                $product_info = $this->get_product_info($adset['object_store_url']);
                if (!$product_info) {
                    continue;
                }

                $publisher_info = $this->get_publisher_info($adset['market_account_id']);

                if (!$publisher_info) {
                    continue;
                }
                
                foreach ($data as $item) {
                    $ad_info = $this->ad_model->get_by_fields(['ad_id'=>$item['id']]);

                    $vars = ['advertiser_id'=>$product_info['user_id'], 'advertiser_name'=>$product_info['user_name'], 'product_id'=>$product_info['product_id'],
                            'product_name'=>$product_info['name'], 'publisher_id'=>$publisher_info['publisher_id'], 'publisher_name'=>$publisher_info['publisher_name']];
                
                    $vars['ad_id']          = $item['id'];
                    $vars['name']           = $item['name'];
                    $vars['adset_id']       = $adset['adset_id'];
                    $vars['market_adset_id']= $adset['market_adset_id'];
                    $vars['adset_name']     = $adset['name'];
                    $vars['campaign_id']    = $adset['campaign_id'];
                    $vars['market_campaign_id']    = $adset['market_campaign_id'];
                    $vars['campaign_name']  = $adset['campaign_name'];
                    $vars['account_id']     = $adset['account_id'];
                    $vars['market_account_id']     = $adset['market_account_id'];
                    $vars['account_name']   = $adset['account_name'];

                    $vars['updated_time']   = strtotime($item['updated_time']);
                    $vars['created_time']   = strtotime($item['created_time']);

                    if (!$item['adcreatives']['data']) {
                        continue;
                    }

                    $creatives = $item['adcreatives']['data'][0];

                    $vars['creatives'] = $creatives['id'];
                    $vars['ad_review_feedback'] = json_encode($item['ad_review_feedback']);
                    $vars['status'] = $item['status'];
                    $vars['effective_status'] = $item['effective_status'];
                    $vars['configured_status'] = $item['configured_status'];
                    
                    $vars['image_url']      = $creatives['image_url'];
                    $vars['thumbnail_url']  = $creatives['thumbnail_url'];
                    $vars['object_story_spec'] =  json_encode($creatives['object_story_spec']);

                    $vars['backup'] = json_encode($item);
                    if (isset($creatives['object_story_spec']['link_data'])) {
                        $object_story_spec = $creatives['object_story_spec']['link_data'];
                        
                        $vars['message'] = $object_story_spec['message'];
                        $vars['title'] = $object_story_spec['call_to_action']['value']['link_title'];
                    }
                    if ($ad_info) {
                        $this->ad_model->update_row_by_id($ad_info['market_ad_id'], $vars);
                        $market_ad_id = $ad_info['market_ad_id'];
                    }else{
                        $market_ad_id = $this->ad_model->add_one($vars);
                    }

                    $vars['market_ad_id'] = $market_ad_id;
                    if (isset($item['insights'])) {
                        $this->ad_insights($vars, $item['insights']);
                    }
                    

                    
                }
                
            }
            echo "done";die();
        }
    }

}