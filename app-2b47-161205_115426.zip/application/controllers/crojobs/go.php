<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Go extends CI_Controller {


    /**
    * 初使化
    */ 
    public function __construct()
    {
        parent::__construct();
        
        $this->load->library('curl'); 
    }

    function getMillisecond() {
        list($t1, $t2) = explode(' ', microtime());
        return (float)sprintf('%.0f',(floatval($t1)+floatval($t2))*1000);
    }


    //模拟登录 
    function login_post($url, $cookie, $post) { 


        //获取token
        $curl = curl_init("http://data.wecloud.io"); //初始化
        curl_setopt($curl, CURLOPT_HEADER, 1); //不返回header部分
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true); //返回字符串，而非直接输出
        curl_setopt($curl, CURLOPT_COOKIEJAR,  $cookie); //存储cookies
        $s = curl_exec($curl);
        curl_close($curl);
        $header = explode("\n", $s);



        //登陆
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);//登录提交的地址 
        curl_setopt($curl, CURLOPT_HTTPHEADER, $header);//是否显示头信息 
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 0);//是否自动显示返回的信息 
        curl_setopt($curl, CURLOPT_COOKIEFILE, $cookie); //设置Cookie信息保存在指定的文件中 
        curl_setopt($curl, CURLOPT_POST, 1);//post方式提交 
        curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($post));//要提交的信息 

        curl_exec($curl);//执行cURL 
        $info = curl_getinfo($curl,CURLINFO_EFFECTIVE_URL);
        curl_close($curl);



        $time = $this->getMillisecond();
        $info = "http://data.wecloud.io/api/promote/report/ga?cacheBuster=".$time."&endDate=2016-09-07T06:14:27.225Z&productId=197&startDate=2016-08-31T06:14:27.225Z&type=4_2";
        $info = "http://data.wecloud.io/api/promote/products?cacheBuster=".$time;

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);//是否显示头信息 
        curl_setopt($ch, CURLOPT_URL, $info);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER,0);        
        curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
        $rs=curl_exec($ch);
        curl_close($ch);  

        var_dump($rs);
        die();      
        return $rs;
    } 



    public function sync()
    {
        $this->load->model('adset_retention_model');
        $this->load->model('product_model');
        $this->load->model('reports_model');
        $this->load->model('publisher_offer_model');
        $this->load->library('aws_sqs');

        $this->load->library('aws_dynamodb');
        $this->load->library('fetch_adset_data');

        $start_date = "2016-08-19";
        $end_date   = "2016-08-26";
        $product = "com.ss.android.article.mynews.br";
        //$product = "com.ss.android.article.master";

        $post = array ( 
            'j_username ' => 'tn', 
            'j_password' => 'palmax',
            'submit' => 'Login'
        ); 
        log_message('debug','fetch_go_data. Starting.-> Product : ' . $product. ' Start : '.$start_date.' End : '.$end_date);
        $time = $this->getMillisecond();
        //登录地址 
        $login_url = "http://data.wecloud.io/api/authentication?cacheBuster=".$time; 
        $cookie = './uploads/go.txt'; 

        $data = $this->login_post($login_url, $cookie,$post); 
        var_dump($data);die();
        if (!$data) {
            log_message('debug','fetch_appsflyer_data. retention is empty.-> Product : ' . $product. ' Start : '.$start_date.' End : '.$end_date);
            return false;
        }

        foreach (explode("\n", $data) as $key=>$row) {
            if ($key==0) {
                continue;
            }

            $item = explode(',', $row);

            if (!isset($item[2])) {
                continue;
            }

            $adset_name = $item[2];

            if ($s = strpos($item[2], "_Instagram")) {
                $adset_name = substr($item[2], 0, $s);
            }

            
            if ($s = strpos($item[2], "_AudienceNetwork")) {
                $adset_name = substr($item[2], 0, $s);
            }


            $campaign_name = $item[3];

            if ($s = strpos($campaign_name, "_Instagram")) {
                $campaign_name = substr($campaign_name, 0, $s);
            }

            
            if ($s = strpos($campaign_name, "_AudienceNetwork")) {
                $campaign_name = substr($campaign_name, 0, $s);
            }

            $adset_info = $this->reports_model->get_report_data("select adset_id,adset_name,product_id,advertiser_id,app_id,account_id,account_name,campaign_id,campaign_name from marketmax_reports where campaign_name='".$campaign_name."' and adset_name='".$adset_name."' limit 1");
            
            if (!$adset_info) {
                continue;
            }
            $adset_id = $adset_info[0]['adset_id'];
            $country = $item[1];
            $date = $item[0];
            $retention = $item[4]?sprintf("%.4f", $item[7]/$item[4]):0;

            $vars = ['adset_id'=>$adset_id, 'adset_name'=>$item[2], 'country'=>strtoupper($country), 'date'=>strtotime($date), 'day0'=>intval($item[4]), 'retention'=>$retention];

            $vars['product_id'] = $adset_info[0]['product_id'];
            $vars['advertiser_id'] = $adset_info[0]['advertiser_id'];
            $vars['account_id'] = $adset_info[0]['account_id'];
            $vars['account_name'] = $adset_info[0]['account_name'];
            $vars['campaign_name'] = $adset_info[0]['campaign_name'];
            $vars['campaign_id'] = $adset_info[0]['campaign_id'];

            $j=1;
            for ($i=5; $i <= 30; $i++) { 
                if (isset($item[$i])) {
                    $vars['day'.$j] = intval($item[$i]);
                    $j++;
                }
            }


            $info = $this->adset_retention_model->get_by_fields(['adset_name'=>$item[2], 'adset_id'=>$adset_id, 'country'=>strtoupper($country), 'date'=>strtotime($date)]);
            if ($info) {
                $this->adset_retention_model->update_row_by_id($info['retention_id'], $vars);
            }else{
                $this->adset_retention_model->add_one($vars);
            }
            //更新报表数据
            $this->fetch_adset_data->update_revenue_by_retention($vars['date'], $vars['adset_id'], $vars['country']);
        }
        log_message('debug','fetch_appsflyer_data. End.-> Product : ' . $product. ' Start : '.$start_date.' End : '.$end_date);
        
    }
}