<?php if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

/**
 *
 * Created by PhpStorm.
 * User: palmax
 * Date: 2016/4/26
 * Time: 15:10
 */
class Report extends Web_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('adaccount_model');
        $this->load->model('adset_model');
        $this->load->model('adset_insight_model');
        $this->load->model('publisher_offer_model');
        $this->load->model('publisher_adaccount_model');
        $this->load->model('adset_country_log_model');
        $this->load->model('adset_country_month_log_model');
        $this->load->model('reports_model');
        $this->load->model('product_model');

        $this->load->model('user_model');

        $this->load->library('pagination');

        $this->load->library('aws_dynamodb');

        $this->data['top_menu']=$this->load->view('web/top_menu_report', '', TRUE);
    }


    private function get_retention_data($start, $end='')
    {
        $retention_sql="select * from adset_retention where date>=" . $start;
        if ($end) {
            $retention_sql.=" and date<=" . $end;
        }
        //$retention_sql .= " group by date";
        $retention_data=$this->adset_insight_model->get_query($retention_sql);

        $retentions=[];
        if ($retention_data) {
            foreach ($retention_data as $key=>$value) {
                $retentions[$value['adset_id']][$value['date']][$value['country']]=$value;
            }
        }
        return $retentions;
    }

    /**
     * 提供Convertion report的每天的是否有留存
     * @param  [type] $start [description]
     * @param  string $end [description]
     * @return [type]        [description]
     */
    private function get_retention_report_data($start, $end='')
    {
        $retention_sql="select * from adset_retention where date>=" . $start;
        if ($end) {
            $retention_sql.=" and date<=" . $end;
        }
        //$retention_sql .= " group by date";
        $retention_data=$this->adset_insight_model->get_query($retention_sql);

        $retentions=[];
        if ($retention_data) {
            foreach ($retention_data as $key => $value) {
                $date = date('m/d/Y', $value['date']);
                $retentions[$date] = $value;
                $month = date('M', $value['date']);
                $retentions[$month] = $value;
                $year = date('Y', $value['date']);
                $retentions[$year] = $value;
            }
        }
        return $retentions;
    }

    /**
     * 取用户设置的所有条件
     * @param  [type] $where [description]
     * @return [type]        [description]
     */
    private function get_custom_reports_list()
    {
       $this->load->model('custom_reports_model');

       $custom_where = ['user_id' => $this->userinfo['user_id'], 'status'=>1];
       if ($this->userinfo['type']==0) {
           $custom_where['is_admin'] = 1;
       }

       $data = $this->custom_reports_model->get_all($custom_where, 1, 100, ['addtime', 'asc']);
       $columns = $filters = [];
       if ($data) {
           foreach ($data as $key => $value) {
                $value['value'] = json_decode($value['value'], true);
               if ($value['type']=='columns') {
                   $columns[] = $value;
               }else{
                    $filters[] = $value;
               }
           }
       }
       return [$columns, $filters];
    }


    /**
     * convertion report
     * @return [type] [description]
     */
    public function index()
    {
        list($custom_columns, $custom_filters) = $this->get_custom_reports_list();

        $this->data['custom_columns'] = $custom_columns;
        $this->data['custom_filters'] = $custom_filters;


        $data_where=$where="1=1";
        if ($this->userinfo['type'] == 1) {
            $data_where=$where="advertiser_id=" . $this->userinfo['user_id'];
        } elseif ($this->userinfo['type'] == 2) {
            $data_where="marketmax_publisher_adaccount.publisher_id=" . $this->userinfo['user_id'];
            $where="publisher_id=" . $this->userinfo['user_id'];
        }
        $offer_sql="SELECT *
                        FROM publisher_offer
                        WHERE " . $where . "
                        ";

        $offer_list=$this->publisher_offer_model->get_query($offer_sql);

        $user_list = $this->user_model->get_query("select * from user");

        $productlist=$advertiserlist=$publisherlist=$offerlist=[];
        if ($offer_list) {
            foreach ($offer_list as $key=>$value) {
                $productlist[$value['product_id']]=['product_id'=>$value['product_id'], 'product_name'=>$value['product_name']];
                $offerlist[$value['offer_id']]=['offer_id'=>$value['offer_id'], 'product_name'=>$value['product_name']];
            }
        }

        $product_sql="SELECT *
                        FROM product
                        ";

        $product_list=$this->publisher_offer_model->get_query($product_sql);
        foreach ($product_list as $key => $value) {
            $productlist[$value['product_id']]=['product_id'=>$value['product_id'], 'product_name'=>$value['name']];
        }


        foreach ($user_list as $key => $value) {
            if ($value['type']==1) {
                $advertiserlist[$value['user_id']]=['advertiser_id'=>$value['user_id'], 'advertiser_name'=>$value['user_name']];
            }else{
                $publisherlist[$value['user_id']]=['publisher_id'=>$value['user_id'], 'publisher_name'=>$value['user_name']];
            }
        }
        $this->data['productlist']=$productlist;
        $this->data['advertiserlist']=$advertiserlist;
        $this->data['publisherlist']=$publisherlist;
        $this->data['offerlist']=$offerlist;

        $this->config->load('country', TRUE);
        $this->data['config_country']=$this->config->item('country');


        if ($this->userinfo['type'] == 2) {
            $account_sql="SELECT *
                        FROM publisher_adaccount
                        WHERE publisher_id=" . $this->userinfo['user_id'];

        } elseif ($this->userinfo['type'] == 1) {
            $account_sql="SELECT *
                        FROM publisher_offer
                        WHERE advertiser_id=" . $this->userinfo['user_id'] . "
                        group by account_id
                        ";
            $agency_sql="select marketmax_publisher_adaccount.publisher_id,marketmax_publisher_adaccount.publisher_name from marketmax_reports RIGHT JOIN marketmax_publisher_adaccount ON marketmax_publisher_adaccount.account_id = marketmax_reports.account_id where advertiser_id=" . $this->userinfo['user_id'] . " and marketmax_publisher_adaccount.publisher_type=2 group by marketmax_publisher_adaccount.publisher_id,marketmax_publisher_adaccount.publisher_name";
            $this->data['agency_list']=$this->reports_model->get_report_data($agency_sql);
        } else {
            $account_sql="SELECT *
                        FROM publisher_adaccount
                        group by account_id
                        ";

            $agency_sql="select * from user where type=2 and publisher_type=2";
            $agency_list=$this->publisher_adaccount_model->get_query($agency_sql);
            foreach ($agency_list as $key=>& $value) {
                $value['publisher_id']=$value['user_id'];
                $value['publisher_name']=$value['user_name'];
            }

            $this->data['agency_list']=$agency_list;
        }


        $this->data['accountlist']=$this->publisher_adaccount_model->get_query($account_sql);


        $yesteday=strtotime(date('Y-m-d', strtotime('-6 day')));
        //$yesteday = 1462665600;

        $data_where.=" and date>=" . $yesteday . " and (spend>0 or results>0) and product_id>0";

        

        $data_sql="SELECT date,
                        sum(results) as results, 
                        sum(clicks) as clicks, 
                        sum(clicks_link) as clicks_link, 
                        sum(spend) as spend,
                        sum(revenue) as revenue,
                        sum(real_earning) as real_earning,
                        sum(impressions) as impressions,
                        sum(expect_revenue) as expect_revenue,
                        sum(day0) as day0,
                        sum(rpa*results) as amount_cost
                    FROM marketmax_reports 
                    WHERE " . $data_where . "
                    GROUP BY date
                    ORDER BY date desc,results desc ";
        if ($this->userinfo['type'] == 2) {

            $data_sql="SELECT date,
                        sum(results) as results, 
                        sum(clicks) as clicks, 
                        sum(clicks_link) as clicks_link, 
                        sum(spend) as spend,
                        sum(revenue) as revenue,
                        sum(real_earning) as real_earning,
                        sum(impressions) as impressions,
                        sum(expect_revenue) as expect_revenue,
                        sum(day0) as day0,
                        sum(rpa*results) as amount_cost
                    FROM marketmax_reports 
                    LEFT JOIN marketmax_publisher_adaccount ON marketmax_publisher_adaccount.account_id = marketmax_reports.account_id
                    WHERE " . $data_where . "
                    GROUP BY date
                    ORDER BY date desc,results desc ";
        }

        if ($this->input->get('publisher')) {
            $data_where .= " and publisher_id=".$this->input->get('publisher');
            $data_sql="SELECT date,
                        sum(results) as results, 
                        sum(clicks) as clicks, 
                        sum(clicks_link) as clicks_link, 
                        sum(spend) as spend,
                        sum(revenue) as revenue,
                        sum(real_earning) as real_earning,
                        sum(impressions) as impressions,
                        sum(expect_revenue) as expect_revenue,
                        sum(day0) as day0,
                        sum(rpa*results) as amount_cost,
                        publisher_name
                    FROM marketmax_reports 
                    WHERE " . $data_where . "
                    GROUP BY date,publisher_name
                    ORDER BY date desc,results desc ";
        }elseif ($this->input->get('agency')) {
            $data_where .= " and marketmax_publisher_adaccount.publisher_id=".$this->input->get('agency');
            $data_sql="SELECT date,
                        sum(results) as results, 
                        sum(clicks) as clicks, 
                        sum(clicks_link) as clicks_link, 
                        sum(spend) as spend,
                        sum(revenue) as revenue,
                        sum(real_earning) as real_earning,
                        sum(impressions) as impressions,
                        sum(expect_revenue) as expect_revenue,
                        sum(day0) as day0,
                        sum(rpa*results) as amount_cost,
                        marketmax_publisher_adaccount.publisher_name
                    FROM marketmax_reports 
                    LEFT JOIN marketmax_publisher_adaccount ON marketmax_publisher_adaccount.account_id = marketmax_reports.account_id
                    WHERE " . $data_where . "
                    GROUP BY date,marketmax_publisher_adaccount.publisher_name
                    ORDER BY date desc,results desc ";
        }

        $data=$this->reports_model->get_report_data($data_sql);
        $last_day=strtotime(date('Y-m-d'));//获取最新的数据日期

        $chart_date = $chart_results = $chart_day0 = $chart_earning = $chart_real_earning = $chart_roi = $chart_cpi = $chart_a_f = [];

        if ($data) {
            foreach ($data as $key=>& $value) {
                $date=$value['date'];
                if ($last_day == strtotime(date('Y-m-d'))) {
                    $last_day=$date;
                }
                $chart_date[]           = $value['date']=date('m/d/Y', $value['date']);
                $value['week']          = date('W', $date);
                $value['ctr']           = $value['impressions']?sprintf("%.2f", $value['clicks'] / $value['impressions']*100):0;
                $value['ctr_link']      = $value['impressions']?sprintf("%.2f", $value['clicks_link'] / $value['impressions']*100):0;

                $value['cvr']           = $value['clicks']?sprintf("%.2f", $value['results'] / $value['clicks']*100):0;
                $value['cvr_link']      = $value['clicks_link']?sprintf("%.2f", $value['results'] / $value['clicks_link']*100):0;

                $value['cpc']           = $value['clicks']?sprintf("%.2f", $value['spend'] / $value['clicks']*100):0;
                $value['cpc_link']      = $value['clicks_link']?sprintf("%.2f", $value['spend'] / $value['clicks_link']*100):0;

                $value['clicks']        = $value['clicks'];
                $chart_real_earning[]   = sprintf("%.2f", $value['real_earning']);
                $chart_earning[]        = sprintf("%.2f", $value['expect_revenue']);
                $chart_roi[]            = sprintf("%.2f", ($value['real_earning']-$value['spend'])/$value['spend']*100);
                $chart_cpi[]            = $value['day0']>0?sprintf("%.2f", $value['spend']/$value['results']*100):0;
                $chart_day0[]           = $value['day0'];
                $chart_results[]        = $value['results'];
                $chart_a_f[]            = $value['results']>0?sprintf("%.2f", $value['day0']/$value['results']*100):0;
            }
        }
        $this->data['data']=$data;

        $this->data['days']=round((strtotime(date('Y-m-d')) - $last_day) / 86400) - 1;

        $this->data['retentions']=[];//$this->get_retention_report_data($yesteday);

        $this->data['chart_date']           = json_encode(array_reverse($chart_date));
        $this->data['chart_real_earning']   = json_encode(array_reverse($chart_real_earning));
        $this->data['chart_earning']        = json_encode(array_reverse($chart_earning));
        $this->data['chart_roi']            = json_encode(array_reverse($chart_roi));
        $this->data['chart_cpi']            = json_encode(array_reverse($chart_cpi));
        $this->data['chart_day0']           = json_encode(array_reverse($chart_day0));
        $this->data['chart_a_f']            = json_encode(array_reverse($chart_a_f));
        $this->data['chart_results']        = json_encode(array_reverse($chart_results));

        $template='report_index';
        $this->template->build($template, $this->data);
    }


    private function getReportData($where, $group="date", $order_by, $offset=0)
    {

        $join=$join_fields="";
        $limit = 50;


        $offset <0 && $offset=0;

        !$offset && $offset=0;
        if ($group) {
            $data_sql="SELECT 
                        " . $group . ",
                        sum(results) as results, 
                        sum(clicks) as clicks, 
                        sum(clicks_link) as clicks_link, 
                        sum(spend) as spend,
                        sum(revenue) as revenue,
                        sum(real_earning) as real_earning,
                        sum(impressions) as impressions,
                        sum(expect_revenue) as expect_revenue,
                        sum(day0) as day0,
                        sum(day1) as day1,
                        sum(rpa*results) as amount_cost
                    FROM marketmax_reports 
                    WHERE " . $where . "
                    GROUP BY " . $group . "
                    ORDER BY " . $order_by . ",results desc 
                    LIMIT  " . $limit. "
                    OFFSET " . $offset;
            
            $count_sql = "SELECT 1,
                        sum(results) as results 
                    FROM marketmax_reports 
                    WHERE " . $where . "
                    GROUP BY " . $group . "
                    ";

            if (strpos($where, 'publisher_id') || strpos($group, 'publisher_id') || strpos($group, 'publisher_name')) {
                $data_sql="SELECT 
                        " . $group . ",
                        sum(results) as results, 
                        sum(clicks) as clicks, 
                        sum(clicks_link) as clicks_link, 
                        sum(spend) as spend,
                        sum(revenue) as revenue,
                        sum(real_earning) as real_earning,
                        sum(impressions) as impressions,
                        sum(expect_revenue) as expect_revenue,
                        sum(day0) as day0,
                        sum(day1) as day1,
                        sum(rpa*results) as amount_cost
                    FROM marketmax_reports 
                    LEFT JOIN marketmax_publisher_adaccount ON marketmax_publisher_adaccount.account_id = marketmax_reports.account_id
                    WHERE " . $where . "
                    GROUP BY " . $group . "
                    ORDER BY " . $order_by . ",results desc
                    LIMIT  " . $limit. "
                    OFFSET " . $offset;
                $count_sql = "SELECT 1,
                        sum(results) as results
                    FROM marketmax_reports 
                    LEFT JOIN marketmax_publisher_adaccount ON marketmax_publisher_adaccount.account_id = marketmax_reports.account_id
                    WHERE " . $where . "
                    GROUP BY " . $group . "
                    ";
            }
        } else {
            $data_sql="SELECT " . $group . ",
                        sum(results) as results, 
                        sum(clicks) as clicks, 
                        sum(clicks_link) as clicks_link, 
                        sum(spend) as spend,
                        sum(revenue) as revenue,
                        sum(real_earning) as real_earning,
                        sum(impressions) as impressions,
                        sum(expect_revenue) as expect_revenue,
                        sum(day0) as day0,
                        sum(day1) as day1,
                        sum(rpa*results) as amount_cost
                    FROM marketmax_reports 
                    LEFT JOIN marketmax_publisher_adaccount ON marketmax_publisher_adaccount.account_id = marketmax_reports.account_id
                    WHERE " . $where . "
                    ORDER BY " . $order_by . ",results desc 
                    LIMIT  " . $limit. "
                    OFFSET " . $offset;
            $count_sql = "SELECT 1,
                        sum(results) as results
                    FROM marketmax_reports 
                    LEFT JOIN marketmax_publisher_adaccount ON marketmax_publisher_adaccount.account_id = marketmax_reports.account_id
                    WHERE " . $where . "
                    ";
        }
        $data = $this->reports_model->get_report_data($data_sql);
        $total_rows = $this->reports_model->get_report_data($count_sql);

        $config['base_url'] = site_url('report/index');
        $config = get_web_page($config, count($total_rows), 3);
        $config['cur_page'] = $offset;
        $config['use_page_numbers'] = false;

        $config['per_page'] = $limit;


        $this->pagination->initialize($config);
        $page_links = $this->pagination->create_links();

        $page_links = str_replace("href", "data-href", $page_links);
        $page_links = str_replace("data-href", " onclick='reports_page_links(this)' data-href", $page_links);

        if ($data) {
            foreach ($data as $key=>& $value) {
                if (isset($value['date'])) {
                    $date = $value['date'];
                    $value['date'] = date('m/d/Y', $value['date']);
                    $value['week'] = date('W', $date);
                    $value['month'] = date('M', $date);
                    $value['year'] = date('Y', $date);
                }

                //$value['cvr'] = $value['clicks']>0?sprintf("%.2f", $value['results']/$value['clicks']*100)."%":0;
                $value['rr']=0;
                $value['spend']=sprintf("%.2f", $value['spend']);
                if (isset($value['retentions']))
                    $value['rr']=$value['results'] > 0?intval($value['retentions'] / $value['results'] * 100) . "%":0;
                //$value['results'] = $value['results'];//number_format($value['results']);
                //$value['clicks'] = $value['clicks'];//number_format($value['clicks']);
            }
        }
        return [$data, $page_links];
    }

    private function getReportChartData($where, $group="date", $order_by)
    {
        $join=$join_fields="";
        if (strpos($group, 'month')===false && strpos($group, 'year')===false) {
            $group .= ",date";
            $order_by = "date desc";
        }
        
        if ($group) {
            $data_sql="SELECT 
                        " . $group . ",
                        sum(results) as results, 
                        avg(cpm) as cpm,
                        avg(cpc) as cpc,
                        avg(ctr) as ctr,
                        sum(clicks) as clicks, 
                        sum(clicks_link) as clicks_link, 
                        sum(spend) as spend,
                        sum(revenue) as revenue,
                        sum(real_earning) as real_earning,
                        sum(impressions) as impressions,
                        sum(expect_revenue) as expect_revenue,
                        sum(day0) as day0,
                        sum(day1) as day1,
                        sum(rpa*results) as amount_cost
                    FROM marketmax_reports 
                    WHERE " . $where . "
                    GROUP BY " . $group . "
                    ORDER BY " . $order_by . ",results desc";

            if (strpos($where, 'publisher_id') || strpos($group, 'publisher_id') || strpos($group, 'publisher_name')) {
                $data_sql="SELECT 
                        " . $group . ",
                        sum(results) as results, 
                        avg(cpm) as cpm,
                        avg(cpc) as cpc,
                        avg(ctr) as ctr,
                        sum(clicks) as clicks, 
                        avg(cpm) as cpm,
                        sum(clicks_link) as clicks_link, 
                        sum(spend) as spend,
                        sum(revenue) as revenue,
                        sum(real_earning) as real_earning,
                        sum(impressions) as impressions,
                        sum(expect_revenue) as expect_revenue,
                        sum(day0) as day0,
                        sum(day1) as day1,
                        sum(rpa*results) as amount_cost
                    FROM marketmax_reports 
                    LEFT JOIN marketmax_publisher_adaccount ON marketmax_publisher_adaccount.account_id = marketmax_reports.account_id
                    WHERE " . $where . "
                    GROUP BY " . $group . "
                    ORDER BY " . $order_by . ",results desc";
            }
        } else {
            $data_sql="SELECT " . $group . ",
                        sum(results) as results, 
                        avg(cpm) as cpm,
                        avg(cpc) as cpc,
                        avg(ctr) as ctr,
                        sum(clicks) as clicks, 
                        avg(cpm) as cpm,
                        sum(clicks_link) as clicks_link, 
                        sum(spend) as spend,
                        sum(revenue) as revenue,
                        sum(real_earning) as real_earning,
                        sum(impressions) as impressions,
                        sum(expect_revenue) as expect_revenue,
                        sum(day0) as day0,
                        sum(day1) as day1,
                        sum(rpa*results) as amount_cost
                    FROM marketmax_reports 
                    LEFT JOIN marketmax_publisher_adaccount ON marketmax_publisher_adaccount.account_id = marketmax_reports.account_id
                    WHERE " . $where . "
                    ORDER BY " . $order_by . ",results desc";
        }
        $data = $this->reports_model->get_report_data($data_sql);
        if ($data) {
            foreach ($data as $key=>& $value) {
                if (isset($value['date'])) {
                    $date = $value['date'];
                    $value['date'] = date('m/d/Y', $value['date']);
                    $value['week'] = date('W', $date);
                    $value['month'] = date('M', $date);
                    $value['year'] = date('Y', $date);
                }

                //$value['cvr'] = $value['clicks']>0?sprintf("%.2f", $value['results']/$value['clicks']*100)."%":0;
                $value['rr']=0;
                $value['spend']=sprintf("%.2f", $value['spend']);
                if (isset($value['retentions']))
                    $value['rr']=$value['results'] > 0?intval($value['retentions'] / $value['results'] * 100) . "%":0;
                //$value['results'] = $value['results'];//number_format($value['results']);
                //$value['clicks'] = $value['clicks'];//number_format($value['clicks']);
            }
        }
        return $data;
    }

    private function getFileds($filed)
    {

        $fileds = ['real_profit'=>'Real Profit', 'offer_id'=>'Offer ID', 'account_id'=>'Account ID', 'agency_id'=>'Agency', 'publisher_id'=>'Publisher', 'advertiser_id'=>'Advertiser', 'rr'=>'RR', 'product_id'=>'Product', 'product_name'=>'Product', 'adset_id'=>'Ad Set', 'campaign_id'=>'Campaign', 'spend'=>'Amount Spent', 'anticipated_income'=>'Earning', 'revenue'=>'Real Earning', 'facebook_cpi'=>'Facebook CPI', 'clicks'=>'Clicks(All)', 'clicks_link'=>'Clicks(Link)', 'epa'=>'EPA(earning per action)','ctr_all'=>'CTR(All)', 'ctr_link'=>'CTR(Link)', 'cvr_all'=>'CVR(All)', 'cvr_link'=>'CVR(Link)', 'cpc_all'=>'CPC(All)', 'cpc_link'=>'CPC(Link)', 'cpm'=>'CPM', 'roi'=>'ROI', 'amount_cost'=>'Amount Cost', 'day0'=>"Day 0 Installs", 'day1'=>'Day X Installs', 'retention'=>'Retention Rate', 'appsflyer_facebook'=>'A / F'];
        return isset($fileds[$filed])?$fileds[$filed]:ucfirst($filed);
    }


    public function get_fields($select_fields)
    {
        $select_data = $select_interval = $select_calculations = $select_statistics = $select_retention = [];
        $data           = ['product_name', 'offer_id', 'advertiser_id', 'publisher_id', 'agency_id', 'country', 'account_id', 'campaign_id', 'adset_id'];
        $statistics     = ['impressions', 'clicks', 'clicks_link', 'results', 'epa', 'amount_cost', 'facebook_cpi', 'spend', 'anticipated_income', 'revenue', 'profit', 'real_profit'];
        $calculations   = ['ctr_all', 'ctr_link', 'cvr_all', 'cvr_link', 'cpc_all', 'cpc_link', 'cpm', 'roi'];
        $interval       = ['year', 'month', 'date'];
        $retention      = ['day0', 'day1', 'retention', 'appsflyer_facebook'];
        foreach ($select_fields as $v) {
            if (in_array($v, $data)) {
                $select_data[] = $v;
            }elseif (in_array($v, $interval)) {
                $select_interval[] = $v;
            }elseif (in_array($v, $calculations)) {
                $select_calculations[] = $v;
            }elseif (in_array($v, $statistics)) {
                $select_statistics[] = $v;
            }elseif (in_array($v, $retention)) {
                $select_retention[] = $v;
            }
        }

        return [$select_data, $select_interval, $select_calculations, $select_statistics, $select_retention];
    }


    public function create_report_action()
    {
        $memory_start = memory_get_usage();  

        $this->config->load('country', TRUE);
        $country=$this->config->item('country');

        $where="1=1 and (spend>0 or results>0)";
        if ($this->userinfo['type'] == 1) {
            $where.=" and advertiser_id=" . $this->userinfo['user_id'];
        } elseif ($this->userinfo['type'] == 2) {
            $where.=" and marketmax_reports.publisher_id=" . $this->userinfo['user_id'];
        }

        if ($this->input->is_ajax_request()) {
            $thead=$tbody=$field_show="";

            $group = "1";
            $is_join = false;
            $order_by = "results desc";

            $filter_offer       = $this->input->post('filter_offer');
            $filter_account     = $this->input->post('filter_account');
            $filter_advertiser  = $this->input->post('filter_advertiser');
            $filter_publisher   = $this->input->post('filter_publisher');
            $filter_product     = $this->input->post('filter_product');
            $filter_country     = $this->input->post('filter_country');
            $filter_agency      = $this->input->post('filter_agency');
            $page      = $this->input->post('page');


            list($data, $interval, $calculations, $statistics, $select_retention) = $this->get_fields($this->input->post('fields'));


            
 
            if ($filter_offer) {
                $where.=" and offer_id in (" . $filter_offer . ")";

                $thead.="<th>Offer ID</th>";
                $field_show[]='offer_id';
                $group.=",offer_id";
            }

            if ($filter_account) {
                $where.=" and marketmax_reports.account_id in (" . $filter_account . ")";

                $thead.="<th>Account ID</th>";
                $field_show[]='account_id';
                $group.=",marketmax_reports.account_id,marketmax_reports.account_name";
            }
            if ($filter_advertiser) {
                $where.=" and advertiser_id in (" . $filter_advertiser . ")";

                !in_array('advertiser_id', $data) && $thead.="<th>Advertiser</th>";
                !in_array('advertiser_id', $data) && $field_show[]='advertiser_name';
                !in_array('advertiser_id', $data) && $group.=",advertiser_id,advertiser_name";
            }

            if ($filter_publisher) {
                $where.=" and marketmax_reports.publisher_id in (" . $filter_publisher. ")";

                !in_array('publisher_id', $data) && $thead.="<th>Publisher</th>";
                !in_array('publisher_id', $data) && $field_show[]='publisher_name';
                !in_array('publisher_id', $data) && $group.=",marketmax_reports.publisher_id,marketmax_reports.publisher_name";
            }

            if ($filter_product) {
                $where.=" and product_id in (" . $filter_product . ")";

                !in_array('product_name', $data) && $thead.="<th>Product</th>";
                !in_array('product_name', $data) && $field_show[]='product_name';
                !in_array('product_name', $data) && $group.=",product_id,product_name";

            }

            if ($filter_country) {
                $filter_country_arr = explode(',', $filter_country);
                $filter_countrys = [];
                foreach ($filter_country_arr as $v) {
                    $filter_countrys[] = "'".$v."'";
                }

                $where.=" and country in (" .implode(',', $filter_countrys). ")";
                $thead.="<th>Country</th>";
                $field_show[]='country';
                $group.=",country";
            }

            if ($filter_agency) {
                $where.=" and marketmax_publisher_adaccount.publisher_id in (" . $filter_agency. ")";

                $thead.="<th>Agency</th>";
                $field_show[]='agency_id';
                $group.=",marketmax_publisher_adaccount.publisher_id,marketmax_publisher_adaccount.publisher_name";
            }

            $retentions = [];//获取有设置过留存的日期
            
            if ($this->input->post('date_start') && $this->input->post('date_end')) {

                $date_start=strtotime($this->input->post('date_start'));
                $date_end=strtotime($this->input->post('date_end'));
                if ($field_show) {
                    if (!in_array('month', $field_show) && !in_array('year', $field_show)) {
                        $where.=" and date>=" . $date_start . " and date<=" . $date_end;
                    }
                }else{
                    $where.=" and date>=" . $date_start . " and date<=" . $date_end;
                }
                
                //$retentions=$this->get_retention_report_data($date_start, $date_end);
            } else {
                //$retentions=$this->get_retention_report_data(strtotime(date('Y-m-d', strtotime('-6 day'))));
            }

            if ($this->input->post('keywords')) {
                $keywords = $this->input->post('keywords');

                $where .= " and campaign_name ilike '%$keywords%'";
                if ($field_show) {
                    if(!in_array("campaign_id", $field_show) || !in_array("campaign_name", $field_show)){
                        $field_show[] = 'campaign_name';
                        $group .= ",campaign_name,campaign_id";
                        $thead .= "<th>Campaign</th>";
                    }
                }else{
                    $field_show[] = 'campaign_name';
                    $group .= ",campaign_name,campaign_id";
                    $thead .= "<th>Campaign</th>";
                }
                
            }

            $chart_data = $this->getReportChartData($where, $group, $order_by);
            
            if ($interval) {
                foreach ($interval as $key => $value) {
                    $thead .= "<th>".$this->getFileds($value)."</th>";
                    $field_show[] = $value;
                    if ($value=='year') {
                        $group .= ",date_year";
                        $order_by = "date_year desc";
                    }elseif ($value=='month') {
                        $group .= ",date_month";
                        $order_by = "date_month desc";
                    }elseif ($value=='date') {
                        $group .= ",date";
                        $order_by = "date desc";
                    }
                }
            }
            if ($data) {
                if(in_array('account_id', $data)){
                    $data[] = 'marketmax_reports.account_name';
                    $data[] = 'marketmax_reports.account_id';
                    foreach ($data as $key => $value) {
                        if ($value=='account_id') {
                            unset($data[$key]);
                        }
                    }
                }
                if (in_array('agency_id', $data)) {
                    $data[]='marketmax_publisher_adaccount.publisher_name';
                    $data[]='marketmax_publisher_adaccount.publisher_id';
                    foreach ($data as $key=>$value) {
                        if ($value == 'agency_id') {
                            unset($data[$key]);
                        }
                    }
                    $where.=" and marketmax_publisher_adaccount.publisher_type=2";
                }

                in_array('campaign_id', $data) && $data[]='campaign_name';
                in_array('adset_id', $data) && $data[]='adset_name';
                if (in_array('product_name', $data) && !in_array('product_id', $data)) {
                    $data[]='product_id';
                    //$data[]='product_name';
                }
                foreach ($data as $key=>$value) {
                    $value == 'marketmax_reports.account_name' && $value='account_name';
                    $value == 'marketmax_reports.account_id' && $value='account_id';

                    $value == 'marketmax_publisher_adaccount.publisher_name' && $value='agency_name';
                    $value == 'marketmax_publisher_adaccount.publisher_id' && $value='agency_id';
                    if (!$field_show || !in_array($value, $field_show)) {
                        if (!in_array($value, ['account_name', 'campaign_id', 'adset_name', 'agency_name', 'product_name'])) {
                            $thead .= "<th>".$this->getFileds($value)."</th>";
                            $field_show[] = $value;
                        }
                    }
                }

                if (in_array('publisher_id', $data)) {

                    !in_array('publisher_name', $data) && $data['publisher_name'] = 'marketmax_reports.publisher_name';
                    foreach ($data as $key => $value) {
                        if ($value=='publisher_id') {
                            unset($data[$key]);
                        }
                    }
                    $group .= ",marketmax_reports.publisher_id";
                    $group .= ",marketmax_reports.publisher_name";
                }
                if (in_array('advertiser_id', $data)) {
                    !in_array('advertiser_name', $data) && $data['advertiser_name'] = 'advertiser_name';
                    foreach ($data as $key => $value) {
                        if ($value=='advertiser_id') {
                            unset($data[$key]);
                        }
                    }
                    $group .= ",advertiser_id";
                    //$group .= ",advertiser_name";
                }
                if (in_array('product_id', $data)) {
                    !in_array('product_name', $data) && $data['product_name'] = 'product_name';
                    foreach ($data as $key => $value) {
                        if ($value=='product_id') {
                            unset($data[$key]);
                        }
                    }
                    $group .= ",product_id";
                    //$group .= ",product_name";
                }
                if ($data) {
                    $group.="," . implode(',', $data);
                }
            }

            
            if ($statistics) {
                foreach ($statistics as $key => $value) {
                    if ($value=='results') {
                        $thead .= "<th class='footable-sortable sortInitialOrder-desc' data-sortinitialorder='desc'>".$this->getFileds($value)."<span class='footable-sort-indicator'></span></th>";
                    }else{
                        if ($this->userinfo['type']==0) {
                            if ($value=='anticipated_income') {
                                $thead .= "<th class='footable-sortable'>Media Buy Earning<span class='footable-sort-indicator'></span></th>";
                            }elseif ($value=='revenue') {
                                $thead .= "<th class='footable-sortable'>Real MB Earning<span class='footable-sort-indicator'></span></th>";
                            }elseif ($value=='profit') {
                                $thead .= "<th class='footable-sortable'>Media Buy Profit<span class='footable-sort-indicator'></span></th>";
                            }elseif ($value=='real_profit') {
                                $thead .= "<th class='footable-sortable'>Real Profit<span class='footable-sort-indicator'></span></th>";
                            }else{
                                $thead .= "<th class='footable-sortable'>".$this->getFileds($value)."<span class='footable-sort-indicator'></span></th>";
                            }
                        } else
                            $thead.="<th class='footable-sortable'>" . $this->getFileds($value) . "<span class='footable-sort-indicator'></span></th>";
                    }
                    $field_show[]=$value;
                }
            }
            if ($select_retention) {
                foreach ($select_retention as $key => $value) {
                    if ($value=='day0' || $value=='day1') {
                        //$group .= ",".$value;
                    }
                    $thead.="<th class='footable-sortable'>" . $this->getFileds($value) . "<span class='footable-sort-indicator'></span></th>";
                    $field_show[]=$value;
                }
                
            }

            if ($calculations) {
                foreach ($calculations as $key => $value) {
                    if($value=='retentions'){
                        $thead .= "<th>Retentions</th>";
                    }elseif($value=='rr'){
                        $thead .= "<th>RR</th>";
                    }elseif($value=='rpc'){
                        $thead .= "<th>RPC</th>";
                    }elseif($value=='rpa'){
                        $thead .= "<th>RPA</th>";
                    }elseif($value=='retention_rate'){
                        $thead .= "<th>Retention Rate</th>";
                    }else{
                        $thead .= "<th>".$this->getFileds($value)."</th>";
                    }
                    $field_show[]=$value;
                }
            }
            list($data, $page_links) = $this->getReportData($where, $group, $order_by, $page);

            $chart_date = $chart_results = $chart_day0 = $chart_earning = $chart_real_earning = $chart_roi = $chart_cpi = $chart_a_f = [];

            $breakwonws = ['product_id', 'product_name', 'advertiser_id', 'advertiser_name', 'publisher_id', 'publisher_name', 'agency_id', 'country', 'account_id', 'campaign_id', 'campaign_name', 'adset_id'];

            foreach ($breakwonws as $b) {
                if (in_array($b, $field_show)) {
                    $thead .= "<th></th>";
                }
            }
            $result = [];
            if ($data) {
                // if (strtotime($this->input->post('date_end')) == strtotime(date('Y-m-d'))) {
                //     if ($interval && in_array("date", $interval)) {
                //         $last_day = strtotime($data[0]['date']);
                //         $this->get_tabel_tr(strtotime(date('Y-m-d')), $last_day, $field_show, $tbody);
                //     }
                // }
                foreach ($data as $key => $value) {
                    //var_dump($value);
                    //if ($this->input->post('interval') && in_array("date", $this->input->post('interval')))
                    //    $this->get_tabel_tr(strtotime($data[0]['date']), strtotime($value['date']), $field_show, $tbody);
                    $tbody .= "<tr>";
                    foreach ($field_show as $k => $v) {
                        if ($v=='campaign_id') {
                            $tbody .= "<td>".$value['campaign_name']."</td>";
                        }elseif ($v=='account_id') {
                            $tbody .= "<td><a target='_blank' href='https://business.facebook.com/ads/manager/account/campaigns/?act=".$value[$v]."'>".$value[$v]."</a></td>";
                        }elseif ($v=='agency_id') {
                            $tbody .= "<td>".$value['publisher_name']."</td>";
                        }elseif ($v=='adset_id') {
                            $tbody .= "<td>".$value['adset_name']."</td>";
                        }elseif ($v=='publisher_id') {
                            $tbody .= "<td>".$value['publisher_name']."</td>";
                        }elseif ($v=='advertiser_id') {
                            $tbody .= "<td>".$value['advertiser_name']."</td>";
                        }elseif ($v=='product_name') {
                            if ($value['product_name']) {
                                $tbody .= "<td><a target='_blank' href='".site_url('product/detail/'.$value['product_id'])."'>".$value['product_name']."</a></td>";
                            }else{
                                $tbody .= "<td>Unknown</td>";
                            }
                        }elseif ($v=='product_id') {
                            if ($value['product_name']) {
                                $tbody .= "<td><a target='_blank' href='".site_url('product/detail/'.$value['product_id'])."'>".$value['product_name']."</a></td>";
                            }else{
                                $tbody .= "<td>Unknown</td>";
                            }
                        }elseif ($v=='country') {
                            if ($value[$v] == 'Unknown') {
                                $tbody .= "<td>Unknown</td>";
                            }else{
                                $c = isset($country['country'][$value[$v]])?$country['country'][$value[$v]]:$value[$v];
                                $tbody .= "<td>".$value[$v].' - '.$c."</td>";
                            }

                        } elseif ($v == 'rr') {
                            $tbody.="<td>" . $value['retention'] . "%</td>";
                        } elseif ($v == 'rpc') {
                            $rpc=$value['clicks']?($value['revenue'] - $value['spend']) / $value['clicks']:0;
                            $tbody.="<td>" . ($rpc > 0?"$" . sprintf("%.2f", $rpc):0) . "</td>";
                        } elseif ($v == 'rpa') {
                            $rpa=$value['results']?($value['revenue'] - $value['spend']) / $value['results']:0;
                            $tbody.="<td>" . ($rpa > 0?"$" . sprintf("%.2f", $rpa):0) . "</td>";
                        } elseif ($v == 'profit') {
                            $profit=($value['expect_revenue'] - $value['spend']);
                            $tbody.="<td>$" . number_format(sprintf("%.2f", $profit), 2) . "</td>";
                        } elseif ($v == 'real_profit') {
                            $profit=($value['real_earning'] - $value['spend']);
                            $tbody  .= "<td>" . ($value['real_earning']>0?"$".number_format(sprintf("%.2f", $profit), 2):'-') . "</td>";
                            // if (isset($value['date']) && isset($retentions[$value['date']])) {
                            //     $profit=($value['real_earning'] - $value['spend']);
                            //     $tbody.="<td>$" . (sprintf("%.2f", $profit)) . "</td>";
                            // }elseif (isset($value['date_month']) && isset($retentions[$value['date_month']])) {
                            //     $profit=($value['real_earning'] - $value['spend']);
                            //     $tbody.="<td>$" . (sprintf("%.2f", $profit)) . "</td>";
                            // }elseif (isset($value['date_year']) && isset($retentions[$value['date_year']])) {
                            //     $profit=($value['real_earning'] - $value['spend']);
                            //     $tbody.="<td>$" . (sprintf("%.2f", $profit)) . "</td>";
                            // }else{
                            //     $tbody .= "<td>-</td>";
                            // }

                        }elseif ($v=='revenue') {
                            $tbody .= "<td>".($value['real_earning']>0?"$".number_format(sprintf("%.2f", $value['real_earning']), 2):'-')."</td>";

                            // if (isset($value['date']) && isset($retentions[$value['date']])) {
                            //     $tbody .= "<td>".($value['real_earning']>0?"$".sprintf("%.2f", $value['real_earning']):'-')."</td>";
                            // }elseif (isset($value['date_month']) && isset($retentions[$value['date_month']])) {
                            //     $tbody .= "<td>".($value['real_earning']>0?"$".sprintf("%.2f", $value['real_earning']):'-')."</td>";
                            // }elseif (isset($value['date_year']) && isset($retentions[$value['date_year']])) {
                            //     $tbody .= "<td>".($value['real_earning']>0?"$".sprintf("%.2f", $value['real_earning']):'-')."</td>";
                            // }else{
                            //     $tbody .= "<td>-</td>";
                            // }
                        } elseif ($v == 'spend') {
                            $tbody.="<td>" . ($value['spend'] > 0?"$" . number_format(sprintf("%.2f", $value['spend']), 2):0) . "</td>";
                        } elseif ($v == 'payout') {
                            $tbody.="<td>" . ($value['payout'] > 0?"$" . number_format(sprintf("%.2f", $value['payout']), 2):0) . "</td>";
                        } elseif ($v == 'anticipated_income') {
                            $tbody.="<td>" . ($value['expect_revenue'] > 0?"$" . number_format(sprintf("%.2f", $value['expect_revenue']),2):0) . "</td>";
                        } elseif ($v == 'retention_rate') {
                            $tbody.="<td>" . ($value['retention'] > 0?sprintf("%.2f", $value['retention'] * 100) . "%":0) . "</td>";
                        } elseif ($v == 'facebook_cpi') {
                            $cpi=$value['results'] > 0?"$" . sprintf("%.2f", $value['spend'] / $value['results']):0;
                            $tbody.="<td>" . $cpi . "</td>";
                        } elseif ($v == 'epa') {
                            $epa=$value['results'] > 0?"$" . sprintf("%.2f", $value['expect_revenue'] / $value['results']):0;
                            $tbody.="<td>" . $epa . "</td>";
                        } elseif ($v == 'ctr_all') {
                            $ctr_all=$value['impressions'] > 0?sprintf("%.2f", $value['clicks'] / $value['impressions'] * 100) . "%":0;
                            $tbody.="<td>" . $ctr_all . "</td>";
                        } elseif ($v == 'ctr_link') {
                            $ctr_link=$value['impressions'] > 0?sprintf("%.2f", $value['clicks_link'] / $value['impressions'] * 100) . "%":0;
                            $tbody.="<td>" . $ctr_link . "</td>";
                        } elseif ($v == 'cvr_all') {
                            $cvr_all=$value['clicks'] > 0?sprintf("%.2f", $value['results'] / $value['clicks'] * 100) . "%":0;
                            $tbody.="<td>" . $cvr_all . "</td>";
                        } elseif ($v == 'cvr_link') {
                            $cvr_link=$value['clicks_link'] > 0?sprintf("%.2f", $value['results'] / $value['clicks_link'] * 100) . "%":0;
                            $tbody.="<td>" . $cvr_link . "</td>";
                        } elseif ($v == 'cpc_all') {
                            $cpc_all=$value['clicks'] > 0?"$" . sprintf("%.2f", $value['spend'] / $value['clicks']):0;
                            $tbody.="<td>" . $cpc_all . "</td>";
                        } elseif ($v == 'cpc_link') {
                            $cpc_link=$value['clicks_link'] > 0?"$" . sprintf("%.2f", $value['spend'] / $value['clicks_link']):0;
                            $tbody.="<td>" . $cpc_link . "</td>";
                        } elseif ($v == 'cpm') {
                            $cpm=$value['impressions'] > 0?"$" . sprintf("%.2f", $value['spend'] / $value['impressions'] * 1000):0;
                            $tbody.="<td>" . $cpm . "</td>";
                        } elseif (in_array($v, ['clicks', 'clicks_link', 'impressions', 'results', 'spend'])) {
                            $tbody.="<td>" . number_format($value[$v]) . "</td>";
                        } elseif ($v == 'amount_cost') {
                            $amount_cost="$" . sprintf("%.2f", $value['amount_cost']);
                            $tbody.="<td>" . $amount_cost . "</td>";
                        } elseif ($v == 'month' && isset($value['date_month'])) {
                            $tbody.="<td>" . $value['date_month'] . "</td>";
                        } elseif ($v == 'year' && isset($value['date_year'])) {
                            $tbody.="<td>" . $value['date_year'] . "</td>";
                        } elseif ($v == 'roi') {
                            $tbody.="<td>" . sprintf('%.2f', ($value['real_earning']-$value['spend'])/$value['spend']*100) . "%</td>";
                        } elseif ($v == 'retention') {
                            if ($value['day0']>0) {
                                $tbody.="<td>" . sprintf("%.2f", $value['day1']/$value['day0']*100) . "%</td>";
                            }else{
                                $tbody.="<td>-</td>";
                            }
                        } elseif ($v == 'day0') {
                            $tbody.="<td>" . ($value['day0']>0?$value['day0']:'-') . "</td>";
                        } elseif ($v == 'day1') {
                            $tbody.="<td>" . ($value['day1']>0?$value['day1']:'-') . "</td>";
                        } elseif ($v == 'appsflyer_facebook') {
                            $tbody.="<td>" . ($value['results']>0?sprintf('%.2f', $value['day0']/$value['results']*100)."%":'-') . "</td>";
                        }  else {
                            $tbody.="<td>" . $value[$v] . "</td>";
                        }
                    }

                    $data_fields= "";
                    foreach ($breakwonws as $b) {
                        if (in_array($b, $field_show)) {
                            if ($b=='publisher_name') {
                                $data_fields .= 'data-publisher_id="'.$value['publisher_id'].'" ';
                            }elseif ($b=='advertiser_name') {
                                $data_fields .= 'data-advertiser_id="'.$value['advertiser_id'].'" ';
                            }elseif ($b=='advertiser_id') {
                                $data_fields .= 'data-advertiser_id="'.$value['advertiser_id'].'" ';
                            }elseif ($b=='product_name') {
                                $data_fields .= 'data-product_id="'.$value['product_id'].'" ';
                            }elseif ($b=='campaign_name') {
                                $data_fields .= 'data-campaign_id="'.$value['campaign_id'].'" ';
                            }elseif ($b=='agency_id') {
                                $data_fields .= 'data-agency_id="'.$value['publisher_id'].'" ';
                            }else
                                $data_fields .= 'data-'.$b.'="'.$value[$b].'" ';
                        }
                    }
                    if ($data_fields) {
                        if ($this->userinfo['type']==1) {
                            $data_fields .= "data-advertiser_id = ".$this->userinfo['user_id']." ";
                        }elseif ($this->userinfo['type']==2) {
                            $data_fields .= "data-publisher_id = ".$this->userinfo['user_id']." ";
                        }
                    }
                    $data_fields && $tbody .= '<td><img class="chart_img" onclick="report_li_chart(this)" '.$data_fields.' src="'.base_url().'assets/images/toggle_basic.png" class="toggle_btn" style="cursor: pointer;" data-click="'.base_url().'assets/images/toggle_click.png" data-base="'.base_url().'assets/images/toggle_basic.png" data-term="false"></td>';

                    $tbody.="</tr>";
                    
                    
                }
                
                foreach ($chart_data as $key => $value) {
                    if (isset($value['date'])) {
                        $date = $value['date'];
                    }elseif (isset($value['date_month'])) {
                        $date = $value['date_month'];
                    }elseif (isset($value['date_year'])) {
                        $date = $value['date_year'];
                    }

                    if ($date) {

                        $chart_date[$date]           = $date;
                    
                        if (isset($chart_real_earning[$date])) {
                            $chart_real_earning[$date]   += sprintf("%.2f", $value['real_earning']);
                        }else{
                            $chart_real_earning[$date]   = sprintf("%.2f", $value['real_earning']);
                        }
                        if (isset($chart_earning[$date])) {
                            $chart_earning[$date]        += sprintf("%.2f", $value['expect_revenue']);
                        }else
                            $chart_earning[$date]        = sprintf("%.2f", $value['expect_revenue']);
                        
                        if (isset($chart_roi[$date])) {
                            $value['spend']>0 && $chart_roi[$date]            += sprintf("%.2f", ($value['real_earning']-$value['spend'])/$value['spend']*100);
                        }else
                            $chart_roi[$date]            = $value['spend']>0?sprintf("%.2f", ($value['real_earning']-$value['spend'])/$value['spend']*100):0;
                        
                        if (isset($chart_cpi[$date])) {
                            $chart_cpi[$date]            += $value['results']>0?sprintf("%.2f", $value['spend']/$value['results']*100):0;
                        }else
                            $chart_cpi[$date]            = $value['results']>0?sprintf("%.2f", $value['spend']/$value['results']*100):0;
                        
                        if (isset($chart_day0[$date])) {
                            $chart_day0[$date]           += $value['day0'];
                        }else
                            $chart_day0[$date]           = $value['day0'];
                        
                        if (isset($chart_results[$date])) {
                            $chart_results[$date]        += $value['results'];
                        }else
                            $chart_results[$date]        = $value['results'];
                        
                        if (isset($chart_a_f[$date])) {
                            $chart_a_f[$date]            += $value['results']>0?sprintf("%.2f", $value['day0']/$value['results']*100):0;
                        }else
                            $chart_a_f[$date]            = $value['results']>0?sprintf("%.2f", $value['day0']/$value['results']*100):0;
                    }
                }
            }
            $memory_end = memory_get_usage();  

            $response=['memory_start'=>$memory_start,'memory_end'=>$memory_end, 'success'=>true, 'page_links'=>$page_links, 'thead'=>"<tr class='change_thead'>" . $thead . "</tr>", 'tbody'=>$tbody, 'thead_data'=>$field_show, 'chart_date'=>json_encode(array_reverse(array_values($chart_date))), 'chart_results'=>json_encode(array_reverse(array_values($chart_results))), 'chart_day0'=>json_encode(array_reverse(array_values($chart_day0))), 'chart_earning'=>json_encode(array_reverse(array_values($chart_earning))), 'chart_real_earning'=>json_encode(array_reverse(array_values($chart_real_earning))), 'chart_roi'=>json_encode(array_reverse(array_values($chart_roi))), 'chart_cpi'=>json_encode(array_reverse(array_values($chart_cpi))), 'chart_a_f'=>json_encode(array_reverse(array_values($chart_a_f)))];
        } else {
            $response=['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
        }
        $this->output->set_content_type('applicaion/json')->set_output(json_encode($response));
    }


    private function get_tabel_tr($current_time, $last_day, $field_show, & $tbody)
    {
        $days=round(($current_time - $last_day) / 86400) - 1;
        for ($i=1; $i <= $days; $i++) {
            $tbody.="<tr>";
            foreach ($field_show as $k=>$v) {
                if ($v == 'date') {
                    $tbody.="<td>" . date('m/d/Y', strtotime("-" . $i . " day", $current_time)) . "</td>";
                } elseif ($v == 'month') {
                    $tbody.="<td>" . date('M', strtotime("-" . $i . " day", $current_time)) . "</td>";
                } elseif ($v == 'year') {
                    $tbody.="<td>" . date('Y', strtotime("-" . $i . " day", $current_time)) . "</td>";
                } else {
                    $tbody.="<td>-</td>";
                }
            }
            $tbody.="</tr>";
        }
    }

    /**
     * 获取product统计信息
     */
    public function product_map()
    {
        //加载lib
        $this->load->library('report_service');
        //接收时间开始
        $date=strtotime(date('Y-m'));
        $date_time=date('Y-m');
        if ($this->input->get('date')) {
            $date_time=date('Y-m', strtotime($this->input->get('date')));
            $date=strtotime(date('Y-m', strtotime($this->input->get('date'))));
        }
        //选择的时间
        $start=$this->data['date_start']=date('m/d/Y', $date);
        $this->data['date_end']=date('m/d/Y', strtotime("$start +1 month -1 day"));
        $start=$this->data['date_start']=date('m/d/Y', $date);
        $this->data['date_end']=date('m/d/Y', strtotime("$start +1 month -1 day"));
        //渠道处理
        $channel=$this->input->get('channel', true);
        if ($this->userinfo['type'] == 0) {
            $where=['product.status'=>1];
            $product_ids=$this->report_service->get_product(0);
            $this->data['channels']=$this->report_service->get_publishers();
        } else {
            $where=['product.status'=>1];
            $product_ids=$this->report_service->get_product($this->userinfo['type'], $this->userinfo['user_id']);
            $this->data['channels']=$this->report_service->get_publishers($this->userinfo['user_id']);
        }
        $data=[];

        //判断请求类型
        $q=$this->input->get('q', true);
        //获取渠道的产品id
        if ($channel && $channel != 'all') {
            $channel_data=$this->report_service->get_channels(['publisher_adaccount.publisher_id'=>$channel]);
            $where['where_in']=['product.product_id', $channel_data];
        } else {
            if ($product_ids) {
                $where['where_in']=['product.product_id', $product_ids];
                //条件
                $and_where=['adset_country_month_log.date'=>$date, 'adset_country_month_log.set_retention >'=>0, 'adset_country_month_log.day0 >'=>0];
                if ($q) {
                    if ($channel && $channel != 'all') {
                        $where['like']=['product.name', $q];
                        $like=['product.name', $q];
                        $where['adset_country_month_log.publisher_id']=$channel;
                    }
                }
                $all_where=array_merge($where, $and_where);
                $data=$this->report_service->get_adsets($all_where);
            }
        }
        if (empty($data)) {
            $data=$this->report_service->get_product_offers($product_ids,$q);
        }
        $this->data['product_list']=$data;
        $template='report_product_map';
        $this->template->build($template, $this->data);
        //var_dump($this->data['product_list'][0]['countries']);die;

    }

    public function retention()
    {
        $this->load->model('product_model');
        if (!$this->input->get('product_id')) {
            redirect('report/retention');
        }

        $this->data['product_info']=$this->product_model->get_by_id($this->input->get('product_id'));

        if (!$this->data['product_info']) {
            redirect('report/retention');
        }


        if ($this->userinfo['type'] == 1) {
            $agency_sql="select marketmax_publisher_adaccount.publisher_id,marketmax_publisher_adaccount.publisher_name from marketmax_reports RIGHT JOIN marketmax_publisher_adaccount ON marketmax_publisher_adaccount.account_id = marketmax_reports.account_id where advertiser_id=" . $this->userinfo['user_id'] . " and marketmax_publisher_adaccount.publisher_type=2 group by marketmax_publisher_adaccount.publisher_id,marketmax_publisher_adaccount.publisher_name";
            $this->data['agency_list']=$this->reports_model->get_report_data($agency_sql);
        } elseif ($this->userinfo['type'] == 0) {
            $agency_sql="select * from user where publisher_type=2 and type=2";
            $agency_list=$this->user_model->get_query($agency_sql);

            foreach ($agency_list as $key=>& $value) {
                $value['publisher_id']=$value['user_id'];
                $value['publisher_name']=$value['user_name'];
            }
            $this->data['agency_list']=$agency_list;
        }


        $this->config->load('country', TRUE);
        $country=$this->data['config_country']=$this->config->item('country');


        if ($this->userinfo['type'] == 2) {
            $account_sql="SELECT *
                        FROM publisher_adaccount
                        WHERE publisher_id=" . $this->userinfo['user_id'];

        } elseif ($this->userinfo['type'] == 1) {
            $account_sql="SELECT *
                        FROM publisher_offer
                        WHERE advertiser_id=" . $this->userinfo['user_id'] . "
                        group by account_id";
        } else {
            $account_sql="SELECT *
                        FROM publisher_adaccount
                        group by account_id";
        }

        $this->data['accountlist']=$this->publisher_adaccount_model->get_query($account_sql);


        $where="product_id=" . $this->input->get('product_id');
        $month_where="set_retention>0 and day0>0";
        if ($this->userinfo['type'] == 1) {
            $month_where.=" and advertiser_id=" . $this->userinfo['user_id'];
            $where.=" and advertiser_id=" . $this->userinfo['user_id'];
        } elseif ($this->userinfo['type'] == 2) {
            $month_where.=" and publisher_id=" . $this->userinfo['user_id'];
            $where.=" and publisher_adaccount.publisher_id=" . $this->userinfo['user_id'];
        }
        $month_where.=" and product_id=" . $this->input->get('product_id');

        $group="";
        $is_join=false;

        $site_url=site_url('report/retention') . "?product_id=" . $this->input->get('product_id');

        $account=$countries=$publisher=[];

        if ($this->input->get('account')) {
            $account=explode(',', $this->input->get('account'));
            $site_url.="&account=" . $this->input->get('account');

            $where.=" and account_id in (" . $this->input->get('account') . ")";
        }

        if ($this->input->get('publisher')) {
            $filter_product=$this->input->get('publisher');
            $month_where.=" and publisher_id in (" . $filter_product . ")";
            $where.=" and publisher_adaccount.publisher_id in (" . $filter_product . ")";

            $publisher=explode(',', $this->input->get('publisher'));

            $site_url.="&publisher=" . $this->input->get('publisher');
        }


        if ($this->input->get('keywords')) {
            $keywords = trim($this->input->get('keywords'));
            $where .= " and campaign_name like '%".$keywords."%'";
            $site_url.="&keywords=" . $keywords;
        }

        $country_params=[];
        if ($this->input->get('country')) {
            $country_params=$countries=explode(',', $this->input->get('country'));

            $filter_country=[];
            foreach ($countries as $key=>$value) {
                $filter_country[]="'" . $value . "'";
            }
            $where.=" and country in (" . implode(',', $filter_country) . ")";

        }

        $this->data['publisher_params']=$publisher;
        $this->data['account_params']=$account;
        $this->data['country_params']=$country_params;

        $time_region="01/" . date('m') . " - " . date('d/m');


        $retentions=[];
        //获取时间条件范围
        if ($this->input->get('time')) {
            $time=$this->input->get('time');
            $time=date('Y-m', strtotime($time));
            $start=strtotime($time);
            $end=strtotime("$time +1 month");

            $site_url.="&time=" . $this->input->get('time');

            $month_where.=" and date=" . $start;

            $time_region="01/" . date('m', $start) . " - " . date('d/m', $end);
            //$retentions=$this->get_retention_data($start, $end);
        } else {
            //$retentions=$this->get_retention_data(strtotime(date('Y-m')));
        }
        $this->data['time_region']=$time_region;

        $month_rr=$this->get_month_data($month_where);

        if ($this->input->get('start') && $this->input->get('end')) {
            $start=strtotime($this->input->get('start'));
            $end=strtotime($this->input->get('end')) + 24 * 60 * 60;

            $site_url.="&start=" . $this->input->get('start');
            $site_url.="&end=" . $this->input->get('end');

            $where.=$tmp=" and date>=" . $start . " and date<" . $end;
            // $data_where .= $tmp;
        } else {
            $where.=$tmp=" and date>=" . strtotime(date('Y-m'));
            // $data_where .= $tmp;
        }

        $this->get_adset_retention_data($where, $site_url, $month_rr, $country);

        //$this->data['retentions']=$retentions;

        $template='report_retention';
        $this->template->build($template, $this->data);
    }


    public function get_adset_retention_data($where, $site_url, $month_rr, $country)
    {
        $config['base_url']=$site_url;
        $count_sql="SELECT 
                count(*) as count
                FROM adset_retention 
                WHERE " . $where;
        if (strpos($where, "publisher_adaccount")) {
            $count_sql="SELECT count(*) as count
                FROM adset_retention 
                LEFT JOIN publisher_adaccount ON publisher_adaccount.account_id = adset_retention.account_id
                where " . $where;
        }

        $total_rows=$this->adset_country_month_log_model->get_one($count_sql);
        $this->data['total_rows']=$total_rows?$total_rows['count']:0;

        //$total_rows = 1500;
        $config=get_web_page($config, $total_rows['count'], 3);


        $page=1;
        if ($this->input->get('page'))
            $page=$this->input->get('page');

        $limit=$config['per_page']=30;

        $this->pagination->initialize($config);
        $this->data['page_links']=$this->pagination->create_links();


        $sql="select * from adset_retention
                where " . $where . "
                ORDER BY date desc
                LIMIT " . ($page - 1) * $limit . ", " . $limit;
        if (strpos($where, "publisher_adaccount")) {
            $sql="select * from adset_retention
                LEFT JOIN publisher_adaccount ON publisher_adaccount.account_id = adset_retention.account_id
                where " . $where . "
                ORDER BY date desc
                LIMIT " . ($page - 1) * $limit . ", " . $limit;
        }


        $list=$this->adset_country_month_log_model->get_query($sql);
        $data=[];
        foreach ($list as $item) {
            // $sql = "select * from marketmax_reports where adset_id_country='".$item['adset_id'] . "_" . $item['country']."' and date<=".$item['date']." order by date desc limit 1";
            // $value=$this->reports_model->get_report_data($sql);
            
            // $key = [
            //     ':val1' => ['S' => $item['adset_id'] . "_" . $item['country']]
            // ];
            // $val = 'adset_id_country = :val1';
            // $value = $this->aws_dynamodb->scan("marketmax_reports_new_2016", $key, $val);

            // if (!$value) {
            //     //continue;
            // }else
            //     $value = $value[0];

            //var_dump($key, $value);die();
            //$item['cpa']=$value?$value['cpa']:'-';

            if (isset($country['country'][$item['country']])) {
                $item['country_info']=$country['country'][$item['country']];
            } else {
                $item['country_info']="Unknown";
            }
            $retention_info=json_decode($item['retention_info'], true);


            $item['payment_ratio']='-';
            if ($retention_info) {
                if ($retention_info['type'] == 'retention') {
                    if ($retention_info['retention']['category'] == 3) {
                        if (isset($month_rr[$item['country']])) {
                            $item['payment_ratio']=sprintf("%.2f", $month_rr[$item['country']]['ration'] / $retention_info['retention']['value'] * 100);
                        }

                        $item['payouts']='<a class="popover-custom popover-rotate" data-toggle="popover" data-trigger="hover" data-html="true" data-content="Payout will be proportional to the retention rate.<br/>If RR > <strong>' . $retention_info['retention']['value'] . '%</strong>, Full Payout.<br/>If RR = x, payout = x/<strong>' . $retention_info['retention']['value'] . '%</strong>*Full Payout." data-placement="top" data-original-title="Payouts" title="" aria-describedby="popover204012">
                                Tier B
                              </a>';

                    } elseif ($retention_info['retention']['category'] == 2) {

                        foreach ($retention_info['retention']['value'] as $val) {
                            $set_retention_rate[$val['retention_rate']]=$val['payout_rate'];
                        }
                        $set_cpa=0;
                        krsort($set_retention_rate);
                        foreach ($set_retention_rate as $k=>$v) {
                            if ($item['retention'] >= $k / 100) {
                                isset($month_rr[$item['country']]) && $item['payment_ratio']=sprintf("%.2f", $month_rr[$item['country']]['ration'] / $k * 100);
                                break;
                            }
                        }


                        $content="";
                        foreach ($retention_info['retention']['value'] as $v) {
                            $content.="If RT > <strong>" . $v['retention_rate'] . "%</strong>, Payout will be <strong>" . $v['payout_rate'] . "%</strong> = <strong>$" . $v['payout'] . "</strong><br>";
                        }

                        $item['payouts']='<a class="popover-primary popover-rotate" data-toggle="popover" data-trigger="hover" data-content="' . $content . '" data-placement="top" data-original-title="Payouts" title="" aria-describedby="popover204012">
                                Tier A
                              </a>';
                    } else {
                        $item['payment_ratio']=100;
                        $item['payouts']='<a class="popover-primary popover-rotate" data-toggle="popover" data-trigger="hover" data-content="' . $retention_info['retention']['cpa'] . '" data-placement="top" data-original-title="Payouts" title="" aria-describedby="popover204012">
                                Fixed
                              </a>';
                    }
                } else {
                    $item['payment_ratio']=100;
                }
                $item['payment_ratio'] > 100 && $item['payment_ratio']=100;

            }

            $data[]=$item;
        }
        $this->data['list']=$data;
    }


    public function get_month_data($month_where)
    {
        $month_rr=[];

        $month_sql="select sum(day0) as day0, sum(day1) as day1, country,set_retention from adset_country_month_log where " . $month_where . " group by country";
        $month_list=$this->adset_country_month_log_model->get_query($month_sql);
        foreach ($month_list as $key=>& $month) {
            $month['ration']=sprintf("%.2f", $month['day1'] / $month['day0'] * 100);

            $month_rr[$month['country']]=['ration'=>sprintf("%.2f", $month['day1'] / $month['day0'] * 100), 'set_retention'=>$month['set_retention']];
        }
        $this->data['month_list']=$month_list;

        return $month_rr;
    }


    /**
     * 下载留存报表
     * @return [type] [description]
     */
    public function retention_report()
    {

        header("Content-type:application/vnd.ms-excel;");
        header("Content-Disposition:attachment;filename=Retention_" . date('m.d') . ".xls");

        $this->config->load('country', TRUE);
        $country=$this->config->item('country');

        $where="1=1";
        $month_where="product_id=" . $this->input->get('product');

        if ($this->userinfo['type'] == 1) {
            $where="advertiser_id=" . $this->userinfo['user_id'];
            $month_where.=" and advertiser_id=" . $this->userinfo['user_id'];
        } elseif ($this->userinfo['type'] == 2) {
            $where="publisher_adaccount.publisher_id=" . $this->userinfo['user_id'];
            $month_where.=" and publisher_id=" . $this->userinfo['user_id'];
        }


        if ($this->input->get('account')) {
            $filter_account=$this->input->get('account');
            $where.=" and account_id in (" . $filter_account . ")";
            $account=explode(',', $this->input->get('account'));

        }

        if ($this->input->get('publisher')) {
            $filter_product=$this->input->get('publisher');
            $where.=" and publisher_adaccount.publisher_id in (" . $filter_product . ")";
            $publisher=explode(',', $this->input->get('publisher'));

        }

        if ($this->input->get('country')) {
            $countries=explode(',', $this->input->get('country'));

            $filter_country=[];
            foreach ($countries as $key=>$value) {
                $filter_country[]="'" . $value . "'";
            }
            $where.=" and country in (" . implode(',', $filter_country) . ")";

        }

        $start_region="01/" . date('m/Y');
        $end_region=date('d/m/Y');

        $month_time=time();
        $retentions=[];
        //获取时间条件范围
        if ($this->input->get('time')) {
            $time=$this->input->get('time');
            $month_time=$start=strtotime($time);
            $end=strtotime("$time +1 month");

            $where.=" and date>=" . $start . " and date<" . $end;

            $end=strtotime("$time +1 month -1 day");
            $start_region="01/" . date('m/Y', $start);
            $end_region=date('d/m/Y', $end);

            //$retentions=$this->get_retention_data($start, $end);
        } else {
            $where.=$tmp=" and date>=" . strtotime(date('Y-m'));
            //$retentions=$this->get_retention_data(strtotime(date('Y-m')));
        }

        $month_where.=" and date=" . strtotime(date('Y-m', $month_time));

        $month_rr=[];

        $month_sql="select sum(day0) as day0, sum(day1) as day1, country,set_retention from adset_country_month_log where " . $month_where . " group by country";
        $month_list=$this->adset_country_month_log_model->get_query($month_sql);
        foreach ($month_list as $key=>$month) {
            if ($month['day0'] > 0) {
                $month_rr[$month['country']]=['ration'=>sprintf("%.2f", $month['day1'] / $month['day0'] * 100), 'set_retention'=>$month['set_retention']];
            }
        }


        //输出内容如下：
        echo "Date\t";
        //echo   "Agency\t";
        echo "Account\t";
        echo "Campaign\t";
        echo "Adset\t";
        echo "Country\t";
        echo "CPA\t";
        echo "RR\t";
        echo "Results\t";
        echo "Payment Ratio\t";
        echo "\n";


        $sql="select * from adset_retention
                where " . $where . "
                ORDER BY date asc";
        if (strpos($where, "publisher_adaccount")) {
            $sql="select * from adset_retention
                LEFT JOIN publisher_adaccount ON publisher_adaccount.account_id = adset_retention.account_id
                where " . $where . "
                ORDER BY date asc";
        }

        $list=$this->adset_country_month_log_model->get_query($sql);

        $data=[];
        foreach ($list as $item) {
            // $sql = "select * from marketmax_reports where adset_id_country='".$item['adset_id'] . "_" . $item['country']."' and date<=".$item['date']." order by date desc limit 1";
            // $value=$this->reports_model->get_report_data($sql);
            // if (!$value) {
            //     //var_dump($item['adset_id'] . "_" . $item['country'], $item['date']);
            //     //continue;
            // }else
            //     $value = $value[0];


            if (isset($country['country'][$item['country']])) {
                $item['country_info']=$country['country'][$item['country']];
            } else {
                $item['country_info']="Unknown";
            }
            $retention_info=json_decode($item['retention_info'], true);


            $item['payment_ratio']=0;
            if ($retention_info) {
                if ($retention_info['type'] == 'retention') {
                    if ($retention_info['retention']['category'] == 3) {
                        if (isset($month_rr[$item['country']])) {
                            $item['payment_ratio']=sprintf("%.2f", $month_rr[$item['country']]['ration'] / $retention_info['retention']['value'] * 100);
                        }

                    } elseif ($retention_info['retention']['category'] == 2) {

                        foreach ($retention_info['retention']['value'] as $val) {
                            $set_retention_rate[$val['retention_rate']]=$val['payout_rate'];
                        }
                        $set_cpa=0;
                        krsort($set_retention_rate);
                        foreach ($set_retention_rate as $k=>$v) {
                            if ($item['retention'] >= $k / 100) {
                                isset($month_rr[$item['country']]) && $item['payment_ratio']=sprintf("%.2f", $month_rr[$item['country']]['ration'] / $k * 100);
                                break;
                            }
                        }

                    } else {
                        $item['payment_ratio']=100;
                    }
                } else {
                    $item['payment_ratio']=100;
                }
                $item['payment_ratio'] > 100 && $item['payment_ratio']=100;
            }


            echo date('Y-m-d', $item['date']) . "\t";
            echo $item['account_id'] . "\t";
            echo $item['campaign_name'] . "\t";
            echo $item['adset_name'] . "\t";
            echo $item['country'] . "(" . $item['country_info'] . ")" . "\t";
            if ($item['cpa']>0) {
                echo "$" . $item['cpa'] . "\t";
            }else{
                echo "" . "\t";
            }
            
            echo sprintf("%.2f", $item['retention'] * 100) . "%\t";

            echo $item['day0'] . "\t";
            if ($item['payment_ratio']) {
                echo $item['payment_ratio'] . "%\t";
            }else{
                echo "\t";
            }
            

            echo "\n";
        }
        die();
    }


    public function agency()
    {
        $this->load->model('product_model');

        $advertiser_id=$this->userinfo['user_id'];
        $this->data['product_list']=$this->product_model->get_all(['user_id'=>$advertiser_id]);

        $agency_sql="select marketmax_publisher_adaccount.publisher_id,marketmax_publisher_adaccount.publisher_name from marketmax_reports RIGHT JOIN marketmax_publisher_adaccount ON marketmax_publisher_adaccount.account_id = marketmax_reports.account_id where marketmax_publisher_adaccount.publisher_type=2 and advertiser_id=" . $advertiser_id . " group by marketmax_publisher_adaccount.publisher_id,marketmax_publisher_adaccount.publisher_name";
        $this->data['agency_list']=$this->reports_model->get_report_data($agency_sql);

        $this->config->load('country', TRUE);
        $this->data['config_country']=$this->config->item('country');

        $where="advertiser_id=" . $this->userinfo['user_id'] . " and marketmax_publisher_adaccount.publisher_type=2";

        $agency_params=$country_params=$product_params=[];
        if ($this->input->get("agency")) {
            $agency_params=explode(',', $this->input->get("agency"));
            $where.=" and marketmax_publisher_adaccount.publisher_id in (" . $this->input->get("agency") . ")";
        }
        if ($this->input->get("country")) {
            $country_params=explode(',', $this->input->get("country"));
            $where.=" and country in (" . $this->input->get("country") . ")";
        }
        if ($this->input->get("product")) {
            $product_params=explode(',', $this->input->get("product"));
            $where.=" and product_id in (" . $this->input->get("product") . ")";
        }

        if ($this->input->get("start")) {
            $where.=" and date >= " . strtotime($this->input->get("start"));
        }
        if ($this->input->get("end")) {
            $where.=" and date <= " . strtotime($this->input->get("end"));
        }

        $data_sql="SELECT 
                        sum(day0) as day0, 
                        sum(day1) as day1,
                        marketmax_publisher_adaccount.publisher_id,
                        marketmax_publisher_adaccount.publisher_name,
                        country,
                        marketmax_reports.account_id,
                        marketmax_reports.account_name
                    FROM marketmax_reports 
                    RIGHT JOIN marketmax_publisher_adaccount ON marketmax_publisher_adaccount.account_id = marketmax_reports.account_id
                    WHERE " . $where . "
                    GROUP BY country,marketmax_publisher_adaccount.publisher_id,marketmax_publisher_adaccount.publisher_name,marketmax_reports.account_id,marketmax_reports.account_name";
        //echo ($data_sql);die();
        $data=$this->reports_model->get_report_data($data_sql);
        $result=[];
        foreach ($data as $item) {
            $result[$item['publisher_id'] . '_' . $item['country']]['item'][]=$item;
        }

        $result_data=[];
        foreach ($result as $country=>& $value) {

            $day0=$day1=0;
            foreach ($value['item'] as & $v) {
                $day0+=$v['day0'];
                $day1+=$v['day1'];
                $v['rate']=$v['day0']?$v['day1'] / $v['day0']:0;
            }
            $value['rate']=$day0?$day1 / $day0:0;
            if ($value['rate'] > 0) {
                $result_data[]=$value;
            }
        }
        $this->data['result']=$result_data;

        $this->data['agency_params']=$agency_params;
        $this->data['country_params']=$country_params;
        $this->data['product_params']=$product_params;

        $template='report_agency';
        $this->template->build($template, $this->data);
    }

    public function user()
    {

        $advertiser_id=$this->userinfo['user_id'];
        $gender_sql="select sum(results) as results,gender from marketmax_gender_reports where advertiser_id=" . $advertiser_id . " group by gender";
        $gender_data=$this->reports_model->get_report_data($gender_sql);

        $gender_info=[];
        foreach ($gender_data as $item) {
            $gender_info[$item['gender']]=$item['results'];
        }
        arsort($gender_info);
        $this->data['gender_info']=array_slice($gender_info, 0, 1);
        $this->data['gender_data']=$gender_info;


        $age_sql="select sum(results) as results,age,gender from marketmax_age_gender_reports where advertiser_id=" . $advertiser_id . " group by age,gender";
        $age_data=$this->reports_model->get_report_data($age_sql);

        $age_info=[];
        $age_gender_info=[];
        foreach ($age_data as $item) {
            $item['age']=trim($item['age']);
            !in_array($item['age'], $age_info) && $age_info[]=$item['age'];
            if (isset($age_gender_info[$item['age']][$item['gender']])) {
                $age_gender_info[$item['age']][$item['gender']]+=$item['results'];
            } else {
                $age_gender_info[$item['age']][$item['gender']]=$item['results'];
            }
        }
        asort($age_info);
        $male_chart=$female_chart=[];
        foreach ($age_info as $age) {
            $male_chart[]=isset($age_gender_info[$age]['male'])?$age_gender_info[$age]['male']:0;
            $female_chart[]=isset($age_gender_info[$age]['female'])?$age_gender_info[$age]['female']:0;
        }


        $this->data['age_info']=json_encode(array_values($age_info));
        $this->data['male_chart']=json_encode($male_chart);
        $this->data['female_chart']=json_encode($female_chart);


        $watch_time_sql="select sum(results) as results,hourly_stats_aggregated_by_audience_time_zone from marketmax_hourly_stats_aggregated_by_audience_time_zone_reports where advertiser_id=" . $advertiser_id . " group by hourly_stats_aggregated_by_audience_time_zone";
        $watch_time_data=$this->reports_model->get_report_data($watch_time_sql);

        $watch_chart_info=[];
        foreach ($watch_time_data as $item) {
            $watch_chart_info[$item['hourly_stats_aggregated_by_audience_time_zone']]=$item['results'];
        }
        ksort($watch_chart_info);

        $x=array_keys($watch_chart_info);
        $watch_chart_x=[];
        foreach ($x as $k=>$v) {
            $watch_chart_x[]=$k . "-" . ($k + 1);
        }
        $this->data['watch_chart_x']=json_encode($watch_chart_x);
        $this->data['watch_chart_y']=json_encode(array_values($watch_chart_info));


        $impression_device_sql="select sum(results) as results,impression_device from marketmax_impression_device_reports where advertiser_id=" . $advertiser_id . " group by impression_device";
        $impression_device_data=$this->reports_model->get_report_data($impression_device_sql);

        $device_x=$device_y=[];
        foreach ($impression_device_data as $item) {
            if ($item['results'] <= 0) {
                continue;
            }
            $device=explode('_', $item['impression_device']);
            $item['impression_device']="";
            foreach ($device as $d) {
                if ($d == 'ipad') {
                    $item['impression_device'].="iPad";
                } elseif ($d == 'ipod') {
                    $item['impression_device'].="iPod";
                } elseif ($d == 'iphone') {
                    $item['impression_device'].="iPhone";
                } else
                    $item['impression_device'].=" " . ucfirst($d);
            }
            $device_x[]=$item['impression_device'];
            $device_y[]=['value'=>$item['results'], 'name'=>$item['impression_device']];
        }
        $this->data['device_chart_x']=json_encode($device_x);
        $this->data['device_chart_y']=json_encode($device_y);


        $placement_sql="select sum(results) as results,placement from marketmax_placement_reports where advertiser_id=" . $advertiser_id . " group by placement";
        $placement_data=$this->reports_model->get_report_data($placement_sql);

        $placement_x=$placement_y=[];
        foreach ($placement_data as $item) {
            $device=explode('_', $item['placement']);
            $item['placement']="";
            foreach ($device as $d) {
                $item['placement'].=" " . ucfirst($d);
            }
            $placement_x[]=$item['placement'];
            $placement_y[]=['value'=>$item['results'], 'name'=>$item['placement']];
        }
        $this->data['placement_chart_x']=json_encode($placement_x);
        $this->data['placement_chart_y']=json_encode($placement_y);


        $country_sql="select sum(results) as results,country from marketmax_reports where advertiser_id=" . $advertiser_id . " and results>0 group by country";
        $country_data=$this->reports_model->get_report_data($country_sql);

        $this->config->load('country', TRUE);
        $config_country=$this->config->item('country');

        $country_info=[];
        foreach ($country_data as $item) {
            if (isset($config_country['country'][$item['country']])) {
                $country_info[]=['name'=>$config_country['country'][$item['country']], 'value'=>$item['results']];
            }
        }


        $this->data['country_data']=json_encode($country_info);


        $region_sql="select sum(results) as results,region from marketmax_region_reports where advertiser_id=" . $advertiser_id . " group by region";
        $region_data=$this->reports_model->get_report_data($region_sql);

        $total=0;
        foreach ($region_data as $item) {
            $total+=$item['results'];
        }
        $i=1;
        $region_info=[];
        $tmp=[];
        foreach ($region_data as $item) {
            if ($i++ <= 3) {
                $tmp[]=$item;
            } else {
                $region_info[]=$tmp;
                $tmp=[];
                $i=1;
            }
        }
        $this->data['region_info']=$region_info;

        $template='report_user';
        $this->template->build($template, $this->data);
    }

    public function user1()
    {
        $advertiser_id=$this->userinfo['user_id'];
        $gender_sql="select sum(results) as results,gender from marketmax_gender_reports where advertiser_id=" . $advertiser_id . " group by gender";
        $gender_data=$this->reports_model->get_report_data($gender_sql);

        $gender_info=[];
        foreach ($gender_data as $item) {
            $gender_info[ucfirst($item['gender'])]=$item['results'];
        }
        arsort($gender_info);
        $this->data['gender_info']=array_slice($gender_info, 0, 1);

        $this->data['gender_data']=$gender_info;


        $age_sql="select sum(results) as results,age from marketmax_age_reports where advertiser_id=" . $advertiser_id . " group by age";
        $age_data=$this->reports_model->get_report_data($age_sql);

        $age_info=[];
        foreach ($age_data as $item) {
            $age_info[$item['age']]=$item['results'];
        }
        arsort($age_info);
        $this->data['age_info']=array_slice($age_info, 0, 1);

        ksort($age_info);
        $this->data['age_data']=$age_info;


        $watch_time_sql="select sum(results) as results,hourly_stats_aggregated_by_audience_time_zone from marketmax_hourly_stats_aggregated_by_audience_time_zone_reports where advertiser_id=" . $advertiser_id . " group by hourly_stats_aggregated_by_audience_time_zone";
        $watch_time_data=$this->reports_model->get_report_data($watch_time_sql);

        $watch_time_info=[];
        foreach ($watch_time_data as $item) {
            $watch_time_info[$item['hourly_stats_aggregated_by_audience_time_zone']]=$item['results'];
        }
        arsort($watch_time_info);
        $this->data['watch_time_info']=array_slice($watch_time_info, 0, 1);
        ksort($watch_time_info);
        $this->data['watch_time_data']=$watch_time_info;


        $impression_device_sql="select sum(results) as results,impression_device from marketmax_impression_device_reports where advertiser_id=" . $advertiser_id . " group by impression_device";
        $impression_device_data=$this->reports_model->get_report_data($impression_device_sql);

        $impression_device_info=[];
        foreach ($impression_device_data as $item) {
            $device=explode('_', $item['impression_device']);
            $item['impression_device']="";
            foreach ($device as $d) {
                $item['impression_device'].=" " . ucfirst($d);
            }
            $impression_device_info[$item['impression_device']]=$item['results'];
        }
        arsort($impression_device_info);
        $this->data['impression_device_info']=array_slice($impression_device_info, 0, 1);

        $this->data['impression_device_data']=$impression_device_info;


        $placement_sql="select sum(results) as results,placement from marketmax_placement_reports where advertiser_id=" . $advertiser_id . " group by placement";
        $placement_data=$this->reports_model->get_report_data($placement_sql);

        $placement_info=[];
        foreach ($placement_data as $item) {
            $device=explode('_', $item['placement']);
            $item['placement']="";
            foreach ($device as $d) {
                $item['placement'].=" " . ucfirst($d);
            }
            $placement_info[$item['placement']]=$item['results'];
        }
        arsort($placement_info);
        $this->data['placement_info']=array_slice($placement_info, 0, 1);

        $this->data['placement_data']=$placement_info;


        $country_sql="select sum(results) as results,country from marketmax_reports where advertiser_id=" . $advertiser_id . " and results>0 group by country";
        $country_data=$this->reports_model->get_report_data($country_sql);

        $country_info=[];
        foreach ($country_data as $item) {
            $country_info[$item['country']]=$item['results'];
        }
        arsort($country_info);
        $this->data['country_info']=array_slice($country_info, 0, 1);
        $this->data['country_data']=$country_info;

        $region_sql="select sum(results) as results,region from marketmax_region_reports where advertiser_id=" . $advertiser_id . " group by region";
        $region_data=$this->reports_model->get_report_data($region_sql);

        $region_info=[];
        foreach ($region_data as $item) {
            $region_info[$item['region']]=$item['results'];
        }
        arsort($region_info);
        $this->data['region_info']=array_slice($region_info, 0, 1);
        $this->data['region_data']=$region_info;


        $template='report_user';
        $this->template->build($template, $this->data);
    }

    public function product()
    {
        $date=strtotime(date('Y-m'));
        $date_time=date('Y-m');
        if ($this->input->get('date')) {
            $date_time=date('Y-m', strtotime($this->input->get('date')));
            $date=strtotime(date('Y-m', strtotime($this->input->get('date'))));
        }

        $start=$this->data['date_start']=date('m/d/Y', $date);
        $this->data['date_end']=date('m/d/Y', strtotime("$start +1 month -1 day"));

        $last_day=strtotime(date('Y-m-d', strtotime("$date_time +1 month -1 day")));

        if ($this->userinfo['type'] == 1) {
            $sql="SELECT product.*
                    FROM product 
                    INNER JOIN publisher_offer ON product.product_id = publisher_offer.product_id
                    where publisher_offer.advertiser_id=" . $this->userinfo['user_id'] . "
                    group by publisher_offer.product_id";
        } elseif ($this->userinfo['type'] == 2) {
            $sql="SELECT product.*
                    FROM product 
                    INNER JOIN publisher_offer ON product.product_id = publisher_offer.product_id
                    where publisher_offer.publisher_id=" . $this->userinfo['user_id'] . "
                    group by publisher_offer.product_id";
            //$sql="select * from product where user_id = " . $this->userinfo['user_id'] . " order by product_id desc ";
        } else {
            $sql="select * from product order by product_id desc ";
        }
        $product_list=$this->product_model->get_query($sql);
        $start=$this->data['date_start']=date('m/d/Y', $date);
        $this->data['date_end']=date('m/d/Y', strtotime("$start +1 month -1 day"));
        $where="adset_country_month_log.date=" . $date . " and adset_country_month_log.set_retention>0 and adset_country_month_log.day0>0 ";
        $productids=[];
        $data=[];
        foreach ($product_list as $key=>$value) {
            $sql="SELECT
                    adset_country_month_log.`value`,
                    sum(adset_country_month_log.`day0`) as day0,
                    sum(adset_country_month_log.`day1`) as day1,
                    adset_country_month_log.`country`,
                    adset_country_month_log.set_retention
                FROM
                    adset_country_month_log
                WHERE " . $where . " and product_id=" . $value['product_id'] . "
                group by adset_country_month_log.country,adset_country_month_log.product_id";

            $retention=$this->adset_model->get_query($sql);
            if (!$retention) {
                continue;
            }
            $result=[];
            foreach ($retention as $item) {
                $result['country'][$item['country']]['set_retention']=$item['set_retention'];
                $monty_value=$item['day1'] / $item['day0'];
                $result['country'][$item['country']]['value']=sprintf("%.2f", $monty_value * 100);
            }
            $value['retention']=$result;

            $install=$this->reports_model->get_report_data("select sum(results) as results from marketmax_reports where product_id =" . intval($value['product_id']) . " and date>=" . $date . " and date<=" . $last_day);
            $value['install']=$install?$install[0]['results']:0;

            $data[]=$value;
        }

        $this->data['product_list']=$data;

        $template='report_product';
        $this->template->build($template, $this->data);
    }


    /**
     * 添加自定义报表条件
     */
    public function add_custom_reports_action()
    {
        $this->load->model('custom_reports_model');
        if ($this->input->is_ajax_request()) {
            $vars['user_id'] = $this->userinfo['user_id'];

            if ($this->userinfo['type']==0) {
                $vars['is_admin'] = 1;
            }
            $vars['title'] = trim($this->input->post('title'));
            $vars['type'] = trim($this->input->post('type'));
            if ($vars['type']=='columns') {
                $vars['value'] = $this->input->post('value');
            }else{
                $vars['value']['offer'] = $this->input->post('filter_offer');
                $vars['value']['account'] = $this->input->post('filter_account');
                $vars['value']['advertiser'] = $this->input->post('filter_advertiser');
                $vars['value']['publisher'] = $this->input->post('filter_publisher');
                $vars['value']['product'] = $this->input->post('filter_product');
                $vars['value']['country'] = $this->input->post('filter_country');
                $vars['value']['agency'] = $this->input->post('filter_agency');
            }
            $vars['value'] = json_encode($vars['value']);
            

            $custom = $this->custom_reports_model->add_one($vars);
            $response=['success'=>true, 'msg'=>"Success", 'data'=>$custom];
        } else {
            $response=['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
        }
        $this->output->set_content_type('applicaion/json')->set_output(json_encode($response));
    }


    /**
     * 删除自定义条件
     * @return [type] [description]
     */
    public function remove_custom_reports_action()
    {
        $this->load->model('custom_reports_model');
        if ($this->input->is_ajax_request()) {
            $custom_id = $this->input->post('custom');

            $this->custom_reports_model->update_row_by_id($custom_id, ['status'=>-1]);
            $response=['success'=>true, 'msg'=>"Success"];
        } else {
            $response=['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
        }
        $this->output->set_content_type('applicaion/json')->set_output(json_encode($response));
    }

    public function get_custom_reports()
    {
        if ($this->input->is_ajax_request()) {
            $custom_id = $this->input->get('custom');

            $this->load->model('custom_reports_model');
            $data = $this->custom_reports_model->get_by_id($custom_id);
            if ($data) {
                $data['value'] = json_decode($data['value'], true);
                $response=['success'=>true, 'msg'=>"Success", 'data'=>$data['value'], 'type'=>$data['type']];
            }else{
                $response=['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
            }
        } else {
            $response=['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
        }
        $this->output->set_content_type('applicaion/json')->set_output(json_encode($response));
        
    }

    public function report_li_chart()
    {
        if ($this->input->is_ajax_request()) {
            $value = json_decode($this->input->post('query'), true);
            $where = "1=1";
            $group = "date";
            if (isset($value['publisher_id'])) {
                $where.=" and marketmax_publisher_adaccount.publisher_id in (" . $value['publisher_id']. ")";

                $group.=",marketmax_publisher_adaccount.publisher_id,marketmax_publisher_adaccount.publisher_name";
            }

            if (isset($value['product_id'])) {
                $where.=" and product_id in (" . $value['product_id'] . ")";
                $group.=",product_id,product_name";
            }

            if (isset($value['country'])) {
                $filter_country_arr = explode(',', $value['country']);
                $filter_countrys = [];
                foreach ($filter_country_arr as $v) {
                    $filter_countrys[] = "'".$v."'";
                }

                $where.=" and country in (" .implode(',', $filter_countrys). ")";
                $group.=",country";
            }

            if (isset($value['agency_id'])) {
                $where.=" and marketmax_publisher_adaccount.publisher_id in (" . $value['agency_id']. ")";
                $group.=",marketmax_publisher_adaccount.publisher_name";
            }

            if (isset($value['account_id'])) {
                $where.=" and marketmax_reports.account_id in (" . $value['account_id'] . ")";

                $group.=",marketmax_reports.account_id,marketmax_reports.account_name";
            }
            if (isset($value['advertiser_id'])) {
                $where.=" and advertiser_id in (" . $value['advertiser_id'] . ")";

                $group.=",advertiser_id,advertiser_name";
            }
            if (isset($value['campaign_id'])) {
                $where.=" and campaign_id in (" . $value['campaign_id'] . ")";

                $group.=",campaign_id,campaign_name";
            }
            if (isset($value['adset_id'])) {
                $where.=" and adset_id in (" . $value['adset_id'] . ")";

                $group.=",adset_id,adset_name";
            }

            if (isset($value['date_start'])) {

                $date_start=strtotime($value['date_start']);
                $date_end=strtotime($value['date_end']);
                $where.=" and date>=" . $date_start . " and date<=" . $date_end;
            }
            $data = $this->getReportChartData($where, $group, "date desc");
            $chart_cpm = $chart_cpc = $chart_ctr = $chart_date = $chart_results = $chart_day0 = $chart_earning = $chart_real_earning = $chart_roi = $chart_cpi = $chart_a_f = [];

            foreach ($data as $key => $value) {
                $date = $value['date'];
                $chart_date[$date]           = $value['date'];
                    
                if (isset($chart_real_earning[$date])) {
                    $chart_real_earning[$date]   += sprintf("%.2f", $value['real_earning']);
                }else{
                    $chart_real_earning[$date]   = sprintf("%.2f", $value['real_earning']);
                }
                if (isset($chart_earning[$date])) {
                    $chart_earning[$date]        += sprintf("%.2f", $value['expect_revenue']);
                }else
                    $chart_earning[$date]        = sprintf("%.2f", $value['expect_revenue']);
                
                if (isset($chart_roi[$date])) {
                    $value['spend']>0 && $chart_roi[$date]            += sprintf("%.2f", ($value['real_earning']-$value['spend'])/$value['spend']*100);
                }else
                    $chart_roi[$date]            = $value['spend']>0?sprintf("%.2f", ($value['real_earning']-$value['spend'])/$value['spend']*100):0;
                
                if (isset($chart_cpi[$date])) {
                    $chart_cpi[$date]            += $value['results']>0?sprintf("%.2f", $value['spend']/$value['results']*100):0;
                }else
                    $chart_cpi[$date]            = $value['results']>0?sprintf("%.2f", $value['spend']/$value['results']*100):0;
                
                if (isset($chart_day0[$date])) {
                    $chart_day0[$date]           += $value['day0'];
                }else
                    $chart_day0[$date]           = $value['day0'];
                
                if (isset($chart_results[$date])) {
                    $chart_results[$date]        += $value['results'];
                }else
                    $chart_results[$date]        = $value['results'];

                $chart_cpm[$date] = $value['cpm'];
                $chart_cpc[$date] = $value['cpc'];
                $chart_ctr[$date] = $value['ctr'];

                if (isset($chart_a_f[$date])) {
                    $chart_a_f[$date]            += $value['results']>0?sprintf("%.2f", $value['day0']/$value['results']*100):0;
                }else
                    $chart_a_f[$date]            = $value['results']>0?sprintf("%.2f", $value['day0']/$value['results']*100):0;
            }
            $response=['success'=>true, 'chart_date'=>json_encode(array_reverse(array_values($chart_date))), 'chart_results'=>json_encode(array_reverse(array_values($chart_results))), 'chart_day0'=>json_encode(array_reverse(array_values($chart_day0))), 'chart_earning'=>json_encode(array_reverse(array_values($chart_earning))), 'chart_real_earning'=>json_encode(array_reverse(array_values($chart_real_earning))), 'chart_roi'=>json_encode(array_reverse(array_values($chart_roi))), 'chart_cpi'=>json_encode(array_reverse(array_values($chart_cpi))), 'chart_a_f'=>json_encode(array_reverse(array_values($chart_a_f))), 'chart_cpm'=>json_encode(array_reverse(array_values($chart_cpm))), 'chart_cpc'=>json_encode(array_reverse(array_values($chart_cpc))), 'chart_ctr'=>json_encode(array_reverse(array_values($chart_ctr)))];
            
        } else {
            $response=['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
        }
        $this->output->set_content_type('applicaion/json')->set_output(json_encode($response));
        
    }


    public function upload_report_action()
    {
        header("Content-type:application/vnd.ms-excel;");
        header("Content-Disposition:attachment;filename=" . time() . ".xls");

        $this->config->load('country', TRUE);
        $country=$this->config->item('country');

        $where="1=1 and (spend>0 or results>0)";
        if ($this->userinfo['type'] == 1) {
            $where.=" and advertiser_id=" . $this->userinfo['user_id'];
        } elseif ($this->userinfo['type'] == 2) {
            $where.=" and marketmax_publisher_adaccount.publisher_id=" . $this->userinfo['user_id'];
        }

        $thead=$tbody="";
        $field_show=[];

        $group = "1";
        $is_join = false;
        $order_by = "results desc";

        $filter_offer       = $this->input->get('filter_offer');
        $filter_account     = $this->input->get('filter_account');
        $filter_advertiser  = $this->input->get('filter_advertiser');
        $filter_publisher   = $this->input->get('filter_publisher');
        $filter_product     = $this->input->get('filter_product');
        $filter_country     = $this->input->get('filter_country');
        $filter_agency      = $this->input->get('filter_agency');

        list($data, $interval, $calculations, $statistics, $select_retention) = $this->get_fields(explode(',', $this->input->get('fields')));

        

        if ($filter_offer) {
            $where.=" and offer_id in (" . $filter_offer . ")";

            $thead[] = "Offer ID";
            $field_show[]='offer_id';
            $group.=",offer_id";
        }

        if ($filter_account) {
            $where.=" and marketmax_reports.account_id in (" . $filter_account . ")";

            $thead[] = "Account ID";
            $field_show[]='account_id';
            $group.=",marketmax_reports.account_id,marketmax_reports.account_name";
        }
        if ($filter_advertiser) {
            $where.=" and advertiser_id in (" . $filter_advertiser . ")";

            !in_array('advertiser_id', $data) && $thead[] = "Advertiser";
            !in_array('advertiser_id', $data) && $field_show[]='advertiser_name';
            !in_array('advertiser_id', $data) && $group.=",advertiser_id,advertiser_name";
        }

        if ($filter_publisher) {
            $where.=" and marketmax_publisher_adaccount.publisher_id in (" . $filter_publisher. ")";

            !in_array('publisher_id', $data) && $thead[] = "Publisher";
            !in_array('publisher_id', $data) && $field_show[]='publisher_name';
            !in_array('publisher_id', $data) && $group.=",marketmax_publisher_adaccount.publisher_id,marketmax_publisher_adaccount.publisher_name";
        }

        if ($filter_product) {
            $where.=" and product_id in (" . $filter_product . ")";

            !in_array('product_name', $data) && $thead[] = "Product";
            !in_array('product_name', $data) && $field_show[]='product_name';
            !in_array('product_name', $data) && $group.=",product_id,product_name";

        }

        if ($filter_country) {
            $filter_country_arr = explode(',', $filter_country);
            $filter_countrys = [];
            foreach ($filter_country_arr as $v) {
                $filter_countrys[] = "'".$v."'";
            }

            $where.=" and country in (" .implode(',', $filter_countrys). ")";
            $thead[] = "Country";
            $field_show[]='country';
            $group.=",country";
        }

        if ($filter_agency) {
            $where.=" and marketmax_publisher_adaccount.publisher_id in (" . $filter_agency. ")";

            $thead[] = "Agency";
            $field_show[]='agency_id';
            $group.=",marketmax_publisher_adaccount.publisher_name";
        }

        $retentions = [];//获取有设置过留存的日期
        
        if ($this->input->get('date_start') && $this->input->get('date_end')) {
            $date_start=strtotime($this->input->get('date_start'));
            $date_end=strtotime($this->input->get('date_end'));
            if ($field_show) {
                if (!in_array('month', $field_show) && !in_array('year', $field_show)) {
                    $where.=" and date>=" . $date_start . " and date<=" . $date_end;
                }
            }else{
                $where.=" and date>=" . $date_start . " and date<=" . $date_end;
            }
            
            //$retentions=$this->get_retention_report_data($date_start, $date_end);
        } else {
            //$retentions=$this->get_retention_report_data(strtotime(date('Y-m-d', strtotime('-6 day'))));
        }

        if ($this->input->get('keywords')) {
            $keywords = $this->input->get('keywords');

            $where .= " and campaign_name ilike '%$keywords%'";
            if ($field_show) {
                if(!in_array("campaign_id", $field_show) || !in_array("campaign_name", $field_show)){
                    $field_show[] = 'campaign_name';
                    $group .= ",campaign_name,campaign_id";
                    $thead[] = "Campaign";
                }
            }else{
                $field_show[] = 'campaign_name';
                $group .= ",campaign_name,campaign_id";
                $thead[] = "Campaign";
            }
            
        }


        if ($interval) {
            foreach ($interval as $key => $value) {
                $thead[] = $this->getFileds($value);
                $field_show[] = $value;
                if ($value=='year') {
                    $group .= ",date_year";
                    $order_by = "date_year desc";
                }elseif ($value=='month') {
                    $group .= ",date_month";
                    $order_by = "date_month desc";
                }elseif ($value=='date') {
                    $group .= ",date";
                    $order_by = "date desc";
                }
            }
        }

        if ($data) {
            if(in_array('account_id', $data)){
                $data[] = 'marketmax_reports.account_name';
                $data[] = 'marketmax_reports.account_id';
                foreach ($data as $key => $value) {
                    if ($value=='account_id') {
                        unset($data[$key]);
                    }
                }
            }
            if (in_array('agency_id', $data)) {
                $data[]='marketmax_publisher_adaccount.publisher_name';
                $data[]='marketmax_publisher_adaccount.publisher_id';
                foreach ($data as $key=>$value) {
                    if ($value == 'agency_id') {
                        unset($data[$key]);
                    }
                }
                $where.=" and marketmax_publisher_adaccount.publisher_type=2";
            }

            in_array('campaign_id', $data) && $data[]='campaign_name';
            in_array('adset_id', $data) && $data[]='adset_name';
            if (in_array('product_name', $data) && !in_array('product_id', $data)) {
                $data[]='product_id';
                //$data[]='product_name';
            }
            foreach ($data as $key=>$value) {
                $value == 'marketmax_reports.account_name' && $value='account_name';
                $value == 'marketmax_reports.account_id' && $value='account_id';

                $value == 'marketmax_publisher_adaccount.publisher_name' && $value='agency_name';
                $value == 'marketmax_publisher_adaccount.publisher_id' && $value='agency_id';
                if (!$field_show || !in_array($value, $field_show)) {
                    if (!in_array($value, ['account_name', 'campaign_name', 'adset_name', 'agency_name', 'product_name'])) {
                        $thead[] = $this->getFileds($value);
                        $field_show[] = $value;
                    }
                }
            }

            if (in_array('publisher_id', $data)) {

                !in_array('publisher_name', $data) && $data['publisher_name'] = 'marketmax_publisher_adaccount.publisher_name';
                foreach ($data as $key => $value) {
                    if ($value=='publisher_id') {
                        unset($data[$key]);
                    }
                }
                $group .= ",marketmax_publisher_adaccount.publisher_id";
                $group .= ",marketmax_publisher_adaccount.publisher_name";
            }
            if (in_array('advertiser_id', $data)) {
                !in_array('advertiser_name', $data) && $data['advertiser_name'] = 'advertiser_name';
                foreach ($data as $key => $value) {
                    if ($value=='advertiser_id') {
                        unset($data[$key]);
                    }
                }
                //$group .= ",advertiser_id";
                $group .= ",advertiser_name";
            }
            if (in_array('product_id', $data)) {
                !in_array('product_name', $data) && $data['product_name'] = 'product_name';
                foreach ($data as $key => $value) {
                    if ($value=='product_id') {
                        unset($data[$key]);
                    }
                }
                $group .= ",product_id";
                //$group .= ",product_name";
            }
            if ($data) {
                $group.="," . implode(',', $data);
            }
        }

        
        if ($statistics) {
            foreach ($statistics as $key => $value) {
                if ($value=='results') {
                    $thead[] = $this->getFileds($value);
                }else{
                    if ($this->userinfo['type']==0) {
                        if ($value=='anticipated_income') {
                            $thead[] = "Media Buy Earning";
                        }elseif ($value=='revenue') {
                            $thead[] = "Real MB Earning";
                        }elseif ($value=='profit') {
                            $thead[] = "Media Buy Profit";
                        }elseif ($value=='real_profit') {
                            $thead[] = "Real Profit";
                        }else{
                            $thead[] = $this->getFileds($value);
                        }
                    } else
                        $thead[] = $this->getFileds($value);
                }
                $field_show[]=$value;
            }
        }
        if ($select_retention) {
            foreach ($select_retention as $key => $value) {
                if ($value=='day0' || $value=='day1') {
                    $group .= ",".$value;
                }
                $thead[] = $this->getFileds($value);
                $field_show[]=$value;
            }
            
        }

        if ($calculations) {
            foreach ($calculations as $key => $value) {
                if($value=='retentions'){
                    $thead[] = "Retentions";
                }elseif($value=='rr'){
                    $thead[] = "RR";
                }elseif($value=='rpc'){
                    $thead[] = "RPC";
                }elseif($value=='rpa'){
                    $thead[] = "RPA";
                }elseif($value=='retention_rate'){
                    $thead[] = "Retention Rate";
                }else{
                    $thead[] = $this->getFileds($value);
                }
                $field_show[]=$value;
            }
        }

        $data = $this->getReportChartData($where, $group, $order_by);

        foreach ($thead as $t) {
            echo $t."\t";
        }
        echo "\n";

        $result = [];
        if ($data) {
            if (strtotime($this->input->get('date_end')) == strtotime(date('Y-m-d'))) {
                if ($interval && in_array("date", $interval)) {
                    $last_day = strtotime($data[0]['date']);
                    $this->get_tabel_tr(strtotime(date('Y-m-d')), $last_day, $field_show, $tbody);
                }
            }
            foreach ($data as $key => $value) {
                $tbody .= "<tr>";
                foreach ($field_show as $k => $v) {
                    if ($v=='campaign_id') {
                        echo trim($value['campaign_name']). "\t";
                    }elseif ($v=='account_id') {
                        echo $value[$v]."\t";
                    }elseif ($v=='agency_id') {
                        echo $value['publisher_name']."\t";
                    }elseif ($v=='adset_id') {
                        echo trim($value['adset_name'])."\t";
                    }elseif ($v=='publisher_id') {
                        echo $value['publisher_name']."\t";
                    }elseif ($v=='advertiser_id') {
                        echo $value['advertiser_name']."\t";
                    }elseif ($v=='product_name') {
                        if ($value['product_name']) {
                            echo $value['product_name']."\t";
                        }else{
                            echo "Unknown\t";
                        }
                    }elseif ($v=='product_id') {
                        if ($value['product_name']) {
                            echo $value['product_name']."\t";
                        }else{
                            echo "Unknown\t";
                        }
                    }elseif ($v=='country') {
                        if ($value[$v] == 'Unknown') {
                            echo "Unknown\t";
                        }else{
                            $c = isset($country['country'][$value[$v]])?$country['country'][$value[$v]]:$value[$v];
                            echo $value[$v].' - '.$c."\t";
                        }

                    } elseif ($v == 'rr') {
                        echo $value['retention'] . "%\t";
                    } elseif ($v == 'rpc') {
                        $rpc=$value['clicks']?($value['revenue'] - $value['spend']) / $value['clicks']:0;
                        $d = ($rpc > 0?"$" . sprintf("%.2f", $rpc):0);
                        echo $d . "\t";
                    } elseif ($v == 'rpa') {
                        $rpa=$value['results']?($value['revenue'] - $value['spend']) / $value['results']:0;
                        $c = ($rpa > 0?"$" . sprintf("%.2f", $rpa):0);
                        echo $c."\t";
                    } elseif ($v == 'profit') {
                        $profit=($value['expect_revenue'] - $value['spend']);
                        echo "$" . (sprintf("%.2f", $profit)) . "\t";
                    } elseif ($v == 'real_profit') {
                        $profit=($value['real_earning'] - $value['spend']);
                        $d = ($value['real_earning']>0?"$".sprintf("%.2f", $profit):'-');
                        echo $d."\t";

                    }elseif ($v=='revenue') {
                        $d = ($value['real_earning']>0?"$".sprintf("%.2f", $value['real_earning']):'-');
                        echo $d."\t";

                    } elseif ($v == 'spend') {
                        $d = ($value['spend'] > 0?"$" . sprintf("%.2f", $value['spend']):0) ;
                        echo $d."\t";
                    } elseif ($v == 'payout') {
                        $d = ($value['payout'] > 0?"$" . sprintf("%.2f", $value['payout']):0);
                        echo $d."\t";
                    } elseif ($v == 'anticipated_income') {
                        $d = ($value['expect_revenue'] > 0?"$" . sprintf("%.2f", $value['expect_revenue']):0);
                        echo $d."\t";

                    } elseif ($v == 'retention_rate') {
                        $d = ($value['retention'] > 0?sprintf("%.2f", $value['retention'] * 100) . "%":0);
                        echo $d."\t";

                    } elseif ($v == 'facebook_cpi') {
                        $cpi=$value['results'] > 0?"$" . sprintf("%.2f", $value['spend'] / $value['results']):0;
                        echo $cpi."\t";
                    } elseif ($v == 'epa') {
                        $epa=$value['results'] > 0?"$" . sprintf("%.2f", $value['expect_revenue'] / $value['results']):0;
                        echo  $epa . "\t";
                    } elseif ($v == 'ctr_all') {
                        $ctr_all=$value['impressions'] > 0?sprintf("%.2f", $value['clicks'] / $value['impressions'] * 100) . "%":0;
                        echo $ctr_all . "\t";
                    } elseif ($v == 'ctr_link') {
                        $ctr_link=$value['impressions'] > 0?sprintf("%.2f", $value['clicks_link'] / $value['impressions'] * 100) . "%":0;
                        echo $ctr_link . "\t";
                    } elseif ($v == 'cvr_all') {
                        $cvr_all=$value['clicks'] > 0?sprintf("%.2f", $value['results'] / $value['clicks'] * 100) . "%":0;
                        echo $cvr_all . "\t";
                    } elseif ($v == 'cvr_link') {
                        $cvr_link=$value['clicks_link'] > 0?sprintf("%.2f", $value['results'] / $value['clicks_link'] * 100) . "%":0;
                        echo $cvr_link . "\t";
                    } elseif ($v == 'cpc_all') {
                        $cpc_all=$value['clicks'] > 0?"$" . sprintf("%.2f", $value['spend'] / $value['clicks']):0;
                        echo $cpc_all . "\t";
                    } elseif ($v == 'cpc_link') {
                        $cpc_link=$value['clicks_link'] > 0?"$" . sprintf("%.2f", $value['spend'] / $value['clicks_link']):0;
                        echo $cpc_link . "\t";
                    } elseif ($v == 'cpm') {
                        $cpm=$value['impressions'] > 0?"$" . sprintf("%.2f", $value['spend'] / $value['impressions'] * 1000):0;
                        echo $cpm . "\t";
                    } elseif (in_array($v, ['clicks', 'clicks_link', 'impressions', 'results', 'spend'])) {
                        echo number_format($value[$v]) . "\t";
                    } elseif ($v == 'amount_cost') {
                        $amount_cost="$" . sprintf("%.2f", $value['amount_cost']);
                        echo $amount_cost . "\t";
                    } elseif ($v == 'month' && isset($value['date_month'])) {
                        echo $value['date_month'] . "\t";
                    } elseif ($v == 'year' && isset($value['date_year'])) {
                        echo $value['date_year'] . "\t";
                    } elseif ($v == 'roi') {
                        echo sprintf('%.2f', ($value['real_earning']-$value['spend'])/$value['spend']*100) . "%\t";
                    } elseif ($v == 'retention') {
                        if ($value['day0']>0) {
                            echo $value['day1']/$value['day0'] . "\t";
                        }else{
                            echo "-\t";
                        }
                    } elseif ($v == 'day0') {
                        $d = ($value['day0']>0?$value['day0']:'-');
                        echo $d."\t";
                    } elseif ($v == 'day1') {
                        $d = ($value['day1']>0?$value['day1']:'-');
                        echo $d."\t";
                    } elseif ($v == 'appsflyer_facebook') {
                        $d = ($value['results']>0?sprintf('%.2f', $value['day0']/$value['results']*100)."%":'-');
                        echo $d."\t";
                    }  else {
                        echo $value[$v] . "\t";
                    }
                }
                echo "\n";
            }
        }
        die();
    }

    /**
     * 获取最近七天的publisher统计数据
     * @return [type] [description]
     */
    public function get_publisher_report_data($start, $end)
    {

        $sql = "select 
                    sum(results) as results,
                    sum(spend) as spend,
                    sum(expect_revenue) as earning,
                    sum(real_earning) as real_earning,
                    sum(day0) as day0,
                    sum(day1) as day1,
                    publisher_id, 
                    marketmax_users.user_name as publisher_name
                from marketmax_reports 
                left join marketmax_users on marketmax_users.user_id=marketmax_reports.publisher_id
                where date>=".$start." and date<=".$end."
                and publisher_id>0 and label != ''
                group by publisher_id,marketmax_users.user_name
                order by results desc";
        $data = $this->reports_model->get_report_data($sql);
        foreach ($data as & $item) {
            $item['cpi'] = $item['results']>0?floatval(sprintf("%.2f", $item['spend']/$item['results'])):0;
            $item['a_f'] = $item['results']>0?floatval(sprintf("%.2f", $item['day0']/$item['results']*100)):0;

            $item['roi'] = sprintf("%.2f", ($item['real_earning']-$item['spend'])/$item['spend']*100);
        }
        return $data;
    }


    public function publisher()
    {
        if ($this->userinfo['type']!=0) {
            redirect("dashboard");die();
        }
        $start = date('m/d/Y', strtotime("-6 day"));
        $end = date('m/d/Y');
        if ($this->input->get('start')) {
            $start = $this->input->get('start');
            $end = $this->input->get('end');
        }
        $this->data['start'] = $start;
        $this->data['end'] = $end;

        $data=$this->get_publisher_report_data(strtotime($start), strtotime($end));

        foreach ($data as $key => & $value) {
            $sql = "SELECT
                        sum(spend) AS spend,
                        sum(expect_revenue) AS earning,
                        sum(real_earning) AS real_earning
                    FROM
                        marketmax_reports
                    LEFT JOIN marketmax_products ON marketmax_products.product_id = marketmax_reports.product_id
                    WHERE
                        marketmax_reports.publisher_id=".$value['publisher_id']."
                        and 
                        (
                            (marketmax_products.retention_day=0 and marketmax_reports.date <=".strtotime($end).")
                            or (
                                marketmax_products.retention_day > 0
                                AND 
                                (
                                    (marketmax_products.retention_updated_time>".strtotime($end)." and marketmax_reports.date <= ".strtotime($end).")
                                    OR (marketmax_products.retention_updated_time<=".strtotime($end).")
                                )
                            )
                        )
                        and date>=".strtotime($start);
            $d = $this->reports_model->get_report_data($sql);
            $value['real_data'] = $d?$d[0]:[];
            if ($value['real_data']) {
                $value['real_data']['spend'] = sprintf("%.2f",$value['real_data']['spend']);
                $value['real_data']['real_profit'] = sprintf("%.2f", $value['real_data']['real_earning']-$value['real_data']['spend']);
            }
        }

        $this->data['publisher_data']=$data;

        $template = 'report_publisher';
        $this->template->build($template,$this->data);
    }

}
