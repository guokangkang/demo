<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Dashboard extends Admin_Controller {

	/**
	* 初使化
	*/
	public function __construct()
	{
		parent::__construct();
	}

	/**
	 * 首页
	 */
	public function index()
	{
		$template = 'index';
		$this->template->build($template,$this->data);
	}

}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */