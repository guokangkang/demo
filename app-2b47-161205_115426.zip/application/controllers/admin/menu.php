<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Menu extends Admin_Controller {

	/**
	* 初使化
	*/
	public function __construct()
	{
		parent::__construct();
		$this->load->model('menu_model');
	}

	/**
	 * 首页
	 */
	public function index()
	{

		$result = $this->menu_model->get_all(['status'=>0]);

		$parentlist = $menulist = [];
    	if(!empty($result)){
    		foreach ($result as $val){
    			if($val['parent_id']==0)
    				$parentlist[] = $val;
    			else 
    				$menulist[$val['parent_id']][] = $val;
    		}
    	}
    	
    	$info = [];
    	if($this->uri->segment(5)){
    		$info = $this->menu_model->get_by_id($this->uri->segment(5));
    	}

    	$this->data['parent'] = $parentlist;
    	$this->data['menulist'] = $menulist;
    	$this->data['menuinfo'] = $info;


		$this->template->build('menu_index',$this->data);
	}

	public function addmenu(){

    	$value = ['name'=>$this->input->post('name'), 'link'=>$this->input->post('url'), 'parent_id'=>intval($this->input->post('parent'))];

    	if(!empty($this->input->post('id'))){
    		$result = $this->menu_model->update_row_by_id($this->input->post('id'), $value);
    		$message = ['status'=>0, 'info'=>'更新完成', 'url'=>'admin/menu'];
    	}else{
    		$result = $this->menu_model->add_one($value);
    		$message = ['status'=>0, 'info'=>'添加完成', 'url'=>'admin/menu'];
    	}
    	
    	echo json_encode($message);die();
    }
    
    public function removemenu(){
    	$result = $this->menu_model->update_row_by_id($this->input->post('id'), ['status'=>1]);
    	echo json_encode($result);die();
    }

}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */