<?php if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}
require_once __DIR__ . '/../libraries/vendor/autoload.php';


use Facebook\Facebook;

/**
 * 
 * Created by PhpStorm.
 * User: palmax
 * Date: 2016/4/26
 * Time: 15:10
 */
class User extends Web_Controller
{
    public function __construct() {
        parent::__construct();
        $this->load->model('adaccount_model');
        $this->load->model('user_model');
        $this->load->model('publisher_adaccount_model');

        $this->data['top_menu'] = $this->load->view('web/top_menu_user', '', TRUE);
    }

    public function account()
    {
        if (!session_id()) {
            session_start();
        }

        $account = [];
        if ($this->userinfo['type']==2) {
            $sql = "SELECT *
                    FROM publisher_adaccount 
                    INNER JOIN adaccount ON publisher_adaccount.market_account_id = adaccount.market_account_id 
                    where publisher_adaccount.publisher_id=".$this->userinfo['user_id']." and adaccount.status=1";
            $list = $this->publisher_adaccount_model->get_query($sql);
        }elseif ($this->userinfo['type']==1) {
            $sql = "select * from publisher_offer where advertiser_id=".$this->userinfo['user_id']." group by account_id";
            $list = $this->publisher_adaccount_model->get_query($sql);
        }else{
            $sql = "select * from publisher_adaccount  LEFT JOIN `user` ON publisher_adaccount.publisher_id = `user`.user_id";
            $list = $this->publisher_adaccount_model->get_query($sql);
            
            foreach ($list as $key => $value) {
                $account[$value['account_id']][] = $value;
            }
        }

        foreach ($list as &$item) {
            $item['backup'] = json_decode($item['backup'], true);
            $item['backup']['created_time'] = json_decode($item['backup']['created_time'], true);
        }


        $this->data['list'] = $list;
        $this->data['account'] = $account;


        $fb = new Facebook([
            'app_id' => config_item('APP_ID'),
            'app_secret' => config_item('APP_SECRET')
        ]);

        $helper = $fb->getRedirectLoginHelper();
        $permissions = ['ads_management'];
        $facebook_url = $helper->getLoginUrl(site_url('active/facebook'), $permissions);

        $this->data['facebook_url'] = $facebook_url;

        $this->data['userinfo'] = $this->user_model->get_by_id($this->userinfo['user_id']);
        $template = 'user_account';
        $this->template->build($template,$this->data);
    }

}