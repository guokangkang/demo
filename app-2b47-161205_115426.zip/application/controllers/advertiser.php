<?php if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

/**
 * 
 * Created by PhpStorm.
 * User: palmax
 * Date: 2016/4/26
 * Time: 15:10
 */
class Advertiser extends MY_Controller
{
    var $country_list;
    public function __construct() {
        parent::__construct();

        $this->load->model('ad_model');
        $this->load->model('offer_model');
        $this->load->model('reports_model');
        $this->load->model('redshift_model');
        $this->load->model('user_model');
        $this->load->model('ad_insight_model');
        $this->load->library('pagination');
        $this->load->helper('common');

        $this->load->library('encrypt');

        $this->config->load('product',TRUE);
        $config_product = $this->config->item('product');
        $this->country_list = $config_product['countries'];

        $this->data['top_menu'] = $this->load->view('web/top_menu_agency', '', TRUE);
    }

    public function subscription()
    {
        // if (!$this->input->get('advertiser')) {
        //     echo "Error~~";
        //     die();
        // }
        // $advertiser = $this->input->get('advertiser');
        // if ($advertiser!=10008) {
        //     echo "Error~~";
        //     die();
        // }
        

        $user_id = $this->session->userdata('DALIY_INFO');

        //echo $this->encode("2016-11-12");die();
        $publisher_id = $publisher_info = '';
        if (!$user_id) {
            $this->template->set_template('web/advertiser_sign');
            $this->template->set_view_dir("web");
            $this->template->build('advertiser_sign',$this->data);
        }else{

            $publisher_id = $user_id;

            $this->data['publisher_id'] = $publisher_id;
            
            $publisher_info = $this->user_model->get_by_id($publisher_id);
            if (!$publisher_info) {
                show_404();
                die();
            }
            if (!$publisher_info['token']) {
                show_404();
                die();
            }
        

            $account_list = $this->user_model->get_query("select * from publisher_offer where publisher_id=".$publisher_id." group by account_id");

            $accountids = [];
            $account_infos = [];

            $advertiser_name = "";
            foreach ($account_list as $key => $value) {
                $advertiser_name = $value['advertiser_name'];
                $accountids[] = $value['account_id'];
                $account_infos[] = ['account_id'=>$value['account_id'], 'name'=>$value['account_name']];
            }
            $this->data['advertiser_name'] = $advertiser_name;
            
            $where = "account_id in (".implode(',', $accountids).")";
            //$where = "1=1";

            $base_url = $config['base_url'] = site_url('advertiser/subscription?');

            $account = [];
            if ($this->input->get('account')) {
                $account = explode(',', $this->input->get('account'));
                $where .= " and account_id in (".$this->input->get('account').")";
                $config['base_url'] .= "&account=".$this->input->get('account');
            }
            $this->data['account_params'] = $account;

            if ($this->input->get('status')) {
                $where .= " and effective_status = '".$this->input->get('status')."'";
                $config['base_url']  .= "&status=".$this->input->get('status');
            }
            
            
            $count_sql = "SELECT 
                    count(*)
                    FROM marketmax_reviews
                    WHERE ".$where;


            $total_rows = $this->redshift_model->get_query($count_sql);
            $this->data['total_rows'] = $total_rows[0]['count'];

            //$total_rows = 1500;
            $config = get_web_page($config, $this->data['total_rows'], 3);


            $page = 1;
            if ($this->input->get('page')){
                $page = $this->input->get('page');
            }

            $limit = $config['per_page'] = 16;

            $this->pagination->initialize($config);
            $this->data['page_links'] = $this->pagination->create_links();

            
            $sql = "SELECT 
                    *
                    FROM marketmax_reviews 
                    WHERE ".$where."
                    ORDER BY updated_time desc
                    OFFSET " . ($page - 1) * $limit . "
                    LIMIT " . $limit;
            
            $this->data['offer'] = ($page - 1) * $limit+1;
            $this->data['limit'] = $limit;
            $ad_list = $this->redshift_model->get_query($sql);

            if ($ad_list) {
                foreach ($ad_list as $key => & $ad) {
                    
                    if (!strpos($ad['thumbnail_url'], "fbcdn")) {
                        $ad['image_url']=config_item('CDN') . $ad['thumbnail_url'];
                    } else {
                        $url=str_replace("w=64", "w=315", $ad['thumbnail_url']);
                        $url=str_replace("h=64", "h=156", $url);
                        $ad['image_url']=$url;
                    }



                    if ($ad['object_type'] == 'MORE_SHARE') {
                        $ad['more_image']=json_decode($ad['more_image'], true);
                        foreach ($ad['more_image'] as & $ad_image) {
                            if (!strpos($ad_image['url'], "fbcdn")) {
                                $ad_image['url']=config_item('CDN') . $ad_image['url'];
                            } else {
                                $ad_image['url']="https://external.xx.fbcdn.net/safe_image.php?d=AQDWAPPEnKQRaMWe&w=315&h=156&url=" . $ad_image['url'];
                            }
                        }
                    }
                    if ($ad['object_type'] == 'VIDEO') {
                        if (!strpos($ad['video_url'], "fbcdn")) {
                            $ad['video_url']=config_item('CDN') . $ad['video_url'];
                        }
                    }
                }
            }


            $this->data['ad_list'] = $ad_list;

            $this->data['base_url'] = $base_url;
            $this->data['account'] = $account_infos;

        }

        $this->data['status'] = ['ACTIVE','PAUSED','DELETED','PENDING_REVIEW','DISAPPROVED','PREAPPROVED','PENDING_BILLING_INFO','CAMPAIGN_PAUSED','ARCHIVED','ADSET_PAUSED'];

        $this->template->set_template('web/advertiser_subscription');

        $this->template
                ->set_view_dir("web");

        $this->template->build('advertiser_subscription',$this->data);
    }


    private function get_account_list($publisher_id)
    {
        $sql = "SELECT
                    account_id,
                    account_name
                FROM
                    publisher_adaccount
                WHERE publisher_id=".$publisher_id;
        return $this->ad_model->get_query($sql);
    }

    public function get_agency_list($publisher_id)
    {
        $sql = "SELECT
                    b.publisher_id,
                    b.publisher_name
                FROM
                    publisher_adaccount as a
                LEFT JOIN publisher_adaccount as b ON a.account_id = b.account_id
                WHERE
                    a.publisher_id = ".$publisher_id." and b.publisher_type=2
                GROUP BY
                    b.publisher_id";
        return $this->ad_model->get_query($sql);
    }


    private function get_account_by_agnecy($agency)
    {
        if (is_array($agency)) {
            $sql = "select publisher_id as agency_id,publisher_name as agency_name,account_id,account_name from publisher_adaccount where publisher_id in (".implode(',', $agency).") group by account_id";
        }else{
            $sql = "select * from publisher_adaccount where publisher_id=".$agency;
        }
        return $this->ad_model->get_query($sql);
    }


    private function get_product_list($publisher_id)
    {
        $sql = "select product_id,product_name,advertiser_id from publisher_offer where publisher_id=".$publisher_id." group by product_id";
        return $this->ad_model->get_query($sql);
    }


    private function get_country_list($product_id)
    {
        $sql = "SELECT offer_country_log.country,offer.product_id
                FROM offer 
                left JOIN offer_country_log ON offer.offer_id = offer_country_log.offer_id
                WHERE offer_country_log.product_id=".$product_id;

        $list = $this->ad_model->get_query($sql);
        $data = [];
        foreach ($list as $key => $value) {
            $s = json_decode($value['country'], true);
            $data = array_merge($data, $s);
        }
        return array_unique($data);
    }


    public function get_data2($publisher_id, $product_id, $product_name, $time)
    {
        $tmp = ['product_name'=>$product_name];
        
        $countries = $this->get_country_list($product_id);

        $sql = "select * from publisher_offer where publisher_id=".$publisher_id;
        $offer_list = $this->offer_model->get_query($sql);

        $country_info  =[];
        foreach ($offer_list as $item) {
            $country = $this->offer_model->get_current_country_log($item);
            $cpa_info = $this->offer_model->get_current_cpa_log($item['offer_id']);
            $status = $this->offer_model->get_offer_current_status($item['offer_id']);
            if ($cpa_info && $country) {
                foreach ($country[1] as $key => $value) {
                    $country_info[$value]['cpa'] = $cpa_info['cpa'];
                    $country_info[$value]['status'] = $status;
                }
            }
        }
        
        $sql = "select 
                    sum(results) as results,
                    country,
                    cpa 
                from 
                    marketmax_reports 
                where 
                    product_id=".$product_id." 
                    and date=".$time." 
                    and publisher_id=".$publisher_id."
                group by 
                    country,cpa";
        
        $results_info = $this->reports_model->get_report_data($sql);
        $country = [];
        foreach ($results_info as $r) {
            if (!$r['cpa'] && isset($country_info[$r['country']])) {
                $r['cpa'] = $country_info[$r['country']]['cpa'];
            }
            $country[$r['country']] = ['results'=>$r['results'], 'cpa'=>$r['cpa']];
        }
        foreach ($countries as $c) {
            $results = $cpa = "";
            if (isset($country[$c])) {
                $results = $country[$c]['results'];
                $cpa = $country[$c]['cpa'];
            }elseif (isset($country_info[$c])) {
                $cpa = $country_info[$c]['cpa'];
            }
            
            $country_info[$c]['status'] && $tmp['country'][] = ['name'=>$c."-".$this->country_list[$c], 'results'=>$results, 'cpa'=>$cpa];
        }
        return $tmp;
    }

    public function get_data3($publisher_id, $start_time, $end_time)
    {
        $sql = "select 
                    sum(results) as results,
                    date 
                from marketmax_reports 
                where date>=".$start_time." and date<=".$end_time." 
                and publisher_id=".$publisher_id." 
                group by date order by date asc";
        $data = $this->reports_model->get_report_data($sql);
        $data3 = $data3_date = $data3_results = [];
        foreach ($data as $item) {
            $data3_date[] = date('d/m', $item['date']);
            $data3_results[] = $item['results'];
        }
        return [$data3_date, $data3_results];
    }

    private function get_data4($publisher_id, $start_time, $end_time)
    {
        $sql = "SELECT
                    sum(results) AS results,
                    date,
                    marketmax_publisher_adaccount.publisher_id,
                    marketmax_publisher_adaccount.publisher_name
                FROM
                    marketmax_reports
                right JOIN marketmax_publisher_adaccount ON marketmax_publisher_adaccount.account_id = marketmax_reports.account_id
                WHERE
                marketmax_reports.publisher_id = ".$publisher_id."
                and date>=".$start_time." and date<=".$end_time." 
                and marketmax_publisher_adaccount.publisher_type=2
                GROUP BY
                    date,
                    marketmax_publisher_adaccount.publisher_id,
                    marketmax_publisher_adaccount.publisher_name
                ORDER BY
                    date asc, marketmax_publisher_adaccount.publisher_id desc";
        $data4 = $this->reports_model->get_report_data($sql);
        $data4_date = $data4_results = $tmp = [];
        foreach ($data4 as $item) {
            $data4_date[$item['date']] = date('d/m', $item['date']);
            $tmp[$item['publisher_name']][] = $item['results'];
        }
        foreach ($tmp as $key => $value) {
            $data4_results[] = ['name'=>$key, 'type'=>'line', 'data'=>$value];
        }
        return [$data4, array_values($data4_date), $data4_results];
    }


    private function get_data5($publisher_id, $start_time, $end_time)
    {
        $sql = "SELECT
                    sum(results) AS results,
                    date,
                    product_name
                FROM
                    marketmax_reports
                WHERE
                marketmax_reports.publisher_id = ".$publisher_id."
                and date>=".$start_time." and date<=".$end_time." 
                GROUP BY
                    date,
                    product_name
                ORDER BY
                    date asc, product_name desc";
        $data5 = $this->reports_model->get_report_data($sql);
        $data5_date = $data5_results = $tmp = [];
        foreach ($data5 as $item) {
            $data5_date[$item['date']] = date('d/m', $item['date']);
            $tmp[$item['product_name']][] = $item['results'];
        }
        foreach ($tmp as $key => $value) {
            $data5_results[] = ['name'=>$key, 'type'=>'line', 'data'=>$value];
        }
        return [$data5, array_values($data5_date), $data5_results];
    }

    private function get_data6($publisher_id, $time)
    {
        $sql = "SELECT
                    sum(results) AS results,
                    product_name,
                    marketmax_reports.account_id,
                    marketmax_reports.account_name,
                    marketmax_publisher_adaccount.publisher_id,
                    marketmax_publisher_adaccount.publisher_name
                FROM
                    marketmax_reports
                right JOIN marketmax_publisher_adaccount ON marketmax_publisher_adaccount.account_id = marketmax_reports.account_id
                WHERE
                marketmax_reports.publisher_id = ".$publisher_id."
                and date=".$time."
                and marketmax_publisher_adaccount.publisher_type=2
                GROUP BY
                    marketmax_publisher_adaccount.publisher_id,
                    marketmax_publisher_adaccount.publisher_name,
                    marketmax_reports.account_id,
                    marketmax_reports.account_name,product_name";
        return $this->reports_model->get_report_data($sql);
    }


    private function get_data7_table($publisher_id, $time)
    {
        $sql = "SELECT
                    sum(results) AS results,
                    sum(clicks) AS clicks,
                    sum(impressions) AS impressions,
                    product_name,
                    marketmax_publisher_adaccount.publisher_id,
                    marketmax_publisher_adaccount.publisher_name
                FROM
                    marketmax_reports
                right JOIN marketmax_publisher_adaccount ON marketmax_publisher_adaccount.account_id = marketmax_reports.account_id
                WHERE
                marketmax_reports.publisher_id = ".$publisher_id."
                and date=".$time."
                and marketmax_publisher_adaccount.publisher_type=2
                GROUP BY
                    marketmax_publisher_adaccount.publisher_id,
                    marketmax_publisher_adaccount.publisher_name,
                    product_name";

        $data5 = $this->reports_model->get_report_data($sql);
        return $data5;
    }

    private function get_data7_chart($publisher_id, $start_time, $end_time)
    {
        $sql = "SELECT
                    sum(results) AS results,
                    sum(clicks) AS clicks,
                    sum(impressions) AS impressions,
                    date,
                    product_name
                FROM
                    marketmax_reports
                WHERE
                publisher_id = ".$publisher_id."
                and date>=".$start_time." and date<=".$end_time."
                GROUP BY
                    date,
                    product_name
                ORDER BY date asc";

        $data5 = $this->reports_model->get_report_data($sql);
        
        $data5_date = $data5_ctr_results = $data5_cvr_results = $tmp= [];
        foreach ($data5 as $item) {
            $data5_date[$item['date']] = date('d/m', $item['date']);
            $tmp[$item['product_name']]['ctr'][] = floatval(sprintf("%.2f", $item['clicks']/$item['impressions']*100));
            $tmp[$item['product_name']]['cvr'][] = floatval(sprintf("%.2f", $item['results']/$item['clicks']*100));
        }
        foreach ($tmp as $key => $value) {
            $data5_ctr_results[] = ['name'=>$key, 'type'=>'line', 'data'=>$value['ctr']];
            $data5_cvr_results[] = ['name'=>$key, 'type'=>'line', 'data'=>$value['cvr']];
        }

        return [array_values($data5_date), $data5_ctr_results, $data5_cvr_results];
    }

    private function get_data7_chart_by_agency($agency_id, $start_time, $end_time)
    {
        $sql = "SELECT
                    sum(results) AS results,
                    sum(clicks) AS clicks,
                    sum(impressions) AS impressions,
                    date,
                    product_name
                FROM
                    marketmax_reports
                right JOIN marketmax_publisher_adaccount ON marketmax_publisher_adaccount.account_id = marketmax_reports.account_id
                WHERE
                marketmax_publisher_adaccount.publisher_id = ".$agency_id."
                and date>=".$start_time." and date<=".$end_time."
                and marketmax_publisher_adaccount.publisher_type=2
                GROUP BY
                    date,
                    product_name
                ORDER BY
                    date asc";

        $data5 = $this->reports_model->get_report_data($sql);
        
        $data5_date = $data5_ctr_results = $data5_cvr_results = $tmp = [];
        foreach ($data5 as $item) {
            $data5_date[$item['date']] = date('d/m', $item['date']);
            $tmp[$item['product_name']]['ctr'][] = floatval(sprintf("%.2f", $item['clicks']/$item['impressions']*100));
            $tmp[$item['product_name']]['cvr'][] = floatval(sprintf("%.2f", $item['results']/$item['clicks']*100));
        }
        foreach ($tmp as $key => $value) {
            $data5_ctr_results[] = ['name'=>$key, 'type'=>'line', 'data'=>$value['ctr']];
            $data5_cvr_results[] = ['name'=>$key, 'type'=>'line', 'data'=>$value['cvr']];
        }

        return [array_values($data5_date), $data5_ctr_results, $data5_cvr_results];
    }


    private function get_data8($publisher_id, $start_time, $end_time)
    {
        // $sql = "
        //         select count(date),date FROM (
        //         select 
        //             marketmax_reviews.ad_id,marketmax_reviews_insights.date
        //         from 
        //             marketmax_reviews
        //         left JOIN marketmax_reviews_insights ON marketmax_reviews.ad_id = marketmax_reviews_insights.ad_id
        //         where 
        //             marketmax_reviews.publisher_id=".$publisher_id."
        //             and date>=".$start_time." and date<=".$end_time." and spend>0
        //         group by marketmax_reviews.ad_id,marketmax_reviews_insights.date) AS DD
        //         GROUP BY date
        //         order by date asc";
        

        $sql = "SELECT
                    date,
                    count(*)
                FROM
                    marketmax_reviews_insights
                WHERE
                publisher_id=".$publisher_id."
                and date>=".$start_time." 
                and date<=".$end_time." 
                and spend>0
                GROUP BY
                    date
                order by date asc";
        //echo $sql;die();
        $data = $this->redshift_model->get_query($sql);
        $data8 = $data8_date = [];
        $date = date('Y-m-d', $start_time);
        for ($i=0; $i < 7; $i++) { 
            $data8_date[] = date('d/m', strtotime("+$i day $date"));
        }
        
        foreach ($data as $key => $value) {
            $data8[date('d/m', $value['date'])] = $value['count'];
        }
        foreach ($data8_date as $item) {
            if (!isset($data8[$item])) {
                $data8[$item] = 0;
            }
        }
        //ksort($data8);
        return [$data8_date, array_values($data8)];
    }

    private function get_data9($publisher_id, $start_time, $end_time)
    {
        // $sql = "select 
        //             ad_id,created_time,publisher_adaccount.publisher_name
        //         from 
        //             ad
        //         right JOIN publisher_adaccount ON publisher_adaccount.account_id = ad.account_id
        //         where 
        //             ad.publisher_id=".$publisher_id."
        //             and created_time>=".$start_time." and created_time<=".$end_time." and is_new=1
        //             and publisher_adaccount.publisher_type=2
        //         order by created_time desc";
        // $data = $this->ad_model->get_query($sql);
        // $sql = "SELECT
        //             date,
        //             agency_name,
        //             (
        //                 SELECT
        //                     COUNT(c.date)
        //                 FROM
        //                     marketmax_reviews_insights AS c
        //                 WHERE
        //                     c.date = marketmax_reviews_insights.date
        //                 GROUP BY
        //                     c.date
        //             ) AS count
        //         FROM
        //             marketmax_reviews_insights
        //         WHERE
        //             publisher_id=".$publisher_id."
        //             and date>=".$start_time." 
        //             and date<=".$end_time." 
        //             and spend>0
        //         GROUP BY
        //             date,
        //             agency_name
        //         order by date asc";
        
        $sql = "select agency_id, agency_name from marketmax_reviews_insights 
                where publisher_id=".$publisher_id."
                    and date>=".$start_time." 
                    and date<=".$end_time." 
                    and spend>0
                GROUP BY
                    agency_id,
                    agency_name";

        $results = $this->redshift_model->get_query($sql);

        $data = [];
        foreach ($results as $value) {
            $sql = "SELECT
                        date,
                        COUNT(*)
                    FROM
                        marketmax_reviews_insights
                    WHERE
                        publisher_id=".$publisher_id."
                        and date>=".$start_time." 
                        and date<=".$end_time." 
                        and spend>0
                        and agency_id=".$value['agency_id']."
                    GROUP BY
                        date
                    order by date asc";
            $tmp = $this->redshift_model->get_query($sql);
            
            foreach ($tmp as $key => $item) {
                $data[] = ['date'=>$item['date'], 'count'=>$item['count'], 'agency_name'=>$value['agency_name']];
            }
        }

        $date = date('Y-m-d', $start_time);
        for ($i=0; $i < 7; $i++) { 
            $data8_date[] = date('d/m', strtotime("+$i day $date"));
        }
        
        $data8_results = $data8 = [];
        foreach ($data as $key => $item) {
            $data8[$item['agency_name']][] = $item['count'];
        }

        foreach ($data8 as $key => $item) {
            $data8_results[] = ['name'=>$key, 'type'=>'line', 'data'=>$item];
        }

        return [$data8_date, $data8_results];
    }

    private function get_data10($publisher_id, $start_time, $end_time)
    {
        // $sql = "select 
        //             ad_id,created_time,product_name
        //         from 
        //             ad
        //         where 
        //             ad.publisher_id=".$publisher_id."
        //             and created_time>=".$start_time." and created_time<=".$end_time." and is_new=1
        //         order by created_time desc";
        // $data = $this->ad_model->get_query($sql);
        
        // $sql = "SELECT
        //             date,
        //             product_name,
        //             (
        //                 SELECT
        //                     COUNT(c.date)
        //                 FROM
        //                     marketmax_reviews_insights AS c
        //                 WHERE
        //                     c.date = marketmax_reviews_insights.date
        //                 GROUP BY
        //                     c.date
        //             ) AS count
        //         FROM
        //             marketmax_reviews_insights
        //         WHERE
        //             publisher_id=".$publisher_id."
        //             and date>=".$start_time." 
        //             and date<=".$end_time." 
        //             and spend>0
        //         GROUP BY
        //             date,
        //             product_name
        //         order by date asc";
        

        $sql = "select product_id, product_name from marketmax_reviews_insights 
                where publisher_id=".$publisher_id."
                    and date>=".$start_time." 
                    and date<=".$end_time." 
                    and spend>0
                GROUP BY
                    product_id,
                    product_name";

        $results = $this->redshift_model->get_query($sql);

        $data = [];
        foreach ($results as $value) {
            $sql = "SELECT
                        date,
                        COUNT(*)
                    FROM
                        marketmax_reviews_insights
                    WHERE
                        publisher_id=".$publisher_id."
                        and date>=".$start_time." 
                        and date<=".$end_time." 
                        and spend>0
                        and product_id=".$value['product_id']."
                    GROUP BY
                        date
                    order by date asc";
            $tmp = $this->redshift_model->get_query($sql);
            
            foreach ($tmp as $key => $item) {
                $data[] = ['date'=>$item['date'], 'count'=>$item['count'], 'product_name'=>$value['product_name']];
            }
        }


        $data8 = $data8_date = [];
        $date = date('Y-m-d', $start_time);
        for ($i=0; $i < 7; $i++) { 
            $data8_date[] = date('d/m', strtotime("+$i day $date"));
        }
        
        $data8_results = $data8 = [];
        foreach ($data as $key => $item) {
            $data8[$item['product_name']][] = $item['count'];
        }

        foreach ($data8 as $key => $item) {
            $data8_results[] = ['name'=>$key, 'type'=>'line', 'data'=>$item];
        }

        return [$data8_date, $data8_results];
    }


    private function get_data11($publisher_id, $date)
    {
        $sql = "SELECT
                    sum(marketmax_reviews_insights.results) as results,
                    sum(marketmax_reviews_insights.impressions) as impressions,
                    sum(marketmax_reviews_insights.clicks) as clicks,
                    marketmax_reviews_insights.ad_id,
                    marketmax_reviews_insights.ad_name,
                    marketmax_reviews_insights.agency_id,
                    marketmax_reviews_insights.agency_name,
                    marketmax_reviews_insights.account_id,
                    marketmax_reviews_insights.account_name,
                    marketmax_reviews_insights.campaign_id,
                    marketmax_reviews_insights.campaign_name,
                    marketmax_reviews_insights.adset_id,
                    marketmax_reviews_insights.adset_name,
                    marketmax_reviews.title,
                    marketmax_reviews.message,
                    marketmax_reviews.image_url,
                    marketmax_reviews.more_image,
                    marketmax_reviews.org_image_url,
                    marketmax_reviews.video_url,
                    marketmax_reviews.object_type
                FROM
                    marketmax_reviews_insights
                left JOIN marketmax_reviews ON marketmax_reviews.ad_id = marketmax_reviews_insights.ad_id
                WHERE
                    marketmax_reviews_insights.publisher_id = $publisher_id
                    and results>0
                    and date = $date
                GROUP BY
                    marketmax_reviews_insights.ad_id,
                    marketmax_reviews_insights.ad_name,
                    marketmax_reviews_insights.agency_id,
                    marketmax_reviews_insights.agency_name,
                    marketmax_reviews_insights.account_id,
                    marketmax_reviews_insights.account_name,
                    marketmax_reviews_insights.campaign_id,
                    marketmax_reviews_insights.campaign_name,
                    marketmax_reviews_insights.adset_id,
                    marketmax_reviews_insights.adset_name,
                    marketmax_reviews.title,
                    marketmax_reviews.message,
                    marketmax_reviews.more_image,
                    marketmax_reviews.image_url,
                    marketmax_reviews.org_image_url,
                    marketmax_reviews.video_url,
                    marketmax_reviews.object_type
                ORDER BY
                    results DESC;
                    ";
        $data = $this->redshift_model->get_query($sql);
        $data8 = [];
        foreach ($data as $key => $value) {
            if (!isset($data8[$value['agency_name']]) || (isset($data8[$value['agency_name']]) && count($data8[$value['agency_name']])<3)) {
                
                if ($value['object_type'] == 'MORE_SHARE') {
                    $value['more_image'] = json_decode($value['more_image'], true);
                    foreach ($value['more_image'] as & $image) {
                        if (!strpos($image['url'], "fbcdn")) {
                            $image['url'] = config_item('CDN').$image['url'];
                        }else{
                            $image['url'] = "https://external.xx.fbcdn.net/safe_image.php?d=AQDWAPPEnKQRaMWe&w=315&h=156&url=".$image['url'];
                        }
                    }
                }
                if ($value['object_type'] == 'VIDEO') {
                    if (!strpos($value['video_url'], "fbcdn")) {
                        $value['video_url'] = config_item('CDN').$value['video_url'];
                    }
                }

                $data8[$value['agency_name']][$value['ad_id']] = $value;
            }
        }
        return $data8;
    }

    private function get_data12($publisher_id)
    {
        $gender_sql = "select 
                            sum(results) as results,
                            sum(impressions) as impressions,
                            sum(clicks) as clicks,
                            gender 
                        from 
                            marketmax_gender_reports 
                        RIGHT JOIN marketmax_publisher_adaccount ON marketmax_publisher_adaccount.account_id = marketmax_gender_reports.account_id
                        where 
                            marketmax_publisher_adaccount.publisher_id=".$publisher_id." and gender is not null
                        group by gender order by results desc";
        $gender_data = $this->reports_model->get_report_data($gender_sql);
        return $gender_data;
    }

    private function get_data13($publisher_id)
    {
        $gender_sql = "select 
                            sum(results) as results,
                            sum(impressions) as impressions,
                            sum(clicks) as clicks,
                            age 
                        from 
                            marketmax_age_reports 
                        RIGHT JOIN marketmax_publisher_adaccount ON marketmax_publisher_adaccount.account_id = marketmax_age_reports.account_id
                        where 
                            marketmax_publisher_adaccount.publisher_id=".$publisher_id." and age is not null
                        group by age
                        order by age asc";
        $gender_data = $this->reports_model->get_report_data($gender_sql);
        return $gender_data;
    }

    private function get_data14($publisher_id)
    {
        $gender_sql = "select 
                            sum(results) as results,
                            sum(impressions) as impressions,
                            sum(clicks) as clicks,
                            placement 
                        from 
                            marketmax_placement_reports 
                        RIGHT JOIN marketmax_publisher_adaccount ON marketmax_publisher_adaccount.account_id = marketmax_placement_reports.account_id
                        where 
                            marketmax_publisher_adaccount.publisher_id=".$publisher_id." and placement is not null 
                        group by placement order by results desc";
        $gender_data = $this->reports_model->get_report_data($gender_sql);
        return $gender_data;
    }

    public function sign_in()
    {
        
        $this->load->model('user_model');
        $this->load->library('validation');
        if (IS_POST) {
            $vars['email'] = $this->input->post('input_email');
            $vars['password'] = $this->input->post('input_password');
            $vars = $this->validation->checkInput($vars);

            if ($this->input->post('params')) {
                $url  = "advertiser/daily";
                $url .= "/".$this->input->post('params');
            }else{
                $url  = "advertiser/subscription";
            }

            $where = ['email'=>$vars['email']];

            $user = $this->user_model->get_by_fields($where);
            if (!$user) {
                $this->input->set_cookie('advertiser_sign_in_error', "The user is not exist.", 1);
                redirect($url);
                die();
            }
            if (password_verify($vars['password'], $user['password'])) {
                unset($user['password']);

                if ($this->input->post('remember')==1) {
                    $date = 86500 * 7;
                }else{
                    $date = 86500;
                }
                $this->session->set_userdata("DALIY_INFO", $user['user_id']);
                redirect($url);
                
            }else{
                $this->input->set_cookie('advertiser_sign_in_error', "Password is wrong.", 1);
                redirect($url);
                die();
            }
            
        }else{
            redirect($url);
        }
    }

    private function encode($data) {
        return str_replace(array('+', '/', '='), array('-', '_', ''), base64_encode(serialize($data)));
    }

    private function decode($string) {
        $data = str_replace(array('-', '_'), array('+', '/'), $string);
        $mod4 = strlen($data) % 4;
        ($mod4) && $data .= substr('====', $mod4);
        return @ unserialize(base64_decode($data));
    }

    private function isDate( $dateString ) {
        return strtotime( date('Y-m-d', strtotime($dateString)) ) === strtotime( $dateString );
    }


    public function daily()
    {
        $user_id = $this->session->userdata('DALIY_INFO');

        //echo $this->encode("2016-11-12");die();

        if (!$user_id) {
            $this->template->set_template('web/advertiser_sign');
            $this->template->set_view_dir("web");
            $this->template->build('advertiser_sign',$this->data);
        }else{

            $publisher_id = $user_id;

            $this->data['publisher_id'] = $publisher_id;
            
            $publisher_info = $this->user_model->get_by_id($publisher_id);
            if (!$publisher_info) {
                show_404();
                die();
            }
            if (!$publisher_info['token']) {
                show_404();
                die();
            }
            $date = date('Y-m-d');
            if ($this->uri->segment(3)) {
                $date = $this->uri->segment(3);

                $date = $this->decode($date);
                if (!$this->isDate($date)) {
                    show_404();
                    die();
                }
            }else{
                show_404();
                die();
            }


            $time = strtotime($date);

            $this->data['current_date'] = $time;


            $agency_list = $this->get_agency_list($publisher_id);
            $this->data['agency_list'] = $agency_list;

            $agency_ids = [];
            foreach ($agency_list as $item) {
                $agency_ids[] = $item['publisher_id'];
            }
            $account_list = $this->get_account_by_agnecy($agency_ids);

            //---------------------推广渠道---------------------
            $data1 = [];
            foreach ($account_list as $item) {
                $data1[$item['agency_name']][] = $item;
            }
            $this->data['data1'] = $data1;

            //---------------------推广任务---------------------
            $data2 = [];
            $product_list = $this->get_product_list($publisher_id);
                
            $advertiser_info = [];
            if ($product_list) {
                $advertiser_id = $product_list[0]['advertiser_id'];
                $advertiser_info = $this->user_model->get_by_id($advertiser_id);
            }
            $this->data['advertiser_info'] = $advertiser_info;

            foreach ($product_list as $item) {
                $data2[] = $this->get_data2($publisher_id, $item['product_id'], $item['product_name'], $time);
            }
            $this->data['data2'] = $data2;

            //---------------------七天的每日波形图+表总数---------------------
            $time = strtotime("-6 day $date");
            list($data3_date, $data3_results) = $this->get_data3($publisher_id, $time, strtotime($date));
            $this->data['data3_date'] = $data3_date;
            $this->data['data3_results'] = $data3_results;
            $this->data['current_7date'] = $time;


            //---------------------七天的分渠道波形图+表总数---------------------
            $time = strtotime("-6 day $date");
            list($data4, $data4_date, $data4_results) = $this->get_data4($publisher_id, $time, strtotime($date));

            $this->data['data4_date'] = $data4_date;
            $this->data['data4_results'] = $data4_results;
            $this->data['data4'] = $data4;

            //---------------------七天的分产品波形图+表总数---------------------
            $time = strtotime("-6 day $date");
            list($data5, $data5_date, $data5_results) = $this->get_data5($publisher_id, $time, strtotime($date));

            $this->data['data5_date'] = $data5_date;
            $this->data['data5_results'] = $data5_results;
            $this->data['data5'] = $data5;
            // var_dump($data5_date, $data5_results);die();

            //---------------------分账号安装数（不用波形图）（报告日当天）---------------------
            $time = strtotime($date);
            $data6 = $this->get_data6($publisher_id, strtotime($date));
            $this->data['data6'] = $data6;

            //---------------------ctr/cvr（报告日当天）---------------------
            $data7_table = $this->get_data7_table($publisher_id, strtotime($date));

            $time = strtotime("-6 day $date");
            list($data7_date, $data7_ctr_results, $data7_cvr_results)  = $this->get_data7_chart($publisher_id, $time, strtotime($date));
            $this->data['data7'] = $data7_table;
            $this->data['data7_date'] = $data7_date;
            $this->data['data7_ctr_results'] = $data7_ctr_results;
            $this->data['data7_cvr_results'] = $data7_cvr_results;

            //---------------------七天广告总数（新添加）---------------------
            $time = strtotime("-6 day $date");
            list($data8_date, $data8) = $this->get_data8($publisher_id, $time, strtotime($date));
            $this->data['data8_date'] = $data8_date;
            $this->data['data8'] = $data8;

            //---------------------七天分渠道广告总数（新添加）---------------------
            $time = strtotime("-6 day $date");
            list($data9_date, $data9) = $this->get_data9($publisher_id, $time, strtotime($date));
            $this->data['data9_date'] = $data9_date;
            $this->data['data9'] = $data9;

            //---------------------七天分产品广告总数（新添加）---------------------
            $time = strtotime("-6 day $date");
            list($data10_date, $data10) = $this->get_data10($publisher_id, $time, strtotime($date));
            $this->data['data10_date'] = $data10_date;
            $this->data['data10'] = $data10;

            //------------------该渠道投放量级最大的广告图数据）(每个渠道的top3)----------------
            $time = strtotime($date);
            $data11 = $this->get_data11($publisher_id, $time);
            $this->data['data11'] = $data11;

            //------------------用户性别分布----------------
            $data12 = $this->get_data12($publisher_id);
            $data12_chart = [];
            foreach ($data12 as $key => $value) {
                $data12_chart[] = ['name'=>ucwords($value['gender']), 'value'=>$value['results']];
            }
            $this->data['data12'] = $data12;
            $this->data['data12_chart'] = $data12_chart;


            //------------------用户年龄分布----------------
            $data13 = $this->get_data13($publisher_id);
            $data13_chart = [];
            foreach ($data13 as $key => $value) {
                $data13_chart[] = ['name'=>ucwords($value['age']), 'value'=>$value['results']];
            }
            $this->data['data13'] = $data13;
            $this->data['data13_chart'] = $data13_chart;

            //------------------用户来源分布----------------
            $data14 = $this->get_data14($publisher_id);
            $data14_chart = [];
            foreach ($data14 as $key => $value) {
                $data14_chart[] = ['name'=>ucwords($value['placement']), 'value'=>$value['results']];
            }
            $this->data['data14'] = $data14;
            $this->data['data14_chart'] = $data14_chart;



            $this->template->set_template('web/advertiser_daily');
            $this->template->set_view_dir("web");
            $this->template->build('advertiser_daily',$this->data);

        }

        
        
    }

    public function ctr_data_chart()
    {
        if ($this->input->is_ajax_request()) {
            $agency_id = $this->input->get('agency_id');
            $publisher_id = $this->input->get('publisher_id');
            $start_time = $this->input->get('time');
            $s =date('Y-m-d', $start_time);
            $end_time = strtotime("+6 day $s");

            if ($agency_id>0) {
                list($data7_date, $data7_ctr_results, $data7_cvr_results)  = $this->get_data7_chart_by_agency($agency_id, $start_time, $end_time);
            }else{
                list($data7_date, $data7_ctr_results, $data7_cvr_results)  = $this->get_data7_chart($publisher_id, $start_time, $end_time);
            }
        
            $response = ['success'=>true, 'ctr'=>$data7_ctr_results, 'cvr'=>$data7_cvr_results, 'date'=>$data7_date];
        }else{
            $response = ['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
        }
        $this->output->set_content_type('applicaion/json')->set_output(json_encode($response));
        
    }
}