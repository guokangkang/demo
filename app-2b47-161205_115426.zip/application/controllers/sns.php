
<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Sns extends CI_Controller {


    /**
    * 初使化
    */
    public function __construct()
    {
        parent::__construct();

        //载入SNS类库
        $this->load->library('aws_sns');
    }


    //接收AWS SNS Message
   	public function subscribe()
    {
        try{
            log_message('debug','AWS SNS Message request received');        
            $message = $this->aws_sns->subscribe();

            if( isset($message['Type']) &&  $message['Type'] == 'Notification'){
                $message_content = json_decode($message['Message'], true);
                $event = $message_content['event'];

                switch ($event) {
                    case 'fetch_facebook_account':
                        $this->_sync_user_facebook_account($message_content['user_id'], $message_content['user_name']);

                        break;
                    case 'verify_review':
                        $this->_verify_review($message_content['status'], $message_content['ad_id']);

                        break;
                    
                    default:
                        
                        break;
                }
            }
            $this->output->set_status_header('200');
        }catch (Exception $e){
            fetch_exception("", $message_content['event'], $e->getMessage(), "队列接收异常");

            log_message('error', 'AWS SQS Message: '. $e->getMessage());
            $this->output->set_status_header('500');
        }
        
    }


    public function _sync_user_facebook_account($user_id, $user_name)
    {
        $this->load->model('adaccount_model');
        $this->adaccount_model->add_account_by_user_id($user_id, $user_name);
    }

    public function _verify_review($status, $ad_id)
    {
        $this->load->library('aws_ses');
        $this->load->model('redshift_model');
        $this->load->model('publisher_adaccount_model');
        // $status = 3;
        // $ad_id = 23842517620870428;
        $info = $this->redshift_model->get_query("select * from marketmax_reviews_verify where ad_id='".$ad_id."'", false);
        if ($info) {
            $this->redshift_model->get_query("update marketmax_reviews_verify set status=".$status." where ad_id='".$ad_id."'", false);
        }else{
            $this->redshift_model->get_query("insert into marketmax_reviews_verify (ad_id, status, addtime) values (".$ad_id.", ".$status.", ".time().")", false);
        }
        $this->redshift_model->get_query("update marketmax_reviews_risk set status=".$status." where ad_id='".$ad_id."'", false);

        log_message("debug", $ad_id."---".$status);

        $return_email = "";
        if ($status==3) {
            $ad_info = $this->redshift_model->get_query("select * from marketmax_reviews where ad_id=".$ad_id);
            if ($ad_info) {
                $user_list = $this->publisher_adaccount_model->get_query("SELECT `user`.email
                                    FROM publisher_adaccount INNER JOIN `user` ON publisher_adaccount.publisher_id = `user`.user_id where account_id=".$ad_info[0]['account_id']);
                $email = [];
                foreach ($user_list as $item) {
                    $email[] = $item['email'];
                }
                if (!$email) {
                    $email[] = "lucas@palmax.com";
                }
                
                $body = "<p>Account ID : ".$ad_info[0]['account_id']."</p>";
                $body .= "<p>Campaign : ".$ad_info[0]['campaign_name']."</p>";
                $body .= "<p>Adset : ".$ad_info[0]['adset_name']."</p>";
                $body .= "<p>Ad : ".$ad_info[0]['name']."</p>";
                $body .= "<p><img src=".$ad_info[0]['org_thumbnail_url']."></p>";
                $return_email = $this->aws_ses->send($email, "违规广告图警告", $body);

                log_message("debug", $ad_id."--".$status."---email status:".$return_email);
            }
        }

    }

}