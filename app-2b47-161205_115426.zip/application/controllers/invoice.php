<?php

/**
 * Created by PhpStorm.
 * User: palmax
 * Date: 2016-10-25
 * Time: 17:13
 */
class Invoice extends Web_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('offer_model');
        $this->load->library('export_pdf');
    }

    /**
     * 生成pdf
     */
    public function index()
    {
        $data='';
        //$template='invoice';
        $html=$this->load->view('web/invoice', $data, true);
        //echo $html;
        $this->export_pdf->export($html);
    }
}