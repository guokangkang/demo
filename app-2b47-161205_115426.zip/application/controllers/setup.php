<?php if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

/**
 *
 * Created by PhpStorm.
 * User: palmax
 * Date: 2016/4/26
 * Time: 15:10
 */
class Setup extends Web_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->library('validation');
        $this->load->model('user_model');
        $this->load->model('company_model');
        $this->load->model('offer_model');
        $this->load->model('publisher_adaccount_model');
        $this->load->library('validation');
        $this->load->library('pagination');

        $this->data['top_menu']=$this->load->view('web/top_menu_setup', '', TRUE);
    }


    public function index()
    {
        $template='setup_index';
        $this->template->build($template, $this->data);
    }

    public function advertiser()
    {
        //配置分页地址
        $config['base_url']=site_url('setup/advertiser?');
        $page=$this->input->get('page', true);
        $q=$this->input->get('q', true);
        if (!$page) {
            $page=1;
        }
        $like='';
        if ($q) {
            $like=" AND user_name like '%{$q}%'";
        }
        $count_sql="select user_id,first_name,last_name,user_name,email,head from user where type=1 AND status=1 $like";
        $total_rows=$this->user_model->get_query_count($count_sql);
        //分页开始
        $this->data['total_rows']=$total_rows;
        $config=get_web_page($config, $total_rows, 3);
        $limit=$config['per_page']=9;
        $this->pagination->initialize($config);
        $this->data['page_links']=$this->pagination->create_links();
        //加载国家
        $this->config->load('product', TRUE);
        $this->data['config_product']=$this->config->item('product');
        //获取数据
        $pages=($page - 1) * $limit;
        $sql="select user_id,first_name,last_name,user_name,email,head from user where type=1 AND status=1 $like LIMIT {$pages},{$limit}";
        $data=$this->user_model->get_query($sql);
        //处理数据
        if ($data) {
            // $letters='';
            foreach ($data as &$item) {
                $temps=explode(' ', $item['user_name']);
                if (count($temps) > 1) {
                    foreach ($temps as $temp) {
                        $item['head'].=get_first_letters($temp);
                    }
                } else {
                    $item['head']=substr($item['user_name'], 0, 2);
                }

            }
        }
        $this->data['data']=$data;
        $template='setup_advertiser';
        $this->template->build($template, $this->data);
    }

    public function advertiser_edit_action()
    {
        if (IS_POST) {
            $post_data=$this->input->post(null, true);
            if (!$post_data) {
                redirect($this->input->server('HTTP_REFERER'));
            }
            $user_id=$post_data['user_id'];
            unset($post_data['user_id']);
            $update['email']=$post_data['input_email'];
            $update['user_name']=$post_data['input_user_name'];
            $update['first_name']=$post_data['input_user_name'];
            $update['company']=$post_data['input_company'];
            $update['country']=$post_data['select_country'];
            $update['type']=$post_data['input_type'];
            $update['contact']=$post_data['input_contact'];
            if ($user_id) {
                $result=$this->user_model->update_row_by_id($user_id, $update);
                redirect('setup/advertiser');
            } else {
                redirect('setup/advertiser');
            }
        } else {
            $user_id=$this->input->get('user_id', true);
            if ($user_id) {
                $sql="select user_id,first_name,last_name,user_name,email,company,country,Contact from user where user_id={$user_id} AND status=1";
                $data=$this->user_model->get_query($sql);
                $data=$data?$data[0]:[];
                return $this->output
                    ->set_content_type('application/json')
                    ->set_output(json_encode($data));
            }
        }
    }

    /**
     * advertiser 删除
     * @return mixed
     */
    public function del_advertiser_action()
    {
        if (IS_AJAX) {
            $user_id=$this->input->post('user_id', true);
            if ($user_id) {
                $result=$this->user_model->update_row_by_id($user_id, ['status'=>0]);
                if ($result) {
                    $response=['success'=>true, 'msg'=>$this->lang->line('success_done')];
                } else {
                    $response=['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
                }
            } else {
                $response=['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
            }
            return $this->output->set_content_type('applicaion/json')->set_output(json_encode($response));
        }
    }

    public function publisher()
    {
        $this->config->load('product', TRUE);
        $this->data['config_product']=$this->config->item('product');


        $sql="SELECT
                    user.*, company.name as company_name
                FROM
                    `user`
                LEFT JOIN company ON `user`.company_id = company.company_id where type=2";
        $this->data['data']=$this->user_model->get_query($sql);


        $sql="select  * from company";
        $this->data['company_data']=$this->user_model->get_query($sql);

        $template='setup_publisher';
        $this->template->build($template, $this->data);
    }

    /**
     * 添加管理员、广告主
     */
    public function add_advertiser_action()
    {
        if (IS_POST) {
            $vars['user_name']=$vars['first_name']=$this->input->post('input_first_name');

            $vars['email']=$this->input->post('input_email');
            $vars['country']=$this->input->post('select_country');
            $vars['contact']=$this->input->post('input_contact');
            $vars['label']=$this->input->post('input_label');

            if ($this->input->post('select_company')) {
                $vars['company_id']=$this->input->post('select_company');

                $company_info=$this->company_model->get_by_id($vars['company_id']);
                $vars['company_account']=$company_info['account'];
                $vars['company']='';
            } else {
                $vars['company']=$this->input->post('input_company');
            }

            $vars=$this->validation->checkInput($vars);

            $url="setup/advertiser";
            if ($this->input->post('input_type') == 2) {
                $url="setup/publisher";
            }

            $info=$this->user_model->get_by_fields(['email'=>$vars['email']]);
            if ($info) {
                $this->error($this->lang->line('notice_bad_request'), $url);
            }

            $vars['password']=password_hash('123456', PASSWORD_DEFAULT);

            $vars['type']=$this->input->post('input_type');

            $this->user_model->add_one($vars);

            $this->success($this->lang->line('success_done'), $url);
        } else {
            $this->error($this->lang->line('notice_bad_request'), $url);
        }
    }


    public function upload()
    {
        if ($this->input->is_ajax_request()) {

            if (!$_FILES) {
                $response=['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
            } else {
                $file=upload_aws();

                if (!$file['error']) {

                    $this->load->library('aws_sqs');
                    $this->load->library('aws');
                    $this->load->library('excelreader');
                    $filename=$this->aws->getPath(config_item('Marketmax_Generalfile'), $file['message']);
                    $data=$this->excelreader->getExcelInfo($filename);

                    if ($data && $data['result']) {
                        $date_data=[];
                        foreach ($data['result'] as $key=>$row) {
                            if (!in_array($row[0], $date_data)) {
                                $date_data[]=$row[0];

                                $message=array('filename'=>$file['message'], 'event'=>'upload_retention', 'bucket'=>config_item('Marketmax_Generalfile'), 'date'=>$row[0]);
                                log_message("debug", "queue_upload_retention: Push Filename:" . $message['filename'] . " ---date:" . $row[0]);
                                $this->aws_sqs->deliver($message);
                            }
                        }
                    }

                    $response=['success'=>true, 'msg'=>$this->lang->line('success_done'), 'data'=>$file['message']];
                } else {
                    log_message("debug", "queue_upload_retention: Push Filename Failed");
                    $response=['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
                }
            }

        } else {
            $response=['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
        }
        $this->output->set_content_type('applicaion/json')->set_output(json_encode($response));
    }


    public function upload_appsflyer()
    {
        if ($this->input->is_ajax_request()) {

            if (!$_FILES) {
                $response=['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
            } else {
                $file=upload_aws();

                if (!$file['error']) {

                    $this->load->library('aws_sqs');
                    $this->load->library('aws');
                    $this->load->library('excelreader');
                    $filename=$this->aws->getPath(config_item('Marketmax_Generalfile'), $file['message']);
                    $data=$this->excelreader->getExcelInfo($filename);

                    if ($data && $data['result']) {
                        $date_data=[];
                        foreach ($data['result'] as $key=>$row) {
                            if ($key == 0) {
                                continue;
                            }
                            if (!in_array($row[0], $date_data)) {
                                $date_data[]=$row[0];

                                $message=array('filename'=>$file['message'], 'event'=>'upload_retention_appsflyer', 'bucket'=>config_item('Marketmax_Generalfile'), 'date'=>$row[0]);
                                log_message("debug", "queue_upload_retention_appsflye: Push Filename:" . $message['filename'] . " ---date:" . $row[0]);
                                $this->aws_sqs->deliver($message);
                            }
                        }
                    }

                    $response=['success'=>true, 'msg'=>$this->lang->line('success_done'), 'data'=>$file['message']];
                } else {
                    log_message("debug", "queue_upload_retention: Push Filename Failed");
                    $response=['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
                }
            }

        } else {
            $response=['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
        }
        $this->output->set_content_type('applicaion/json')->set_output(json_encode($response));
    }


    /**
     * 添加企业信息
     * @param string $value [description]
     */
    public function company()
    {

        $this->config->load('product', TRUE);
        $this->data['config_product']=$this->config->item('product');


        $sql="select * from company where status=1";
        $this->data['data']=$this->company_model->get_query($sql);

        $template='setup_company';
        $this->template->build($template, $this->data);
    }


    /**
     * 添加企业信息，表单提交
     */
    public function add_company_action()
    {
        if (IS_POST) {
            if (!$this->input->post('input_name')) {
                $this->error($this->lang->line('notice_params_empty'));
            }

            $vars['name']=$this->input->post('input_name');
            $vars['account']=$this->input->post('input_account');
            // $uuid = create_guid();
            // $vars['only_code'] = substr($uuid, 0, 8);
            $vars['contact']=$this->input->post('input_contact');
            $vars['country']=$this->input->post('select_country');

            $vars=$this->validation->checkInput($vars);
            $vars['bm']=explode(", ", $this->input->post('input_bm'));

            $vars['bm']=json_encode($vars['bm']);

            $info=$this->company_model->get_by_fields(['account'=>$vars['account']]);
            if ($info) {
                $this->error($this->lang->line('company_exists_code'), 'setup/company');
            }

            $this->company_model->add_one($vars);

            $this->success($this->lang->line('success_done'), 'setup/company');
        } else {
            $this->error($this->lang->line('notice_bad_request'));
        }
    }

    public function account_list()
    {
        if ($this->input->is_ajax_request()) {
            if (!$this->input->get('user_id')) {
                $response=['success'=>false, 'msg'=>$this->lang->line('notice_params_empty')];
            } else {
                $account=[];

                $user_id=$this->input->get('user_id');
                $account_list=$this->user_model->get_query("select * from publisher_adaccount where publisher_id=" . $user_id . " and status=1");
                foreach ($account_list as $key=>$value) {
                    $account[$value['market_account_id']]=['name'=>$value['account_name'], 'id'=>$value['account_id']];
                }
                $response=['success'=>true, 'msg'=>"success", 'data'=>$account];
            }
        } else {
            $response=['success'=>false, 'msg'=>$this->lang->line('notice_params_empty')];
        }
        $this->output->set_content_type('applicaion/json')->set_output(json_encode($response));
    }

    public function offer_list()
    {
        if ($this->input->is_ajax_request()) {
            if (!$this->input->get('user_id')) {
                $response=['success'=>false, 'msg'=>$this->lang->line('notice_params_empty')];
            } else {
                $offer=[];

                $user_id=$this->input->get('user_id');
                $offer_list=$this->offer_model->get_query("select * from offer where user_id=" . $user_id);
                foreach ($offer_list as $key=>$value) {
                    $countries=json_decode($value['countries'], true);
                    list($history, $schedule, $current)=$this->offer_model->get_payout($value['offer_id']);
                    if ($current && $current['cpa'] > 0) {
                        $offer[$value['offer_id']]=$value['product_name'] . "-" . implode(",", $countries) . "-$" . $current['cpa'];
                    }

                }
                $response=['success'=>true, 'msg'=>"success", 'data'=>$offer];
            }
        } else {
            $response=['success'=>false, 'msg'=>$this->lang->line('notice_params_empty')];
        }
        $this->output->set_content_type('applicaion/json')->set_output(json_encode($response));
    }

    /**
     * 设置账号对应的publisher
     * @param  string $value [description]
     * @return [type]        [description]
     */
    public function offer($value='')
    {

        $this->data['publisher_list']=$this->user_model->get_query("select * from user where type=2");
        $this->data['advertiser_list']=$this->user_model->get_query("select * from user where type=1");
        $this->data['account_list']=$this->user_model->get_query("select * from adaccount");

        $template='setup_offer';
        $this->template->build($template, $this->data);
    }


    /**
     * 为publisher指定申请offer
     * @param string $value [description]
     */
    public function add_publisher_offer_action($value='')
    {
        if (IS_POST) {
            $accounts=$this->input->post('select_accounts');
            $advertiser_id=$this->input->post('select_advertiser');
            $offers=$this->input->post('select_offers');

            if (!$accounts) {
                $this->error($this->lang->line('notice_bad_request'));
            }

            $account_list=[];
            $publisher_list=[];
            foreach ($accounts as $account_id) {
                $info=$this->publisher_adaccount_model->get_by_fields(['market_account_id'=>$account_id]);
                if ($info) {
                    $publisher_list[$info['publisher_id']]=$info['publisher_name'];

                    $account_list[$info['publisher_id']][]=$account_id;
                }

            }


            if (!$offers) {
                $sql='select * from offer where user_id=' . $advertiser_id;
                $offer_list=$this->offer_model->get_query($sql);
                foreach ($offer_list as $item) {
                    $offers[]=$item['offer_id'];
                }
            }

            if ($offers) {
                foreach ($offers as $offer_id) {
                    foreach ($publisher_list as $publisher_id=>$publisher_name) {
                        if (isset($account_list[$publisher_id])) {
                            $this->offer_model->apply_offer($offer_id, $account_list[$publisher_id], $publisher_id, $publisher_name, 1);
                        }
                    }

                }
            }
            $this->success($this->lang->line('success_done'), 'setup/offer');
        } else {
            $this->error($this->lang->line('notice_bad_request'));
        }
    }

    /**
     * 上传文件，批量申请offer
     */
    public function add_batch_publisher_offer_action()
    {
        if ($this->input->is_ajax_request()) {

            if (!$_FILES) {
                $response=['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
            } else {
                $file=upload_aws();

                if (!$file['error']) {

                    $this->load->library('aws_sqs');
                    $this->load->library('aws');
                    $this->load->library('excelreader');
                    $filename=$this->aws->getPath(config_item('Marketmax_Generalfile'), $file['message']);
                    $data=$this->excelreader->getExcelInfo($filename);
                    if ($data && $data['result']) {
                        $date_data=[];
                        foreach ($data['result'] as $key=>$row) {
                            if ($key == 0) {
                                continue;
                            }
                            $account_id=trim($row[0]);
                            $product_id=trim($row[1]);
                            $accounts=$offers=[];
                            if (trim($row[2])) {
                                $offers[]=trim($row[2]);
                            }

                            $info=$this->publisher_adaccount_model->get_by_fields(['account_id'=>$account_id]);
                            if (!$info) {
                                continue;
                            }
                            if (!$offers) {
                                $sql='select * from offer where product_id=' . $product_id;
                                $offer_list=$this->offer_model->get_query($sql);
                                foreach ($offer_list as $item) {
                                    $offers[]=$item['offer_id'];
                                }
                            }
                            $accounts[]=$info['market_account_id'];


                            if ($offers) {
                                foreach ($offers as $offer_id) {
                                    $this->offer_model->apply_offer($offer_id, $accounts, $info['publisher_id'], $info['publisher_name'], 1);
                                }
                            }
                        }
                    }

                    $response=['success'=>true, 'msg'=>$this->lang->line('success_done'), 'data'=>$file['message']];
                } else {
                    log_message("debug", "queue_upload_retention: Push Filename Failed");
                    $response=['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
                }
            }

        } else {
            $response=['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
        }
        $this->output->set_content_type('applicaion/json')->set_output(json_encode($response));
    }


    /**
     * 添加系统管理员
     * @return [type] [description]
     */
    public function manager()
    {
        $this->load->model('manager_model');
        $data=$this->manager_model->get_all(['status'=>1]);

        foreach ($data as $key=>& $value) {
            $value['role']=json_decode($value['role'], true);
        }

        $this->data['data']=$data;

        $template='setup_manager';
        $this->template->build($template, $this->data);
    }


    public function manager_info()
    {
        $this->load->model('manager_model');
        if ($this->input->is_ajax_request()) {
            if (!$this->input->get('manager_id')) {
                $response=['success'=>false, 'msg'=>$this->lang->line('notice_params_empty')];
            } else {
                $offer=[];

                $manager_id=$this->input->get('manager_id');
                $manager_info=$this->manager_model->get_by_id($manager_id);
                if (!$manager_info) {
                    $response=['success'=>false, 'msg'=>$this->lang->line('notice_params_empty')];
                } else {
                    $manager_info['role']=json_decode($manager_info['role'], true);
                    unset($manager_info['password']);
                    $response=['success'=>true, 'msg'=>"success", 'data'=>$manager_info];
                }
            }
        } else {
            $response=['success'=>false, 'msg'=>$this->lang->line('notice_params_empty')];
        }
        $this->output->set_content_type('applicaion/json')->set_output(json_encode($response));
    }


    /**
     * 添加管理员数据提交
     * @param string $value [description]
     */
    public function add_manager_action()
    {
        $this->load->model('manager_model');
        if (IS_POST) {
            if (!$this->input->post('select_role')) {
                $this->error($this->lang->line('notice_bad_request'), 'setup/manager');
            }
            $role=$this->input->post('select_role');
            $name=trim($this->input->post('input_first_name'));
            $email=trim($this->input->post('input_email'));

            $vars['user_name']=$name;
            $vars['email']=$email;
            $vars['role']=json_encode($role);
            if ($this->input->post('manager')) {
                $info=$this->manager_model->get_by_fields(['email'=>$email]);
                if ($info && $info['manager_id'] != $this->input->post('manager')) {
                    $this->error("注册邮箱已经存在！！！", 'setup/manager');
                }
                $this->manager_model->update_row_by_id($this->input->post('manager'), $vars);
            } else {
                $info=$this->manager_model->get_by_fields(['email'=>$email]);
                if ($info) {
                    $this->error("注册邮箱已经存在！！！", 'setup/manager');
                }
                $vars['password']=password_hash('123456', PASSWORD_DEFAULT);
                $this->manager_model->add_one($vars);
            }
            $this->success($this->lang->line('success_done'), 'setup/manager');
        } else {
            $this->error($this->lang->line('notice_bad_request'), 'setup/manager');
        }
    }

    /**
     * 删除bucket
     * @return [type] [description]
     */
    public function del_manager_action()
    {
        $this->load->model('manager_model');
        if ($this->input->is_ajax_request()) {
            if ($this->input->post('manager_id')) {
                $manager_id=$this->input->post('manager_id');
                $this->manager_model->update_row_by_id($manager_id, ['status'=>-1]);
                $response=['success'=>true, 'msg'=>$this->lang->line('success_delete')];
            } else {
                $response=['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
            }
        } else {
            $response=['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
        }
        $this->output->set_content_type('applicaion/json')->set_output(json_encode($response));

    }


    /**
     * 产品列表
     * @return [type] [description]
     */
    public function product()
    {
        $this->load->model('product_model');

        $this->data['product_list']=$this->product_model->get_all(['status >='=>0]);

        $template='setup_product';
        $this->template->build($template, $this->data);
    }


    /**
     * 修改密码
     * @param  string $value [description]
     * @return [type]        [description]
     */
    public function password()
    {
        $template='setup_password';
        $this->template->build($template, $this->data);
    }

    public function edit_password_action()
    {
        $this->load->model('user_model');
        $this->load->model('manager_model');
        if (IS_POST) {
            $current=trim($this->input->post('current_password'));
            $new=trim($this->input->post('new_password'));
            $re_new=trim($this->input->post('re_new_password'));

            if ($new != $re_new) {
                $this->error("Re-type password is wrong.", 'setup/password');
                die();
            }


            if ($this->userinfo['type'] == 0) {
                $user_info=$this->manager_model->get_by_id($this->userinfo['user_id']);
                if (!password_verify($current, $user_info['password'])) {
                    $this->error("Current password is wrong.", 'setup/password');
                    die();
                }

                $this->manager_model->update_row_by_id($this->userinfo['user_id'], ['password'=>password_hash($new, PASSWORD_DEFAULT)]);

                delete_cookie('P_INFO');
                $this->clean_login();

                redirect('sign/manager_in');
            } else {
                $user_info=$this->user_model->get_by_id($this->userinfo['user_id']);
                if (!password_verify($current, $user_info['password'])) {
                    $this->error("Current password is wrong.", 'setup/password');
                    die();
                }

                $this->user_model->update_row_by_id($user_info['user_id'], ['password'=>password_hash($new, PASSWORD_DEFAULT)]);

                delete_cookie('P_INFO');
                $this->clean_login();

                redirect('sign/in');
            }
        } else {
            $this->error($this->lang->line('notice_bad_request'), 'setup/password');
        }
    }

    /**
     * agency
     */
    public function agency()
    {
        $this->config->load('product', TRUE);
        $this->data['config_product']=$this->config->item('product');

        $this->load->model('offer_model');
        $this->load->model('publisher_adaccount_model');
        $data=$this->user_model->get_query("select * from user where type=2 and publisher_type=2");

        foreach ($data as $key=>& $value) {
            $account=[];
            $account_list=$this->publisher_adaccount_model->get_query("select * from publisher_adaccount where publisher_id=" . $value['user_id']);
            foreach ($account_list as $item) {
                $account[]=$item['account_id'];
            }

            if ($account) {
                $advertiser_sql="select advertiser_id,advertiser_name from publisher_offer where account_id in (" . implode(',', $account) . ") group by advertiser_id";
                $value['advertiser']=$this->offer_model->get_query($advertiser_sql);

                $product_sql="select product_id,product_name from publisher_offer where account_id in (" . implode(',', $account) . ") group by product_id";
                $value['product']=$this->offer_model->get_query($product_sql);

                $account_sql="select account_id,account_name from publisher_adaccount where publisher_id=" . $value['user_id'];
                $value['account']=$this->offer_model->get_query($account_sql);
            } else {
                $value['advertiser']=$value['product']=$value['account']=[];
            }

        }

        $this->data['account']=$this->user_model->get_query("select * from adaccount");

        $this->data['data']=$data;
        $template='setup_agency';
        $this->template->build($template, $this->data);
    }


    public function add_agency_action()
    {
        $this->load->model('agency_model');
        if (IS_POST) {
            if (!$this->input->post('input_name')) {
                $this->error($this->lang->line('notice_params_empty'));
            }

            $vars['user_name']=$vars['first_name']=$this->input->post('input_name');

            $vars['email']=$this->input->post('input_email');
            $vars['country']=$this->input->post('select_country');
            $vars['company']='';
            $vars['publisher_type']=2;

            $vars=$this->validation->checkInput($vars);
            $vars['agency_chart']=json_encode($this->input->post('chart'));

            $info=$this->user_model->get_by_fields(['email'=>$vars['email']]);
            if ($info) {
                $this->error($this->lang->line('notice_bad_request'), $url);
            }

            $vars['password']=password_hash('123456', PASSWORD_DEFAULT);

            $vars['type']=2;

            $this->user_model->add_one($vars);

            $this->success($this->lang->line('success_done'), 'setup/agency');
        } else {
            $this->error($this->lang->line('notice_bad_request'));
        }
    }

    public function add_agency_account_action()
    {
        $this->load->model('publisher_adaccount_model');
        $this->load->model('adaccount_model');
        if (IS_POST) {
            $select_account=$this->input->post('select_account');
            $vars['publisher_id']=$this->input->post('agency_id');
            $vars['publisher_name']=$this->input->post('agency_name');
            $vars['publisher_type']=2;
            $account_list=$this->adaccount_model->get_query("select * from adaccount where account_id in (" . implode(',', $select_account) . ")");
            foreach ($account_list as $item) {
                $vars['market_account_id']=$item['market_account_id'];
                $vars['account_id']=$item['account_id'];
                $vars['account_name']=$item['name'];


                $is_exists=$this->publisher_adaccount_model->get_by_fields(['account_id'=>$item['account_id'], 'publisher_id'=>$vars['publisher_id'], 'publisher_type'=>2]);
                if (!$is_exists) {
                    $this->publisher_adaccount_model->add_one($vars);
                } else {
                    $this->publisher_adaccount_model->update_row_by_id($is_exists['relation_id'], $vars);
                }
            }
            $this->success($this->lang->line('success_done'), 'setup/agency');
        } else {
            $this->error($this->lang->line('notice_bad_request'));
        }
    }


    public function get_agency_account_action()
    {
        if ($this->input->is_ajax_request()) {
            if ($this->input->get('agency')) {
                $this->load->model('publisher_adaccount_model');
                $data=$this->publisher_adaccount_model->get_query("select * from publisher_adaccount where publisher_type=2 and publisher_id=" . $this->input->get('agency'));
                $response=['success'=>true, 'msg'=>"success", 'data'=>$data];
            } else {
                $this->output->set_status_header('403');
                $response=['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
            }
        } else {
            $this->output->set_status_header('403');
            $response=['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
        }
        $this->output->set_content_type('applicaion/json')->set_output(json_encode($response));

    }

    public function get_agency_advertiser_action($value='')
    {
        if ($this->input->is_ajax_request()) {
            if ($this->input->get('agency')) {
                $this->load->model('publisher_adaccount_model');
                $data=$this->publisher_adaccount_model->get_query("select * from publisher_adaccount where publisher_type=2 and publisher_id=" . $this->input->get('agency'));

                $account=[];
                foreach ($data as $item) {
                    $account[]=$item['account_id'];
                }
                $advertiser_sql="select advertiser_id,advertiser_name from publisher_offer where account_id in (" . implode(',', $account) . ") group by advertiser_id";
                $advertiser=$this->offer_model->get_query($advertiser_sql);

                $response=['success'=>true, 'msg'=>"success", 'data'=>$advertiser];
            } else {
                $this->output->set_status_header('403');
                $response=['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
            }
        } else {
            $this->output->set_status_header('403');
            $response=['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
        }
        $this->output->set_content_type('applicaion/json')->set_output(json_encode($response));

    }
}