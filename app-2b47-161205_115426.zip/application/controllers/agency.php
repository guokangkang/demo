<?php if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

/**
 *
 * Created by PhpStorm.
 * User: palmax
 * Date: 2016/4/26
 * Time: 15:10
 */
class Agency extends Web_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('product_model');
        $this->load->model('reports_model');
        $this->load->model('agency_model');
        $this->load->model('ad_model');
        $this->load->model('user_model');
        $this->load->model('offer_model');

        $this->data['top_menu']=$this->load->view('web/top_menu_agency', '', TRUE);
    }


    public function listview()
    {
        $advertiser_id=$this->userinfo['user_id'];
        $agency_sql="select marketmax_publisher_adaccount.publisher_id,marketmax_publisher_adaccount.publisher_name from marketmax_reports RIGHT JOIN marketmax_publisher_adaccount ON marketmax_publisher_adaccount.account_id = marketmax_reports.account_id where advertiser_id=" . $advertiser_id . " and marketmax_publisher_adaccount.publisher_type=2 group by marketmax_publisher_adaccount.publisher_id,marketmax_publisher_adaccount.publisher_name";

        //$agency_list = $this->user_model->get_all(['publisher_type'=>2]);
        $agency_list=$this->reports_model->get_report_data($agency_sql);

        if ($agency_list) {

            foreach ($agency_list as & $item) {

                $agency_info=$this->user_model->get_by_id($item['publisher_id']);

                $item['letters']=get_first_letters($item['publisher_name'], 2);
                $sql="select product_id from marketmax_reports RIGHT JOIN marketmax_publisher_adaccount ON marketmax_publisher_adaccount.account_id = marketmax_reports.account_id where marketmax_publisher_adaccount.publisher_id=" . $item['publisher_id'] . " group by product_id";
                $item['product']=count($this->reports_model->get_report_data($sql));

                $sql="select account_id from marketmax_publisher_adaccount where publisher_id=" . $item['publisher_id'];
                $account_id=$this->reports_model->get_report_data($sql);
                $item['account_id']=count($account_id);
                $accounts=[];
                foreach ($account_id as $value) {
                    $accounts[]=$value['account_id'];
                }

                $sql="select sum(results) as results, sum(shares) as shares from marketmax_reports RIGHT JOIN marketmax_publisher_adaccount ON marketmax_publisher_adaccount.account_id = marketmax_reports.account_id where marketmax_publisher_adaccount.publisher_id=" . $item['publisher_id'];
                $insights=$this->reports_model->get_report_data($sql);
                $item['results']=$item['shares']=0;
                if ($insights) {
                    $item['results']=$insights[0]['results'];
                    $item['shares']=$insights[0]['shares'];
                }

                $item['illegal']=0;
                $item['illegal_rate']=0;
                $illegal_rate=0.00;
                if ($accounts) {
                    $illegal=$this->ad_model->get_query("select count(*) as count from ad where verify=3 and account_id in (" . implode(',', $accounts) . ")");
                    $item['illegal']=$illegal?$illegal[0]['count']:0;
                    $ad_count=$this->ad_model->get_query("select count(*) as count from ad where account_id in (" . implode(',', $accounts) . ")");
                    $illegal_rate=0;
                    if ($ad_count && $ad_count[0]['count'] > 0) {
                        $item['illegal_rate']=sprintf("%.2f", ($item['illegal'] / $ad_count[0]['count'] * 100));
                    }
                }

                $item['chart']=json_decode($agency_info['agency_chart'], true);
                $item['addtime']=$agency_info['addtime'];
            }
        }

        $this->data['agency_list']=$agency_list;

        $template='agency_listview';
        $this->template->build($template, $this->data);
    }

    public function task()
    {
        $advertiser_id=$this->userinfo['user_id'];


        $offer_sql="SELECT offer_country_log.country
                                            FROM offer 
                                            LEFT JOIN offer_country_log ON offer.offer_id = offer_country_log.offer_id
                                            where user_id=" . $advertiser_id;
        $offer_country_log=$this->product_model->get_query($offer_sql);

        $country=$country_list=[];
        foreach ($offer_country_log as $item) {
            $tmp=json_decode($item['country'], true);
            if (is_array($tmp)) {
                foreach ($tmp as $v) {
                    if (!in_array("'" . $v . "'", $country)) {
                        $country[]="'" . $v . "'";
                        $country_list[]=$v;
                    }
                }
            }
        }


        $this->config->load('product', TRUE);
        $this->data['config_product']=$this->config->item('product');
        $this->data['country_list']=$country_list;

        $this->data['product_list']=$this->product_model->get_all(['user_id'=>$advertiser_id]);


        $agency_sql="select marketmax_publisher_adaccount.publisher_id,marketmax_publisher_adaccount.publisher_name from marketmax_reports RIGHT JOIN marketmax_publisher_adaccount ON marketmax_publisher_adaccount.account_id = marketmax_reports.account_id where advertiser_id=" . $advertiser_id . " and marketmax_publisher_adaccount.publisher_type=2 group by marketmax_publisher_adaccount.publisher_id,marketmax_publisher_adaccount.publisher_name";
        $this->data['agency_list']=$this->reports_model->get_report_data($agency_sql);

        $where="advertiser_id=" . $advertiser_id . " and marketmax_publisher_adaccount.publisher_type=2 and country in (" . implode(',', $country) . ")";

        $agency_params=$country_params=$product_params=[];
        if ($this->input->get("agency")) {
            $agency_params=explode(',', $this->input->get("agency"));
            $where.=" and marketmax_publisher_adaccount.publisher_id in (" . $this->input->get("agency") . ")";
        }
        if ($this->input->get("country")) {
            $country_params=explode(',', $this->input->get("country"));
            $where.=" and country in (" . $this->input->get("country") . ")";
        }
        if ($this->input->get("product")) {
            $product_params=explode(',', $this->input->get("product"));
            $where.=" and product_id in (" . $this->input->get("product") . ")";
        }


        // if ($this->input->get("start")) {
        //     $where .= " and date >= ".strtotime($this->input->get("start"));
        // }
        // if ($this->input->get("end")) {
        //     $where .= " and date <= ".strtotime($this->input->get("end"));
        // }

        $agency_sql="select marketmax_publisher_adaccount.publisher_id,marketmax_publisher_adaccount.publisher_name,country,offer_id,marketmax_reports.product_id from marketmax_reports RIGHT JOIN marketmax_publisher_adaccount ON marketmax_publisher_adaccount.account_id = marketmax_reports.account_id where $where group by marketmax_publisher_adaccount.publisher_id,marketmax_publisher_adaccount.publisher_name,country,offer_id,marketmax_reports.product_id";
        $agency_list=$this->reports_model->get_report_data($agency_sql);

        $agency_infos=[];
        $results=[];
        foreach ($agency_list as $key=>$value) {
            $agency_infos[$value['publisher_name']]=$value['publisher_name'];

            $value['rate']='-';
            if ($value['offer_id']) {
                $offer_id=$value['offer_id'];
                list($rpa, $start)=$this->offer_model->get_current_rpa_log(['offer_id'=>$offer_id]);
                $payout=$this->offer_model->get_current_cpa_log($offer_id);
                $value['rate']=$payout['value']?$payout['value'] . "%":'';
                $value['category']=$payout['category'];
            }
            $value['rpa']=$rpa;
            $results[$value['product_id']][$value['country']][$value['publisher_name']]=$value;
        }


        $this->data['agency']=$agency_infos;
        $this->data['results']=$results;
        $this->data['agency_params']=$agency_params;
        $this->data['country_params']=$country_params;
        $this->data['product_params']=$product_params;

        $this->config->load('country', TRUE);
        $this->data['config_country']=$this->config->item('country');


        $template='agency_task';
        $this->template->build($template, $this->data);
    }


    public function publisher()
    {
        $advertiser_id=$this->userinfo['user_id'];
        $publisher_sql="select marketmax_publisher_adaccount.publisher_id,marketmax_publisher_adaccount.publisher_name,count(marketmax_reports.product_id) as product_id from marketmax_reports RIGHT JOIN marketmax_publisher_adaccount ON marketmax_publisher_adaccount.account_id = marketmax_reports.account_id where advertiser_id=" . $advertiser_id . " and marketmax_publisher_adaccount.publisher_type=1 group by marketmax_publisher_adaccount.publisher_id,marketmax_publisher_adaccount.publisher_name";
        $publisher_list=$this->reports_model->get_report_data($publisher_sql);

        foreach ($publisher_list as & $item) {
            $item['letters']=get_first_letters($item['publisher_name'], 2);
            $sql="select product_id from marketmax_reports RIGHT JOIN marketmax_publisher_adaccount ON marketmax_publisher_adaccount.account_id = marketmax_reports.account_id where marketmax_publisher_adaccount.publisher_id=" . $item['publisher_id'] . " group by product_id";
            $item['product']=count($this->reports_model->get_report_data($sql));

            $sql="select marketmax_reports.account_id from marketmax_reports RIGHT JOIN marketmax_publisher_adaccount ON marketmax_publisher_adaccount.account_id = marketmax_reports.account_id where marketmax_publisher_adaccount.publisher_id=" . $item['publisher_id'] . " group by marketmax_reports.account_id";
            $account_id=$this->reports_model->get_report_data($sql);
            $item['account_id']=count($account_id);
            $accounts=[];
            foreach ($account_id as $value) {
                $value['account_id'] && $accounts[]=$value['account_id'];
            }

            $sql="select sum(results) as results, sum(shares) as shares from marketmax_reports RIGHT JOIN marketmax_publisher_adaccount ON marketmax_publisher_adaccount.account_id = marketmax_reports.account_id where marketmax_publisher_adaccount.publisher_id=" . $item['publisher_id'];
            $insights=$this->reports_model->get_report_data($sql);
            $item['results']=$item['shares']=0;
            if ($insights) {
                $item['results']=$insights[0]['results'];
                $item['shares']=$insights[0]['shares'];
            }

            $item['illegal']=0;
            $illegal_rate=0;
            if ($accounts) {
                $illegal=$this->ad_model->get_query("select count(*) as count from ad where verify=3 and account_id in (" . implode(',', $accounts) . ")");
                $item['illegal']=$illegal?$illegal[0]['count']:0;
                $ad_count=$this->ad_model->get_query("select count(*) as count from ad where account_id in (" . implode(',', $accounts) . ")");
                $item['illegal_rate']=0;
                if ($ad_count && $ad_count[0]['count'] > 0) {
                    $item['illegal_rate']=sprintf("%.2f", ($item['illegal'] / $ad_count[0]['count'] * 100));
                }
            }

        }

        $this->data['publisher_list']=$publisher_list;

        $template='agency_publisher';
        $this->template->build($template, $this->data);
    }

    public function index()
    {
        $this->load->library('agency_service');
        $user_id=$this->userinfo['user_id'];

        if ($this->userinfo['type']==0) {
            list($agency_list,$chart)=$this->agency_service->get_agency_admin($user_id);
            $publisher_list=$this->agency_service->get_publisher_admin($user_id);
            $this->data['publisher_list']=$publisher_list;
            $this->data['agency_list']=$agency_list;
            $this->data['chart']=$chart;
        }else{
            list($agency_list,$chart)=$this->agency_service->get_agency($user_id);
            $publisher_list=$this->agency_service->get_publisher($user_id);
            $this->data['publisher_list']=$publisher_list;
            $this->data['agency_list']=$agency_list;
            $this->data['chart']=$chart;
        }
        
        $template='agency_index';
        $this->template->build($template, $this->data);
    }
}