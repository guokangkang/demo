<?php if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

/**
 * 
 * Created by PhpStorm.
 * User: palmax
 * Date: 2016/4/26
 * Time: 15:10
 */
class Offer extends Web_Controller
{
    public function __construct() {
        parent::__construct();
        $this->load->model('offer_model');
        $this->load->model('publisher_offer_model');
        $this->load->model('product_model');

        $this->load->library('pagination');

        $this->data['top_menu'] = $this->load->view('web/top_menu_product', '', TRUE);
    }

    /**
     * 获取用户申请过的offer
     * @param string $value [description]
     */
    private function get_my_offer()
    {

        $publisher_offer_sql = "select * from publisher_offer where publisher_id=".$this->userinfo['user_id'];

        $offer_list = $this->publisher_offer_model->get_query($publisher_offer_sql);

        $offer_ids = [];
        foreach ($offer_list as $key => $value) {
            $offer_ids[$value['offer_id']] = $value['status'];
        }
        return $offer_ids;
    }


    /**
     * 我得offer
     * @return [type] [description]
     */
    public function my()
    {
        $this->config->load('country',TRUE);
        $this->data['country_list'] = $country_list = $this->config->item('country');

        $offer_where = "1=1";
        $country = $product = [];
        if ($this->input->get('product')) {
            $product = explode(',', $this->input->get('product'));
            $offer_where .= " and offer.product_id in (".$this->input->get('product').")";
        }
        if ($this->input->get('country')) {
            $country = explode(',', $this->input->get('country'));
            $offer_where .= " and offer.countries like '%".$this->input->get('country')."%'";
        }
        if ($this->input->get('approved')) {
            $offer_where .= " and publisher_offer.status=1";
        }

        $sql = "SELECT publisher_offer.status as apply_status,offer.*
                    FROM publisher_offer LEFT JOIN offer ON publisher_offer.offer_id = offer.offer_id
                    WHERE publisher_id=".$this->userinfo['user_id']." and ".$offer_where."
                    GROUP BY publisher_offer.offer_id
                    ORDER BY publisher_offer.addtime desc
                    ";

        $this->data['product_params'] = $product;
        $this->data['country_params'] = $country;
        //获取offer
        $listview = $this->offer_model->get_query($sql);

        foreach ($listview as $key => & $value) {
            //获取cpa
            list($history, $schedule, $current) = $this->offer_model->get_payout($value['offer_id']);
            
            $value['specific_payout'] = $this->offer_model->get_current_specific_payout($value['offer_id'], $this->userinfo['user_id']);

            $value['history'] = $history;
            $value['schedule'] = $schedule;
            $value['current'] = $current;

            $value['country_size'] = 0;
            $value['country_info'] = [];
            if ($value['countries']) {
                $value['countries'] = $country = json_decode($value['countries'], true);
                $value['country_size'] = count($country);

                foreach ($value['countries'] as $c) {
                    $value['country_info'][$c] = isset($country_list['country'][$c])?$country_list['country'][$c]:"Unknow";
                }
            }
            $value['start_time'] = date('m/d/Y h:i A', $value['start_time']);
            $value['end_time'] && $value['end_time'] = date('m/d/Y h:i A', $value['end_time']);
            
        }
        $this->data['listview'] = $listview;


        $this->data['apply_status'] = [-10=>'Need Apply', -1=>'Disapproved', 0=>'Applied', 1=>'Approved'];


        $this->data['product_list'] = $this->product_model->get_query("select * from product where status=1");

        $this->config->load('product',TRUE);
        $this->data['config_product'] = $this->config->item('product');
        
        $template = 'offer_my';
        $this->template->build($template,$this->data);
    }

    /**
     * offer 列表
     * @return [type] [description]
     */
    public function listview()
    {
        $this->config->load('country',TRUE);
        $this->data['country_list'] = $country_list = $this->config->item('country');

        $offer_where = "1=1";
        $country = $product = [];
        if ($this->input->get('product')) {
            $product = explode(',', $this->input->get('product'));
            $offer_where .= " and offer.product_id in (".$this->input->get('product').")";
        }
        if ($this->input->get('country')) {
            $country = explode(',', $this->input->get('country'));
            $offer_where .= " and offer.countries like '%".$this->input->get('country')."%'";
        }

        $sql = "SELECT publisher_offer.status as apply_status,offer.*
                    FROM publisher_offer LEFT JOIN offer ON publisher_offer.offer_id = offer.offer_id
                    WHERE publisher_id=".$this->userinfo['user_id']." and ".$offer_where."
                    GROUP BY publisher_offer.offer_id
                    ";

        $this->data['product_params'] = $product;
        $this->data['country_params'] = $country;
        //获取offer
        $listview = $this->offer_model->get_query($sql);

        foreach ($listview as $key => & $value) {
            //获取cpa
            list($history, $schedule, $current) = $this->offer_model->get_payout($value['offer_id']);
            //获取rpa
            list($value['choose_type'], $value['countries'], $value['rpa'], $value['start_time']) = $this->offer_model->get_rpa_log($value);

            $value['history'] = $history;
            $value['schedule'] = $schedule;
            $value['current'] = $current;

            $value['country_size'] = 0;
            $value['country_info'] = [];
            if ($value['countries']) {
                $value['countries'] = $country = json_decode($value['countries'], true);
                $value['country_size'] = count($country);

                foreach ($value['countries'] as $c) {
                    $value['country_info'][$c] = isset($country_list['country'][$c])?$country_list['country'][$c]:"Unknow";
                }
            }
            $value['start_time'] = date('m/d/Y h:i A', $value['start_time']);
            $value['end_time'] && $value['end_time'] = date('m/d/Y h:i A', $value['end_time']);
            
            $value['specific_payout'] && $specific_payout[$value['offer_id']] = json_decode($value['specific_payout'], true);
            $value['specific_payout'] = json_decode($value['specific_payout'], true);

        }
        $this->data['listview'] = $listview;


        $this->data['apply_status'] = [-10=>'Need Apply', -1=>'Disapproved', 0=>'Applied', 1=>'Approved'];


        $this->data['product_list'] = $this->product_model->get_query("select * from product where status=1");

        //添加offer
        $this->data['product_detail_add_offer'] = $this->load->view('web/product_detail_add_offer', $this->data, TRUE);

        //添加payout
        $this->data['product_detail_add_offer_payout'] = $this->load->view('web/product_detail_add_offer_payout', $this->data, TRUE);
        
        $template = 'offer_listview';
        $this->template->build($template,$this->data);
    }


    /**
     * 批量授权offer
     * @param string $value [description]
     */
    public function applications()
    {
        $total_sql = "select count(*) as count from publisher_offer where status=0";
        $total_rows = $this->publisher_offer_model->get_one($total_sql);

        $config['base_url'] = site_url('offer/applications');
        $config = get_web_page($config, $total_rows['count'], 3);

        $page = 1;
        if ($this->input->get('page'))
            $page = $this->input->get('page');


        $limit = $config['per_page'] = 50;

        $this->pagination->initialize($config);
        $this->data['page_links'] = $this->pagination->create_links();

        $sql = "SELECT publisher_offer.*,offer.countries
                    FROM publisher_offer LEFT JOIN offer ON publisher_offer.offer_id = offer.offer_id
                    WHERE publisher_offer.status=0 ORDER BY publisher_offer.addtime desc
                LIMIT ".($page - 1) * $limit.", ".$limit;

        $publisher_offer_account = $this->publisher_offer_model->get_query($sql);

        $apply_applicaion = [];
        if ($publisher_offer_account) {
            foreach ($publisher_offer_account as $offer_item) {
                list($offer_item['choose_type'], $offer_item['countries'], $offer_item['rpa'], $offer_item['start_time']) = $this->offer_model->get_rpa_log($offer_item['offer_id']);

                $offer_item['countries'] = json_decode($offer_item['countries'], true);
                $offer_item['countries'] = implode(',', $offer_item['countries']);
                foreach ($offer_item as $k => $v) {
                    if ($k=='account_id') {
                        $apply_applicaion[$offer_item['offer_id'].'_'.$offer_item['publisher_id']][$k][] = $v;
                    }else{
                        $apply_applicaion[$offer_item['offer_id'].'_'.$offer_item['publisher_id']][$k] = $v;
                    }
                }
            }
        }

        $this->data['apply_applicaion'] = $apply_applicaion;

        $template = 'offer_applications';
        $this->template->build($template,$this->data);
    }


    /**
     * 批量授权offer
     * @param string $value [description]
     */
    public function accounts()
    {

        $total_sql = "select count(*) as count from publisher_offer where status=1";
        $total_rows = $this->publisher_offer_model->get_one($total_sql);

        $config['base_url'] = site_url('offer/accounts');
        $config = get_web_page($config, $total_rows['count'], 3);

        $page = 1;
        if ($this->input->get('page'))
            $page = $this->input->get('page');


        $limit = $config['per_page'] = 50;

        $this->pagination->initialize($config);
        $this->data['page_links'] = $this->pagination->create_links();

        $sql = "SELECT publisher_offer.*,offer.countries
                    FROM publisher_offer LEFT JOIN offer ON publisher_offer.offer_id = offer.offer_id
                    WHERE publisher_offer.status=1 ORDER BY publisher_offer.addtime desc
                LIMIT ".($page - 1) * $limit.", ".$limit;

        $publisher_offer_account = $this->publisher_offer_model->get_query($sql);

        $apply_applicaion = [];
        if ($publisher_offer_account) {
            foreach ($publisher_offer_account as $offer_item) {

                foreach ($offer_item as $k => $v) {
                    if ($k=='account_id') {
                        $apply_applicaion[$offer_item['offer_id'].'_'.$offer_item['publisher_id']][$k][] = $v;
                    }else{
                        $apply_applicaion[$offer_item['offer_id'].'_'.$offer_item['publisher_id']][$k] = $v;
                    }
                }
            }
        }

        $this->data['apply_applicaion'] = $apply_applicaion;



        $template = 'offer_accounts';
        $this->template->build($template,$this->data);
    }


    public function detail()
    {
        if (!$this->uri->segment(3)) {
            redirect('product/listview');
        }
        $offer_id = $this->uri->segment(3);

        $offer_info = $this->offer_model->get_by_id($offer_id);

        $this->data['offer_info'] = $offer_info;

        $template = 'offer_detail';
        $this->template->build($template,$this->data);
    }


}
