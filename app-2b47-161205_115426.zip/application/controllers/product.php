<?php if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

/**
 * Created by PhpStorm.
 * User: palmax
 * Date: 2016/4/26
 * Time: 15:10
 */
class Product extends Web_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('product_model');
        $this->load->model('user_model');
        $this->load->model('offer_model');
        $this->load->model('payout_model');
        $this->load->model('offer_country_log_model');
        $this->load->library('validation');
        $this->load->model('publisher_model');
        $this->load->model('specific_payout_model');
        $this->load->model('offer_cpa_log_model');
        $this->load->model('offer_rpa_log_model');
        $this->load->model('publisher_offer_model');

        if ($this->_method == 'find' || $this->_method == 'confirm') {
            $this->data['top_menu']=$this->load->view('web/top_menu_setup', '', TRUE);
        } else {
            $this->data['top_menu']=$this->load->view('web/top_menu_product', '', TRUE);
        }
    }

    /**
     * 产品列表
     * @return [type] [description]
     */
    public function listview()
    {
        $where=['status'=>1];
        $q=$this->input->get('q');
        if ($this->userinfo['type'] == 1) {
            $where['in']=['status'=>[0, 1]];
            $where['user_id']=$this->userinfo['user_id'];
        } elseif ($this->userinfo['type'] == 0) {
            $where['in']=['status'=>[0, 1]];
        }
        if ($q) {
            $where['like']=['name'=>$q];
        }
        $listview=$this->product_model->get_all($where);

        foreach ($listview as $key => & $item) {
            
            if (!$item['score']) {
                $item['score'] = 4.5;
            }
        }

        // foreach ($listview as &$item) {
        //     if ($item['category']=='android') {
        //         $item['score_info'] = json_decode($item['score_info'], true);
        //     }
        // }


        $this->data['lists']=$listview;
        $template='product_listview';
        $this->template->build($template, $this->data);
    }

    /**
     * 获取产品信息
     * @return [type] [description]
     */
    public function app_item()
    {
        if ($this->input->is_ajax_request()) {
            $this->load->model('product_model');
            if (!$this->input->get('item_id')) {
                $response=['success'=>false, 'msg'=>$this->lang->line('notice_params_empty')];
                $this->output->set_content_type('applicaion/json')->set_output(json_encode($response));
                die();
            }
            $item_id=$this->input->get('item_id');
            if (strpos($item_id, "google") !== false) {
                $category="android";
            } elseif (strpos($item_id, "itunes") !== false) {
                $category="ios";
            } else {
                $response=['success'=>false, 'msg'=>$this->lang->line('notice_not_find')];
                $this->output->set_content_type('applicaion/json')->set_output(json_encode($response));
                die();
            }

            if ($category == 'android') {
                //$url = "http://search.voga360.com/api/search.htm?q=".$item_id;
                //获取app信息
                if ($index=strpos($item_id, "=")) {
                    $app_id=$play_id=substr($item_id, $index + 1);
                    $this->load->library('playapi');
                    $data=$this->playapi->getPackage($play_id);
                } else {
                    $response=['success'=>false, 'msg'=>$this->lang->line('notice_not_find')];
                    $this->output->set_content_type('applicaion/json')->set_output(json_encode($response));
                    die();
                }

            } elseif ($category == 'ios') {
                //获取app信息
                $index=strpos($item_id, "/id");
                if ($index=strpos($item_id, "/id")) {
                    //$app_id = $itunes_id = substr($item_id, $index+3, 9);
                    if (strpos($item_id, '?') === false) {
                        $app_id=$itunes_id=substr($item_id, $index + 3);
                    } else {
                        $end=strpos($item_id, '?');
                        $app_id=$itunes_id=substr($item_id, $index + 3, $end - ($index + 3));
                    }
                    $url="http://itunes.apple.com/lookup?id=" . $itunes_id;
                    $this->load->library('curl');
                    $data=$this->curl->simple_get($url);
                    $data=json_decode($data, true);
                } else {
                    $response=['success'=>false, 'msg'=>$this->lang->line('notice_not_find')];
                    $this->output->set_content_type('applicaion/json')->set_output(json_encode($response));
                    die();
                }
            }

            $result=[];
            if ($data) {
                if ($category == 'android') {
                    $googleurl=$item_id;
                    $result=['name'=>$data['name'], 'desc'=>$data['description'], 'app_id'=>$app_id, 'object_store_url'=>$googleurl, 'logo'=>$data['image'], 'category'=>$category, 'play_category'=>$data['category'], 'score'=>$data['score'], 'score_info'=>$data['score_info']];
                } else {
                    $tmp=$data['results']?$data['results'][0]:[];
                    $tmp && $result=['name'=>$tmp['trackCensoredName'], 'desc'=>$tmp['description'], 'app_id'=>$tmp['trackId'], 'object_store_url'=>$tmp['trackViewUrl'], 'logo'=>$tmp['artworkUrl512'], 'category'=>$category, 'play_category'=>$tmp['wrapperType'], 'score'=>$tmp['averageUserRating'], 'score_info'=>$tmp['userRatingCount']];
                }
                if (!$result) {
                    $response=['success'=>false, 'msg'=>$this->lang->line('notice_not_find')];
                    $this->output->set_content_type('applicaion/json')->set_output(json_encode($response));
                    die();
                }

                $product=$this->product_model->get_by_fields(['category'=>$category, 'app_id'=>$result['app_id']]);

                // if ($product && $product['user_id']!=$this->userinfo['user_id']) {
                //     $response = ['success'=>false, 'msg'=>$this->lang->line('notice_product_exists')];
                //     $this->output->set_content_type('applicaion/json')->set_output(json_encode($response));
                //     die();
                // }

            } else {
                $response=['success'=>false, 'msg'=>$this->lang->line('notice_not_find')];
                $this->output->set_content_type('applicaion/json')->set_output(json_encode($response));
                die();
            }
            $response=['success'=>true, 'msg'=>"success", 'data'=>$result];
        } else {
            $this->output->set_status_header('403');
            $response=['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
        }
        $this->output->set_content_type('applicaion/json')->set_output(json_encode($response));


    }

    /**
     * 下一步
     */
    public function add_product_action()
    {
        if ($this->input->is_ajax_request()) {
            $user_id=$this->userinfo['user_id'];
            $vars['user_id']=$user_id;
            $vars['category']=$this->input->post('category', true);
            $vars['play_category']=$this->input->post('play_category', true);
            $vars['app_id']=$this->input->post('app_id', true);
            $vars['desc']=$this->input->post('desc', true);
            $vars['name']=$this->input->post('name', true);
            $vars['object_store_url']=$this->input->post('object_store_url', true);
            $vars['logo']=$this->input->post('logo', true);
            $vars['score']=$this->input->post('score', true);
            $vars['score_info']=$this->input->post('score_info', true);

            $product=$this->product_model->get_by_fields(['category'=>$vars['category'], 'app_id'=>$vars['app_id']]);
            if (!$product) {
                $vars['status']=0;
                $product_id=$this->product_model->add_one($vars);
            } else {
                $this->product_model->update_row_by_id($product['product_id'], $vars);
                $product_id=$product['product_id'];
            }
            $response=['success'=>true, 'msg'=>"success", 'url'=>site_url('product/confirm/' . $product_id)];

        } else {
            $this->output->set_status_header('403');
            $response=['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
        }
        $this->output->set_content_type('applicaion/json')->set_output(json_encode($response));
    }

    /**
     * 确认完成产品
     * @param  string $value [description]
     * @return [type]        [description]
     */
    public function confirm($value='')
    {
        if (!$this->uri->segment(3)) {
            redirect('setup/product');
            die();
        }
        $product_id=intval($this->uri->segment(3), 0);
        if (!isset($product_id)) {
            redirect('setup/product');
            die();
        }
        $product=$this->product_model->get_by_id($product_id);
        if (!$product) {
            redirect('setup/product');
            die();
        }
        $this->data['info']=$product;


        $sql="select * from user where type=1";
        $this->data['advertiserlist']=$this->user_model->get_query($sql);

        $template='product_confirm';
        $this->template->build($template, $this->data);
    }

    public function form_confirm_action($value='')
    {
        if (IS_POST) {
            if (!$this->input->post('product_id')) {
                $this->error($this->lang->line('notice_bad_request'));
            }
            $product_id=$this->input->post('product_id');
            $product_name=$this->input->post('input_product_name');
            $retention_days=$this->input->post('retention_days');

            if (!is_numeric($retention_days)) {
                $this->error($this->lang->line('notice_bad_request'));
            }

            $info=$this->product_model->get_by_id($product_id);
            if (!$info) {
                $this->error($this->lang->line('notice_bad_request'));
            }

            $advertiser_info=[];
            if ($this->input->post('select_advertiser')) {
                $advertiser_id=$this->input->post('select_advertiser');
                $advertiser_info=$this->user_model->get_by_id($advertiser_id);
                if (!$advertiser_info) {
                    $this->error($this->lang->line('notice_bad_request'));
                }
            }


            $desc=$this->input->post('input_desc');
            $this->load->library('validation');
            $desc=$this->validation->checkInput($desc);
            $name=$this->validation->checkInput($product_name);
            $retention_day=$this->validation->checkInput($retention_days);

            $vars=['description'=>$desc, 'status'=>1, 'name'=>$name, 'retention_day'=>$retention_day];

            if ($advertiser_info) {
                $vars['user_id']=$advertiser_id;
                $vars['user_name']=$advertiser_info['user_name'];
            }
            $this->product_model->update_row_by_id($product_id, $vars);

            $this->success($this->lang->line('success_done'), 'manage/offer?product=' . $this->input->post('product_id'));
        } else {
            $this->error($this->lang->line('notice_bad_request'));
        }
    }

    public function find()
    {
        $template='product_find';
        $this->template->build($template, $this->data);
    }

    /**
     * 添加country
     * @return [type] [description]
     */
    public function country()
    {

        if (!$this->uri->segment(3)) {
            redirect('product/listview');
            die();
        }
        $product_id=intval($this->uri->segment(3), 0);
        if (!isset($product_id)) {
            redirect('product/listview');
            die();
        }
        $product=$this->product_model->get_by_id($product_id);
        if (!$product) {
            redirect('product/listview');
            die();
        }
        $this->data['info']=$product;
        $offerinfo=[];
        if ($offer_id=intval($this->uri->segment(4), 0)) {
            $offerinfo=$this->offer_model->get_by_id($offer_id);
            if ($offerinfo) {
                $offerinfo['countries'] && $offerinfo['countries']=json_decode($offerinfo['countries'], true);
                $offerinfo['start_date']=date('m/d/Y', $offerinfo['start_time']);
                $offerinfo['start_time']=date('h:i A', $offerinfo['start_time']);
                $offerinfo['end_date']=$offerinfo['end_time']?date('m/d/Y', $offerinfo['end_time']):'';
                $offerinfo['end_time']=$offerinfo['end_time']?date('h:i A', $offerinfo['end_time']):'';
            }
        }
        $this->data['offerinfo']=$offerinfo;

        $offerlist=$this->offer_model->get_all(['product_id'=>$product_id]);

        $country=[];
        if ($offerlist) {
            foreach ($offerlist as $key=>$value) {
                $value['countries']=json_decode($value['countries'], true);
                $value['countries'] && $country=array_merge($value['countries'], $country);
            }
        }
        $this->data['countries']=$country;
        $this->config->load('product', TRUE);
        $this->data['config_product']=$this->config->item('product');

        $template='product_country';
        $this->template->build($template, $this->data);
    }


    /**
     * 添加offer国家关系日志
     * @param string $value [description]
     */
    private function add_offer_log($offer_info, $countries, $type, $choose_type, $start_time)
    {
        if (is_array($countries)) {
            foreach ($countries as $key=>$value) {
                $vars=['user_id'=>$offer_info['user_id'], 'offer_id'=>$offer_info['offer_id'], 'type'=>$type, 'country'=>$value, 'choose_type'=>$choose_type, 'start_time'=>$start_time];
                $this->offer_country_log_model->add_one($vars);
            }
        } else {
            $vars=['user_id'=>$offer_info['user_id'], 'offer_id'=>$offer_info['offer_id'], 'type'=>$type, 'country'=>$countries, 'choose_type'=>$choose_type, 'start_time'=>$start_time];
            $this->offer_country_log_model->add_one($vars);
        }

    }


    /**
     * 设置offer状体
     *
     */
    public function set_offer_status_action()
    {
        if ($this->input->is_ajax_request()) {
            $offer_id=$this->input->post('offer_id', true);
            $status=$this->input->post('val', true);
            if ($offer_id) {
                $where=array('offer_id'=>$offer_id);
                $res=$this->offer_model->update_row_by_fields($where, ['status'=>$status]);
                if ($res) {
                    $response=['success'=>true, 'msg'=>$this->lang->line('success_done')];
                } else {
                    $response=['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
                }
            } else {
                $response=['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
            }
        } else {
            $response=['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
        }
        $this->output->set_content_type('applicaion/json')->set_output(json_encode($response));
    }

    

    /**
     * 获取当期、过往、未来的留存率
     * @param  [type] $offer_id [description]
     * @return [type]           [description]
     */
    public function get_payout($offer_id)
    {
        $sql="select * from payout where offer_id=" . $offer_id . " and status=1 order by start_time desc";
        $list=$this->payout_model->get_query($sql);

        $history=$schedule=$current=[];
        foreach ($list as $key=>$value) {
            $value['value']=json_decode($value['value'], true);
            if ($value['value'] && is_array($value['value'])) {
                foreach ($value['value'] as $k=>&$v) {
                    $v['payout']=sprintf("%.2f", $v['payout_rate'] / 100 * $value['cpa']);
                }
            }
            if (!$current && $value['start_time'] < time()) {
                $current=$value;
                $schedule[]=$value;
                continue;
            }

            if ($value['start_time'] < time()) {
                $history[]=$value;
            }
            if ($value['start_time'] > time()) {
                $schedule[]=$value;
            }
        }
        return [$history, $schedule, $current];
    }


    /**·
     * 获取offer过往日志
     * @param  string $value [description]
     * @return [type]        [description]
     */
    public function get_rpa_log($offer_info)
    {
        $offer_id=$offer_info['offer_id'];
        $sql="select * from offer_rpa_log where offer_id=" . $offer_id . " and start_time<=" . time() . " order by start_time desc,log_id desc limit 1";

        $countries=[];
        $choose_type='';
        $rpa=0;
        $this->load->model('offer_rpa_log_model');
        $log=$this->offer_rpa_log_model->get_query($sql);

        if ($log) {
            $countries_data=json_decode($log[0]['country'], true);
            $countries=json_encode($countries_data['countries']);
            $choose_type=$countries_data['choose_type'];
            $rpa=$log[0]['rpa'];
            $start_time=$log[0]['start_time'];
        } else {
            $countries=$offer_info['countries'];
            $choose_type=$offer_info['choose_type'];
            $rpa=$offer_info['rpa'];
            $start_time=$offer_info['start_time'];
        }

        return [$choose_type, $countries, $rpa, $start_time];
    }


    /**
     * 产品详情
     * @return [type] [description]
     */
    public function detail2()
    {
        if (!$this->uri->segment(3)) {
            redirect('product/listview');
        }
        $this->config->load('country', TRUE);
        $country_list=$this->config->item('country');
        $product_id=$this->uri->segment(3);

        $product_info=$this->product_model->get_by_id($product_id);
        if (!$product_info) {
            redirect('product/listview');
        }
        $this->data['product_info']=$product_info;


        $offer_sql="select * from offer where product_id=" . $product_id;
        // if ($this->userinfo['type']==2) {
        //     $offer_sql .= " and status=1";
        // }else{
        //     $offer_sql .= " and status>=0";
        // }
        //$offer_sql .= " and start_time<".time()." and end_time>".time();

        $offer_sql.=" order by addtime desc";
        //获取offer
        $listview=$this->offer_model->get_query($offer_sql);
        $data=[];
        foreach ($listview as $key=>$value) {

            list($history, $schedule, $current)=$this->offer_model->get_payout($value['offer_id']);

            if (!$current) {
                continue; //没有设置cpa价格
            }

            $value['specific_payout']=$this->offer_model->get_current_specific_payout($value['offer_id'], $this->userinfo['user_id']);
            $value['status']=$this->offer_model->get_offer_current_status($value['offer_id']);
            $value['next_status']=$this->offer_model->get_offer_next_status($value['offer_id']);

            if ($value['status'] == -1) {
                continue; //处于删除状态
            }

            $value['history']=$history;
            $value['schedule']=$schedule;
            $value['current']=$current;

            $value['country_size']=0;
            $value['country_info']=[];
            list($value['choose_type'], $value['countries'])=$this->offer_model->get_current_country_log($value);
            if ($value['countries']) {
                $value['country_size']=count($value['countries']);

                foreach ($value['countries'] as $c) {
                    $value['country_info'][$c]=isset($country_list['country'][$c])?$country_list['country'][$c]:"Unknow";
                }
            }
            $value['start_time']=date('m/d/Y h:i A', $value['start_time']);
            $value['end_time'] && $value['end_time']=date('m/d/Y h:i A', $value['end_time']);

            $data[]=$value;
        }

        $this->data['listview']=$data;

        $this->config->load('product', TRUE);
        $this->data['config_product']=$this->config->item('product');


        //获取申请的offer

        $publisher_offer_sql_where="product_id=" . $product_id;
        if ($this->userinfo['type'] == 2) {
            $publisher_offer_sql_where.=" and publisher_id=" . $this->userinfo['user_id'];
        }
        $publisher_offer_sql="select * from publisher_offer where " . $publisher_offer_sql_where;

        $publisher_offer_account=$this->publisher_offer_model->get_query($publisher_offer_sql);

        //申请过的offer
        //申请过的账号
        $apply_applicaion=$apply_publisher_offer=$apply_publisher_account=$publisher_offer_account2=[];

        if ($publisher_offer_account) {
            foreach ($publisher_offer_account as $offer_item) {
                $apply_publisher_offer[$offer_item['offer_id']]=$offer_item['offer_id'];


                if ($offer_item['advertiser_id'] != $product_info['user_id'])
                    $apply_publisher_account[]=$offer_item['account_id'];

                $publisher_offer_account2[$offer_item['offer_id']]=$offer_item;

                foreach ($offer_item as $k=>$v) {
                    if ($k == 'account_id') {
                        $apply_applicaion[$offer_item['offer_id'] . '_' . $offer_item['publisher_id']][$k][]=$v;
                    } else {
                        $apply_applicaion[$offer_item['offer_id'] . '_' . $offer_item['publisher_id']][$k]=$v;
                    }
                }

            }
        }
        $this->data['apply_publisher_offer']=$apply_publisher_offer;
        $this->data['publisher_offer_account']=$publisher_offer_account2;
        $this->data['apply_applicaion']=$apply_applicaion;

        //获取当前流量主名下所有账号
        $this->data['accountlist']=$this->publisher_account($product_info['user_id']);

        //offer
        $this->data['product_detail_offer']=$this->load->view('web/product_detail_offer', $this->data, TRUE);

        //publsiher offer
        $this->data['product_detail_publisher_offer']=$this->load->view('web/product_detail_publisher_offer', $this->data, TRUE);

        //申请offer
        $this->data['product_detail_apply_offer']=$this->load->view('web/product_detail_apply_offer', $this->data, TRUE);


        $template='product_detail';
        $this->template->build($template, $this->data);
    }


    /**
     * 获取publisher下的所有的账号
     * @return [type] [description]
     */
    private function publisher_account($advertiser_id)
    {
        $this->load->model('publisher_adaccount_model');
        $sql="select * from publisher_adaccount where publisher_id=" . $this->userinfo['user_id'];
        $accountlist=$this->publisher_adaccount_model->get_query($sql);

        $publisher_offer_sql="select * from publisher_offer where publisher_id=" . $this->userinfo['user_id'];
        $publisher_offer=$this->publisher_adaccount_model->get_query($publisher_offer_sql);

        $accounts=[];
        foreach ($publisher_offer as $key=>$value) {
            if ($value['advertiser_id'] != $advertiser_id) {
                $accounts[]=$value['account_id'];
            }
        }

        $result=[];
        foreach ($accountlist as $key=>$value) {
            if (!in_array($value['account_id'], $accounts)) {
                $result[]=$value;
            }
        }

        return $result;
    }


    /**
     * 删除bucket
     * @return [type] [description]
     */
    public function del_bucket_action()
    {
        if ($this->input->is_ajax_request()) {
            if ($this->input->post('bucket_id')) {
                $offer_id=$this->input->post('bucket_id');
                $this->offer_model->update_row_by_id($offer_id, ['status'=>-1]);
                $response=['success'=>true, 'msg'=>$this->lang->line('success_delete')];
            } else {
                $response=['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
            }
        } else {
            $response=['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
        }
        $this->output->set_content_type('applicaion/json')->set_output(json_encode($response));

    }

    /**
     * 删除bucket payout
     * @return [type] [description]
     */
    public function del_bucket_payout_action()
    {
        if ($this->input->is_ajax_request()) {
            if ($this->input->post('payout_id')) {
                $offer_id=$this->input->post('payout_id');
                $this->payout_model->update_row_by_id($offer_id, ['status'=>-1]);
                $response=['success'=>true, 'msg'=>$this->lang->line('success_delete')];
            } else {
                $response=['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
            }
        } else {
            $response=['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
        }
        $this->output->set_content_type('applicaion/json')->set_output(json_encode($response));

    }


    /**
     * 获取bucket信息
     * @return [type] [description]
     */
    public function ajax_bucket_info()
    {
        if ($this->input->is_ajax_request()) {
            if ($this->input->get('data_id')) {
                $info=$this->offer_model->get_by_id($this->input->get('data_id'));
                if ($info) {
                    list($info['choose_type'], $info['countries'], $info['rpa'], $info['start_time'])=$this->get_rpa_log($info);
                    $info['countries']=$info_countries=json_decode($info['countries'], true);
                    // $this->config->load('product',TRUE);
                    // $countries = $this->config->item('product');


                    // if ($info_countries) {
                    //     foreach ($info_countries as $key => $value) {
                    //         $tmp_countries[] = ['key'=>$value, 'value'=>$countries['countries'][$value]];
                    //     }
                    //     $info['countries'] = $tmp_countries;
                    // }
                    $info['start_date']=date('m/d/Y', $info['start_time']);
                    $info['start_time']=date('g:i a', $info['start_time']);
                    $info['end_date']=date('m/d/Y', $info['end_time']);
                    $info['end_time']=date('g:i a', $info['end_time']);
                    $info['rpa']=sprintf("%.2f", $info['rpa']);
                    $response=['success'=>true, 'msg'=>"Success", 'data'=>$info];
                } else {
                    $response=['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
                }
            } else {
                $response=['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
            }
        } else {
            $response=['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
        }
        $this->output->set_content_type('applicaion/json')->set_output(json_encode($response));
    }


    /**
     * 申请offer
     * @return [type] [description]
     */
    public function apply_offer_action()
    {
        $this->load->model('adaccount_model');
        $this->load->model('publisher_offer_model');
        if (IS_POST) {
            $product_id=$this->input->post('product_id');
            if (!$this->input->post('offer_id') || !$this->input->post('apply_account')) {
                $this->error($this->lang->line('notice_bad_request'), 'product/detail/' . $product_id);
                die();
            }

            $offer_ids=explode(',', $this->input->post('offer_id'));
            $apply_account=$this->input->post('apply_account');
            foreach ($offer_ids as $key=>$offer_id) {
                $this->offer_model->apply_offer($offer_id, $apply_account, $this->userinfo['user_id'], $this->userinfo['full_name']);
            }

            $this->success($this->lang->line('success_done'), 'product/detail/' . $product_id);

        } else {
            $product_id=$this->input->get('product_id');
            $this->error($this->lang->line('notice_bad_request'), 'product/detail/' . $product_id);
        }
    }


    /**
     * 获取offer对应的申请账号
     * @param  string $value [description]
     * @return [type]        [description]
     */
    public function apply_publisher_account()
    {
        if ($this->input->is_ajax_request()) {
            $offer_id=$this->input->get('offer_id');
            $publisher_offer_sql="select * from publisher_offer where offer_id=" . $offer_id . " and publisher_id=" . $this->userinfo['user_id'];

            $apply_applicaion=[];
            $publisher_offer_account=$this->publisher_offer_model->get_query($publisher_offer_sql);

            if ($publisher_offer_account) {
                foreach ($publisher_offer_account as $offer_item) {
                    foreach ($offer_item as $k=>$v) {
                        if ($k == 'market_account_id') {
                            $apply_applicaion[$k][]=$v;
                        } else {
                            $apply_applicaion[$k]=$v;
                        }
                    }

                }
            }
            $response=['success'=>true, 'msg'=>$this->lang->line('success_done'), 'data'=>$apply_applicaion];
        } else {
            $response=['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
        }
        $this->output->set_content_type('applicaion/json')->set_output(json_encode($response));
    }

    public function lists()
    {
        $where=['status'=>1];

        if ($this->userinfo['type'] == 1) {
            $where=['in'=>['status'=>[0, 1]]];
            $where['user_id']=$this->userinfo['user_id'];
        } elseif ($this->userinfo['type'] == 0) {
            $where=['in'=>['status'=>[0, 1]]];
        }

        $lists=$this->product_model->get_all($where);
        //var_dump($lists);die;
        $this->data['lists']=$lists;
        $template='product_list';
        $this->template->build($template, $this->data);
    }

    public function detail()
    {
        //检测是否非法请求
        $param=$this->uri->segment(3);
        if (!$this->uri->segment(3)) {
            redirect('product/listview');
        }
        $this->config->load('country', TRUE);
        $country_list=$this->config->item('country');
        $product_id=intval($this->uri->segment(3));
        if (!$product_id) {
            redirect('product/listview');
        }
        //获取产品信息
        $user_id=$this->userinfo['user_id'];
        $product_info=$this->product_model->get_by_id($product_id);
        if (!$product_info) {
            redirect('product/listview');
        }
        $product_info['score_info']=$product_info['score_info']?json_decode($product_info['score_info'], true):[];
        //var_dump($product_info);die;
        $this->data['product_info']=$product_info;
        //获取offers
        $this->load->library('offer_service');
        //获取offer
        $listview=$this->offer_service->get_offers(['product_id'=>$product_id]);
        //获取offer处理后数据
        $this->data['list']=$this->offer_service->do_offer_data($listview, $user_id);

        $this->config->load('product', TRUE);
        $this->data['config_product']=$this->config->item('product');

        //获取申请的offer
        $publisher_offer_sql_where="product_id=" . $product_id;
        if ($this->userinfo['type'] == 2) {
            $publisher_offer_sql_where.=" and publisher_id=" . $this->userinfo['user_id'];
        }
        $publisher_offer_sql="select * from publisher_offer where " . $publisher_offer_sql_where;

        $publisher_offer_account=$this->publisher_offer_model->get_query($publisher_offer_sql);

        //申请过的offer
        //申请过的账号
        $apply_applicaion=$apply_publisher_offer=$apply_publisher_account=$publisher_offer_account2=[];

        if ($publisher_offer_account) {
            foreach ($publisher_offer_account as $offer_item) {
                $apply_publisher_offer[$offer_item['offer_id']]=$offer_item['offer_id'];
                if ($offer_item['advertiser_id'] != $product_info['user_id'])
                    $apply_publisher_account[]=$offer_item['account_id'];
                $publisher_offer_account2[$offer_item['offer_id']]=$offer_item;
                foreach ($offer_item as $k=>$v) {
                    if ($k == 'account_id') {
                        $apply_applicaion[$offer_item['offer_id'] . '_' . $offer_item['publisher_id']][$k][]=$v;
                    } else {
                        $apply_applicaion[$offer_item['offer_id'] . '_' . $offer_item['publisher_id']][$k]=$v;
                    }
                }
            }
        }
        $this->data['apply_publisher_offer']=$apply_publisher_offer;
        $this->data['publisher_offer_account']=$publisher_offer_account2;
        $this->data['apply_applicaion']=$apply_applicaion;

        //获取当前流量主名下所有账号
        $this->data['accountlist']=$this->publisher_account($product_info['user_id']);

        //offer
        $this->data['product_detail_offer']=$this->load->view('web/product_detail_offer', $this->data, TRUE);

        //publsiher offer
        $this->data['product_detail_publisher_offer']=$this->load->view('web/product_detail_publisher_offer', $this->data, TRUE);

        //申请offer
        $this->data['product_detail_apply_offer' ]=$this->load->view('web/product_detail_apply_offer', $this->data, TRUE);
        $template='product_detail';
        $this->template->build($template, $this->data);
    }
}
