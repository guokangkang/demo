<?php if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

/**
 * 
 * Created by PhpStorm.
 * User: palmax
 * Date: 2016/4/26
 * Time: 15:10
 */
class Manage extends Web_Controller
{
    public function __construct() {
        parent::__construct();
        $this->load->model('offer_model');
        $this->load->model('publisher_offer_model');
        $this->load->model('product_model');
        $this->load->model('user_model');
        $this->load->model('specific_payout_model');
        $this->load->model('specific_cap_model');
        $this->load->model('offer_country_log_model');
        $this->load->model('offer_rpa_log_model');
        $this->load->model('offer_cpa_log_model');
        $this->load->model('payout_model');
        $this->load->model('offer_effective_log_model');

        $this->load->library('pagination');

        $this->data['top_menu'] = $this->load->view('web/top_menu_setup', '', TRUE);
    }


    public function product()
    {
        $template = 'manage_product';
        $this->template->build($template,$this->data);
    }


    /**
     * offer 列表
     * @return [type] [description]
     */
    public function offer()
    {
        $this->config->load('country',TRUE);
        $this->data['country_list'] = $country_list = $this->config->item('country');

        if (!$this->input->get('product')) {
            redirect('product/listview');
            die();
        }
        $product_id = $this->input->get('product');
        $offer_where = "1=1";
        $country = $product = [];
        
        $product = explode(',', $this->input->get('product'));
        $offer_where .= " and offer.product_id in (".$this->input->get('product').")";
        
        if ($this->input->get('country')) {
            $country = explode(',', $this->input->get('country'));
            $offer_where .= " and offer.countries like '%".$this->input->get('country')."%'";
        }

        $sql = "SELECT * from offer  where ".$offer_where." group by offer.offer_id order by offer.addtime desc";
    

        $this->data['product_params'] = $product;
        $this->data['country_params'] = $country;
        $this->data['product_info'] = $this->product_model->get_by_id($this->input->get('product'));
        //获取offer
        $listview = $this->offer_model->get_query($sql);

        $data = [];
        foreach ($listview as $key => $value) {
            //获取cpa
            list($history, $schedule, $current) = $this->offer_model->get_payout($value['offer_id']);
            //获取rpa
            list($value['rpa'], $value['start_time']) = $this->offer_model->get_current_rpa_log($value);
            list($value['choose_type'], $value['countries']) = $this->offer_model->get_current_country_log($value);
            
            //获取当前offer状态
            $value['status'] = $this->offer_model->get_offer_current_status($value['offer_id']);
            if ($value['status']==-1) {
                continue;
            }

            $value['next_status'] = $this->offer_model->get_offer_next_status($value['offer_id']);

 
            $value['history'] = $history;
            $value['schedule'] = $schedule;
            $value['current'] = $current;

            $value['country_size'] = 0;
            $value['country_info'] = [];
            if ($value['countries']) {
                $country = $value['countries'];
                $value['country_size'] = count($country);

                foreach ($value['countries'] as $c) {
                    $value['country_info'][$c] = isset($country_list['country'][$c])?$country_list['country'][$c]:"Unknow";
                }
            }
            $value['start_time'] = date('m/d/Y h:i A', $value['start_time']);
            
            $value['specific_payout'] && $specific_payout[$value['offer_id']] = json_decode($value['specific_payout'], true);
            $value['specific_payout'] = json_decode($value['specific_payout'], true);


            $data[] = $value;
        }
        $this->data['listview'] = $data;


        $this->data['apply_status'] = [-10=>'Need Apply', -1=>'Disapproved', 0=>'Applied', 1=>'Approved'];


        $this->data['product_list'] = $this->product_model->get_query("select * from product where status=1");


        $rpa_log_sql = "SELECT *
                        FROM offer 
                        where product_id=".$product_id;
        $rpa_list = $this->product_model->get_query($rpa_log_sql);

        $include_countries = $exclude_countries = [];
        if ($rpa_list) {
            foreach ($rpa_list as $key => $val) {
                $status = $this->offer_model->get_current_offer_status($val['offer_id']);
                if ($status==-1) {
                    continue;
                }

                list($choose_type, $offer_country) = $this->offer_model->get_current_country_log($val);
                
                if ($offer_country) {
                    if ($choose_type=='include') {
                        $offer_country && $include_countries = array_merge($offer_country, $include_countries);
                    }else{
                        $offer_country && $exclude_countries = array_merge($offer_country, $exclude_countries);
                    }
                }
                
            }
        }
        $this->data['include_countries'] = $include_countries;
        $this->data['exclude_countries'] = $exclude_countries;

        
        
        $this->config->load('product',TRUE);
        $this->data['config_product'] = $this->config->item('product');

        //添加offer
        $this->data['product_detail_add_offer'] = $this->load->view('web/product_detail_add_offer', $this->data, TRUE);


        $template = 'manage_offer';
        $this->template->build($template,$this->data);
    }


    /**
     * 批量授权offer
     * @param string $value [description]
     */
    public function applications()
    {
        $total_sql = "select count(*) as count from publisher_offer where status=0";
        $total_rows = $this->publisher_offer_model->get_one($total_sql);

        $config['base_url'] = site_url('offer/applications');
        $config = get_web_page($config, $total_rows['count'], 3);

        $page = 1;
        if ($this->input->get('page'))
            $page = $this->input->get('page');


        $limit = $config['per_page'] = 50;

        $this->pagination->initialize($config);
        $this->data['page_links'] = $this->pagination->create_links();

        $sql = "SELECT publisher_offer.*,offer.countries
                    FROM publisher_offer LEFT JOIN offer ON publisher_offer.offer_id = offer.offer_id
                    WHERE publisher_offer.status=0 ORDER BY publisher_offer.addtime desc
                LIMIT ".($page - 1) * $limit.", ".$limit;

        $publisher_offer_account = $this->publisher_offer_model->get_query($sql);

        $apply_applicaion = [];
        if ($publisher_offer_account) {
            foreach ($publisher_offer_account as $offer_item) {
                list($offer_item['rpa'], $offer_item['start_time']) = $this->offer_model->get_current_rpa_log($offer_item['offer_id']);
                $offer_item['current_cpa'] = $this->offer_model->get_current_cpa_log($offer_item['offer_id']);
                $offer_item['specific_payout'] = $this->offer_model->get_current_specific_payout($offer_item['offer_id'], $offer_item['publisher_id']);
                foreach ($offer_item as $k => $v) {
                    if ($k=='account_id') {
                        $apply_applicaion[$offer_item['offer_id'].'_'.$offer_item['publisher_id']][$k][] = $v;
                    }else{
                        $apply_applicaion[$offer_item['offer_id'].'_'.$offer_item['publisher_id']][$k] = $v;
                    }
                }
            }
        }

        $this->data['apply_applicaion'] = $apply_applicaion;

        $this->config->load('product',TRUE);
        $this->data['config_product'] = $this->config->item('product');

        $template = 'manage_applications';
        $this->template->build($template,$this->data);
    }


    public function assigned_offer()
    {
        $publisher_params = $accounts_params = $product_params=[];
        $where = "publisher_offer.status=1";
        if ($this->input->get('product')) {
            $where .= " and publisher_offer.product_id=".$this->input->get('product');
            $product_params = [$this->input->get('product')];
        }
        if ($this->input->get('account')) {
            $where .= " and publisher_offer.account_id=".$this->input->get('account');
            $accounts_params = [$this->input->get('account')];
        }
        if ($this->input->get('publisher')) {
            $where .= " and publisher_offer.publisher_id=".$this->input->get('publisher');
            $publisher_params = [$this->input->get('publisher')];
        }

        
        $this->data['publisher_params'] = $publisher_params;
        $this->data['account_params'] = $accounts_params;
        $this->data['product_params'] = $product_params;

        $total_sql = "select count(*) as count from publisher_offer where ".$where." group by publisher_offer.product_id,publisher_offer.account_id,publisher_offer.publisher_id";
        $total_rows = $this->publisher_offer_model->get_one($total_sql);

        $count = $total_rows?$total_rows['count']:0;
        $config['base_url'] = site_url('manage/assigned_offer');
        $config = get_web_page($config, $count, 3);

        $page = 1;
        if ($this->input->get('page'))
            $page = $this->input->get('page');


        $limit = $config['per_page'] = 100;

        $this->pagination->initialize($config);
        $this->data['page_links'] = $this->pagination->create_links();

        $sql = "SELECT publisher_offer.*,offer.countries
                    FROM publisher_offer LEFT JOIN offer ON publisher_offer.offer_id = offer.offer_id
                    WHERE ".$where." ORDER BY publisher_offer.addtime desc
                LIMIT ".($page - 1) * $limit.", ".$limit;

        $publisher_offer_account = $this->publisher_offer_model->get_query($sql);

        $apply_applicaion = [];
        foreach ($publisher_offer_account as $key=>& $item) {
            $specific = $this->offer_model->get_specific_payout($item['offer_id']);
            $item['payout'] = ['type'=>'specific', 'payout'=>$specific];
            if (!$specific) {
                $cpa = $this->offer_model->get_current_cpa_log($item['offer_id']);
                if ($cpa) {
                    $item['payout'] = ['type'=>'cpa', 'payout'=>$cpa];
                }else{
                    continue;
                }
                
            }

            list($item['choose_type'], $item['country']) = $this->offer_model->get_current_country_log($item);
        
            foreach ($item as $k => $v) {
                if ($k=='account_id') {
                    if (isset($apply_applicaion[$item['offer_id'].'_'.$item['publisher_id']][$k])) {
                        !in_array($v, $apply_applicaion[$item['offer_id'].'_'.$item['publisher_id']][$k]) && $apply_applicaion[$item['offer_id'].'_'.$item['publisher_id']][$k][] = $v;
                    }else{
                        $apply_applicaion[$item['offer_id'].'_'.$item['publisher_id']][$k][] = $v;
                    }
                    
                }else{
                    $apply_applicaion[$item['offer_id'].'_'.$item['publisher_id']][$k] = $v;
                }
            }
        }
        $this->data['offer_list'] = $apply_applicaion;

        $this->data['publisher_ids'] = $this->publisher_offer_model->get_query("select publisher_id,publisher_name from publisher_offer where status=1 group by publisher_id");
        $this->data['account_ids'] = $this->publisher_offer_model->get_query("select account_id,account_name from publisher_offer where status=1 group by account_id");
        $this->data['product_ids'] = $this->publisher_offer_model->get_query("select product_id,product_name from publisher_offer where status=1 group by product_id");

        $template = 'manage_assigned_offer';
        $this->template->build($template,$this->data);
    }



    /**
     * 用户用那些账号申请了那些账号
     * @param string $value [description]
     */
    public function accounts()
    {
        
        $publisher_params = $accounts_params = $product_params=[];
        $where = "publisher_offer.status=1";
        if ($this->input->get('product')) {
            $where .= " and publisher_offer.product_id=".$this->input->get('product');
            $product_params = [$this->input->get('product')];
        }
        if ($this->input->get('account')) {
            $where .= " and publisher_offer.account_id=".$this->input->get('account');
            $accounts_params = [$this->input->get('account')];
        }
        if ($this->input->get('publisher')) {
            $where .= " and publisher_offer.publisher_id=".$this->input->get('publisher');
            $publisher_params = [$this->input->get('publisher')];
        }

        
        $this->data['publisher_params'] = $publisher_params;
        $this->data['account_params'] = $accounts_params;
        $this->data['product_params'] = $product_params;

        $total_sql = "select count(*) as count from publisher_offer where ".$where." group by publisher_offer.product_id,publisher_offer.account_id,publisher_offer.publisher_id";
        $total_rows = $this->publisher_offer_model->get_one($total_sql);

        $count = $total_rows?$total_rows['count']:0;

        $config['base_url'] = site_url('manage/accounts?');
        $config = get_web_page($config, $count, 3);

        $page = 1;
        if ($this->input->get('page'))
            $page = $this->input->get('page');


        $limit = $config['per_page'] = 50;

        $this->pagination->initialize($config);
        $this->data['page_links'] = $this->pagination->create_links();

        $sql = "SELECT publisher_offer.*,offer.countries
                    FROM publisher_offer LEFT JOIN offer ON publisher_offer.offer_id = offer.offer_id
                    WHERE ".$where." ORDER BY publisher_offer.addtime desc
                LIMIT ".($page - 1) * $limit.", ".$limit;

        $publisher_offer_account = $this->publisher_offer_model->get_query($sql);

        $apply_applicaion = [];
        if ($publisher_offer_account) {
            foreach ($publisher_offer_account as $offer_item) {

                foreach ($offer_item as $k => $v) {
                    if ($k=='account_id') {
                        if (isset($apply_applicaion[$offer_item['product_id'].'_'.$offer_item['publisher_id']][$k])) {
                            !in_array($v, $apply_applicaion[$offer_item['product_id'].'_'.$offer_item['publisher_id']][$k]) && $apply_applicaion[$offer_item['product_id'].'_'.$offer_item['publisher_id']][$k][] = $v;
                        }else{
                            $apply_applicaion[$offer_item['product_id'].'_'.$offer_item['publisher_id']][$k][] = $v;
                        }
                        
                    }else{
                        $apply_applicaion[$offer_item['product_id'].'_'.$offer_item['publisher_id']][$k] = $v;
                    }
                }
            }
        }

        $this->data['apply_applicaion'] = $apply_applicaion;


        $this->data['publisher_ids'] = $this->publisher_offer_model->get_query("select publisher_id,publisher_name from publisher_offer where status=1 group by publisher_id");
        $this->data['account_ids'] = $this->publisher_offer_model->get_query("select account_id,account_name from publisher_offer where status=1 group by account_id");
        $this->data['product_ids'] = $this->publisher_offer_model->get_query("select product_id,product_name from publisher_offer where status=1 group by product_id");


        $template = 'manage_accounts';
        $this->template->build($template,$this->data);
    }


    public function offer_detail()
    {
        if (!$this->uri->segment(3)) {
            redirect('setup/product');
        }

        $offer_id = $this->uri->segment(3);

        $offer_info = $this->offer_model->get_by_id($offer_id);
        if (!$offer_info) {
            redirect('setup/product');
        }

        $offer_info['specific_payout'] = $this->offer_model->get_specific_payout($offer_id);

        $offer_info['status'] = $this->offer_model->get_offer_current_status($offer_id);

        $this->data['product_info'] = $this->product_model->get_by_id($offer_info['product_id']);

        //获取cpa
        list($history, $schedule, $current) = $this->offer_model->get_payout($offer_info['offer_id']);
        //获取rpa
        list($offer_info['rpa'], $offer_info['start_time']) = $this->offer_model->get_current_rpa_log($offer_info);

        $offer_info['cpa'] = 0;
        if ($current) {
            $offer_info['cpa'] = $current['cpa'];
        }

        list($choose_type, $countries) = $this->offer_model->get_current_country_log($offer_info);

        $offer_info['countries'] = $countries;

        $this->data['offer_info'] = $offer_info;

        $this->data['offer_cpa'] = ['schedule'=>$schedule, 'current'=>$current ,'history'=>$history];

        $product_info = $this->product_model->get_by_id($offer_info['product_id']);
        if (!$product_info) {
            redirect('product/listview');
        }
        $this->data['product_info'] = $product_info;


        //获取所有的流量主
        $publisher_sql = "select user_id,first_name,last_name,user_name,publisher_type from user where type=2";
        $publisher = $this->user_model->get_query($publisher_sql);
        $this->data['publisher'] = $publisher;


        //获取offer下有特殊价格的用户
        $specific_publisher_sql = 'select * from specific_payout where offer_id='.$offer_id." and type=1 and status=1 group by user_id";
        $this->data['specific_publisher'] = $this->specific_payout_model->get_query($specific_publisher_sql);

        //获取offer下有特殊cap的用户
        $specific_cap_publisher_sql = 'select * from specific_cap where offer_id='.$offer_id." and type=1 and status=1 group by user_id";
        $this->data['specific_cap_publisher'] = $this->specific_cap_model->get_query($specific_cap_publisher_sql);

        $this->config->load('product',TRUE);
        $coufig_product = $this->data['config_product'] = $this->config->item('product');

        //查看国家日志
        $country_sql = "select * from offer_country_log where offer_id=".$offer_id." order by start_time desc";
        $country_log = $this->offer_model->get_query($country_sql);
        $country_data = [];
        $flag = false;
        foreach ($country_log as $item) {
            $item['is_current'] = false;
            if (!$flag && $item['start_time']<=time()) {
                $item['is_current'] = true;
                $flag = true;
            }
            $country_data[$item['start_time']]['is_current'] = $item['is_current'];

            $country_data[$item['start_time']]['choose_type'] = $item['choose_type'];

            $countries_tmp = json_decode($item['country'], true);
            if ($countries_tmp) {
                foreach ($countries_tmp as $c) {
                    $country_data[$item['start_time']]['countries'][] = $coufig_product['countries'][$c];
                }
            }else{
                $country_data[$item['start_time']]['countries'][] = "All Countries";
            }
        }
        $this->data['offer_country'] = $country_data;

        //rpa列表
        $rpa_list = $this->offer_model->get_rpa_log($offer_id);
        $flag = false;
        foreach ($rpa_list as $key => &$rpa) {
            $rpa['is_current'] = false;
            if (!$flag && $rpa['start_time']<=time()) {
                $rpa['is_current'] = true;
                $flag = true;
            }
        }
        $this->data['rpa_list'] = $rpa_list;


        //cap列表
        $cap_list = $this->offer_model->get_cap_log($offer_id);
        $flag = false;
        foreach ($cap_list as $key => &$rpa) {
            $rpa['is_current'] = false;
            if (!$flag && $rpa['start_time']<=time()) {
                $rpa['is_current'] = true;
                $flag = true;
            }
        }
        $this->data['cap_list'] = $cap_list;

        $this->data['specific_cap'] = $this->offer_model->get_specific_cap($offer_id);



        //获取offer所有时间设置
        $effective_list = $this->offer_model->get_offer_status($offer_id);

        $this->data['effective_list'] = $effective_list;

 

        $this->data['offer_detail_payout'] = $this->load->view('web/offer_detail_payout', $this->data, TRUE);
        $this->data['offer_detail_add_payout'] = $this->load->view('web/offer_detail_add_payout', $this->data, TRUE);
        $this->data['offer_detail_cancel_payout'] = $this->load->view('web/offer_detail_cancel_payout', $this->data, TRUE);
        

        $this->data['offer_detail_cpa'] = $this->load->view('web/offer_detail_cpa', $this->data, TRUE);
        $this->data['offer_detail_set_cpa'] = $this->load->view('web/offer_detail_set_cpa', $this->data, TRUE);
        
        $this->data['offer_detail_country'] = $this->load->view('web/offer_detail_country', $this->data, TRUE);
        $this->data['offer_detail_set_country'] = $this->load->view('web/offer_detail_set_country', $this->data, TRUE);

        $this->data['offer_detail_rpa'] = $this->load->view('web/offer_detail_rpa', $this->data, TRUE);
        $this->data['offer_detail_set_rpa'] = $this->load->view('web/offer_detail_set_rpa', $this->data, TRUE);

        $this->data['offer_detail_cap'] = $this->load->view('web/offer_detail_cap', $this->data, TRUE);
        $this->data['offer_detail_set_cap'] = $this->load->view('web/offer_detail_set_cap', $this->data, TRUE);

        $this->data['offer_detail_specific_cap'] = $this->load->view('web/offer_detail_specific_cap', $this->data, TRUE);
        $this->data['offer_detail_set_specific_cap'] = $this->load->view('web/offer_detail_set_specific_cap', $this->data, TRUE);
        $this->data['offer_detail_cancel_specific_cap'] = $this->load->view('web/offer_detail_cancel_specific_cap', $this->data, TRUE);
        
        $this->data['offer_detail_event'] = $this->load->view('web/offer_detail_event', $this->data, TRUE);

        $template = 'manage_offer_detail';
        $this->template->build($template,$this->data);

    }

    /**
     * 添加特殊价格
     * @param string $value [description]
     */
    public function add_payout_action()
    {
        if (IS_POST) {
            $select_publisher = $this->input->post('select_publisher');
            $input_note = $this->input->post('input_note');
            $input_payout = $this->input->post('input_payout');
            $offer_id = $this->input->post('offer_id');

            $offer_info = $this->offer_model->get_by_id($offer_id);
            $specific_payout = json_decode($offer_info['specific_payout'], true);

            $input_time = $this->input->post('input_time');
            $input_date = $this->input->post('input_date');

            $effective = $this->input->post('effective');

            if ($effective==1) {
                $start_time = time();
            }else{
                $start_time = strtotime($input_date.' '.$input_time);
            }

            foreach ($select_publisher as $user_id) {

                $infos = $this->specific_payout_model->get_all(['user_id'=>$user_id, 'offer_id'=>$offer_id], 1, 1);
                $info = $infos[0];
                // if ($info['type']=='add') {
                //     continue;
                // }

                $user_info = $this->user_model->get_by_id($user_id);
                $specific_payout[$user_id] = ['user_id'=>$user_id, 'user_name'=>$user_info['user_name'], 'payout'=>$input_payout, 'note'=>$input_note];

                $this->specific_payout_model->add_specific_payout_log_action($user_id, $user_info['user_name'], $input_payout, $offer_id, $input_note, $start_time);
            }
            
            $specific_payout = json_encode($specific_payout);
            $this->offer_model->update_row_by_id($offer_id, ['specific_payout'=>$specific_payout]);
            
            $this->success($this->lang->line('success_done'), 'manage/offer_detail/'.$this->input->post('offer_id'));
        }else{
            $this->error($this->lang->line('notice_bad_request'));
        }
    }

    /**
     * 删除特殊价格给用户
     */
    public function cancel_specific_payout_action(){
        if (IS_POST) {
            $offer_id = $this->input->post('offer_id');

            $select_publisher = $this->input->post('select_publisher');
            $input_note = $this->input->post('input_note');

            $effective = $this->input->post('effective');

            $input_time = $this->input->post('input_time');
            $input_date = $this->input->post('input_date');
            
            if ($effective==1) {
                $start_time = time();
            }else{
                $start_time = strtotime($input_date.' '.$input_time);
            }

            if ($offer_id) {
                foreach ($select_publisher as $user_id) {

                    $this->specific_payout_model->cancel_specific_payout_log_action($offer_id, $user_id, $input_note, $start_time);
                }
            }
            
            $this->success($this->lang->line('success_done'), 'manage/offer_detail/'.$this->input->post('offer_id'));
        }else{
            $this->error($this->lang->line('notice_bad_request'));
        }
    }


    /**
     * 添加特殊价格
     * @param string $value [description]
     */
    public function add_specific_cap_action()
    {
        if (IS_POST) {
            $select_publisher = $this->input->post('select_publisher');
            $input_note = $this->input->post('input_note');
            $input_payout = $this->input->post('input_payout');
            $offer_id = $this->input->post('offer_id');

            $offer_info = $this->offer_model->get_by_id($offer_id);
            $specific_payout = json_decode($offer_info['specific_payout'], true);

            $input_time = $this->input->post('input_time');
            $input_date = $this->input->post('input_date');

            $effective = $this->input->post('effective');

            if ($effective==1) {
                $start_time = time();
            }else{
                $start_time = strtotime($input_date.' '.$input_time);
            }

            foreach ($select_publisher as $user_id) {

                $user_info = $this->user_model->get_by_id($user_id);
                $specific_payout[$user_id] = ['user_id'=>$user_id, 'user_name'=>$user_info['user_name'], 'payout'=>$input_payout, 'note'=>$input_note];

                $this->specific_cap_model->add_specific_cap_log_action($user_id, $user_info['user_name'], $input_payout, $offer_id, $input_note, $start_time);
            }
            
            $this->success($this->lang->line('success_done'), 'manage/offer_detail/'.$this->input->post('offer_id'));
        }else{
            $this->error($this->lang->line('notice_bad_request'));
        }
    }

    /**
     * 删除特殊价格给用户
     */
    public function cancel_specific_cap_action(){
        if (IS_POST) {
            $offer_id = $this->input->post('offer_id');

            $select_publisher = $this->input->post('select_publisher');
            $input_note = $this->input->post('input_note');

            $effective = $this->input->post('effective');

            $input_time = $this->input->post('input_time');
            $input_date = $this->input->post('input_date');

            if ($effective==1) {
                $start_time = time();
            }else{
                $start_time = strtotime($input_date.' '.$input_time);
            }

            if ($offer_id) {
                foreach ($select_publisher as $user_id) {

                    $this->specific_cap_model->cancel_specific_cap_log_action($offer_id, $user_id, $input_note, $start_time);
                }
            }
            
            $this->success($this->lang->line('success_done'), 'manage/offer_detail/'.$this->input->post('offer_id'));
        }else{
            $this->error($this->lang->line('notice_bad_request'));
        }
    }


    /**
     * 设置国家
     * @param string $value [description]
     */
    public function set_offer_country_action($value='')
    {
        if (IS_POST) {
            $offer_id = $this->input->post('offer_id');
            $offer_info = $this->offer_model->get_by_id($offer_id);
            
            if (!$offer_info) {
                $this->error('offer not exists');
            }

            $countries = $this->input->post('select_country');
            $category = $this->input->post('category');

            $input_time = $this->input->post('input_time');
            $input_date = $this->input->post('input_date');
            $effective = $this->input->post('effective');

            if ($effective==1) {
                $start_time = time();
            }else{
                $start_time = strtotime($input_date.' '.$input_time);
            }
            $vars = ['offer_id'=>$offer_id, 'choose_type'=>$category, 'start_time'=>$start_time];
            if ($countries) {
                $vars['country'] = json_encode($countries);
            }

            $this->offer_country_log_model->add_one($vars);

            $this->success($this->lang->line('success_done'), 'manage/offer_detail/'.$this->input->post('offer_id'));
        }else{
            $this->error($this->lang->line('notice_bad_request'));
        }
        
    }


    /**
     * 添加country
     * @return [type] [description]
     */
    public function add_offer_action()
    {
        $this->load->model('offer_effective_log_model');
        if (IS_POST) {
            if (!$this->input->post('product_id')) {
                $this->error($this->lang->line('notice_bad_request'));
            }
            $vars['product_id'] = $this->input->post('product_id');

            $info = $this->product_model->get_by_id($vars['product_id']);
            if (!$info) {
                $this->error($this->lang->line('notice_bad_request'));
            }
            $vars['product_name'] = $info['name'];
            $vars['user_id'] = $info['user_id'];
            $vars['user_name'] = $info['user_name'];


            $countries = $vars['countries'] = $this->input->post('select_country');

            $input_time = $this->input->post('input_time');
            $input_date = $this->input->post('input_date');

            //$end_time = $this->input->post('end_input_time');
            //$end_date = $this->input->post('end_input_date');
            //$vars['category'] = $category = $this->input->post('category');
            $vars['choose_type'] = $category = $this->input->post('choose_type');

            $vars['rpa'] = $this->input->post('input_rpa');

            $vars['countries'] && $vars['countries'] = json_encode($vars['countries']);
            //$vars['desc'] = $this->input->post('input_desc');
            $vars['start_time'] = strtotime($input_date.' '.$input_time);
 

            $vars['status'] = 0;

            $offer_id = $this->offer_model->add_one($vars);
            //添加有效时间日志（开关）
            $this->offer_effective_log_model->add_one(['effective_time'=>$vars['start_time'], 'offer_id'=>$offer_id, 'status'=>1]);
            //添加rpa日志
            $this->offer_rpa_log_model->add_offer_rpa_log_action($vars['product_id'], $offer_id, $vars['rpa'], $vars['start_time'], $vars['countries'], $vars['choose_type']);
            
            $vars['offer_id'] = $offer_id;
            //添加关系日志
            $this->offer_country_log_model->add_one(['offer_id'=>$offer_id, 'country'=>$vars['countries'], 'choose_type'=>$vars['choose_type'], 'start_time'=>$vars['start_time']]);

            $offercount = $this->offer_model->get_total(['product_id'=>$vars['product_id'], 'status'=>0]);
            $this->product_model->update_row_by_id($vars['product_id'], ['offer_count'=>$offercount]);

            $this->success($this->lang->line('success_done'), 'manage/offer?product='.$vars['product_id']);
        }else{
            $this->success("success", 'manage/offer?product='.$this->input->post('product_id'));
        }
    }

    /**
     * 添加rpa日志
     * @param string $value [description]
     */
    public function set_offer_rpa_action()
    {
        if (IS_POST) {
            $offer_id = $this->input->post('offer_id');
            $offer_info = $this->offer_model->get_by_id($offer_id);
            
            if (!$offer_info) {
                $this->error('offer not exists');
            }

            $rpa = $this->input->post('input_rpa');

            $input_time = $this->input->post('input_time');
            $input_date = $this->input->post('input_date');

            $effective = $this->input->post('effective');

            if ($effective==1) {
                $start_time = time();
            }else{
                $start_time = strtotime($input_date.' '.$input_time);
            }
            $vars = ['product_id'=>$offer_info['product_id'], 'offer_id'=>$offer_id, 'rpa'=>$rpa, 'start_time'=>$start_time];

            $this->offer_rpa_log_model->add_one($vars);


            $this->success($this->lang->line('success_done'), 'manage/offer_detail/'.$offer_id);
        }else{
            $this->success("success", 'manage/offer_detail/'.$offer_id);
        }
    }


    /**
     * 添加rpa日志
     * @param string $value [description]
     */
    public function set_offer_cap_action()
    {
        $this->load->model('offer_cap_log_model');
        if (IS_POST) {
            $offer_id = $this->input->post('offer_id');
            $offer_info = $this->offer_model->get_by_id($offer_id);
            
            if (!$offer_info) {
                $this->error('offer not exists');
            }

            $rpa = $this->input->post('input_rpa');

            $input_time = $this->input->post('input_time');
            $input_date = $this->input->post('input_date');

            $effective = $this->input->post('effective');

            if ($effective==1) {
                $start_time = time();
            }else{
                $start_time = strtotime($input_date.' '.$input_time);
            }
            $vars = ['product_id'=>$offer_info['product_id'], 'offer_id'=>$offer_id, 'cap'=>$rpa, 'start_time'=>$start_time];

            $this->offer_cap_log_model->add_one($vars);


            $this->success($this->lang->line('success_done'), 'manage/offer_detail/'.$offer_id);
        }else{
            $this->success("success", 'manage/offer_detail/'.$offer_id);
        }
    }

    /**
     * 添加cpa日志
     * @param  [type] $offer_id [description]
     * @param  [type] $cpa      [description]
     * @param  [type] $vars     [description]
     * @return [type]           [description]
     */
    private function update_offer_cpa_log($offer_id, $cpa, $vars)
    {
        //$sql = "select * from publisher_offer where offer_id=".$offer_id." group by offer_id";
        $sql = "select * from publisher_offer where offer_id=".$offer_id;
        $publisherlist = $this->publisher_offer_model->get_query($sql);
        if ($publisherlist) {
            $vars['value'] = json_decode($vars['value'], true);
            foreach ($publisherlist as $key => $value) {
                //排除有特殊价格的用户
                $this->offer_cpa_log_model->add_one(['offer_id'=>$offer_id, 'user_id'=>$value['publisher_id'], 'cpa'=>$cpa, 'start_time'=>$vars['start_time'], 'type'=>'retention', 'retention'=>json_encode($vars)]);
            }
        }
    }

    /**
     * 添加payout数据
     */
    public function set_offer_cpa_action()
    {
        if (IS_POST) {
            if (!$this->input->post('offer_id')) {
                $this->error($this->lang->line('notice_bad_request'));
            }
            $vars['offer_id'] = $this->input->post('offer_id');

            $info = $this->offer_model->get_by_id($vars['offer_id']);
            if (!$info) {
                $this->error($this->lang->line('notice_bad_request'));
            }
            $vars['category'] = $this->input->post('category');

            $vars['cpa'] = $this->input->post('myprice');
            $input_percent = $this->input->post('input_percent');
            $input_currency = $this->input->post('input_price');
            $input_time = $this->input->post('input_time');
            $input_date = $this->input->post('input_date');
            $effective = $this->input->post('effective');

            if ($vars['category'] == 2) {
                foreach ($input_percent as $key => $value) {
                    if ($value) {
                        $vars['value'][$key]['retention_rate'] = $value;
                        $vars['value'][$key]['payout_rate']    = $input_currency[$key];
                    }
                }
                $vars['value'] = json_encode($vars['value']);
            }elseif ($vars['category'] == 3) {
                $vars['value'] = $this->input->post('input_typeb');
            }
            
            
            if ($effective==1) {
                $vars['start_time'] = time();
            }else{
                $vars['start_time'] = strtotime($input_date.' '.$input_time);
            }

            //$vars = $this->validation->checkInput($vars);
            $this->payout_model->add_one($vars);

            $this->update_offer_cpa_log($vars['offer_id'], $vars['cpa'], $vars);
            
            //redirect('product/detail/'.$info['product_id']);
            $this->success("Success", 'manage/offer_detail/'.$info['offer_id']);

        }else{
            $this->success("参数错误。", 'manage/offer_detail/'.$info['offer_id']);
        }
    }

    /**
     * 设置offer的开关时间
     */
    public function add_offer_effective_action()
    {
        if (IS_POST) {
            $offer_id = $this->input->post('offer_id');
            $offer_info = $this->offer_model->get_by_id($offer_id);
            
            if (!$offer_info) {
                $this->error('offer not exists');
            }

            $input_time = $this->input->post('input_time');
            $input_date = $this->input->post('input_date');

            $start_time = strtotime($input_date.' '.$input_time);
            $status = $this->input->post('status');

            $vars = ['offer_id'=>$offer_info['offer_id'], 'effective_time'=>$start_time, 'status'=>$status];

            $this->offer_effective_log_model->add_one($vars);

            $this->success($this->lang->line('success_done'), 'manage/offer_detail/'.$offer_id);
        }else{
            $this->success("success", 'manage/offer_detail/'.$offer_id);
        }
    }


    /**
     * 确认offer的申请
     * offer_id  
     * type   approve(通过)  disapprove(拒绝)
     * @return [type] [description]
     */
    public function approve_apply_offer_action()
    {
        if ($this->input->is_ajax_request()) {
            
            if (is_array($this->input->post('offer_id'))) {
                $status = $this->input->post('status');
                $offer_ids = $this->input->post('offer_id');
                foreach ($offer_ids as $offer_id) {
                    $this->publisher_offer_model->update_row_by_fields(['offer_id'=>$offer_id], ['status'=>$status]);
                }
            }else{
                $status = $this->input->post('status');
                $offer_id = $this->input->post('offer_id');

                $this->publisher_offer_model->update_row_by_fields(['offer_id'=>$offer_id], ['status'=>$status]);
            }
            $response = ['success'=>true, 'msg'=>$this->lang->line('success_done')];
        }else{
            $response = ['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
        }
        $this->output->set_content_type('applicaion/json')->set_output(json_encode($response));
    }

    
}
