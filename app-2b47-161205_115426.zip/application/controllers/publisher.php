<?php
/**
 * Created by PhpStorm.
 * User: palmax
 * Date: 2016/4/26
 * Time: 15:10
 */
class Publisher extends Web_Controller
{

    public function __construct() {
        parent::__construct();

        $this->load->model('user_model');
        $this->load->model('reports_model');
    }


    public function get_data1($publisher_id, $start_time, $end_time)
    {
        $sql = "select 
                    count(campaign_id) as campaign,
                    count(adset_id) as adset,
                    sum(results) as results,
                    sum(spend) as spend,
                    sum(expect_revenue) as earning,
                    sum(real_earning) as real_earning,
                    sum(real_earning) as real_earning,
                    sum(day0) as day0,
                    sum(day1) as day1,
                    product_id, 
                    product_name
                from marketmax_reports 
                where date>=".$start_time." and date<=".$end_time."
                and publisher_id=".$publisher_id." 
                group by product_id,product_name
                order by results desc";
        $data = $this->reports_model->get_report_data($sql);
        foreach ($data as & $item) {
            $item['cpi'] = $item['results']>0?floatval(sprintf("%.2f", $item['spend']/$item['results'])):0;
            $item['a_f'] = $item['results']>0?floatval(sprintf("%.2f", $item['day0']/$item['results']*100)):0;
        
            $sql = "SELECT
                        sum(spend) AS spend,
                        sum(expect_revenue) AS earning,
                        sum(real_earning) AS real_earning
                    FROM
                        marketmax_reports
                    LEFT JOIN marketmax_products ON marketmax_products.product_id = marketmax_reports.product_id
                    WHERE
                        marketmax_reports.publisher_id=".$publisher_id."
                        and marketmax_reports.product_id=".$item['product_id']."
                        and 
                        (
                            (marketmax_products.retention_day=0 and marketmax_reports.date <=".$end_time.")
                            or (
                                marketmax_products.retention_day > 0
                                AND 
                                (
                                    (marketmax_products.retention_updated_time>".$end_time." and marketmax_reports.date <= ".$end_time.")
                                    OR (marketmax_products.retention_updated_time<=".$end_time.")
                                )
                            )
                        )
                        and date>=".$start_time;
            $item['roi'] = 0;
            $d = $this->reports_model->get_report_data($sql);
            $item['real_data'] = $d?$d[0]:[];
            if ($item['real_data']) {
                $item['real_data']['spend'] = sprintf("%.2f",$item['real_data']['spend']);
                $item['real_data']['real_profit'] = sprintf("%.2f", $item['real_data']['real_earning']-$item['real_data']['spend']);
                if ($item['real_data']['spend']>0) {
                    $item['roi'] = sprintf("%.2f", ($item['real_data']['real_earning']-$item['real_data']['spend'])/$item['real_data']['spend']*100);
                }
            }


        }

        return $data;
    }

    public function daily(){

        $publisher_id = $this->userinfo['user_id'];

        if ($this->userinfo['type']==0) {
            if (!$this->input->get('publisher')) {
                redirect('dashboard');die();
            }
            $publisher_id = $this->input->get('publisher');
        }
        $publisher_info = $this->user_model->get_by_id($publisher_id);

        $publisher_info = $this->user_model->get_by_id($publisher_id);
        if (!$publisher_info) {
            redirect('dashboard');die();
        }
        if (!$publisher_info['token']) {
            redirect('dashboard');die();
        }
        $this->data['publisher_info'] = $publisher_info;


        $start_date = date('Y-m-d', strtotime("-6 day"));
        $end_date = date('Y-m-d');
        if ($this->input->get('start')) {
            $start_date = $this->input->get('start');
            $end_date = $this->input->get('end');
        }
        
        $this->data['start_date'] = $start_date;
        $this->data['end_date'] = $end_date;

        

        $data = $this->get_data1($publisher_id, strtotime($start_date), strtotime($end_date));
        $this->data['data'] = $data;

        $this->template->set_template('web/publisher_daily');
        $this->template->set_view_dir("web");
        $this->template->build('publisher_daily',$this->data);
    }


    private function get_chart_li_data($publisher_id, $product_id, $start, $end)
    {
        // $sql = "select 
        //             sum(results) as results,
        //             sum(spend) as spend,
        //             sum(expect_revenue) as earning,
        //             sum(real_earning) as real_earning,
        //             sum(day0) as day0,
        //             sum(day1) as day1,
        //             date
        //         from marketmax_reports 
        //         where date>=".$start." and date<=".$end."
        //         and publisher_id=".$publisher_id." 
        //         and product_id = ".$product_id."
        //         group by date
        //         order by date asc";
        
        $sql = "SELECT
                    sum(results) as results,
                     sum(spend) as spend,
                     sum(expect_revenue) as earning,
                     sum(real_earning) as real_earning,
                     sum(day0) as day0,
                     sum(day1) as day1,
                     date
                    FROM
                        marketmax_reports
                    LEFT JOIN marketmax_products ON marketmax_products.product_id = marketmax_reports.product_id
                    WHERE
                        marketmax_reports.publisher_id=".$publisher_id."
                        and marketmax_reports.product_id=".$product_id."
                        and 
                        (
                            (marketmax_products.retention_day=0 and marketmax_reports.date <=".$end.")
                            or (
                                marketmax_products.retention_day > 0
                                AND 
                                (
                                    (marketmax_products.retention_updated_time>".$end." and marketmax_reports.date <= ".$end.")
                                    OR (marketmax_products.retention_updated_time<=".$end.")
                                )
                            )
                        )
                        and date>=".$start."
                    group by date
                    order by date asc";

        $data = $this->reports_model->get_report_data($sql);

        $tmp = $data_list = $data1 = $data1_product = $data1_a_f = $data1_day0 = $data1_day1 = $data1_roi = $data1_product = $data1_spend = $data1_results = $data1_earning = $data1_real_earning = [];
        foreach ($data as $item) {
            $data1_date[$item['date']]           = date('M d', $item['date']);




            $tmp['results'][$item['date']] = $item['results'];            
            $tmp['day0'][$item['date']] = $item['day0'];            
            $tmp['day1'][$item['date']] = $item['day1'];            
            $tmp['earning'][$item['date']] = floatval(sprintf("%.2f", $item['earning']));  
            $tmp['real_earning'][$item['date']] = floatval(sprintf("%.2f", $item['real_earning']));  
            $tmp['spend'][$item['date']] = floatval(sprintf("%.2f", $item['spend']));  
            $tmp['roi'][$item['date']] = floatval(sprintf("%.2f", ($item['real_earning']-$item['spend'])/$item['spend']*100));
            $tmp['cpi'][$item['date']] = $item['results']>0?floatval(sprintf("%.2f", $item['spend']/$item['results'])):0;
            $tmp['a_f'][$item['date']] = $item['results']>0?floatval(sprintf("%.2f", $item['day0']/$item['results']*100)):0;
        }
        $day = floor(($end-$start)/86400);
        for ($i=0; $i <= $day; $i++) { 
            $start_date = date('Y-m-d', $start);
            $d = strtotime("$start_date +$i day");
            !isset($data1_date[$d]) && $data1_date[$d] = date('M d', $d);
        }

        ksort($data1_date);

        foreach ($tmp as $key => $value) {
            for ($i=0; $i <= $day; $i++) { 
                $start_date = date('Y-m-d', $start);
                $d = strtotime("$start_date +$i day");
                !isset($value[$d]) && $value[$d] = 0;
            }
            ksort($value);
            $data1[$key] = array_values($value);
        }

        return [array_values($data1_date), $data1];
    }

    public function daily_li_chart()
    {
        if ($this->input->is_ajax_request()) {
            $product_id = $this->input->post('product');
            $publisher_id = $this->input->post('publisher');
            $start = $this->input->post('start');
            $end = $this->input->post('end');

            list($data_date, $data) = $this->get_chart_li_data($publisher_id, $product_id, strtotime($start), strtotime($end));
            if ($data) {
                $response=['success'=>true, 'chart_date'=>json_encode($data_date), 'chart_results'=>json_encode($data['results']), 'chart_day0'=>json_encode($data['day0']), 'chart_earning'=>json_encode($data['earning']), 'chart_real_earning'=>json_encode($data['real_earning']), 'chart_roi'=>json_encode($data['roi']), 'chart_cpi'=>json_encode($data['cpi']), 'chart_a_f'=>json_encode($data['a_f']), 'chart_spend'=>json_encode($data['spend'])];
            }else{
                $response=['success'=>true, 'chart_date'=>"", 'chart_results'=>"", 'chart_day0'=>"", 'chart_earning'=>"", 'chart_real_earning'=>"", 'chart_roi'=>"", 'chart_cpi'=>"", 'chart_a_f'=>"", 'chart_spend'=>""];
            }
            
        } else {
            $response=['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
        }
        $this->output->set_content_type('applicaion/json')->set_output(json_encode($response));
        
    }

}
