<?php if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

require_once __DIR__ . '/../libraries/vendor/autoload.php';


use Facebook\Facebook;
use Facebook\FacebookRequest;
use Facebook\Exceptions\FacebookResponseException;
use Facebook\Exceptions\FacebookSDKException;

class Active extends Web_Controller
{

    var $fb;
    public function __construct() {
        parent::__construct();

        $this->load->model('business_model');
        $this->load->model('business_permissions_model');
        $this->load->model('adaccount_model');
        $this->load->model('publisher_adaccount_model');

        $this->load->library('curl');

        if (!session_id()) {
            session_start();
        }

        $this->fb = new Facebook([
            'app_id' => config_item('APP_ID'),
            'app_secret' => config_item('APP_SECRET'),
            'default_graph_version' => config_item('APP_VERSION')
        ]);

    }
 

    //获取当前使用的token的用户是谁
    private function getMe($token = '')
    {
        $this->load->library('curl');
        //$url = config_item('APP_URL').config_item('APP_VERSION')."/me?fields=businesses.limit(1024),gender,first_name,name,last_name,picture.type(large).redirect(false)&access_token=" . $token;
        $url = config_item('APP_URL').config_item('APP_VERSION')."/me?fields=gender,first_name,name,last_name,picture.type(large).redirect(false)&access_token=" . $token;
        $userinfo = $this->curl->simple_get($url);

        return $userinfo;
    }


    /**
     * 获取token
     * @param  [type] $fb_exchange_token [临时token]
     * @return [type]                    [description]
     */
    private function createToken($fb_exchange_token)
    {

        $url = config_item('APP_URL')."oauth/access_token";


        $tokenstr = $this->curl->simple_post($url, array(
            'grant_type' => 'fb_exchange_token',
            'client_id' => config_item('APP_ID'),
            'client_secret' => config_item('APP_SECRET'),
            'fb_exchange_token' => $fb_exchange_token
        ));
        $queryParts = explode('&', $tokenstr);

        $token = explode('=', $queryParts[0]);
        //$expires = explode('=', $queryParts[1]);
        $expires = 50 * 86500;//有效期为60天，直接搞成50天吧，到50天就在生成一次

        return [$token[1], time() + $expires];
    }



    public function facebook()
    {
        $this->load->model('user_model');
        $this->load->model('company_model');
        $this->load->library('aws_sns');
        

        
        $helper = $this->fb->getRedirectLoginHelper();

        if (!isset($_SESSION['facebook_access_token'])) {
            $_SESSION['facebook_access_token'] = null;
        }

        if (!$_SESSION['facebook_access_token']) {
            $helper = $this->fb->getRedirectLoginHelper();
            try {
                $_SESSION['facebook_access_token'] = (string)$helper->getAccessToken();
            } catch (FacebookResponseException $e) {
                // When Graph returns an error
                echo 'Graph returned an error: ' . $e->getMessage();
                exit;
            } catch (FacebookSDKException $e) {
                // When validation fails or other local issues
                echo 'Facebook SDK returned an error: ' . $e->getMessage();
                exit;
            }
        }
        if ($_SESSION['facebook_access_token']) {

            $userinfo = $this->getMe($_SESSION['facebook_access_token']);
            if (!$userinfo) {
                echo "user error\r\n";
                die();
            }
            list($token, $expires) = $this->createToken($_SESSION['facebook_access_token']);
            if (!$token) {
                echo "error";
                die();
            } 

            $user = json_decode($userinfo, true);

            //获取用户头像
            $filename = $this->get_user_head($user['id']);


            $this->user_model->update_row_by_id($this->userinfo['user_id'], ['facebook_id'=>$user['id'], 'backup'=>$userinfo, 'token'=>$token, 'head'=>$filename, 'token_expires'=>$expires, 'fb_active'=>1]);
            

            $user_info = $this->user_model->get_by_id($this->userinfo['user_id']);
            unset($user_info['password']);
            $this->input->set_cookie("P_INFO", json_encode($user_info), 86500);

            $message = ['event'=>'fetch_facebook_account', 'user_id'=>$this->userinfo['user_id'], 'user_name'=>$this->userinfo['full_name']];
            $this->aws_sns->publish($message);
            
            //$this->adaccount_model->add_account_by_user_id($this->userinfo['user_id'], $this->userinfo['full_name']);
            
        }
        redirect('user/account');
    }

    public function get_user_head($facebook_id)
    {
        $this->load->library('Aws');

        $response = $this->fb->get('/'.$facebook_id.'/picture?type=large&redirect=false', $_SESSION['facebook_access_token']);
        $pagesEdge = $response->getGraphObject();
        $head = $pagesEdge->getProperty('url');
        $data = file_get_contents(str_replace("https", "http", $head));

        $path = "avatar/" . $this->userinfo['user_id'] . ".jpg";
        $this->aws->upload(config_item('Marketmax_Generalfile'), $path, $data);

        return $path;
    }


}