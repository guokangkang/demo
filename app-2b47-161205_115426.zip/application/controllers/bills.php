<?php if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

/**
 *
 * Created by PhpStorm.
 * User: palmax
 * Date: 2016/4/26
 * Time: 15:10
 */
class Bills extends Web_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('bills_model');
        $this->load->model('reports_model');
        $this->load->model('user_model');
        $this->load->model('bills_extend_model');
        $this->load->library('export_pdf');
        $this->data['top_menu']=$this->load->view('web/top_menu_bills', '', TRUE);
    }


    public function listview()
    {

        $date=date('M Y');
        if ($this->input->get('date')) {
            $date=$this->input->get('date');
        }

        $start=date('Y-m-01', strtotime($date));
        $end=date('Y-m-d', strtotime("$start +1 month -1 day"));

        $sql="select sum(spend) as spend,sum(expect_revenue) as earning from marketmax_reports where date>=" . strtotime($start) . " and date<=" . strtotime($end);
        if ($this->userinfo['type']!=0) {
            $sql="select sum(spend) as spend,sum(expect_revenue) as earning from marketmax_reports where publisher_id=".$this->userinfo['user_id']." and date>=" . strtotime($start) . " and date<=" . strtotime($end);
        }
        $data1=$this->reports_model->get_report_data($sql);

        $this->data['data1']=$data1?$data1[0]:[];

        if ($this->userinfo['type']!=0) {
            $bills_data=$this->bills_model->get_query("select sum(results) as results,sum(amount) as amount,bill_id,user_id,user_name,user_type,paid from bills where user_id=".$this->userinfo['user_id']." and date>=" . strtotime($start) . " and date<=" . strtotime($end) . " group by user_id");
        }else{
            $bills_data=$this->bills_model->get_query("select sum(results) as results,sum(amount) as amount,bill_id,user_id,user_name,user_type,paid from bills where  date>=" . strtotime($start) . " and date<=" . strtotime($end) . " group by user_id");
        }

        $advertiser_bill=$publisher_bill=[];
        foreach ($bills_data as & $item) {

            $sql="select sum(money) as money from bills_extend where user_id=" . $item['user_id'] . " and extend_date>=" . strtotime($start) . " and extend_date<=" . strtotime($end);
            $adjust=$this->bills_extend_model->get_query($sql);
            if ($adjust) {
                $item['amount']+=$adjust[0]['money'];
            }

            if ($item['user_type'] == 1) {
                $advertiser_bill[]=$item;
            } else {
                $publisher_bill[]=$item;
            }

        }
        $this->data['advertiser_bill']=$advertiser_bill;
        $this->data['publisher_bill']=$publisher_bill;

        $this->data['date']=$date;

        $this->template->build('bills_listview', $this->data);
    }

    public function detail()
    {

        if ($this->userinfo['type']==0) {
            if (!$this->input->get('user')) {
                redirect("bills");
                return false;
            }
            $user_id=$this->input->get('user');
            $date=$this->input->get('date');
        }else{
            $user_id = $this->userinfo['user_id'];
            $date = date('M Y');
        }
        
        

        $user_info=$this->user_model->get_by_id($user_id);
        if (!$user_info) {
            redirect("bills");
        }
        if (!$date) {
            $date=date('M Y');
        }
        $start=date('Y-m-01', strtotime($date));
        $end=date('Y-m-d', strtotime("$start +1 month -1 day"));


        //用户的详细账单
        $sql="select product_category,user_name,sum(results) as results,sum(amount) as amount,product_name from bills where user_id=" . $user_id . " and date>=" . strtotime($start) . " and date<=" . strtotime($end) . " group by product_id";
        $data=$this->bills_model->get_query($sql);

        //应收
        $sql="select sum(amount) as amount from bills where user_id=" . $user_id . " and date>=" . strtotime($start) . " and date<=" . strtotime($end);
        $data_paid=$this->bills_model->get_query($sql);
        //调整金额
        $sql="select * from bills_extend where user_id=" . $user_id . " and extend_date>=" . strtotime($start) . " and extend_date<=" . strtotime($end) . " order by extend_date desc";
        $adjust=$this->bills_extend_model->get_query($sql);

        $adjust_money=0;
        foreach ($adjust as $item) {
            $adjust_money+=$item['money'];
        }

        $this->data['adjust_money']=$adjust_money;
        $this->data['adjust']=$adjust;

        $this->data['data']=$data;
        $this->data['paid']=$data_paid?$data_paid[0]['amount']:0;
        $this->data['user_info']=$user_info;

        $this->data['date']=$date;
        $this->data['print_url']=site_url('bills/prints?user=').$user_id.'&date='.$date;
        $this->template->build('bills_detail', $this->data);
    }

    public function prints()
    {
       if (!$this->input->get('user')) {
            redirect("bills");
        }
        $user_id=$this->input->get('user');
        $date=$this->input->get('date');

        $user_info=$this->user_model->get_by_id($user_id);
        if (!$user_info) {
            redirect("bills");
        }
        if (!$date) {
            $date=date('M Y');
        }
        $start=date('Y-m-01', strtotime($date));
        $end=date('Y-m-d', strtotime("$start +1 month -1 day"));


        //用户的详细账单
        $sql="select product_category,user_name,sum(results) as results,sum(amount) as amount,product_name from bills where user_id=" . $user_id . " and date>=" . strtotime($start) . " and date<=" . strtotime($end) . " group by product_id";
        $data=$this->bills_model->get_query($sql);

        //应收
        $sql="select sum(amount) as amount from bills where user_id=" . $user_id . " and date>=" . strtotime($start) . " and date<=" . strtotime($end);
        $data_paid=$this->bills_model->get_query($sql);

        //调整金额
        $sql="select * from bills_extend where user_id=" . $user_id . " and extend_date>=" . strtotime($start) . " and extend_date<=" . strtotime($end) . " order by extend_date desc";
        $adjust=$this->bills_extend_model->get_query($sql);

        $adjust_money=0;
        foreach ($adjust as $item) {
            $adjust_money+=$item['money'];
        }

        $this->data['adjust_money']=$adjust_money;
        $this->data['adjust']=$adjust;

        $this->data['data']=$data;
        $this->data['paid']=$data_paid?$data_paid[0]['amount']:0;
        $this->data['user_info']=$user_info;

        $this->data['date']=$date;

        $this->template->build('bills_print', $this->data);
    }


    public function test($value='')
    {
        $page="http://192.168.99.100/marketmax-web/bills/prints";

        $printer="PrinterName";
        if ($ph=printer_open($printer)) {
            $content=get_file_contents($page);

            printer_set_option($ph, PRINTER_MODE, "RAW");
            printer_write($ph, $content);
            printer_close($ph);
        }


        echo "sdf";
        die();
    }

    /**
     * 确认付款
     * @return [type] [description]
     */
    public function confrim_paid_action()
    {
        if ($this->input->is_ajax_request()) {
            $bill=$this->input->post('bill');
            $this->bills_model->update_row_by_id($bill, ['paid'=>1]);
            $response=['success'=>true];
        } else {
            $response=['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
        }
        $this->output->set_content_type('applicaion/json')->set_output(json_encode($response));
    }

    /**
     * 账单pdf
     */
    public function invoice()
    {
        $user_id=$this->input->get('user', true);
        $date=$this->input->get('date', true);
        $start_date=strtotime(date('Y-m-01', strtotime($date)));
        $start_times=date('M d Y', $start_date);
        $end_date=strtotime("{$start_times}+1 month -1 day");
        $where="user_id = '{$user_id}' AND `date` >= '{$start_date}'  AND `date` <= '{$end_date}'";
        $sql="SELECT *,SUM(amount) as amounts FROM bills WHERE {$where}";
        $bills_data=$this->bills_model->get_query($sql);
        $user_info=$this->user_model->get_data('user_name,invoice_company_name,invoice_payto,invoice_address,invoice_phone,invoice_pay_period', ['user_id'=>$user_id]);
        $user_info=$user_info?$user_info[0]:[];
        $bills_data=$bills_data?$bills_data[0]:[];
        if ($bills_data['invoice_start_time'] == 0 || $bills_data['invoice_number'] == 0) {
            list($invoice_num,$time,$last_num)=$this->create_num();
            $bills_data['invoice_number']=$invoice_num?$invoice_num:'';
            $bills_data['invoice_start_time']=strtotime(date('Y-m-d',$time));
            //更新生成次数
            $this->bills_model->update_row_by_fields(['user_id'=>$user_id,'invoice_start_time'=>0],['invoice_start_time'=>$bills_data['invoice_start_time'],'invoice_number'=>$bills_data['invoice_number'],'invoice_times'=>$last_num]);
        }
        $invoice_pay_period=$user_info['invoice_pay_period'];
        $payto=config_item('payto');
        $bills_data['payto']=$payto[$user_info['invoice_payto']];
        $bills_data['invoice_company_name']=$user_info['invoice_company_name'];
        $bills_data['invoice_address']=$user_info['invoice_address'];
        $bills_data['invoice_phone']=$user_info['invoice_phone'];
        $bills_data['start_time']=$start_times;
        $bills_data['invoice_end_time']=date('M d Y',$bills_data['invoice_start_time']+$invoice_pay_period*24*3600);
        $html=$this->load->view('web/invoice', $bills_data, true);
        //echo $html;
        $this->export_pdf->export($html);
    }

    /**
     * 生成invoice号码
     * @param $last_num int
     */
    public function create_num()
    {
        $time=time();
        // 2016-CN-0913001
        $fr_num=date('Y', $time);
        $fr_num.='-CN-';
        $mid_num=date('md', $time);
        $num=$fr_num . $mid_num;
        $last_num=$this->bills_model->get_data('MAX(invoice_times) as t',['invoice_start_time'=>strtotime(date('Y-m-d',$time))]);
        $last_num=$last_num?$last_num[0]['t']+1:1;
        //$last_num=substr(strval($last_num+1000),1,3);
        $last_num=sprintf('%03d', $last_num);
        return [$num . $last_num,$time,$last_num];
    }
}