<?php if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

/**
 * 
 * Created by PhpStorm.
 * User: palmax
 * Date: 2016/4/26
 * Time: 15:10
 */
class Business extends Web_Controller
{
    public function __construct() {
        parent::__construct();

        $this->load->model('offer_model');
        $this->load->model('adaccount_model');
        $this->load->model('company_model');
        $this->load->model('business_model');
        $this->load->model('publisher_offer_model');
        $this->load->model('product_model');
        $this->load->model('user_model');
        $this->load->model('specific_payout_model');
        $this->load->model('publisher_adaccount_model');
        $this->load->model('business_permissions_model');

        $this->load->library('pagination');
        $this->load->library('curl');

        if (!$this->userinfo['business']) {
            redirect('/');
        }

        $this->data['top_menu'] = $this->load->view('web/top_menu_business', '', TRUE);
    }


    public function users()
    {
        //$business = $this->business_model->get_business_admin($this->userinfo['user_id']);
            
        $sql = "select * from business_permissions where market_business_id in (".implode(',', $this->userinfo['business']).")";
        $publisher_list = $this->business_model->get_query($sql);

        $this->data['publisher_list'] = $publisher_list;


        //$sql = "select * from business_permissions where user_id != '' and market_business_id in (".implode(',', $this->userinfo['business']).") group by user_id";
        $sql = "select * from user where type=2 and facebook_id is null";
        $this->data['user_list'] = $this->user_model->get_query($sql);

        $template = 'business_users';
        $this->template->build($template,$this->data);
    }

    /**
     * 废掉
     * @return [type] [description]
     */
    public function accounts()
    {
        //$business = $this->business_model->get_business_admin($this->userinfo['user_id']);

        $account_list = [];
        $sql = "select publisher_adaccount.*,user.facebook_id from publisher_adaccount LEFT JOIN user ON publisher_adaccount.publisher_id = user.user_id where market_business_id in (".implode(',', $this->userinfo['business']).")";
        $account_list = $this->publisher_adaccount_model->get_query($sql);

        $apply_applicaion = [];
        if ($account_list) {
            foreach ($account_list as $offer_item) {

                foreach ($offer_item as $k => $v) {
                    if ($k=='account_id') {
                        $apply_applicaion[$offer_item['business_id']."_".$offer_item['publisher_id']][$k][] = $v."(".$offer_item['account_name'].")";
                    }else{
                        $apply_applicaion[$offer_item['business_id']."_".$offer_item['publisher_id']][$k] = $v;
                    }
                }
            }
        }

        $this->data['account_list'] = $apply_applicaion;

        $template = 'business_accounts';
        $this->template->build($template,$this->data);
    }

    /**
     * 废掉
     * @return [type] [description]
     */
    public function offers()
    {
        $color = ['#D6494B', '#E53B75', '#6D45BC', '#465BD4', '#3583CA', '#37A9B7', '#178D81', '#279566', '#70A532', '#FBC02D', '#E98F2E', '#715146', '#424242', '#263238'];


        $sql = "SELECT publisher_offer.*,publisher_adaccount.business_id,publisher_adaccount.business_name
                    FROM publisher_adaccount LEFT OUTER JOIN publisher_offer ON publisher_adaccount.account_id = publisher_offer.account_id
                    WHERE publisher_offer.status=1 and publisher_adaccount.market_business_id in (".implode(',', $this->userinfo['business']).") GROUP BY publisher_offer.market_account_id";

        $publisher_offer_account = $this->publisher_adaccount_model->get_query($sql);


        $apply_applicaion = [];
        if ($publisher_offer_account) {
            $tmp_color = [];
            foreach ($publisher_offer_account as $offer_item) {

                $letters = "";
                $business_name = $offer_item['business_name'];
                $business_array = explode(" ", $business_name);
                foreach ($business_array as $name) {
                    $letters .= get_first_letters($name);
                }
                $offer_item['letters']  =$letters;

                foreach ($offer_item as $k => $v) {
                    if ($k=='account_id') {
                        $apply_applicaion[$offer_item['product_id'].'_'.$offer_item['publisher_id']][$k][] = $v;
                        $apply_applicaion[$offer_item['product_id'].'_'.$offer_item['publisher_id']]['account'][] = $v."(".$offer_item['account_name'].")";
                    }else{
                        $apply_applicaion[$offer_item['product_id'].'_'.$offer_item['publisher_id']][$k] = $v;
                    }
                }
            }
        }

        $this->data['apply_applicaion'] = $apply_applicaion;


        $template = 'business_offers';
        $this->template->build($template,$this->data);
    }

    /**
     * 通过指定的account获取申请的offer
     * @param  string $value [description]
     * @return [type]        [description]
     */
    public function account_offer()
    {
        if ($this->input->is_ajax_request()) {
            if ($this->input->get('account')) {
                $business = $this->business_model->get_business_admin($this->userinfo['user_id']);
                $accounts = $this->input->get('account');

                $sql = "SELECT offer.countries, publisher_offer.*,publisher_adaccount.business_id,publisher_adaccount.business_name
                    FROM publisher_adaccount LEFT OUTER JOIN publisher_offer ON publisher_adaccount.account_id = publisher_offer.account_id
                    LEFT JOIN offer ON publisher_offer.offer_id = offer.offer_id
                    WHERE publisher_offer.status=1 and publisher_adaccount.account_id in (".$accounts.") and publisher_adaccount.market_business_id in (".implode(',', $business).") GROUP BY publisher_offer.offer_id";
                $publisher_offer_account = $this->publisher_adaccount_model->get_query($sql);

                foreach ($publisher_offer_account as $key => & $value) {
                    list($history, $schedule, $current) = $this->offer_model->get_payout($value['offer_id']);
                    $current && $value['cpa'] = $current['cpa'];
                    $value['countries'] = implode(',', json_decode($value['countries'], true));
                }
                $response = ['success'=>true, 'msg'=>"success", 'data'=>$publisher_offer_account];
            }else{
                $this->output->set_status_header('403');
                $response = ['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
            }
            
        }else{
            $this->output->set_status_header('403');
            $response = ['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
        }
        $this->output->set_content_type('applicaion/json')->set_output(json_encode($response));
    }

    /**
     * 为流量主批量申请offer
     * @param  string $value [description]
     * @return [type]        [description]
     */
    public function apply_offer()
    {

        if (!$this->input->get('offer_ids')) {
            redirect("product/listview");
            die();
        }
        $offer_ids = $this->input->get('offer_ids');

        $offer_array = explode(',', $offer_ids);
        $offer_info = $this->offer_model->get_by_id($offer_array[0]);

        if (!$offer_info) {
            redirect("product/listview");
            die();
        }

        $account_list = [];

        $sql = "select publisher_adaccount.*,user.facebook_id from publisher_adaccount LEFT JOIN user ON publisher_adaccount.publisher_id = user.user_id where market_business_id in (".implode(',', $this->userinfo['business']).") and publisher_adaccount.role='EMPLOYEE'";
        $account_list = $this->publisher_adaccount_model->get_query($sql);

        $account_ids = [];
        foreach ($account_list as $key => $value) {
            $account_ids[] = $value['market_account_id'];
        }


        $publisher_offer_sql = "select * from publisher_offer where market_account_id in (".implode(',', $account_ids).")";
        $publisher_offer = $this->publisher_adaccount_model->get_query($publisher_offer_sql);

        $accounts = [];
        // foreach ($publisher_offer as $key => $value) {
        //     if ($value['advertiser_id'] != $offer_info['user_id']) {
        //         $accounts[] = $value['account_id'];
        //     }
        // }

        $this->data['account_list'] = $account_list;
        $this->data['accounts'] = $accounts;

        $template = 'business_apply_offer';
        $this->template->build($template,$this->data);
    }
 
    /**
     * 提交offer申请
     * @param  string $value [description]
     * @return [type]        [description]
     */
    public function batch_offer_confirm_action()
    {
        if ($this->input->is_ajax_request()) {
            $offer_ids = explode(',', $this->input->post('offer_ids'));
            $account_ids = $this->input->post('account_ids');
            if ($account_ids && $offer_ids) {
                foreach ($offer_ids as $offer_id) {
                    foreach ($account_ids as $key => $account) {
                        list($publisher_id, $market_account_id) = explode('-', $account);
                        $this->offer_model->apply_offer_by_account($offer_id, $market_account_id, $publisher_id);
                    }
                }
            }
            
            $response = ['success'=>true, 'msg'=>"success"];
        }else{
            $this->output->set_status_header('403');
            $response = ['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
        }
        $this->output->set_content_type('applicaion/json')->set_output(json_encode($response));
    }


    /**
     * 为未激活账号绑定pushlisher
     */
    public function add_related_publisher_action()
    {
        if (IS_POST) {
            if (!$this->input->post('business_id') || !$this->input->post('facebook_id')) {
                $this->error($this->lang->line('notice_bad_request'));die();
            }
            $business_id = $this->input->post('business_id');
            $facebook_id = $this->input->post('facebook_id');

            $permissions_info = $this->business_permissions_model->get_by_fields(['business_id'=>$business_id, 'facebook_id'=>$facebook_id]);
            if (!$permissions_info) {
                $this->error($this->lang->line('notice_bad_request'), 'business/users');die();
            }
 
            //$company_info = $this->company_model->get_query("select * from company where bm like '%".$business_id."%'");

            $type = $this->input->post('bind_publisher');
            if ($type==1) {
                $vars['first_name'] = trim($this->input->post('input_first'));
                $vars['last_name'] = trim($this->input->post('input_last'));
                $vars['email'] = trim($this->input->post('input_email'));

                $vars['company'] = 'Palmax';
                $vars['country'] = "CN";
                //$vars['label']   = $label;
                $vars['password'] = password_hash('123456', PASSWORD_DEFAULT);
                $vars['user_name'] = $vars['last_name']." ".$vars['first_name'];

                $vars['facebook_id'] = $facebook_id;
                // if ($company_info) {
                //     $vars['company_id'] = $company_info[0]['company_id'];
                //     $vars['company_account'] = $company_info[0]['account'];
                // }


                $userinfo = $this->user_model->get_by_fields(['email'=>$vars['email']]);
                if ($userinfo) {
                    $this->error("Email has been registered", 'business/users');die();
                }
                $publisher_id = $this->user_model->add_one($vars);
            }else{
                $publisher_id = $this->input->post('select_publisher');

                $user_vars = ['facebook_id'=>$facebook_id];

                $this->user_model->update_row_by_id($publisher_id, $user_vars);

                $vars = $this->user_model->get_by_fields(['user_id'=>$publisher_id]);
            } 

            $userinfo = $this->user_model->get_by_fields(['user_id'=>$publisher_id]);

            $this->adaccount_model->addAccount($publisher_id, $userinfo['user_name'], $facebook_id, $business_id);

            $this->business_permissions_model->update_row_by_id($permissions_info['permissions_id'], ['user_id'=>$publisher_id, 'user_name'=>$vars['user_name']]);

            $this->success($this->lang->line('success_done'), 'business/users');
        }else{
            $this->error($this->lang->line('notice_bad_request'));die();
        }
    }




}



