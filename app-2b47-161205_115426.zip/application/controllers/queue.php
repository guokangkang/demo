<?php if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

/**
 *
 * Created by PhpStorm.
 * User: palmax
 * Date: 2016/4/26
 * Time: 15:10
 */
class Queue extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        //载入SNS类库
        $this->load->library('aws_sqs');
        $this->load->helper('common');
    }


    /**
     * 接受AWS SQS队列
     */
    public function receiver()
    {
        try {
            log_message('debug', 'AWS SQS Message: message received');
            $message=$this->aws_sqs->receive();

            log_message('debug', 'AWS SQS Message: message body: ' . $message);
            $message=json_decode($message, true);

            switch ($message['event']) {
                case 'fetch_account_by_dynamodb'://抓取account、campaign、 adset
                    log_message('debug', 'AWS SQS Message: message event ' . $message['event']);
                    $this->_fetch_account($message['publisher_id'], $message['account_id'], $message['date']);
                    break;
                case 'fetch_adset_insights_by_dynamodb'://抓取adset 统计信息
                    $this->_fetch_adset_insights($message['publisher_id'], $message['data'], $message['date']);
                    break;
                case 'fetch_adset_country_insights_by_dynamodb'://抓取adset 按国家分组以及统计报表
                    $this->_fetch_adset_country_insights_prepare($message['publisher_id'], $message['data'], $message['date']);
                    break;
                case 'fetch_review'://抓取review
                    $this->_fetch_review($message['account_id'], $message['date']);
                    break;
                case 'upload_retention'://上传kika模板留存
                    $this->_upload_retention($message['filename'], $message['bucket'], $message['date']);
                    break;
                case 'upload_retention_appsflyer'://上传appsflyer模板留存
                    $this->_upload_retention_appsflyer($message['filename'], $message['bucket'], $message['date']);
                    break;
                case 'upload_retention_go'://上传go模板留存
                    $this->_upload_retention_go($message['filename'], $message['bucket'], $message['date']);
                    break;
                case 'batch_apply_offer'://上传appsflyer模板留存
                    $this->_upload_batch_apply_offer($message['filename'], $message['bucket']);
                    break;
                case 'fetch_comment':
                    $this->_fetch_comment($message['object_id'], $message['account_id'], $message['ad_id']);
                    break;
                case 'fetch_account_breakdowns_by_dynamodb':
                    $this->_fetch_account_breakdowns($message['publisher_id'], $message['account_id'], $message['date'], $message['breakdowns']);
                    break;
                case 'fetch_adset_breakdowns_insights_by_dynamodb'://抓取adset 统计信息
                    $this->_fetch_adset_breakdowns_insights_prepare($message['publisher_id'], $message['data'], $message['date'], $message['breakdowns']);
                    break;
                case 'fetch_redshift':
                    $this->_fetch_redshift($message['number']);
                    break;
                case 'fetch_adset_country_insights_by_dynamodb_subtask':
                    $this->_fetch_adset_country_insights_subtask_prepare($message['week']);
                    break;
                case 'fetch_adset_breakdowns_insights_by_dynamodb_subtask':
                    $this->_fetch_adset_breakdowns_insights_subtask_prepare($message['week']);
                    break;
                case 'fetch_appsflyer':
                    $this->_fetch_appsflyer($message['app_id'], $message['start_date'], $message['end_date'], $message['retention_day']);
                    break;
                case 'sync_creative_statistics':
                    $this->_sync_creative_statistics();
                    break;
                case 'fetch_to_s3':
                    $this->_fetch_to_s3($message['path'], $message['url']);
                    break;
                case 'create_bills':
                    $this->_create_bills($message['user_id'], $message['user_type'], $message['date']);
                    break;
                case 'sync_retention_tmp':
                    $this->_sync_retention_tmp($message['date']);
                    break;
                default:
                    break;
            }

            $this->output->set_status_header('200');
        } catch (Exception $e) {

            fetch_exception("", $message['event'], $e->getMessage(), "队列接收异常");

            log_message('error', 'AWS SQS Message: ' . $e->getMessage());
            $this->output->set_status_header('500');
        }
    }


    /**
     * 同步数据
     * @return [type] [description]
     */
    public function push_sync()
    {
        if (getenv('APP_ENVIRONMENT') != 'production') {
            return false;
        }

        //$task = ['sync_creative_statistics'=>[0, 1, 2], 'sdfds'=>[2, 3]]
        $task=['sync_creative_statistics'=>[0]];

        $hour=date('H');
        foreach ($task as $event=>$hours) {
            if (in_array($hour, $hours)) {
                $this->aws_sqs->deliver(['event'=>$event]);
            }
        }
    }


    public function push_tmp()
    {
        $date = "2016-09-01";
        
        for ($i=0; $i < 62; $i++) {
            $message=array('event'=>'sync_retention_tmp', 'date'=>$date);
            // $this->_sync_retention_tmp($date);
            $this->aws_sqs->deliver($message);

            $d = strtotime("$date +1 day");
            $date = date('Y-m-d', $d);
        }
    }


    /**
     * dynamodb to redshift
     * @return [type] [description]
     */
    public function push_redshift()
    {
        if (getenv('APP_ENVIRONMENT') != 'production') {
            return false;
        }

        for ($i=1; $i <= 12; $i++) {
            $message=array('number'=>$i, 'event'=>'fetch_redshift');
            $this->aws_sqs->deliver($message);
        }
        log_message("debug", "queue_redshift_data: " . date('Y-m-d') . " Push Done");
    }


    public function push_breakdowns()
    {
        if (getenv('APP_ENVIRONMENT') != 'production') {
            return false;
        }


        // if (!$this->input->get('breakdowns')) {
        //     echo "error";die();
        // }
        //$breakdowns_list=['age', 'gender', 'impression_device', 'region', 'hourly_stats_aggregated_by_audience_time_zone', 'placement', 'age_gender'];
        $breakdowns_list=['gender', 'age', 'placement'];

        // $breakdowns = $this->input->get('breakdowns');
        // if (!in_array($breakdowns, $breakdowns_list)) {
        //     echo "error";die();
        // }

        //默认多当前月
        $date=date('Y-m-d');
        $days=date('d');

        if ($this->input->get('date')) {
            $date=$this->input->get('date');
            $days=date('d', strtotime($date));
            $days=$days > 0?$days:1;
        }

        if ($this->input->get('month')) {
            if ($this->input->get('month') == 'last_month') {
                $date=date('Y-m', strtotime($date));

                $month=date('m', strtotime($date)); //取当前月份
                if ($month == 1) { //如果当前1月的话，处理下
                    $month=12;
                } else {
                    $month=$month - 1; //获得上个月月份
                }

                $year=date('Y', strtotime($date));
                $days=cal_days_in_month(CAL_GREGORIAN, $month, $year);
                $days+=1;
            } elseif ($this->input->get('month') == 'this_month') {
                $date=date('Y-m-d');
                $days=date('d');
            }
        } else {
            if ($this->input->get('days')) {
                $days=$this->input->get('days');
            }
        }

        $this->load->model('publisher_offer_model');
        $sql="SELECT * FROM publisher_offer
                WHERE STATUS = 1  and account_id in ('980704358672590', '907182572713152', '907182499379826')
                GROUP BY account_id";
        $accountlist=$this->publisher_offer_model->get_query($sql);


        $account_ids=$this->remove_account_list();

        if ($accountlist) {
            foreach ($breakdowns_list as $item) {
                for ($i=0; $i < $days; $i++) {
                    $sync_date=date('Y-m-d', strtotime($date) - $i * 86400);
                    foreach ($accountlist as $key=>$value) {
                        if (in_array($value['account_id'], $account_ids)) {
                            continue;
                        }

                        log_message("debug", "queue_adset_breakdowns_data: Push Account ID:" . $value['account_id']);
                        $message=array('publisher_id'=>$value['publisher_id'], 'account_id'=>$value['account_id'], 'date'=>$sync_date, 'breakdowns'=>$item, 'event'=>'fetch_account_breakdowns_by_dynamodb');
                        $this->aws_sqs->deliver($message);
                    }
                    log_message("debug", "queue_adset_data: " . $sync_date . " Push Done");
                }
            }

        }
    }


    /**
     * 同步appsflyer数据
     * @param  string $value [description]
     * @return [type]        [description]
     */
    public function push_appsflyer()
    {
        if (getenv('APP_ENVIRONMENT') != 'production') {
            return false;
        }
        $this->load->model("product_model");
        $sql="select * from product where retention_day>0";
        if ($this->input->get('product_id')) {
            $sql.=" and product_id=" . $this->input->get('product_id');
        }
        $list=$this->product_model->get_query($sql);

        $start_date=$end_date=date('Y-m-d');

        if ($this->input->get('start')) {
            $start_date=$this->input->get('start');
        }
        if ($this->input->get('end')) {
            $end_date=$this->input->get('end');
        }

        if ($this->input->get('days')) {
            $days=$this->input->get('days');
            $end_date=date('Y-m-d');
            $start_date=date('Y-m-d', strtotime("-" . $days . " day"));
        }


        foreach ($list as $key=>$value) {
            if ($value['category'] == 'ios') {
                $value['app_id']="id" . $value['app_id'];
            }

            if ($value['retention_updated_time'] > 0 && $value['retention_updated_time'] + 3.5 * 3600 > time()) {
                continue;
            }

            log_message("debug", "queue_appsflyer_data: Push Product ID:" . $value['product_id']);
            $message=array('app_id'=>$value['app_id'], 'end_date'=>$end_date, 'start_date'=>$start_date, 'event'=>'fetch_appsflyer', 'retention_day'=>$value['retention_day']);
            $s=$this->aws_sqs->deliver($message);

            sleep(60);
        }
        log_message("debug", "queue_appsflyer_data: " . $date . " Push Done");
    }


    /**
     * push报表统计队列
     * @return [type] [description]
     */
    public function push_account()
    {
        if (getenv('APP_ENVIRONMENT') != 'production') {
            return false;
        }
        //默认多当前月
        $date=date('Y-m-d');
        $days=date('d');

        if ($this->input->get('date')) {
            $date=$this->input->get('date');
            $days=date('d', strtotime($date));
            $days=$days > 0?$days:1;
        }

        if ($this->input->get('month')) {
            if ($this->input->get('month') == 'last_month') {
                $date=date('Y-m', strtotime($date));

                $month=date('m', strtotime($date)); //取当前月份
                if ($month == 1) { //如果当前1月的话，处理下
                    $month=12;
                } else {
                    $month=$month - 1; //获得上个月月份
                }

                $year=date('Y', strtotime($date));
                $days=cal_days_in_month(CAL_GREGORIAN, $month, $year);
                $days+=1;
            } elseif ($this->input->get('month') == 'this_month') {
                $date=date('Y-m-d');
                $days=date('d');
                if ($days <= 7) {
                    log_message("debug", "queue_adset_data: " . $date . " Push Done");
                    return false;
                }
                $date=date('Y-m-d', strtotime("-7 day"));
                $days=$days - 7;
            }
        } else {
            if ($this->input->get('days')) {
                $days=$this->input->get('days');
            }
        }

        $this->load->model('publisher_offer_model');
        $sql="SELECT * FROM publisher_offer
                WHERE STATUS = 1
                GROUP BY account_id";

        if ($this->input->get('account')) {
            $sql = "SELECT * FROM publisher_offer
                WHERE STATUS = 1 and account_id=".$this->input->get('account')."
                GROUP BY account_id";
        }
        $accountlist = $this->publisher_offer_model->get_query($sql);        


        for ($i=1; $i <= 55; $i++) { //清除所有包含Week的键值
            $w=$i < 10?"0" . $i:$i;

            $this->redis->del("fetch_adset_insights_" . $w);//初始化adset list
        }

        $account_ids=$this->remove_account_list();

        if ($accountlist) {

            for ($i=0; $i < $days; $i++) {
                $sync_date=date('Y-m-d', strtotime($date) - $i * 86400);

                foreach ($accountlist as $key=>$value) {

                    if (in_array($value['account_id'], $account_ids)) {
                        continue;
                    }
                    log_message("debug", "queue_adset_data_account: Push Account ID:".$value['account_id']);
                    $message = array('publisher_id' => $value['publisher_id'], 'account_id' => $value['account_id'], 'date'=>$sync_date, 'event'=>'fetch_account_by_dynamodb');
                    $s = $this->aws_sqs->deliver($message); 

                }
                log_message("debug", "queue_adset_data: " . $sync_date . " Push Done");
            }
        }


    }


    /**
     * push报表统计队列
     * @return [type] [description]
     */
    public function push_account_last_week()
    {
        $this->load->model('publisher_offer_model');
        $sql="SELECT * FROM publisher_offer
                WHERE STATUS = 1  
                GROUP BY account_id";
        $accountlist=$this->publisher_offer_model->get_query($sql);

        $last_week7=date('Y-m-d', strtotime('-1 sunday', time()));

        if ($accountlist) {
            for ($i=0; $i < 7; $i++) {
                $date=date('Y-m-d', strtotime("-$i day", strtotime($last_week7)));

                foreach ($accountlist as $key=>$value) {
                    log_message("debug", "queue_adset_data: Push Account ID:" . $value['account_id']);
                    $message=array('publisher_id'=>$value['publisher_id'], 'account_id'=>$value['account_id'], 'date'=>$date, 'event'=>'fetch_account');
                    $this->aws_sqs->deliver($message);
                }
            }
        }

        log_message("debug", "queue_adset_data: " . $date . " Push Done");
    }


    /**
     * push review队列
     * @param  string $value [description]
     * @return [type]        [description]
     */
    public function push_review()
    {
        if (getenv('APP_ENVIRONMENT') != 'production') {
            return false;
        }

        //默认多当前月
        $date=date('Y-m-d');
        $days=date('d');

        if ($this->input->get('date')) {
            $date=$this->input->get('date');
            $days=date('d', strtotime($date));
            $days=$days > 0?$days:1;
        }

        if ($this->input->get('month')) {
            if ($this->input->get('month') == 'last_month') {
                $date=date('Y-m', strtotime($date));

                $month=date('m', strtotime($date)); //取当前月份
                if ($month == 1) { //如果当前1月的话，处理下
                    $month=12;
                } else {
                    $month=$month - 1; //获得上个月月份
                }

                $year=date('Y', strtotime($date));
                $days=cal_days_in_month(CAL_GREGORIAN, $month, $year);
                $days+=1;
            } elseif ($this->input->get('month') == 'this_month') {
                $date=date('Y-m-d');
                $days=date('d');
            }
        } else {
            if ($this->input->get('days')) {
                $days=$this->input->get('days');
            }
        }


        $this->load->model('publisher_offer_model');
        $sql="SELECT * FROM publisher_offer
                WHERE STATUS = 1  
                GROUP BY account_id";
        $accountlist=$this->publisher_offer_model->get_query($sql);

        $account_ids=$this->remove_account_list();

        for ($i=0; $i < $days; $i++) {
            $sync_date=date('Y-m-d', strtotime($date) - $i * 86400);
            foreach ($accountlist as $data) {
                if (in_array($data['account_id'], $account_ids)) {
                    continue;
                }

                log_message("debug", "queue_review_data: Push Account ID:" . $data['account_id'] . " Date : " . $sync_date);
                $message=array('account_id'=>$data['account_id'], 'date'=>$sync_date, 'event'=>'fetch_review');
                $this->aws_sqs->deliver($message);
            }
            log_message("debug", "queue_review_data: " . date('Y-m-d') . " Push Done");
        }
    }


    public function push_comment()
    {
        if (getenv('APP_ENVIRONMENT') != 'production') {
            return false;
        }
        $this->load->model('ad_model');
        $data=$this->ad_model->get_query("select * from ad where object_story_id is not null and effective_status='ACTIVE' group by ad_id");

        foreach ($data as $item) {
            $message=array('object_id'=>$item['object_story_id'], 'account_id'=>$item['account_id'], 'ad_id'=>$item['ad_id'], 'event'=>'fetch_comment');
            $this->aws_sqs->deliver($message);
            //$this->_fetch_comment($item['object_story_id'], $item['account_id'], $item['ad_id']);
        }
        log_message("debug", "queue_comment_data: " . date('Y-m-d') . " Push Done");
    }


    /**
     * 发起账单生成
     * @return bool
     */
    public function push_bills()
    {
        if (getenv('APP_ENVIRONMENT') != 'production') {
            return false;
        }
        try {
            $sync_date=date('Y-m-d', strtotime("-1 day"));
            $this->load->model('user_model');
            $sql="SELECT * FROM user WHERE STATUS = 1";
            $user_list=$this->user_model->get_query($sql);
            foreach ($user_list as $item) {
                $message=array('user_id'=>$item['user_id'], 'user_type'=>$item['type'], 'date'=>$sync_date, 'event'=>'create_bills');
                //$this->_create_bills($message['user_id'],$message['user_type'],$sync_date);
                $this->aws_sqs->deliver($message);
            }
            log_message("debug", "create_bills: " . $sync_date . " Push Done");
        } catch (Exception $e) {
            log_message('error', 'Pushe Bill AWS SQS Message: ' . $e->getMessage());
        }
    }


    /**
     * 执行抓取任务的私有方法
     */
    private function _fetch_account($publisher_id, $account_id, $date)
    {
        try {
            $this->load->library('fetch_adset_data');
            $start=time();
            log_message('debug', "queue_adset_data: fetch account started -> " . date('Y-m-d H:i:s') . " Account ID -> " . $account_id);
            $result=$this->fetch_adset_data->sync($publisher_id, $account_id, $date);
            $end=time();
            log_message('debug', "queue_adset_data: fetch account completed -> " . date('Y-m-d H:i:s') . " Account ID -> " . $account_id . ' Duration -> ' . ($end - $start));
        } catch (Exception $e) {

            fetch_exception($account_id, 'fetch_account', $e->getMessage(), $date);

            log_message('error', 'AWS SQS Message: ' . $e->getMessage());
        }

    }

    public function _fetch_adset_country_insights_subtask_prepare($week)
    {
        $this->load->library('fetch_adset_data');

        for ($i=1; $i <= 100; $i++) {
            $key="fetch_adset_insights_" . $week;

            $message=$this->redis->spop($key);
            $message=json_decode($message, true);

            if (!$message || !$message['data']) {
                log_message('error', "redis is empty");
                continue;
            }

            log_message('debug', "queue_adset_data: " . $message['data']['account_id'] . '_' . $message['data']['adset_id'] . " adset fetch " . $message['date']);
            $this->_fetch_adset_country_insights($message['publisher_id'], $message['data'], $message['date']);
        }
    }


    public function _fetch_adset_country_insights_prepare($publisher_id, $adset_data, $date)
    {
        $this->load->library('fetch_adset_data');

        foreach ($adset_data as $data) {
            $this->_fetch_adset_country_insights($publisher_id, $data, $date);
        }
    }

    /**
     * 执行抓取任务的私有方法
     */
    private function _fetch_adset_country_insights($publisher_id, $data, $date)
    {
        try {
            $result=$this->fetch_adset_data->setAdSetCountryInsightForQueue($publisher_id, $data, $date);
        } catch (Exception $e) {
            fetch_exception($data['account_id'], 'fetch_adset_country_insights', $data['adset_id'] . '---' . $e->getMessage(), $date);
            log_message('error', 'AWS SQS Message: ' . $e->getMessage());
        }
    }


    public function _fetch_account_breakdowns($publisher_id, $account_id, $date, $breakdowns)
    {
        try {
            $this->load->library('fetch_adset_breakdowns_data');
            $start=time();
            log_message('debug', "queue_adset_data: fetch account breakdowns started -> " . date('Y-m-d H:i:s') . " Account ID -> " . $account_id);
            $result=$this->fetch_adset_breakdowns_data->sync($publisher_id, $account_id, $date, $breakdowns);
            $end=time();
            log_message('debug', "queue_adset_data: fetch account breakdowns completed -> " . date('Y-m-d H:i:s') . " Account ID -> " . $account_id . ' Duration -> ' . ($end - $start));
        } catch (Exception $e) {

            fetch_exception($account_id, 'fetch_account_breakdowns', $e->getMessage(), $date);

            log_message('error', 'AWS SQS Message: ' . $e->getMessage());
        }
    }

    public function _fetch_adset_breakdowns_insights_subtask_prepare($week)
    {
        $this->load->library('fetch_adset_breakdowns_data');

        for ($i=1; $i <= 100; $i++) {
            $key="fetch_adset_breakdowns_insights_" . $week;

            $message=$this->redis->spop($key);
            $message=json_decode($message, true);

            if (!$message || !$message['data']) {
                log_message('error', json_encode($message));
                continue;
            }

            log_message('debug', "queue_adset_breakdowns_data: " . $message['data']['account_id'] . '_' . $message['data']['adset_id'] . " adset fetch " . $message['date'] . " breakdowns->" . $message['breakdowns']);
            $this->_fetch_adset_breakdowns_insights($message['publisher_id'], $message['data'], $message['date'], $message['breakdowns']);
        }
    }

    public function _fetch_adset_breakdowns_insights_prepare($publisher_id, $adset_data, $date, $breakdowns)
    {
        $this->load->library('fetch_adset_breakdowns_data');

        foreach ($adset_data as $data) {
            $this->_fetch_adset_breakdowns_insights($publisher_id, $data, $date, $breakdowns);
        }
    }

    public function _fetch_adset_breakdowns_insights($publisher_id, $adset_info, $date, $breakdowns)
    {
        try {
            $this->fetch_adset_breakdowns_data->setAdSetBreakdownsInsightForQueue($publisher_id, $adset_info, $breakdowns, $date);

        } catch (Exception $e) {
            fetch_exception($adset_info['account_id'], 'fetch_adset_breakdowns_insights', $adset_info['adset_id'] . '---' . $e->getMessage(), $date);

            log_message('error', 'AWS SQS Message: ' . $e->getMessage());
        }
    }

    /**
     * 执行抓取任务的私有方法
     */
    private function _fetch_adset_insights($publisher_id, $data, $date)
    {
        try {
            $this->load->library('fetch_adset_data');
            $start=time();
            log_message('debug', "queue_adset_data: fetch adset insights started -> " . date('Y-m-d H:i:s') . " Adset ID -> " . $data['adset_id']);
            $result=$this->fetch_adset_data->setAdSetInsight($publisher_id, $data, $date);
            $end=time();
            log_message('debug', "queue_adset_data: fetch adset insights completed -> " . date('Y-m-d H:i:s') . " Adset ID -> " . $data['adset_id'] . ' Duration -> ' . ($end - $start));
        } catch (Exception $e) {
            fetch_exception($data['account_id'], 'fetch_adset_insights', $e->getMessage(), $date);

            log_message('error', 'AWS SQS Message: ' . $e->getMessage());
        }
    }

    /**
     * 抓取创意信息
     * @param  [type] $market_account_id [description]
     * @return [type]                    [description]
     */
    private function _fetch_review($account_id, $date)
    {
        try {
            $this->load->library('review');
            $start=time();
            log_message('debug', "queue_review_data: fetch review started -> " . date('Y-m-d H:i:s') . " Adset ID -> " . $account_id);
            $result=$this->review->sync($account_id, $date);
            $end=time();
            log_message('debug', "queue_review_data: fetch review completed -> " . date('Y-m-d H:i:s') . " Adset ID -> " . $account_id . ' Duration -> ' . ($end - $start));
        } catch (Exception $e) {
            fetch_exception($account_id, 'fetch_review', $e->getMessage());

            log_message('error', 'AWS SQS Message: ' . $e->getMessage());
        }
    }

    public function _fetch_comment($object_id, $account_id, $ad_id)
    {
        try {
            $this->load->library('review');
            $start=time();
            log_message('debug', "queue_ad_comment_data: fetch comment started -> " . date('Y-m-d H:i:s') . " Object ID -> " . $object_id);
            $result=$this->review->fetch_ad_comment($object_id, $account_id, $ad_id);
            $end=time();
            log_message('debug', "queue_ad_comment_data: fetch comment completed -> " . date('Y-m-d H:i:s') . " Object ID -> " . $object_id . ' Duration -> ' . ($end - $start));
        } catch (Exception $e) {
            fetch_exception($object_id, 'fetch_comment', $e->getMessage());

            log_message('error', 'AWS SQS Message: ' . $e->getMessage());
        }
    }

    /**
     * 批量申请offer
     * @param  [type] $filename [description]
     * @param  [type] $bucket   [description]
     * @return [type]           [description]
     */
    public function _upload_batch_apply_offer($filename, $bucket)
        //public function upload_batch_apply_offer()
    {
        // $bucket = config_item('Marketmax_Generalfile');
        // $filename = "apply_offer/14759944337375.csv";
        $this->load->library('excelreader');
        $this->load->library('aws');
        $this->load->model('publisher_adaccount_model');
        $this->load->model('offer_model');

        log_message('debug', "batch_apply_offer: upload start -> " . date('Y-m-d H:i:s') . " Filename -> " . $filename);
        try {
            $filename=$this->aws->getPath($bucket, $filename);

            $this->load->library('aws_dynamodb');

            $data=$this->excelreader->getExcelInfo($filename);
            $result=[];
            if ($data && $data['result']) {

                foreach ($data['result'] as $key=>$row) {
                    if ($key == 0 || $key == 1) {
                        continue;
                    }
                    $account_id=trim($row[0]);
                    $advertiser_id=trim($row[1]);
                    $product_id=trim($row[2]);
                    $accounts=$offers=[];
                    if ($product_id) {
                        $sql='select * from offer where product_id=' . $product_id;
                        $offer_list=$this->offer_model->get_query($sql);
                        foreach ($offer_list as $item) {
                            $offers[]=$item['offer_id'];
                        }
                    }


                    $info=$this->publisher_adaccount_model->get_by_fields(['account_id'=>$account_id]);
                    if (!$info) {
                        continue;
                    }
                    if (!$offers) {
                        $sql='select * from offer where user_id=' . $advertiser_id;
                        $offer_list=$this->offer_model->get_query($sql);
                        foreach ($offer_list as $item) {
                            $offers[]=$item['offer_id'];
                        }
                    }
                    $accounts[]=$info['market_account_id'];

                    if ($offers) {
                        foreach ($offers as $offer_id) {
                            $this->offer_model->apply_offer($offer_id, $accounts, $info['publisher_id'], $info['publisher_name'], 1);
                        }
                    }
                }
            } else {
                log_message('error', "batch_apply_offer: upload data is empty -> " . date('Y-m-d H:i:s') . " Filename -> " . $filename);
            }
        } catch (Exception $e) {
            log_message('error', 'AWS SQS Message: ' . $e->getMessage());
            fetch_exception($filename, 'batch_apply_offer', $e->getMessage());
        }
    }


    /**
     * 更新留存数据
     * @param  [type] $filename [description]
     * @return [type]           [description]
     */
    public function _upload_retention($filename, $bucket, $date_params)
        //public function upload_retention()
    {
        // $bucket = config_item('Marketmax_Generalfile');
        // $filename = "retention_report/146962319727.csv";
        // $date_params = "2016/7/20";


        $retention_file = $filename;

        $this->load->library('excelreader');
        $this->load->library('aws');

        log_message('debug', "queue_upload_retention: upload start -> " . date('Y-m-d H:i:s') . " Filename -> " . $filename);
        try {
            $filename=$this->aws->getPath($bucket, $filename);
            $this->load->model('adset_retention_model');
            $this->load->model('product_model');

            $this->load->library('aws_dynamodb');

            $data=$this->excelreader->getExcelInfo($filename);
            $result=[];
            if ($data && $data['result']) {
                $this->load->library('fetch_adset_data');
                foreach ($data['result'] as $key=>$row) {
                    $vars=[];

                    if (strtotime($row[0]) != strtotime($date_params)) {
                        continue;
                    }
                    if (strlen($row[1]) != 2) {

                        $start=strpos($row[1], '(');
                        $end=strpos($row[1], ')');
                        $adset=substr($row[1], $start + 1, $end - $start - 1);
                    } else {

                        $date=strtotime($row[0]);

                        $table_name='marketmax_reports_' . date('Y', $date);
                        $key=['adset_id_country'=>$adset . "_" . strtoupper($row[1]), 'date'=>$date];

                        $report_info=$this->aws_dynamodb->getItem($table_name, json_encode($key));

                        if (!$report_info) {
                            continue;
                        }
                        $product_info=$this->product_model->get_by_fields(['app_id'=>$report_info['app_id']]);
                        if (!$product_info) {
                            continue;
                        }

                        if ($product_info['retention_day'] <= 0) {
                            continue;
                        }

                        if (!isset($row[2 + $product_info['retention_day']])) {
                            continue;
                        }


                        $retention=$row[2] > 0?$row[2 + $product_info['retention_day']] / $row[2]:0;
                        $vars=['country'=>strtoupper($row[1]), 'date'=>strtotime($row[0]), 'retention'=>$retention, 'adset_id'=>$adset, 'day0'=>$row[2]];

                        $country=strtoupper($row[1]);

                        for ($i=2; $i <= 30; $i++) {
                            if (isset($row[$i])) {
                                $vars['day' . ($i - 2)]=intval($row[$i]);
                            }
                        }


                        $vars['product_id']=$report_info['product_id'];
                        $vars['advertiser_id']=$report_info['advertiser_id'];
                        //$vars['publisher_id'] = $report_info['publisher_id'];
                        $vars['adset_name']=$report_info['adset_name'];

                        $vars['account_id']=$report_info['account_id'];
                        $vars['account_name']=$report_info['account_name'];
                        $vars['campaign_id']=$report_info['campaign_id'];
                        $vars['campaign_name']=$report_info['campaign_name'];

                        $retention_tmp = $this->get_retention_info($vars['product_id'], $vars['date'], $vars['country']);
                        if ($retention_tmp) {
                            $value['cpa'] = $retention_tmp['cpa'];
                            $value['retention_info'] = $retention_tmp['retention_info'];
                        }

                        $info=$this->adset_retention_model->get_by_fields(['adset_id'=>$adset, 'country'=>strtoupper($row[1]), 'date'=>strtotime($row[0])]);
                        if ($info) {
                            $this->adset_retention_model->update_row_by_id($info['retention_id'], $vars);
                        } else {
                            $this->adset_retention_model->add_one($vars);
                        }
                        if (!$product_info['retention_updated_time'] || $product_info['retention_updated_time']<$vars['date']) {
                            $this->product_model->update_row_by_id($vars['product_id'], ['retention_updated_time'=>$vars['date'], 'retention_updated_file'=>$retention_file]);
                        }
                        //更新报表数据
                        $this->fetch_adset_data->update_revenue_by_retention(strtotime($row[0]), $adset, strtoupper($row[1]));
                    }
                }
            } else {
                log_message('error', "queue_upload_retention: upload data is empty -> " . date('Y-m-d H:i:s') . " Filename -> " . $filename);
            }
        } catch (Exception $e) {
            log_message('error', 'AWS SQS Message: ' . $e->getMessage());
            fetch_exception($filename, 'upload_retention', $e->getMessage());
        }

    }


    /**
     * 更新留存数据
     * @param  [type] $filename [description]
     * @return [type]           [description]
     */
    public function _upload_retention_appsflyer($filename, $bucket, $date_params)
    // public function upload_retention_appsflyer()
    {
        // $bucket = config_item('Marketmax_Generalfile');
        // $retention_file = $filename = "retention_report/14769517893940.csv";
        // $date_params = "2016/10/13";

        $retention_file = $filename;

        $this->load->library('excelreader');
        $this->load->library('aws');
        $this->load->model('reports_model');

        log_message('debug', "queue_upload_retention_appsflyer: upload start -> " . date('Y-m-d H:i:s') . " Filename -> " . $filename);
        try {
            $filename=$this->aws->getPath($bucket, $filename);
            $this->load->model('adset_retention_model');
            $this->load->model('product_model');
            $this->load->model('offer_model');

            $this->load->library('aws_dynamodb');

            $data=$this->excelreader->getExcelInfo($filename);
            $result=[];
            if ($data && $data['result']) {
                $this->load->library('fetch_adset_data');
                foreach ($data['result'] as $key=>$row) {
                    $vars=[];
                    if ($key == 0) {
                        continue;
                    }
                    if (strtotime($row[0]) != strtotime($date_params)) {
                        continue;
                    }

                    $date=strtotime($row[0]);

                    $adset_name=$row[2];
                    if ($s=strpos($adset_name, "_Instagram")) {
                        $adset_name=substr($adset_name, 0, $s);
                    }

                    if ($s=strpos($adset_name, "_AudienceNetwork")) {
                        $adset_name=substr($adset_name, 0, $s);
                    }

                    $campaign_name=$row[1];
                    if ($s=strpos($campaign_name, "_Instagram")) {
                        $campaign_name=substr($campaign_name, 0, $s);
                    }


                    if ($s=strpos($campaign_name, "_AudienceNetwork")) {
                        $campaign_name=substr($campaign_name, 0, $s);
                    }
                    $report_info=$this->reports_model->get_report_data("select adset_id,adset_name,product_id,advertiser_id,app_id,account_id,account_name,campaign_id,campaign_name from marketmax_reports where campaign_name='" . $campaign_name . "' and adset_name='" . $adset_name . "' limit 1");

                    if (!$report_info) {
                        continue;
                    }
                    $report_info=$report_info[0];
                    $adset=$report_info['adset_id'];

                    $product_info=$this->product_model->get_by_fields(['app_id'=>$report_info['app_id']]);
                    if (!$product_info) {
                        continue;
                    }

                    if ($product_info['retention_day'] <= 0) {
                        continue;
                    }

                    if (!isset($row[4 + $product_info['retention_day']])) {
                        continue;
                    }

                    $retention=$row[4] > 0?$row[4 + $product_info['retention_day']] / $row[4]:0;
                    $vars=['country'=>strtoupper($row[3]), 'date'=>strtotime($row[0]), 'retention'=>$retention, 'adset_id'=>$adset, 'day0'=>$row[4]];

                    $country=strtoupper($row[3]);

                    for ($i=4; $i <= 34; $i++) {
                        if (isset($row[$i])) {
                            $vars['day' . ($i - 4)]=intval($row[$i]);
                        }
                    }


                    $vars['product_id']=$report_info['product_id'];
                    $vars['advertiser_id']=$report_info['advertiser_id'];
                    $vars['adset_name']=$report_info['adset_name'];

                    $vars['account_id']=$report_info['account_id'];
                    $vars['account_name']=$report_info['account_name'];
                    $vars['campaign_id']=$report_info['campaign_id'];
                    $vars['campaign_name']=$report_info['campaign_name'];

                    if (!$product_info['retention_updated_time'] || $product_info['retention_updated_time']<$vars['date']) {
                        $this->product_model->update_row_by_id($vars['product_id'], ['retention_updated_time'=>$vars['date'], 'retention_updated_file'=>$retention_file]);
                    }

                    if (isset($result[$vars['adset_id'] . '_' . $vars['country'] . '_' . $vars['date']])) {
                        for ($i=0; $i <= 31; $i++) {
                            if (isset($result[$vars['adset_id'] . '_' . $vars['country'] . '_' . $vars['date']]["day" . $i]) && isset($vars["day" . $i])) {
                                $result[$vars['adset_id'] . '_' . $vars['country'] . '_' . $vars['date']]["day" . $i]+=$vars["day" . $i];
                            }
                        }
                    } else
                        $result[$vars['adset_id'] . '_' . $vars['country'] . '_' . $vars['date']]=$vars;

                }
                foreach ($result as $key=>$value) {
                    $vars = $this->get_retention_info($value['product_id'], $value['date'], $value['country']);
                    
                    $info=$this->adset_retention_model->get_by_fields(['adset_id'=>$value['adset_id'], 'country'=>strtoupper($value['country']), 'date'=>$value['date']]);
                    
                    if ($vars) {
                        $value['cpa'] = $vars['cpa'];
                        $value['retention_info'] = $vars['retention_info'];
                    }
                    if ($info) {
                        $this->adset_retention_model->update_row_by_id($info['retention_id'], $value);
                    } else {
                        $this->adset_retention_model->add_one($value);
                    }
                    //更新报表数据
                    $this->fetch_adset_data->update_revenue_by_retention($value['date'], $value['adset_id'], strtoupper($value['country']));
                }
            } else {
                log_message('error', "queue_upload_retention: upload data is empty -> " . date('Y-m-d H:i:s') . " Filename -> " . $filename);
            }
        } catch (Exception $e) {
            log_message('error', 'AWS SQS Message: ' . $e->getMessage());
            fetch_exception($filename, 'upload_retention', $e->getMessage());
        }

    }


    /**
     * 更新留存数据
     * @param  [type] $filename [description]
     * @return [type]           [description]
     */
    public function _upload_retention_go($filename, $bucket, $date_params)
    //public function upload_retention_go()
    {
        // $bucket = config_item('Marketmax_Generalfile');
        // $filename = "retention_report/1477293704698.csv";
        // $date_params = "2016/10/22";
        
        $retention_file = $filename;
        
        $this->load->library('excelreader');
        $this->load->library('aws');
        $this->load->model('reports_model');
        
        log_message('debug', "queue_upload_retention_appsflyer: upload start -> " . date('Y-m-d H:i:s') . " Filename -> ".$filename);
        try{
            $filename = $this->aws->getPath($bucket, $filename);            
            $this->load->model('adset_retention_model');
            $this->load->model('product_model');
            $this->load->model('offer_model');

            $this->load->library('aws_dynamodb');
            
            $data = $this->excelreader->getExcelInfo($filename);
            $result = [];
            if ($data && $data['result']) {
                $this->load->library('fetch_adset_data');
                foreach ($data['result'] as $key => $row) {

                    $vars = [];
                    if ($key==0) {
                        continue;
                    }
                    if (strtotime($row[0])!=strtotime($date_params)) {
                        continue;
                    }
                    $row[3] = intval($row[3]);
                    $row[4] = intval($row[4]);
                    
                    $date = strtotime($row[0]);

                    $campaign_name = $row[1];
                    if ($s = strpos($campaign_name, "_instagram")) {
                        $campaign_name = substr($campaign_name, 0, $s);
                    }

                    
                    if ($s = strpos($campaign_name, "_audiencenetwork")) {
                        $campaign_name = substr($campaign_name, 0, $s);
                    }
                    $report_info = $this->reports_model->get_report_data("select adset_id,adset_name,product_id,advertiser_id,app_id,account_id,account_name,campaign_id,campaign_name from marketmax_reports where campaign_name ilike '".$campaign_name."' limit 1");
                    
                    if (!$report_info) {
                        continue;
                    }
                    $report_info = $report_info[0];
                    $adset = $report_info['adset_id'];

                    $product_info = $this->product_model->get_by_fields(['app_id'=>$report_info['app_id']]);
                    if (!$product_info) {
                        continue;
                    }

                    $retention = $row[3]>0?$row[4]/$row[3]:0;
                    $vars = ['country'=>strtoupper($row[2]), 'date'=>strtotime($row[0]), 'retention'=>$retention, 'day0'=>$row[3]];

                    $country = strtoupper($row[3]);
                    $vars['day1'] = $row[4];


                    $vars['product_id'] = $report_info['product_id'];
                    $vars['advertiser_id'] = $report_info['advertiser_id'];

                    $vars['account_id'] = $report_info['account_id'];
                    $vars['account_name'] = $report_info['account_name'];
                    $vars['campaign_id'] = $report_info['campaign_id'];
                    $vars['campaign_name'] = $report_info['campaign_name'];


                    if (!$product_info['retention_updated_time'] || $product_info['retention_updated_time']<$vars['date']) {
                        $this->product_model->update_row_by_id($vars['product_id'], ['retention_updated_time'=>$vars['date'], 'retention_updated_file'=>$retention_file]);
                    }

                    if (isset($result[$vars['campaign_id'].'_'.$vars['country'].'_'.$vars['date']])) {
                        for ($i=0; $i <= 31; $i++) { 
                            if (isset($result[$vars['campaign_id'].'_'.$vars['country'].'_'.$vars['date']]["day".$i]) && isset($vars["day".$i])) {
                                $result[$vars['campaign_id'].'_'.$vars['country'].'_'.$vars['date']]["day".$i] += $vars["day".$i];
                            }
                        }
                    }else
                        $result[$vars['campaign_id'].'_'.$vars['country'].'_'.$vars['date']] = $vars;
                    
                }
                foreach ($result as $key => $value) {
                    $adset_list = $this->reports_model->get_report_data("select adset_id,adset_name from marketmax_reports where account_id=".$value['account_id']." and campaign_id=".$value['campaign_id']." group by adset_name,adset_id");
                    if ($adset_list) {
                        foreach ($adset_list as $item) {
                            $value['adset_name'] = $item['adset_name'];
                            $value['adset_id'] = $item['adset_id'];

                            $vars = $this->get_retention_info($value['product_id'], $value['date'], $value['country']);
                            if ($vars) {
                                $value['cpa'] = $vars['cpa'];
                                $value['retention_info'] = $vars['retention_info'];
                            }

                            $info = $this->adset_retention_model->get_by_fields(['adset_id'=>$item['adset_id'], 'country'=>strtoupper($value['country']), 'date'=>$value['date']]);
                            if ($info) {
                                $this->adset_retention_model->update_row_by_id($info['retention_id'], $value);
                            }else{
                                $this->adset_retention_model->add_one($value);
                            }
                            //更新报表数据
                            $this->fetch_adset_data->update_revenue_by_retention($value['date'], $value['adset_id'], strtoupper($value['country']));
                        }
                    }
                    
                }
            }else{
                log_message('error', "queue_upload_retention: upload data is empty -> " . date('Y-m-d H:i:s') . " Filename -> ".$filename);
            }
        }catch(Exception $e){
            log_message('error', 'AWS SQS Message: '. $e->getMessage());
            fetch_exception($filename, 'upload_retention', $e->getMessage());
        }
        
    }

    public function _fetch_redshift($number)
    {
        log_message('DEBUG', 'queue_redshift starting: ' . $number);
        if (getenv('APP_ENVIRONMENT') == 'production') {
            shell_exec('cd ' . FCPATH . 'crontab/; /bin/bash dynamodb2redshift.sh ' . $number);
        }
        log_message('DEBUG', 'queue_redshift end: ' . $number);

    }

    public function _fetch_appsflyer($app_id, $start_date, $end_date, $retention_day)
    {
        try {
            $this->load->library('appsflyer');
            log_message('debug', "queue_appsflyer_data: fetch appsflyer started -> " . date('Y-m-d H:i:s') . " App ID -> " . $app_id);
            $result=$this->appsflyer->sync($app_id, $start_date, $end_date, $retention_day);
            log_message('debug', "queue_appsflyer_data: fetch appsflyer completed -> " . date('Y-m-d H:i:s') . " App ID -> " . $app_id);
        } catch (Exception $e) {
            fetch_exception($app_id, 'fetch_appsflyer', $e->getMessage(), $date);

            log_message('error', 'AWS SQS Message: ' . $e->getMessage());
        }

    }

    //同步广告数量临时表
    public function _sync_creative_statistics()
    {
        try {
            log_message('debug', "sync_creative_statistics started -> " . date('Y-m-d H:i:s'));
            $this->load->library('statistics');
            $this->statistics->sync();
            log_message('debug', "sync_creative_statistics completed -> " . date('Y-m-d H:i:s'));
        } catch (Exception $e) {
            log_message('error', 'AWS SQS Message: ' . $e->getMessage());
        }

    }

    /**
     * 抓取远程图片到s3
     * @param  [type] $path [description]
     * @param  [type] $url  [description]
     * @return [type]       [description]
     */
    public function _fetch_to_s3($path, $url)
    {
        $this->load->library('Aws');

        $ch=curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $data=curl_exec($ch);
        curl_close($ch);

        $this->aws->upload(config_item('Marketmax_Creative'), $path, $data);
    }

    /**
     * 返回已经失去授权的账号
     * @return [type] [description]
     */
    private function remove_account_list()
    {
        $account=[];
        $this->load->model('adaccount_model');
        $list=$this->adaccount_model->get_query("select * from adaccount where status=-1");
        foreach ($list as $key=>$value) {
            $account[]=$value['account_id'];
        }
        return $account;
    }

    /**
     *账单生成
     */
    private function _create_bills($user_id, $user_type, $date)
    {
        log_message('debug', "create_bills:  started -> " . $date . " User ID -> " . $user_id);
        try {
            $this->load->library('bills');
            $this->bills->sync($user_id, $user_type, $date);
        } catch (Exception $e) {
            fetch_exception($user_id, 'create_bills', $e->getMessage(), $date);
            log_message('error', 'AWS SQS Message: ' . $e->getMessage());
        }
    }

    private function get_retention_info($product_id, $date, $country)
    {
        $sql = "select * from offer_country_log where product_id=".$product_id." and country like '%".$country."%' and start_time <=".$date." order by start_time desc limit 1";
        $value = $this->adset_retention_model->get_query($sql);
        
        $vars = [];
        if ($value) {

            $offer_id = $value[0]['offer_id'];
            $cpa_data = $this->offer_model->get_current_cpa_log($offer_id, $date);

            $retention_info['retention'] = $cpa_data;
            $retention_info['user_id'] = '';
            $retention_info['type'] = 'retention';
            $retention_info['cpa'] = $cpa_data['cpa'];
            $retention_info['offer_id'] = $offer_id;

            $vars['cpa'] = $cpa_data['cpa'];
            $vars['retention_info'] = json_encode($retention_info);
        }
        return $vars;
    }


    public function _sync_retention_tmp($date)
    {
        log_message("debug", $date); 

        $sql = "select * from adset_retention where date=".strtotime($date);
        $this->load->model('adset_retention_model');
        $this->load->model('offer_model');
        $this->load->model('reports_model');
        $list = $this->adset_retention_model->get_query($sql);
        foreach ($list as $item) {
            $sql = "select * from offer_country_log where product_id=".$item['product_id']." and country like '%".$item['country']."%' and start_time <=".$item['date']." order by start_time desc limit 1";
            $value = $this->adset_retention_model->get_query($sql);
            
            if ($value) {

                $offer_id = $value[0]['offer_id'];
                $cpa_data = $this->offer_model->get_current_cpa_log($offer_id, $item['date']);

                $retention_info['retention'] = $cpa_data;
                $retention_info['user_id'] = '';
                $retention_info['type'] = 'retention';
                $retention_info['cpa'] = $cpa_data['cpa'];
                $retention_info['offer_id'] = $offer_id;

                $vars['cpa'] = $cpa_data['cpa'];
                $vars['retention_info'] = json_encode($retention_info);
                $this->adset_retention_model->update_row_by_id($item['retention_id'], $vars);
            }
        }
    }
}