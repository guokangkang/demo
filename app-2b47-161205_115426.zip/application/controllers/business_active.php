<?php if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

require_once __DIR__ . '/../libraries/vendor/autoload.php';


use Facebook\Facebook;
use Facebook\FacebookRequest;
use Facebook\Exceptions\FacebookResponseException;
use Facebook\Exceptions\FacebookSDKException;
use FacebookAds\Object\AdUser;

class Active extends Web_Controller
{

    var $fb;
    public function __construct() {
        parent::__construct();

        $this->load->model('business_model');
        $this->load->model('business_permissions_model');
        $this->load->model('adaccount_model');
        $this->load->model('publisher_adaccount_model');

        $this->load->library('curl');

        if (!session_id()) {
            session_start();
        }

        $this->fb = new Facebook([
            'app_id' => config_item('APP_ID'),
            'app_secret' => config_item('APP_SECRET')
        ]);

    }
 

    //获取当前使用的token的用户是谁
    private function getMe($token = '')
    {
        $this->load->library('curl');
        $url = config_item('APP_URL').config_item('APP_VERSION')."/me?fields=businesses.limit(1024),gender,first_name,name,last_name,picture.type(large).redirect(false)&access_token=" . $token;
        $userinfo = $this->curl->simple_get($url);

        return $userinfo;
    }

    /**
     * 获取bm详情
     * 
     * @param  [type] $business_id [description]
     * @param  string $token       [description]
     * @return [type]              [description]
     */
    private function getBussiness($business_id, $token='')
    {
        $this->load->library('curl');
        $url = config_item('APP_URL').config_item('APP_VERSION')."/".$business_id."?fields=created_by,name,timezone_id,updated_by,userpermissions.limit(1024),adaccounts.limit(1024)&access_token=" . $token;
        $info = $this->curl->simple_get($url);

        return $info;
    }


    /**
     * 获取token
     * @param  [type] $fb_exchange_token [临时token]
     * @return [type]                    [description]
     */
    private function createToken($fb_exchange_token)
    {

        $url = config_item('APP_URL')."oauth/access_token";


        $tokenstr = $this->curl->simple_post($url, array(
            'grant_type' => 'fb_exchange_token',
            'client_id' => config_item('APP_ID'),
            'client_secret' => config_item('APP_SECRET'),
            'fb_exchange_token' => $fb_exchange_token
        ));
        $queryParts = explode('&', $tokenstr);

        $token = explode('=', $queryParts[0]);
        //$expires = explode('=', $queryParts[1]);
        $expires = 50 * 86500;//有效期为60天，直接搞成50天吧，到50天就在生成一次

        return [$token[1], time() + $expires];
    }



    public function facebook()
    {
        $this->load->model('user_model');
        $this->load->model('company_model');
        

        
        $helper = $this->fb->getRedirectLoginHelper();

        if (!isset($_SESSION['facebook_access_token'])) {
            $_SESSION['facebook_access_token'] = null;
        }

        if (!$_SESSION['facebook_access_token']) {
            $helper = $this->fb->getRedirectLoginHelper();
            try {
                $_SESSION['facebook_access_token'] = (string)$helper->getAccessToken();
            } catch (FacebookResponseException $e) {
                // When Graph returns an error
                echo 'Graph returned an error: ' . $e->getMessage();
                exit;
            } catch (FacebookSDKException $e) {
                // When validation fails or other local issues
                echo 'Facebook SDK returned an error: ' . $e->getMessage();
                exit;
            }
        }
        if ($_SESSION['facebook_access_token']) {

            $userinfo = $this->getMe($_SESSION['facebook_access_token']);
            if (!$userinfo) {
                echo "user error\r\n";
                die();
            }
            list($token, $expires) = $this->createToken($_SESSION['facebook_access_token']);
            if (!$token) {
                echo "error";
                die();
            } 

            $user = json_decode($userinfo, true);

            //获取用户头像
            $filename = $this->get_user_head($user['id']);

            $this->user_model->update_row_by_id($this->userinfo['user_id'], ['facebook_id'=>$user['id'], 'backup'=>$userinfo, 'token'=>$token, 'head'=>$filename, 'token_expires'=>$expires, 'fb_active'=>1]);
            

            $user_info = $this->user_model->get_by_id($this->userinfo['user_id']);
            unset($user_info['password']);
            $this->input->set_cookie("P_INFO", json_encode($user_info), 86500);

            if ($this->userinfo['company_id']) {
                $company_info = $this->company_model->get_by_id($this->userinfo['company_id']);
                if (!$company_info) {//未找到对应的企业信息
                    redirect('user/account/1');
                    die();
                }
                $bm = json_decode($company_info['bm'], true);
                if (isset($user['businesses']) && $user['businesses']) {
                    $this->set_business($_SESSION['facebook_access_token'], $user['id'], $user['businesses'], $bm);
                }
            }else{
                $this->adaccount_model->add_account_by_user_id($this->userinfo['user_id'], $this->userinfo['full_name']);
            }
            
        }
        redirect('user/account');
    }

    public function get_user_head($facebook_id)
    {
        $response = $this->fb->get('/'.$facebook_id.'/picture?type=large&redirect=false', $_SESSION['facebook_access_token']);
        $pagesEdge = $response->getGraphObject();
        $head = $pagesEdge->getProperty('url');
        $data = file_get_contents(str_replace("https", "http", $head));

        if (!is_dir('./avatar/')){  
            mkdir(iconv("UTF-8", "GBK", './avatar/'),0777); 
        }

        $filename = "./avatar/".$this->userinfo['user_id'].".jpg";
        file_put_contents($filename, $data);
        return $filename;
    }


    /**
     * 设置用户权限关系
     * @param [type] $business_info [description]
     * @param [type] $facebook_id   [description]
     */
    public function set_user_permission($business_info, $facebook_id)
    {
        
        //添加权限关系 
        if ($business_info['userpermissions']) {
            $business_info['userpermissions'] = json_decode($business_info['userpermissions'], true);
            foreach ($business_info['userpermissions']['data'] as $role) {
                $permissions = $this->business_permissions_model->get_by_fields(['market_business_id'=>$business_info['market_business_id'], 'facebook_id'=>$role['user']['id']]);
                $user_info = $this->user_model->get_by_fields(['facebook_id'=>$role['user']['id'], 'company_id'=>$this->userinfo['company_id']]);
                
                if (!$permissions) {
                    $vars = ['market_business_id'=>$business_info['market_business_id'], 'business_id'=>$business_info['business_id'], 'business_name'=>$business_info['name'], 'business_persona'=>json_encode($role['business_persona']), 'role'=>$role['role'], 'status'=>$role['status'], 'facebook_id'=>$role['user']['id'], 'facebook_name'=>$role['user']['name']];
                    if (isset($role['email'])) {
                        $vars['email'] = $role['email'];
                    } 
                    
                    if ($user_info) {
                        $vars['user_id'] = $user_info['user_id'];
                        $vars['user_name'] = $user_info['user_name'];
                        if ($role['role']=='ADMIN') {
                            $this->business_model->update_row_by_id($business_info['market_business_id'], ['token'=>$user_info['token']]);
                        }
                    }
                    $this->business_permissions_model->add_one($vars);
                }else{

                    $vars = ['role'=>$role['role'], 'status'=>$role['status']];
                    if ($user_info){
                        $vars['user_id'] = $user_info['user_id'];
                        $vars['user_name'] = $user_info['user_name'];
                    }
                    $this->business_permissions_model->update_row_by_id($permissions['permissions_id'], $vars);
                    if ($user_info) {
                        if ($role['role']=='ADMIN') {
                            $this->business_model->update_row_by_id($business_info['market_business_id'], ['token'=>$user_info['token']]);
                        }
                        $this->publisher_adaccount_model->update_row_by_fields(['publisher_id'=>$user_info['user_id'], 'market_business_id'=>$business_info['market_business_id']], ['role'=>$role['role']]);
                    }
                }

                if ($role['user']['id'] == $facebook_id) {
                    // $publisher = $this->publisher_business_model->get_by_fields(['market_business_id'=>$business_info['market_business_id'], 'publisher_id'=>$this->userinfo['user_id']]);
                    // if (!$publisher) {
                    //     $vars = ['publisher_id'=>$this->userinfo['user_id'], 'market_business_id'=>$business_info['market_business_id'], 'business_id'=>$business_info['business_id'], 'role'=>$role['role']];
                    //     $this->publisher_business_model->add_one($vars);
                    // }else{
                    //     $this->publisher_business_model->update_row_by_id($publisher['relation_id'], ['role'=>$role['role']]);
                    // }

                    $this->publisher_adaccount_model->update_row_by_fields(['publisher_id'=>$this->userinfo['user_id'], 'market_business_id'=>$business_info['market_business_id']], ['role'=>$role['role']]);
                }
            }
        }
        
    }

    /**
     * 添加账号与
     * @param [type] $business_info [description]
     * @param [type] $accounts      [description]
     */
    private function set_business_adaccount($market_business_id, $business_info, $facebook_id)
    {
        $accounts = [];
        foreach ($business_info['adaccounts']['data'] as $key => $value) {
            $accounts[] = $value['account_id'];
        }

        $permissions = $this->business_permissions_model->get_by_fields(['facebook_id'=>$facebook_id, 'market_business_id'=>$market_business_id]);
        $this->adaccount_model->addAccount($this->userinfo['user_id'], $this->userinfo['full_name'], $facebook_id, $accounts, $business_info['id'], $permissions['role']);
    }

    /**
     * 设置bm关系
     * @param [type] $token       [description]
     * @param [type] $facebook_id [description]
     * @param [type] $businesses  [description]
     * @param [type] $user_bm     [description]
     */
    private function set_business($token, $facebook_id, $businesses, $user_bm)
    {
        $businesses = $businesses['data'];
        foreach ($businesses as $item) {
            if (in_array($item['id'], $user_bm)) {
                $business_info = $this->getBussiness($item['id'], $token);
                if ($business_info) {
                    $business_info = json_decode($business_info, true);

                    $vars = ['name'=>$business_info['name'], 'created_by'=>json_encode($business_info['created_by']), 'timezone_id'=>$business_info['timezone_id'], 'updated_by'=>json_encode($business_info['updated_by']), 'userpermissions'=>json_encode($business_info['userpermissions'])];
                    $data_info = $this->business_model->get_by_fields(['business_id'=>$item['id']]);
                    if ($data_info) {
                        $this->business_model->update_row_by_id($data_info['market_business_id'], $vars);
                        $market_business_id = $data_info['market_business_id'];
                        //$data_info = $vars;
                        //$data_info['market_business_id'] = $market_business_id;
                    }else{
                        $vars['business_id'] = $business_info['id'];
                        $market_business_id = $this->business_model->add_one($vars);
                        $data_info = $vars;
                        $data_info['market_business_id'] = $market_business_id;
                    }
                    //设置账号关系
                    if (isset($business_info['adaccounts'])) {
                        $this->set_business_adaccount($market_business_id, $business_info, $facebook_id);
                    }

                    if ($data_info) {
                        $this->set_user_permission($data_info, $facebook_id);
                    }
                
                }
            }
        }
    }
}