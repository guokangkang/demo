<?php if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

/**
 *
 * User: palmax
 * Date: 2016/4/26
 * Time: 15:10
 */
class Review extends Web_Controller
{
    public function __construct()
    {
        parent::__construct();

        $this->load->model('ad_model');
        $this->load->model('redshift_model');
        $this->load->model('ad_insight_model');
        $this->load->model('product_model');
        $this->load->model('user_model');
        $this->load->model('comments_model');
        $this->load->model('adaccount_model');
        $this->load->library('pagination');

        $this->data['top_menu']=$this->load->view('web/top_menu_review', '', TRUE);
    }

    private function get_sort_link($site_url)
    {
        $sort_clicks="CLICKS";
        $sort_ctr="CTR";
        $sort_spent="SPENT";

        $mysql_sort="marketmax_reviews.updated_time desc";

        if ($this->input->get('sort')) {
            $sort=$this->input->get('sort');
            if ($sort == 'ctr_asc') {
                $sort_ctr="CTR ASC";
                $mysql_sort="marketmax_reviews_insights.ctr asc";
            } elseif ($sort == 'ctr_desc') {
                $sort_ctr="CTR DESC";
                $mysql_sort="marketmax_reviews_insights.ctr desc";
            } elseif ($sort == 'clicks_asc') {
                $sort_clicks="CLICKS ASC";
                $mysql_sort="marketmax_reviews_insights.clicks asc";
            } elseif ($sort == 'clicks_desc') {
                $sort_clicks="CLICKS DESC";
                $mysql_sort="marketmax_reviews_insights.clicks desc";
            } elseif ($sort == 'spent_asc') {
                $sort_spent="SPENT ASC";
                $mysql_sort="marketmax_reviews_insights.spend asc";
            } elseif ($sort == 'spent_desc') {
                $sort_spent="SPENT ASC";
                $mysql_sort="marketmax_reviews_insights.spend desc";
            }
        }

        $this->data['sort_ctr']=$sort_ctr;
        $this->data['sort_clicks']=$sort_clicks;
        $this->data['sort_spent']=$sort_spent;
        return $mysql_sort;
    }


    public function index()
    {
        $where="is_new=1";
        $where = "1=1";

        if ($this->userinfo['type'] == 1) {
            $where.=" and marketmax_reviews.advertiser_id=" . $this->userinfo['user_id'];
        }

        $site_url=site_url('review') . "?";
        $account=$publisher=$product=[];
        if ($this->input->get('account')) {
            $account=explode(',', $this->input->get('account'));
            $where.=" and marketmax_reviews.account_id in (" . $this->input->get('account') . ")";
            $site_url.="&account=" . $this->input->get('account');
        }
        if ($this->input->get('publisher')) {
            $publisher=explode(',', $this->input->get('publisher'));
            $where.=" and marketmax_reviews.publisher_id in (" . $this->input->get('publisher') . ")";
            $site_url.="&publisher=" . $this->input->get('publisher');
        }
        $this->data['product_params']=$product;
        if ($this->input->get('product')) {
            $product=explode(',', $this->input->get('product'));
            $where.=" and marketmax_reviews.product_id in (" . $this->input->get('product') . ")";
            $site_url.="&product=" . $this->input->get('product');
        }

        if ($this->input->get('status')) {
            $where.=" and marketmax_reviews.effective_status = '" . $this->input->get('status') . "'";
            $site_url.="&status=" . $this->input->get('status');
        }
        if ($this->input->get('campaign')) {
            $where.=" and marketmax_reviews.campaign_name ilike '%" . trim($this->input->get('campaign')) . "%'";
            $site_url.="&campaign=" . $this->input->get('campaign');
        }

        // if ($this->input->get('tag') >= -1) {
        //     $tag=$this->input->get('tag');
        //     $site_url.="&tag=" . $tag;

        //     if ($tag != 'all') {
        //         $where.=" and ad.verify=" . $tag;
        //     }
        // } else {
        //     $where.=" and ad.verify=0";
        // }

        if ($this->input->get('type')) {
            $type=$this->input->get('type');
            $site_url.="&type=" . $type;

            if ($type != 'all') {
                $where.=" and marketmax_reviews.object_type='" . strtoupper($type) . "'";
            }
        }

        $this->data['verify']=['-1'=>'Checked', '0'=>'Pending', '1'=>'Favorite', '2'=>'Suspected', '3'=>'Illegal'];
        $this->data['product_params']=$product;
        $this->data['account_params']=$account;
        $this->data['publisher_params']=$publisher;

        $mysql_sort=$this->get_sort_link($site_url);

        $start = strtotime(date('Y-m-d', strtotime("-3 day")));
        $end = time();
        if ($this->input->get('start') && $this->input->get('end')) {
            $start = strtotime(str_replace(" ", "-", $start));
            $end = strtotime(str_replace(" ", "-", $this->input->get('end'))) + 24 * 60 * 60;
        }

        $where.=" and marketmax_reviews.updated_time>=" . $start . " and marketmax_reviews.updated_time<" . $end;
        $site_url.="&start=" . date('m/d/Y', $start) . "&end=" . date('m/d/Y', $end);

        $this->data['site_url']=$site_url;

        if ($this->input->get('sort')) {
            $site_url.="&sort=" . $this->input->get('sort');
        }

        $config['base_url']=$site_url;

        $count_sql="SELECT 
                count(*) as count
                FROM marketmax_reviews 
                WHERE " . $where;

        $total_rows=$this->redshift_model->get_query($count_sql);
        $this->data['total_rows']=$total_rows?$total_rows[0]['count']:0;

        //$total_rows = 1500;
        $config=get_web_page($config, $this->data['total_rows'], 3);


        $page=1;
        if ($this->input->get('page'))
            $page=$this->input->get('page');

        if (is_numeric($this->input->get('type')) && $this->input->get('type') == 0) {
        }

        $limit=$config['per_page']=16;

        $this->pagination->initialize($config);
        $this->data['page_links']=$this->pagination->create_links();


        $sql="SELECT 
                DISTINCT marketmax_reviews.ad_id,
                marketmax_reviews.*
                FROM marketmax_reviews 
                WHERE " . $where . "
                ORDER BY " . $mysql_sort . "
                OFFSET " . ($page - 1) * $limit . "
                LIMIT " . $limit . "
                ";

        $this->data['offer']=($page - 1) * $limit + 1;
        $this->data['limit']=$limit;


        $ad_list=$this->redshift_model->get_query($sql);

        $ad_id_arr=$ad_ids=$tmp=$new_ad_list=[];


        if ($ad_list) {
            foreach ($ad_list as $item) {
                if (count($tmp)<10) {
                    $tmp[]=$item['ad_id'];
                }else{
                    $ad_ids[] = $tmp;
                    $tmp = [];
                    $tmp[]=$item['ad_id'];
                }
            }
            $tmp && $ad_ids[] = $tmp;
            foreach ($ad_ids as $ids) {
                $tmp = $this->redshift_model->get_query("select * from marketmax_reviews where ad_id in (" . implode(',', $ids) . ")");
                $new_ad_list = array_merge($new_ad_list, $tmp);
            }
            $data=[];
            foreach ($new_ad_list as $ad) {
                if (!strpos($ad['thumbnail_url'], "fbcdn")) {
                    $ad['image_url']=config_item('CDN') . $ad['thumbnail_url'];
                } else {
                    $url=str_replace("w=64", "w=315", $ad['thumbnail_url']);
                    $url=str_replace("h=64", "h=156", $url);
                    $ad['image_url']=$url;
                }



                if ($ad['object_type'] == 'MORE_SHARE') {
                    $ad['more_image']=json_decode($ad['more_image'], true);
                    foreach ($ad['more_image'] as & $ad_image) {
                        if (!strpos($ad_image['url'], "fbcdn")) {
                            $ad_image['url']=config_item('CDN') . $ad_image['url'];
                        } else {
                            $ad_image['url']="https://external.xx.fbcdn.net/safe_image.php?d=AQDWAPPEnKQRaMWe&w=315&h=156&url=" . $ad_image['url'];
                        }
                    }
                }
                if ($ad['object_type'] == 'VIDEO') {
                    if (!strpos($ad['video_url'], "fbcdn")) {
                        $ad['video_url']=config_item('CDN') . $ad['video_url'];
                    }
                }

                $data[$ad['ad_id']][]=$ad;
            }
            foreach ($ad_list as $key=>& $value) {
                $sql = "select sum(spend) as spend,sum(results) as results, sum(link_clicks) as link_clicks, sum(impressions) as impressions, sum(clicks) as clicks, sum(shares) as shares, sum(comments) as comments, sum(likes) as likes, sum(cost) as cost, avg(cpc) as cpc from marketmax_reviews_insights where ad_id=".$value['ad_id'];
                $insight = $this->redshift_model->get_query($sql);
                var_dump($insight);die();
                $value['ad']=$data[$value['ad_id']];

                if (!strpos($value['thumbnail_url'], "fbcdn")) {
                    $value['image_url']=config_item('CDN') . $value['thumbnail_url'];
                } else {
                    $url=str_replace("w=64", "w=315", $value['thumbnail_url']);
                    $url=str_replace("h=64", "h=156", $url);
                    $value['image_url']=$url;
                }

                $ad_id_arr[]=$value['ad_id'];


                if ($value['object_type'] == 'MORE_SHARE') {
                    $value['more_image']=json_decode($value['more_image'], true);
                    foreach ($value['more_image'] as & $image) {
                        if (!strpos($image['url'], "fbcdn")) {
                            $image['url']=config_item('CDN') . $image['url'];
                        } else {
                            $image['url']="https://external.xx.fbcdn.net/safe_image.php?d=AQDWAPPEnKQRaMWe&w=315&h=156&url=" . $image['url'];
                        }
                    }
                }
                if ($value['object_type'] == 'VIDEO') {
                    if (!strpos($value['video_url'], "fbcdn")) {
                        $value['video_url']=config_item('CDN') . $value['video_url'];
                    }
                }

                $good_comments=$this->comments_model->get_query("select * from comments where ad_id=" . $value['ad_id'] . " order by addtime desc limit 10");

                $value['comment_list']=$good_comments;
            }
        }

        $this->data['ad_list']=$ad_list;
        $this->data['ad_ids']=implode(',', $ad_id_arr);


        $product_sql="select * from product where status=1";
        $this->data['product_list']=$this->product_model->get_query($product_sql);

        $account_sql="select * from adaccount";
        $this->data['account_list']=$this->product_model->get_query($account_sql);

        $user_sql="select * from user where type=2";
        $this->data['user_list']=$this->product_model->get_query($user_sql);


        $this->data['status']=['ACTIVE', 'PAUSED', 'DELETED', 'PENDING_REVIEW', 'DISAPPROVED', 'PREAPPROVED', 'PENDING_BILLING_INFO', 'CAMPAIGN_PAUSED', 'ARCHIVED', 'ADSET_PAUSED'];

        $template='review_index';
        $this->template->build($template, $this->data);
    }


    /**
     * 检查创意效果
     */
    public function add_review_category_action()
    {
        if ($this->input->is_ajax_request()) {
            $data_id=$this->input->post('data_id');
            $data_val=$this->input->post('data_val');

            $this->ad_model->update_row_by_id($data_id, ['verify'=>$data_val]);
            $response=['success'=>true, 'msg'=>"success"];
        } else {
            $this->output->set_status_header('403');
            $response=['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
        }
        $this->output->set_content_type('applicaion/json')->set_output(json_encode($response));

    }


    /**
     * 检查创意效果
     */
    public function add_review_ids_category_action()
    {
        if ($this->input->is_ajax_request()) {
            $data=$this->input->post('data');
            $is_read=$this->input->post('is_read');


            $sql="update ad set verify=-1 where market_ad_id in (" . $data . ") and verify=0";
            if ($is_read) {
                $this->ad_model->update_by_query($sql);
            }

            $response=['success'=>true, 'msg'=>"success"];
        } else {
            $this->output->set_status_header('403');
            $response=['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
        }
        $this->output->set_content_type('applicaion/json')->set_output(json_encode($response));

    }


    public function detail()
    {
        if (!$this->input->get('ad')) {
            redirect('review/index');
        }
        $ad_id=$this->input->get('ad');
        $ad_info=$this->ad_model->get_by_fields(['ad_id'=>$ad_id]);
        if (!$ad_info) {
            redirect('review/index');
        }
        $this->load->model('comments_model');

        $this->load->model('reports_model');
        $sql="select * from marketmax_comments limit 100";
        $comments_list=$this->reports_model->get_report_data($sql, false);

        //$good_comments = $this->comments_model->get_query("select * from comments where ad_id='".$ad_id."'");
        $good_comments=$this->comments_model->get_query("select * from comments");

        $comment_ids=[];
        if ($good_comments) {
            foreach ($good_comments as $key=>$value) {
                $comment_ids[$value['facebook_comment_id']]=$value['featured'];
            }
        }
        $this->data['comment_ids']=$comment_ids;

        $this->data['comment_list']=$comments_list;


        $ad_list=$this->ad_model->get_query("select * from ad where ad_id = '" . $ad_id . "'");

        if ($ad_list) {
            foreach ($ad_list as $key=>& $value) {

                if (!strpos($value['thumbnail_url'], "fbcdn")) {
                    $value['image_url']=config_item('CDN') . $value['thumbnail_url'];
                } else {
                    $url=str_replace("w=64", "w=315", $value['thumbnail_url']);
                    $url=str_replace("h=64", "h=156", $url);
                    $value['image_url']=$url;
                }

                if ($value['ad_review_feedback']) {
                    $value['ad_review_feedback']=json_decode($value['ad_review_feedback'], true);
                }
                $ad_ids[]=$value['market_ad_id'];

                if ($value['object_type'] == 'MORE_SHARE') {
                    $value['more_image']=json_decode($value['more_image'], true);
                    foreach ($value['more_image'] as & $image) {
                        $image['url']="https://external.xx.fbcdn.net/safe_image.php?d=AQDWAPPEnKQRaMWe&w=315&h=156&url=" . $image['url'];
                        if (!strpos($image['url'], "fbcdn")) {
                            $image['url']=config_item('CDN') . $value['url'];
                        }
                    }
                }
                if ($value['object_type'] == 'VIDEO') {
                    if (!strpos($value['video_url'], "fbcdn")) {
                        $value['video_url']=config_item('CDN') . $value['video_url'];
                    }
                }
            }
        }

        $this->data['insight']=$this->ad_insight_model->get_by_fields(['ad_id'=>$ad_id]);

        $this->data['ad_list']=$ad_list;

        $this->data['ad_info']=$ad_info;
        $template='review_detail';
        $this->template->build($template, $this->data);
    }


    public function risk()
    {
        $template='review_risk';
        $this->template->build($template, $this->data);
    }

    public function social()
    {
        $site_url=site_url('review/social') . "?";
        $where="is_new=1";
        if ($this->userinfo['type'] == 1) {
            $where.=" and advertiser_id=" . $this->userinfo['user_id'];
        }
        $total_rows['count']=100;
        $this->data['total_rows']=$total_rows?$total_rows['count']:0;

        $config['base_url']=$site_url;
        $config=get_web_page($config, $total_rows['count'], 3);
        $page=1;
        if ($this->input->get('page'))
            $page=$this->input->get('page');

        if (is_numeric($this->input->get('type')) && $this->input->get('type') == 0) {
        }

        $limit=$config['per_page']=16;

        $this->pagination->initialize($config);
        $this->data['page_links']=$this->pagination->create_links();
        $sql="SELECT 
                ad_insight.*,
                ad.*
                FROM  ad_insight
                right JOIN ad ON ad_insight.market_ad_id = ad.market_ad_id
                WHERE " . $where . "
                ORDER BY ad.addtime desc
                LIMIT " . ($page - 1) * $limit . ", " . $limit . "
                ";

        $this->data['offer']=($page - 1) * $limit + 1;
        $this->data['limit']=$limit;
        $ad_list=$this->ad_model->get_query($sql);

        foreach ($ad_list as $key=>& $value) {
            if (!strpos($value['thumbnail_url'], "fbcdn")) {
                $value['image_url']=config_item('CDN') . $value['thumbnail_url'];
            } else {
                $url=str_replace("w=64", "w=315", $value['thumbnail_url']);
                $url=str_replace("h=64", "h=156", $url);
                $value['image_url']=$url;
            }
        }
        //var_dump($ad_list);die();
        $this->data['ad_list']=$ad_list;

        $template='review_social';
        $this->template->build($template, $this->data);
    }

    public function addcomment()
    {
        if ($this->input->is_ajax_request()) {
            $this->load->model('reports_model');
            $this->load->model('comments_model');
            if (!$this->input->post('comment_id')) {
                $response=['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
            } else {
                $comment_id=$this->input->post('comment_id');
                $text=$this->input->post('text');
                $info=$this->reports_model->get_report_data("select * from marketmax_comments where comment_id='" . $comment_id . "'");
                if (!$info) {
                    $response=['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
                } else {
                    $info=$info[0];

                    $vars=['facebook_comment_id'=>$info['comment_id'], 'ad_id'=>$info['ad_id'], 'message'=>$info['message'], 'user_id'=>$info['user_id'], 'user_name'=>$info['user_name'], 'created_time'=>$info['created_time'], 'featured'=>$text];
                    $this->comments_model->add_one($vars);
                }
            }
            $response=['success'=>true, 'msg'=>"success"];
        } else {
            $this->output->set_status_header('403');
            $response=['success'=>false, 'msg'=>$this->lang->line('notice_bad_request')];
        }
        $this->output->set_content_type('applicaion/json')->set_output(json_encode($response));
    }

    public function agency()
    {
        $this->load->model('agency_ad_statistics_model');
        $where=[];
        switch ($this->userinfo['type']) {
            case 0:
                $user_data=$this->user_model->get_all(['user.type'=>2, 'user.publisher_type'=>2], 1, 100);
                //var_dump($user_data);die;
                $user_ids=$user_data?array_column($user_data, 'user_id'):[];
                //var_dump($user_ids);die;
                $sql='SELECT advertiser_name,sum(ad_count) as ads, sum(campaign_count) as campaigns,sum(adset_count) as adsets,sum(image_count) as images,sum(carousel_count) as carousels,sum(video_count) as videos,sum(pending_count) as pendings,sum(approved_count) as approveds,sum(suspected_count) as suspecteds,sum(illegal_count) as illegals FROM agency_ad_statistics WHERE advertiser_id in (' . implode(',', $user_ids) . ') group by advertiser_id limit 10';
                //var_dump($sql);die;
                //$this->data['list']=$this->agency_ad_statistics_model->get_query($sql);
                break;
            case 1:
            case 2:
                $user_id=$this->userinfo['user_id'];
                $sql="SELECT advertiser_name,sum(ad_count) as ads, sum(campaign_count) as campaigns,sum(adset_count) as adsets,sum(image_count) as images,sum(carousel_count) as carousels,sum(video_count) as videos,sum(pending_count) as pendings,sum(approved_count) as approveds,sum(suspected_count) as suspecteds,sum(illegal_count) as illegals  FROM agency_ad_statistics WHERE advertiser_id ='{$user_id}' group by advertiser_id limit 10";
                break;
        }
        $this->data['list']=$this->agency_ad_statistics_model->get_query($sql);
        $this->template->build('review_agency', $this->data);
    }

    public function social_bak()
    {

        $site_url=site_url('review') . "?";


        $where="is_new=1";
        if ($this->userinfo['type'] == 1) {
            $where.=" and advertiser_id=" . $this->userinfo['user_id'];
        }


        // $count_sql = "SELECT
        //         count(*) as count
        //         FROM  ad
        //         LEFT JOIN ad_insight ON ad_insight.market_ad_id = ad.market_ad_id
        //         WHERE ".$where."  group by ad.ad_id";

        // $total_rows = $this->ad_model->get_one($count_sql);
        $total_rows['count']=100;
        $this->data['total_rows']=$total_rows?$total_rows['count']:0;

        $config['base_url']=$site_url;
        $config=get_web_page($config, $total_rows['count'], 3);


        $page=1;
        if ($this->input->get('page'))
            $page=$this->input->get('page');

        if (is_numeric($this->input->get('type')) && $this->input->get('type') == 0) {
        }

        $limit=$config['per_page']=16;

        $this->pagination->initialize($config);
        $this->data['page_links']=$this->pagination->create_links();


        $sql="SELECT 
                ad_insight.*,
                ad.*
                FROM  ad_insight
                right JOIN ad ON ad_insight.market_ad_id = ad.market_ad_id
                WHERE " . $where . "
                ORDER BY ad.addtime desc
                LIMIT " . ($page - 1) * $limit . ", " . $limit . "
                ";

        //echo $count_sql;die();
        $this->data['offer']=($page - 1) * $limit + 1;
        $this->data['limit']=$limit;
        $ad_list=$this->ad_model->get_query($sql);

        foreach ($ad_list as $key=>& $value) {
            if (!strpos($value['thumbnail_url'], "fbcdn")) {
                $value['image_url']=config_item('CDN') . $value['thumbnail_url'];
            } else {
                $url=str_replace("w=64", "w=315", $value['thumbnail_url']);
                $url=str_replace("h=64", "h=156", $url);
                $value['image_url']=$url;
            }
        }
        //var_dump($ad_list);die();
        $this->data['ad_list']=$ad_list;

        $template='review_social';
        $this->template->build($template, $this->data);
    }

    /**
     * 导出报告
     */
    public function get_export()
    {
        $time=date('m.d.s');
        $comments=$ad_ids=[];
        $ad_id=$this->input->get('ad_id', true);
        $comment=$this->input->get('comments', true);
        if ($comment) {
            $comments=array_unique(explode(',', $comment));
            $where=['where_in'=>['ad_id', $comments]];
        }else{
            return false;
        }
        if ($ad_id) {
            $ad_ids=array_unique(explode(',', $ad_id));
            $where=['where_in'=>['ad_id', $ad_ids]];
        }else{
            return false;
        }
        $this->load->model('comments_model');
        $this->load->library('excel');
        $data=$this->comments_model->get_data('*', $where, 0, 0);
        if ($comments) {
            $head=['UserName', 'UserId', 'AdId', 'Message', 'FBLink'];
            $name='comments';
            foreach ($data as &$item) {
                $item['fb_link']='https://www.facebook.com/app_scoped_user_id/' . $item['user_id'] . '/';
            }
            $this->excel->get_excel($name, $head, $data, $time . '.xls');
        }
        if ($ad_id) {
            //输出内容如下：
            $head=['UserName', 'UserId', 'FBLink'];
            $name='comments';
            foreach ($data as &$item) {
                $item['fb_link']='https://www.facebook.com/app_scoped_user_id/' . $item['user_id'] . '/';
            }
            $this->excel->get_excel($name, $head, $data, $time . '.xls');
        }
    }
}