<?php

require_once __DIR__ . '/../libraries/vendor/autoload.php';


use Facebook\Facebook;
use Facebook\Exceptions\FacebookResponseException;
use Facebook\Exceptions\FacebookSDKException;

class Sign extends Web_Controller
{

    public function __construct()
    {
        parent::__construct();
        session_start();

        $this->load->model('user_model');
        $this->load->model('manager_model');

        $this->load->library('session');
        $this->load->helper('cookie');
        $this->load->library('curl');
        $this->load->library('validation');

    }

    public function index()
    {
        $template = 'sign_index';
        $this->template->build($template,$this->data);
    }

    /**
     * 登陆
     * @param  string $value [description]
     * @return [type]        [description]
     */
    public function in()
    {
        $template = 'sign_in';
        $this->template->build($template,$this->data);
    }

    public function form_in()
    {
        if (IS_POST) {
            $vars['email'] = $this->input->post('input_email');
            $vars['password'] = $this->input->post('input_password');
            $vars = $this->validation->checkInput($vars);

            $where = ['email'=>$vars['email']];

            $url = "sign/manager_in";
            if (strpos(site_url(), "addigger.palmax.com")) {
                $url = "advertiser/sign/in";
            }elseif (strpos(site_url(), "adcaptain.palmax.com")) {
                $url = "publisher/sign/in";
            }elseif (strpos(site_url(), "management.palmax.com")) {
                $url = "sign/manager_in";
            }

            // if ($this->input->post('type')) {
            //     if ($this->input->post('type')!='advertiser') {
            //         $this->input->set_cookie('sign_in_error', "The advertiser type error.", 1);
            //         redirect('sign/advertiser_in');
            //         die();
            //     }else{
            //         $where['type'] = 1;
            //         $url  = "sign/advertiser_in";

            //     }
            // }

            $user = $this->user_model->get_by_fields($where);
            if (!$user) {
                $this->input->set_cookie('sign_in_error', "The user is not exist.", 1);
                redirect($url);
                die();
            }
            if (password_verify($vars['password'], $user['password'])) {
                unset($user['password']);

                if ($this->input->post('remember')==1) {
                    $date = 86500 * 7;
                }else{
                    $date = 86500;
                }
                $this->input->set_cookie("P_INFO", json_encode($user), $date);
                if ($user['type']==1) {
                    redirect('product/listview');
                }else{
                    redirect('dashboard/index');
                }
                
            }else{
                $this->input->set_cookie('sign_in_error', "Password is wrong.", 1);
                redirect($url);
                die();
            }
            
        }else{
            redirect('sign/in');
        }
    }


    /**
     * 注册
     * @param  string $value [description]
     * @return [type]        [description]
     */
    public function up($value='')
    {
        $this->config->load('product',TRUE);
        $this->data['config_product'] = $this->config->item('product');

        $template = 'sign_up';
        $this->template->build($template,$this->data);
    }

    public function form_up()
    {
        if (IS_POST) {
            $vars['first_name'] = $this->input->post('input_first');
            $vars['last_name'] = $this->input->post('input_last');
            $vars['company'] = $this->input->post('input_campany');
            $vars['country'] = $this->input->post('select_country');
            $vars['address'] = $this->input->post('input_address');
            $select_message_type = $this->input->post('select_message_type');
            $input_message_name = $this->input->post('input_message_name');
            $vars['email'] = $this->input->post('input_email');
            $vars['password'] = $password = $this->input->post('input_password');
            $input_PasswordCheck = $this->input->post('input_PasswordCheck');

            $vars['user_name'] = $vars['last_name'].' '.$vars['first_name'];

            $vars = $this->validation->checkInput($vars);
            if (!$vars['email']) {
                $this->input->set_cookie('sign_up_error', "The email is required and cannot be empty", 1);
                redirect('sign/up');
                die();
            }
            if ($password != $input_PasswordCheck) {
                $this->input->set_cookie('sign_up_error', "The password and re-enter password are not the same", 1);
                redirect('sign/up');
                die();
            }
            $input_message_name = $this->validation->checkInput($input_message_name);
            $vars['contact'] = json_encode(['type'=>$select_message_type, 'name'=>$input_message_name]);

            $user = $this->user_model->get_by_fields(['email'=>$vars['email']]);
            if ($user) {
                $this->input->set_cookie('sign_up_error', "Email has already been registered", 1);
                redirect('sign/up');
                die();
            }
            $vars['password'] = password_hash($vars['password'], PASSWORD_DEFAULT);

            $this->user_model->add_one($vars);
            $this->success('Registered successfully', 'sign/in');
        }else{
            $this->error('error');
        }
    }

    /**
     * 忘记密码
     * @param  string $value [description]
     * @return [type]        [description]
     */
    public function forget($value='')
    {
        $template = 'sign_forget';
        $this->template->build($template,$this->data);
    }


    /**
     * 退出登录
     * @return [type] [description]
     */
    public function logout()
    {
        delete_cookie('P_INFO');

        $this->clean_login();
        $site_url = site_url();

        if (strpos($site_url, "addigger.palmax.com")) {
            redirect("advertiser/sign/in");
            die();
        }elseif (strpos($site_url, "adcaptain.palmax.com")) {
            redirect("publisher/sign/in");
            die();
        }else{
            redirect("sign/manager_in");
        }
    }

    /**
     * 企业登录
     * @return [type] [description]
     */
    public function company_in()
    {
        $template = 'sign_company_in';
        $this->template->build($template,$this->data);
    }

    /**
     * 企业登录
     * @return [type] [description]
     */
    public function advertiser_in()
    {
        $template = 'sign_advertiser_in';
        $this->template->build($template,$this->data);
    }


    /**
     * 企业登录
     * @return [type] [description]
     */
    public function form_company_in_action()
    {
        if (IS_POST) {
            $vars['email'] = $this->input->post('input_email');
            $vars['password'] = $this->input->post('input_password');
            $vars['company_account'] = $this->input->post('input_account');
            $vars = $this->validation->checkInput($vars);

            $user = $this->user_model->get_by_fields(['email'=>$vars['email']]);
            if (!$user) {
                $this->input->set_cookie('sign_in_error', "The user is not exist.", 1);
                redirect('sign/company_in/'.$vars['input_account']);
                die();
            }
            if ($user['company_account']!=$vars['company_account']) {
                $this->input->set_cookie('sign_in_error', "Account is wrong.", 1);
                redirect('sign/company_in/'.$vars['input_account']);
                die();
            }
            if (password_verify($vars['password'], $user['password'])) {
                unset($user['password']);

                if (!$user['company_id']) {
                    $this->input->set_cookie('sign_in_error', "Please select a normal user login.", 1);
                    redirect('sign/in/');
                    die();
                }

                if ($this->input->post('remember')==1) {
                    $date = 86500 * 7;
                }else{
                    $date = 86500;
                }
                $this->input->set_cookie("P_INFO", json_encode($user), $date);
                redirect('dashboard/index');
            }else{
                $this->input->set_cookie('sign_in_error', "Password is wrong.", 1);
                redirect('sign/company_in/'.$vars['input_account']);
                die();
            }
            
        }else{
            redirect('sign/company_in');
        }
    }


    /**
     * 公司注册
     * @return [type] [description]
     */
    public function company_up()
    {

        $template = 'sign_company_up';
        $this->template->build($template,$this->data);
    }


    /**
     * 企业邀请注册
     * @param  string $value [description]
     * @return [type]        [description]
     */
    public function form_company_up_action($value='')
    {
        if (IS_POST) {
            $this->load->model('company_model');
            if (!$this->input->post('input_account')) {
                $this->input->set_cookie('sign_up_error', "The account is error", 1);
                redirect('sign/company_up');
                die();
            }
            $account = $this->input->post('input_account');
            $company_info = $this->company_model->get_by_fields(['account'=>$account]);
            if (!$company_info) {
                $this->input->set_cookie('sign_up_error', "The account is error", 1);
                redirect('sign/company_up/'.$account);
                die();
            }

            $vars['first_name'] = $this->input->post('input_first');
            $vars['last_name'] = $this->input->post('input_last');
            $vars['email'] = $this->input->post('input_email');
            $vars['password'] = $password = $this->input->post('input_password');
            $input_PasswordCheck = $this->input->post('input_PasswordCheck');

            $vars['user_name'] = $vars['last_name'].' '.$vars['first_name'];

            $vars = $this->validation->checkInput($vars);
            if (!$vars['email']) {
                $this->input->set_cookie('sign_up_error', "The email is required and cannot be empty", 1);
                redirect('sign/company_up/'.$account);
                die();
            }
            if ($password != $input_PasswordCheck) {
                $this->input->set_cookie('sign_up_error', "The password and re-enter password are not the same", 1);
                redirect('sign/company_up/'.$account);
                die();
            }

            $vars['company_id'] = $company_info['company_id'];
            $vars['company_account'] = $company_info['account'];

            $user = $this->user_model->get_by_fields(['email'=>$vars['email']]);
            if ($user) {
                $this->input->set_cookie('sign_up_error', "Email has already been registered", 1);
                redirect('sign/company_up/'.$account);
                die();
            }
            $vars['password'] = password_hash($vars['password'], PASSWORD_DEFAULT);

            $this->user_model->add_one($vars);
            $this->success('Registered successfully', 'sign/company_in/'.$vars['company_account']);
        }else{
            $this->error('error');
        }
    }


    /**
     * 登陆
     * @param  string $value [description]
     * @return [type]        [description]
     */
    public function manager_in($value='')
    {
        $template = 'sign_manager_in';
        $this->template->build($template,$this->data);
    }

    public function form_manager_in_action()
    {
        if (IS_POST) {
            $vars['email'] = $this->input->post('input_email');
            $vars['password'] = $this->input->post('input_password');
            $vars = $this->validation->checkInput($vars);

            $user = $this->manager_model->get_by_fields(['email'=>$vars['email']]);
            if (!$user) {
                $this->input->set_cookie('sign_in_error', "The manager is not exist.", 1);
                redirect('sign/manager_in');
                die();
            }
            if ($user['status']!=1) {
                $this->input->set_cookie('sign_in_error', "The manager account is closed.", 1);
                redirect('sign/manager_in');
                die();
            }
            if (password_verify($vars['password'], $user['password'])) {
                unset($user['password']);

                if ($this->input->post('remember')==1) {
                    $date = 86500 * 7;
                }else{
                    $date = 86500;
                }

                $user['type'] = 0;
                $user['head'] = "";
                $user['user_id'] = $user['manager_id'];
                unset($user['manager_id']);
                $this->input->set_cookie("P_INFO", json_encode($user), $date);
                redirect('dashboard/index');
            }else{
                $this->input->set_cookie('sign_in_error', "Password is wrong.", 1);
                redirect('sign/manager_in');
                die();
            }
            
        }else{
            redirect('sign/manager_in');
        }
    }
}

?>