<?php if (!defined('BASEPATH')) exit('No direct script access allowed');


class Dashboard extends Web_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('reports_model');
        $this->load->model('offer_model');

        if ($this->userinfo['type']==1) {
            redirect("product/listview");
        }


        $this->data['top_menu']=$this->load->view('web/top_menu_dashboard');
    }


    public function get_sql_where($sql)
    {
        if ($this->userinfo['type'] == 2) {
            //$sql .= " and marketmax_publisher_adaccount.publisher_id=".$this->userinfo['user_id'];
            $sql.=" and marketmax_publisher_adaccount.publisher_id=" . $this->userinfo['user_id'];
        } elseif ($this->userinfo['type'] == 1) {
            $sql.=" and advertiser_id=" . $this->userinfo['user_id'];
        }

        return $sql;
    }

    /**
     * 获取收入数据
     * @param  [type] $date [description]
     * @return [type]       [description]
     */
    public function get_revenue($where)
    {
        $sql="select sum(expect_revenue) as revenue,sum(spend) as spend from marketmax_reports where " . $where;

        if ($this->userinfo['type'] == 2) {
            $sql="select sum(expect_revenue) as revenue,sum(spend) as spend from marketmax_reports RIGHT JOIN marketmax_publisher_adaccount ON marketmax_publisher_adaccount.account_id = marketmax_reports.account_id  where " . $where;
        }

        $sql=$this->get_sql_where($sql);

        $data=$this->reports_model->get_report_data($sql);

        return $data?$data[0]:[];
    }


    /**
     * 获取最近七天的转化统计数据
     * @return [type]        [description]
     */
    public function get_report_data()
    {
        $date=strtotime(date('Y-m-d', strtotime("-7 day")));

        $today=strtotime(date('Y-m-d'));

        $sql="select sum(real_earning) as earning, sum(spend) as spend, sum(expect_revenue) as revenue, sum(results) as results, sum(clicks) as clicks, date from marketmax_reports  where (spend>0 or results>0) and product_id>0 and date>=" . $date . " and date<" . $today;

        if ($this->userinfo['type'] == 2) {
            $sql="select sum(real_earning) as earning, sum(spend) as spend, sum(expect_revenue) as revenue, sum(results) as results, sum(clicks) as clicks, date from marketmax_reports RIGHT JOIN marketmax_publisher_adaccount ON marketmax_publisher_adaccount.account_id = marketmax_reports.account_id where (spend>0 or results>0) and product_id>0 and date>=" . $date . " and date<" . $today;
        }

        $sql=$this->get_sql_where($sql);
        $sql.=" group by date order by date asc";

        $data=$this->reports_model->get_report_data($sql);
        return $data;
    }


    /**
     * 获取最近七天的转化统计数据
     * @return [type]        [description]
     */
    public function get_product_report_data($group, $date='')
    {
        if (!$date) {
            $date=strtotime(date('Y-m-d', strtotime("-8 day")));
        }

        //$sql = "select sum(results) as results, sum(spend) as spend, sum(expect_revenue) as revenue,".$group." from marketmax_reports RIGHT JOIN marketmax_publisher_adaccount ON marketmax_publisher_adaccount.account_id = marketmax_reports.account_id where date>=".$date;
        $sql="select sum(results) as results, sum(spend) as spend, sum(expect_revenue) as revenue," . $group . " from marketmax_reports  where date>=" . $date;

        if ($this->userinfo['type'] == 2) {
            $sql="select sum(results) as results, sum(spend) as spend, sum(expect_revenue) as revenue," . $group . " from marketmax_reports RIGHT JOIN marketmax_publisher_adaccount ON marketmax_publisher_adaccount.account_id = marketmax_reports.account_id  where date>=" . $date;
        }
        $sql=$this->get_sql_where($sql);
        $sql.=" group by " . $group;

        $data=$this->reports_model->get_report_data($sql);
        return $data;
    }


    /**
     * 获取最近七天的转化统计数据
     * @return [type]        [description]
     */
    public function get_product_rate($group, $date='')
    {
        if (!$date) {
            $date=strtotime(date('Y-m-d', strtotime("-8 day")));
        }

        //$sql = "select sum(results) as results, sum(spend) as spend, sum(expect_revenue) as revenue,".$group." from marketmax_reports RIGHT JOIN marketmax_publisher_adaccount ON marketmax_publisher_adaccount.account_id = marketmax_reports.account_id where date>=".$date;
        $sql="select sum(results) as results, sum(spend) as spend, sum(expect_revenue) as revenue," . $group . " from marketmax_reports   where date>=" . $date;
        if ($this->userinfo['type'] == 2) {
            $sql="select sum(results) as results, sum(spend) as spend, sum(expect_revenue) as revenue," . $group . " from marketmax_reports RIGHT JOIN marketmax_publisher_adaccount ON marketmax_publisher_adaccount.account_id = marketmax_reports.account_id  where date>=" . $date;

        }
        $sql=$this->get_sql_where($sql);
        $sql.=" group by " . $group;
        $data=$this->reports_model->get_report_data($sql);
        return $data;
    }

        /**
     * 获取最近七天的publisher统计数据
     * @return [type] [description]
     */
    public function get_publisher_report_data($group, $business_id='')
    {
        $date=strtotime(date('Y-m-d', strtotime("-8 day")));

        if ($this->userinfo['business']) {
            $sql="select sum(spend) as spend, sum(expect_revenue) as revenue, marketmax_publisher_adaccount.publisher_id, marketmax_publisher_adaccount.publisher_name from marketmax_reports RIGHT JOIN marketmax_publisher_adaccount ON marketmax_publisher_adaccount.account_id = marketmax_reports.account_id where date>=" . $date . " and market_business_id in (" . implode(',', $this->userinfo['business']) . ") and spend>0 group by " . $group . " order by revenue desc limit 10";
        } else {

            $sql="select sum(spend) as spend, sum(expect_revenue) as revenue, publisher_id, publisher_name from marketmax_reports where date>=" . $date . " and marketmax_publisher_adaccount.publisher_id = (" . $this->userinfo['user_id'] . ") and spend>0 group by " . $group . " order by revenue desc limit 10";
            if ($this->userinfo['type'] == 0) {
                $sql="select sum(spend) as spend, sum(expect_revenue) as revenue, publisher_id, publisher_name from marketmax_reports where date>=" . $date . " and spend>0 group by " . $group . " order by revenue desc limit 10";
            }
        }

        $data=$this->reports_model->get_report_data($sql);
        return $data;
    }





    public function index()
    {
        //昨天收入
        $date=strtotime(date('Y-m-d', strtotime("-1 day")));
        $yesterday=$this->get_revenue("date=" . $date);
        $yesterday_data=0;
        if ($yesterday) {
            $yesterday_data=$yesterday['revenue'] - $yesterday['spend'];
        }
        $this->data['yesterday_data']=$yesterday_data;

        //上个月每天的平均收入
        $this_month_date=strtotime(date('Y-m', time()) . '-01 00:00:00');
        $last_month_date=strtotime('-1 month', strtotime(date('Y-m', time()) . '-01 00:00:00'));
        $last_month=$this->get_revenue("date>=" . $last_month_date . " and date<" . $this_month_date);

        $last_month_data=0;
        if ($last_month) {
            $last_month_data=$last_month['revenue'] - $last_month['spend'];
        }

        $date=date('Y-m');
        $month=date('m', strtotime($date)); //取当前月份
        if ($month == 1) { //如果当前1月的话，处理下
            $month=12;
        } else {
            $month=$month - 1; //获得上个月月份
        }

        $year=date('Y', strtotime($date));
        $days=cal_days_in_month(CAL_GREGORIAN, $month, $year);
        $this->data['last_month_data']=$last_month_data / $days;

        //本月每月平均值
        $this_month=$this->get_revenue("date>=" . $this_month_date);
        $this_month_data=0;
        if ($this_month) {
            $this_month_data=$this_month['revenue'] - $this_month['spend'];
        }
        $this->data['this_month_data']=$this_month_data / date('d');
        $this->data['this_month_total_data']=$this_month_data;


        //最近七天的利润
        $data=$this->get_report_data();
        $profit_date=$profit_data=[];
        foreach ($data as $item) {
            $profit_date[]=date('M d', $item['date']);
            $profit_data[]=$item['revenue'] - $item['spend'];
        }
        $this->data['profit_chart']=['date'=>json_encode($profit_date), 'data'=>json_encode($profit_data)];


        //获取最近七天的产品花费数据
        $data=$this->get_product_report_data('product_id,product_name');

        $product_name=$profit_arr=$tmp_data=[];
        foreach ($data as $key=>$value) {
            $tmp_data[$value['revenue'] - $value['spend']]=$value;
        }
        krsort($tmp_data);

        foreach ($tmp_data as $profit=>$item) {
            if (count($product_name) < 10) {
                $product_name[]=$item['product_name'];
                $profit_arr[]=$profit;
            } else {
                break;
            }
        }

        $this->data['product_data']=['name'=>json_encode($product_name), 'profit'=>json_encode($profit_arr)];


        //获取最近七天的publisher花费数据
        $data=$this->get_publisher_report_data('publisher_id,publisher_name');

        $publisher_data=$tmp_data=[];
        foreach ($data as $key=>$value) {
            $tmp_data[$value['revenue'] - $value['spend']]=$value;
        }
        krsort($tmp_data);

        foreach ($tmp_data as $profit=>$item) {
            if ($item['publisher_name']) {
                $publisher_data[]=['publisher_name'=>$item['publisher_name'], 'spend'=>$item['spend'], 'revenue'=>$item['revenue'], 'profit'=>$profit];
            }
        }
        $this->data['publisher_data']=$publisher_data;


        //变化最大的10个产品
        //昨天数据
        $yesterday_date=strtotime(date('Y-m-d', strtotime("-1 day")));
        $before_yesterday_date=strtotime(date('Y-m-d', strtotime("-2 day")));
        $yesterday=$this->get_product_rate('product_id,product_name', $yesterday_date);
        $before_yesterday=$this->get_product_rate('product_id,product_name', $before_yesterday_date);

        $yesterday_results_data=$before_yesterday_results_data=$yesterday_profit_data=$before_yesterday_profit_data=[];
        if ($yesterday) {
            foreach ($yesterday as $item) {
                $yesterday_profit_data[$item['product_id']]=$item['revenue'] - $item['spend'];
                $yesterday_results_data[$item['product_id']]=$item['results'];
            }
        }
        $profit_data=$results_data=[];
        if ($before_yesterday) {
            foreach ($before_yesterday as $item) {

                $before_yesterday_profit_data[$item['product_id']]=$item['revenue'] - $item['spend'];
                $before_yesterday_results_data[$item['product_id']]=$item['results'];
            }
        }

        $product_name=[];
        if ($yesterday) {
            foreach ($yesterday as $item) {
                $product_name[$item['product_id']]=$item['product_name'];
                $profit=$item['revenue'] - $item['spend'];
                $profit_rate=1;
                if (isset($before_yesterday_profit_data[$item['product_id']])) {
                    if ($before_yesterday_profit_data[$item['product_id']] != 0) {
                        $profit_rate=($profit - $before_yesterday_profit_data[$item['product_id']]) / $before_yesterday_profit_data[$item['product_id']];
                        if ($profit - $before_yesterday_profit_data[$item['product_id']] > 0) {
                            $profit_rate=abs($profit_rate);
                        }
                    } else {
                        $profit_rate=-1;
                    }
                }
                $profit_data[$item['product_id']]=$profit_rate;


                $results_rate=1;
                if (isset($before_yesterday_results_data[$item['product_id']])) {
                    if ($before_yesterday_results_data[$item['product_id']] != 0) {
                        $results_rate=($item['results'] - $before_yesterday_results_data[$item['product_id']]) / $before_yesterday_results_data[$item['product_id']];
                        if ($item['results'] - $before_yesterday_results_data[$item['product_id']]) {
                            $results_rate=abs($results_rate);
                        }
                    } else {
                        $results_rate=-1;
                    }
                }
                $results_data[$item['product_id']]=$results_rate;
            }
        }
        arsort($results_data);
        arsort($profit_data);

        $product_profit_name=$product_results_name=$product_profit=$product_results=[];
        foreach ($results_data as $key=>$value) {
            $product_results[]=sprintf("%.2f", $value * 100);
            $product_results_name[]=$product_name[$key];
        }
        foreach ($profit_data as $key=>$value) {
            $product_profit[]=sprintf("%.2f", $value * 100);
            $product_profit_name[]=$product_name[$key];
        }

        $this->data['product_profit']=['name'=>json_encode($product_profit_name), 'data'=>json_encode($product_profit)];
        $this->data['product_results']=['name'=>json_encode($product_results_name), 'data'=>json_encode($product_results)];

        $profit_today=$this->data['last_month_data']?round(($this->data['this_month_data'] - $this->data['last_month_data']) / $this->data['last_month_data'], 2) * 100:0;
        
        $this->data['profit_today']=$profit_today;
 


        //publisher 日报列表
        if ($this->userinfo['type']==2) {
            $date = strtotime(date('Y-m-d', strtotime("-1 day")));
            $sql="select product_id,product_name, sum(day0) as day0, sum(results) as results, sum(real_earning) as real_earning, sum(spend) as spend, sum(expect_revenue) as revenue from marketmax_reports  where date=" . $date;
            $sql.=" and publisher_id=" . $this->userinfo['user_id'];
            $sql.=" group by product_id,product_name order by results desc";
            
            $data=$this->reports_model->get_report_data($sql);

            foreach ($data as $key => & $value) {
                $value['real_roi'] = $value['spend']>0?sprintf("%.2f", ($value['real_earning']-$value['spend'])/$value['spend']*100):0;
                $value['roi'] = $value['spend']>0?sprintf("%.2f", ($value['revenue']-$value['spend'])/$value['spend']*100):0;
                $value['profit'] = sprintf("%.2f", $value['revenue'] - $value['spend']);
                $value['real_profit'] = sprintf("%.2f", $value['real_earning'] - $value['spend']);
            }

            $this->data['publisher_product_data'] = $data;
        }



        $template='dashboard_index';
        $this->template->build($template, $this->data);
    }
}