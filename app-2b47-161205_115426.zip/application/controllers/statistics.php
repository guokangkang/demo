<?php

/**
 * Created by PhpStorm.
 * User: palmax
 * Date: 2016/4/26
 * Time: 15:10
 */
class Statistics extends Web_Controller
{ 
    public function __construct() {
        parent::__construct();

        //$this->userinfo = $this->checkUser('publisher');
        $this->config->load('facebook',TRUE);
        $this->data['top_menu'] = $this->load->view('web/top_menu_statistics', '', TRUE);
    }

    /**
     * 重新加载account
     * @param string $value [description]
     */
    public function reload()
    {
        $this->load->model('adaccount_model');
        $this->adaccount_model->addAccount($this->userinfo['user_id'], $this->userinfo['name']);

        $facebook_config = $this->config->item('facebook');

        $account_status = $facebook_config['account_status'];

        $this->load->model('publisher_adaccount_model');
        $sql = "SELECT adaccount.account_id, 
                    adaccount.`name`, 
                    adaccount.`status`, 
                    adaccount.min_daily_budget, 
                    adaccount.`backup`
                FROM publisher_adaccount INNER JOIN adaccount ON publisher_adaccount.account_id = adaccount.account_id
                WHERE publisher_id=".$this->userinfo['user_id']."
                ORDER BY adaccount.`name` desc
                ";

        $account = [];
        $accountlist = $this->publisher_adaccount_model->get_query($sql);
        foreach ($accountlist as $key => & $value) {
            $backup = json_decode($value['backup'], true);
            
            $value['timezone'] = $backup['timezone_name'];
            $value['currency'] = $backup['currency'];
            $value['status']   = $account_status[$value['status']];

            $account[] = $value['account_id'];
        }

        echo json_encode($accountlist);
        die();
    }

    /**
     * account列表
     * @return [type] [description]
     */
    public function account()
    {
        $facebook_config = $this->config->item('facebook');

        $account_status = $facebook_config['account_status'];
        $this->data['account_status'] = json_encode($facebook_config['account_status']);

        $this->data['currency'] = json_encode($facebook_config['currency']);

        $this->load->model('publisher_adaccount_model');
        $sql = "SELECT adaccount.account_id, 
                    adaccount.`name`, 
                    adaccount.`status`, 
                    adaccount.min_daily_budget, 
                    adaccount.`backup`
                FROM publisher_adaccount INNER JOIN adaccount ON publisher_adaccount.account_id = adaccount.account_id
                WHERE publisher_id=".$this->userinfo['user_id']."
                ORDER BY adaccount.`name` desc
                ";

        $account = [];
        $accountlist = $this->publisher_adaccount_model->get_query($sql);
        foreach ($accountlist as $key => & $value) {
            $backup = json_decode($value['backup'], true);
            $value['timezone'] = isset($backup['timezone_name'])?$backup['timezone_name']:'';
            $value['currency'] = $backup['currency'];
            $value['status']   = $account_status[$value['status']];

            $account[] = $value['account_id'];
        }

        $this->data['accountlist'] = $accountlist;
        $this->data['account'] = json_encode($account);

        $template = 'statistics_account';
        $this->template->build($template,$this->data);
    }

    public function campaign()
    {
        $facebook_config = $this->config->item('facebook');

        $currency = $facebook_config['currency'];

        $this->load->model('adaccount_model');
        $info = $this->adaccount_model->get_by_fields(['account_id'=>$this->uri->segment(3)]);

        $this->data['currency'] = $currency[$info['currency']];

        $template = 'statistics_campaign';
        $this->template->build($template,$this->data);
    }

    public function adset()
    {

        $facebook_config = $this->config->item('facebook');

        $currency = $facebook_config['currency'];

        $this->load->model('adaccount_model');
        $info = $this->adaccount_model->get_by_fields(['account_id'=>$this->uri->segment(3)]);

        $this->data['currency'] = $currency[$info['currency']];

        $facebookurl = "act_".$this->uri->segment(3)."/adsets";
        if ($this->uri->segment(4)) {
            $facebookurl = $this->uri->segment(4)."/adsets";
        }

        $this->data['facebookurl'] = $facebookurl;

        $template = 'statistics_adset';
        $this->template->build($template,$this->data);
    }


    public function ad()
    {

        $facebook_config = $this->config->item('facebook');

        $currency = $facebook_config['currency'];

        $this->load->model('adaccount_model');
        $info = $this->adaccount_model->get_by_fields(['account_id'=>$this->uri->segment(3)]);

        $this->data['currency'] = $currency[$info['currency']];

        $facebookurl = "act_".$this->uri->segment(3)."/ads";
        if ($this->uri->segment(4)) {
            $facebookurl = $this->uri->segment(4)."/ads";
        }

        $this->data['facebookurl'] = $facebookurl;

        $template = 'statistics_ad';
        $this->template->build($template,$this->data);
    }

}