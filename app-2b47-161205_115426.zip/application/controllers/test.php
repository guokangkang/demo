<?php if (!defined('BASEPATH')) exit('No direct script access allowed');


class Test extends Web_Controller
{

    /**
     * 初使化
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->model('offer_model');
    }

    public function index()
    {
        show_404();
    }

    public function wyq($value='')
    {


        $this->load->library('review');
        // $this->review->sync('652112101637285', '2016-11-13');

        $ad_data =['ad_id'=>'23842522775440565', 'country'=>'CO', 'date'=>1479052800, 'ctr'=>15.2, 'clicks'=>200, 'cvr'=>55, 'results'=>2000];
        $this->review->get_review_risk($ad_data);
    }


}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */