<?php if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

/**
 *
 * Created by PhpStorm.
 * User: palmax
 * Date: 2016/4/26
 * Time: 15:10
 */
class Demo extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
        // $this->load->library('Aws');
        // $this->load->library('appsflyer');
        // //$this->load->library('facebookapi', ['user_id'=>10040]);
        $this->load->library('aws_dynamodb');

        //$this->load->library('fetch_adset_data');
        // $this->load->library('fetch_adset_breakdowns_data');
        //$this->load->library('review');
    }


    public function tmp_sync()
    {
        $this->load->model('redshift_model');
        $ad_data['ad_id'] = '23842519369100159';
        $verify = $this->redshift_model->get_query("select * from marketmax_reviews_verify where ad_id='".$ad_data['ad_id']."'", false);

        var_dump($verify);die();

        $d = 3.4;

        for ($i=1; $i <= intval($d); $i++) { 
            echo "----<br>";
        }

        $s = $d-intval($d);
        if ($s>=0.5) {
            echo "--++<br>";
        }else{
            echo "++++<br>";
        }


        for ($i=1; $i <= 5-round($d); $i++) { 
            echo "++++<br>";
        }

        die();



        // $this->load->model('reports_model');
        // $d = $this->reports_model->get_report_data("select * from marketmax_reports where adset_id=6050111075122 limit 1");
        // var_dump($d);die();
        $this->load->library('review');

        $d = ['ad_id_country'=>'23842513526850752_US','ad_id'=>'23842513526850752', 'country'=>'US', 'date'=>1478448000, 'ctr'=>1.9785, 'cvr'=>0.6758, 'likes'=>2956, 'results'=>3420, 'shares'=>10, 'comments'=>11, 'spend'=>368.8400, 'cost'=>0.1078];

        $s = $this->review->get_review_risk($d);
        var_dump($s);die();


        // $account = [980705882005771];

        // $date = date('Y-m-d');
        // $days = date('d');
        // for ($i=0; $i <$days; $i++) { 
        //     $sync_date = date('Y-m-d', strtotime($date)-$i*86400);
        //     foreach ($account as $account_id) {
        //         $data = $this->review->sync($account_id, $sync_date);
        //         echo "done";
        //         die();
        //     }

        // }
    }


    public function fetch($value='')
    {
        // $this->load->library('fetch_adset_breakdowns_data');

        // $d = [
        //     'adset_id' => '6059734945627',
        //     'name'=>'09/14-F-M-0.1',
        //     'account_id'=>'565765470271949',
        //     'account_name'=>'sdfsdf',
        //     'campaign_id'=>'6059734792627',
        //     'campaign_name'=>'sdfdsf',
        //     'object_store_url' => 'http://play.google.com/store/apps/details?id=com.gto.zero.zboost',
        //     'app_id'=> '1625169611028646'
        // ];
        // $key = "test_eeeee";
        // $dd = $this->redis->sadd($key, json_encode($d));

        // var_dump($dd);
        // $ff = $this->redis->spop($key);

        // var_dump($ff);die();

        $this->load->library('fetch_adset_data');

        

        //$this->fetch_adset_data->setAdSetCountryInsightForQueue(10050, $d, "2016-09-20");
        // $this->fetch_adset_data->sync(10040, '679091875605974', "2016-11-12");

        // die();

        //$s= $this->facebookapi->accountToCampaigns('993169367447805');
        //var_dump($s);die();

        //$this->fetch_adset_data->sync(10075, 980705882005771, "2016-09-20");
        //$this->fetch_adset_breakdowns_data->sync(10040, 975710119193730, "2016-09-09", 'age');
       


        //$this->review->fetch_ad_comment('203935153317969_256068004771350', '572528046262358', "6055930908801");


        //$a = [1, 2, 3];
        //var_dump($a);die();
    }

    public function aws_create()
    {

        if (!$this->input->get('table')) {
            echo "no table name";
            die();
        }
        $table=$this->input->get('table');

        switch ($table) {
            case 'campaign':
                $params=[
                    'TableName'=>'campaign',
                    'KeySchema'=>[
                        [
                            'AttributeName'=>'campaign_id',
                            'KeyType'=>'HASH'  //Partition key
                        ]
                    ],
                    'AttributeDefinitions'=>[
                        [
                            'AttributeName'=>'campaign_id',
                            'AttributeType'=>'N'
                        ]
                    ]
                ];
                break;
            case 'campaign_insights':
                $params=[
                    'TableName'=>'campaign_insights',
                    'KeySchema'=>[
                        [
                            'AttributeName'=>'date',
                            'KeyType'=>'HASH'  //Partition key
                        ],
                        [
                            'AttributeName'=>'campaign_id',
                            'KeyType'=>'RANGE'  //Sort key
                        ]
                    ],
                    'AttributeDefinitions'=>[
                        [
                            'AttributeName'=>'date',
                            'AttributeType'=>'N'
                        ],
                        [
                            'AttributeName'=>'campaign_id',
                            'AttributeType'=>'N'
                        ],

                    ]
                ];
                break;
            case 'adset':
                $params=[
                    'TableName'=>'adset',
                    'KeySchema'=>[
                        [
                            'AttributeName'=>'adset_id',
                            'KeyType'=>'HASH'  //Partition key
                        ]
                    ],
                    'AttributeDefinitions'=>[
                        [
                            'AttributeName'=>'adset_id',
                            'AttributeType'=>'N'
                        ]
                    ]
                ];
                break;
            case 'adset_insights':
                $params=[
                    'TableName'=>'adset_insights',
                    'KeySchema'=>[
                        [
                            'AttributeName'=>'date',
                            'KeyType'=>'HASH'  //Partition key
                        ],
                        [
                            'AttributeName'=>'adset_id',
                            'KeyType'=>'RANGE'  //Sort key
                        ]
                    ],
                    'AttributeDefinitions'=>[
                        [
                            'AttributeName'=>'date',
                            'AttributeType'=>'N'
                        ],
                        [
                            'AttributeName'=>'adset_id',
                            'AttributeType'=>'N'
                        ],

                    ]
                ];
                break;
            case 'adset_country_insights':
                $params=[
                    'TableName'=>'adset_country_insights',
                    'KeySchema'=>[
                        [
                            'AttributeName'=>'date',
                            'KeyType'=>'HASH'  //Partition key
                        ],
                        [
                            'AttributeName'=>'adset_id_country',
                            'KeyType'=>'RANGE'  //Sort key
                        ]
                    ],
                    'AttributeDefinitions'=>[
                        [
                            'AttributeName'=>'date',
                            'AttributeType'=>'N'
                        ],
                        [
                            'AttributeName'=>'adset_id_country',
                            'AttributeType'=>'S'
                        ],

                    ]
                ];
                break;
            case 'reports':
                $params=[
                    'TableName'=>'reports_2016-06',
                    'KeySchema'=>[
                        [
                            'AttributeName'=>'date',
                            'KeyType'=>'HASH'  //Partition key
                        ],
                        [
                            'AttributeName'=>'adset_id_country',
                            'KeyType'=>'RANGE'  //Sort key
                        ]
                    ],
                    'AttributeDefinitions'=>[
                        [
                            'AttributeName'=>'date',
                            'AttributeType'=>'N'
                        ],
                        [
                            'AttributeName'=>'adset_id_country',
                            'AttributeType'=>'S'
                        ],

                    ]
                ];
                break;
            default:
                $params=[
                    'TableName'=>'comments',
                    'KeySchema'=>[
                        [
                            'AttributeName'=>'comment_id',
                            'KeyType'=>'HASH'  //Sort key
                        ]
                    ],
                    'AttributeDefinitions'=>[
                        [
                            'AttributeName'=>'comment_id',
                            'AttributeType'=>'S'
                        ],

                    ]
                ];
                break;
        }

        $params['ProvisionedThroughput']=[
            'ReadCapacityUnits'=>200,
            'WriteCapacityUnits'=>20
        ];


        $data=$this->aws_dynamodb->createTable($params);

        var_dump($data);
    }


    public function aws_put()
    {
        $params=['date'=>1462032000, 'adset_id_country'=>"6043882963096_DE", 'country'=>'ID', 'content'=>['tet'=>'333', 'dd'=>'ffff']];

        $fields=['date'=>1462032000, 'adset_id_country'=>'6043882963096_DE', 'account_id'=>0, 'account_name'=>'', 'adset_id'=>0, 'adset_name'=>'',
            'campaign_id'=>0, 'campaign_name'=>'', 'clicks'=>0, 'clicks_link'=>0, 'advertiser_id'=>0, 'advertiser_name'=>'',
            'business_id'=>'', 'business_name'=>'', 'company_id'=>0, 'company_name'=>'', 'cost'=>'', 'country'=>'',
            'cpa'=>'', 'cpc'=>'', 'cpm'=>'', 'ctr'=>'', 'date_day'=>0, 'date_week'=>0, 'date_month'=>0, 'date_year'=>0,
            'day0'=>0, 'day1'=>0, 'expect_revenue'=>'', 'frequency'=>'', 'impressions'=>0, 'offer_id'=>0,
            'payment_ratio'=>'', 'product_id'=>0, 'product_name'=>'', 'publisher_id'=>0, 'publisher_name'=>'',
            'reach'=>'', 'real_earning'=>'', 'results'=>0, 'retention'=>'', 'retention_info'=>'', 'revenue'=>'', 'rpa'=>'', 'spend'=>''
        ];

        //$d = ['ad_id'=>'123456', 'updated_time'=>1462032000, 'image_url'=>''];

        $data=$this->aws_dynamodb->putItem('lamaba_demo', json_encode($fields));

        $data=$this->aws_dynamodb->putItem('reports_2016-06', json_encode($fields));
        $mtime=explode(' ', microtime());
        $end=$mtime[1] + $mtime[0];

        var_dump($end - $startTime);
        die();
    }

    public function aws_get()
    {

        $key=['adset_id_country'=>'6043882963096_DE', 'date'=>1462032000];

        $data=$this->aws_dynamodb->getItem('reports-2016-05', json_encode($key));

        var_dump($data);
    }

    public function aws_update()
    {
        $params=['date'=>123456, 'adset_id_country'=>"123456_ID", 'adset_id'=>123456, 'country'=>'ID', 'content'=>['tet'=>'333', 'dd'=>'ffff']];


        $key=['date'=>123456, 'adset_id_country'=>"123456_ID"];

        $eav=[':a'=>'wang', ':b'=>'yanqing', ':c'=>"aaaa"];
        $query='set first_name = :a, last_name=:b, content.dd=:c';


        $data=$this->aws_dynamodb->updateItem('Reports', json_encode($key), json_encode($eav), $query);

        var_dump($data);
        die();
    }


    public function deleteTable($value='')
    {
        $s=$this->aws_dynamodb->deleteTable('Reports');
        var_dump($s);
    }


    public function test($value='')
    {
        $this->load->model('reports_model');
        $this->reports_model->find();
    }


    public function describeTable($value='')
    {
        $s=$this->aws_dynamodb->listTables('comments');
        var_dump($s);
    }


    public function wyq($value='')
    {
        $result=$this->aws_dynamodb->describeTable('reports-2016-06');

        // The result of an operation can be used like an array
        echo $result['Table']['ItemCount'] . "\n";
    }


    public function scan($value='')
    {
        $key = [':val1' => ['S' => '23842514325740752_GD']];
        $val = 'adset_id_country = :val1';
        $response = $this->aws_dynamodb->scan("marketmax_reports_new_2016", $key, $val);

        var_export($response);die();
    }

    


}