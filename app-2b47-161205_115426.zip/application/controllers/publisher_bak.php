<?php
/**
 * Created by PhpStorm.
 * User: palmax
 * Date: 2016/4/26
 * Time: 15:10
 */
class Publisher extends Web_Controller
{

    public function __construct() {
        parent::__construct();

        $this->load->model('user_model');
        $this->load->model('reports_model');
    }


    public function get_data1($publisher_id, $start_time, $end_time)
    {
        $sql = "select 
                    sum(results) as results,
                    sum(spend) as spend,
                    sum(expect_revenue) as earning,
                    sum(real_earning) as real_earning,
                    sum(real_earning) as real_earning,
                    sum(day0) as day0,
                    sum(day1) as day1,
                    date,
                    product_id, 
                    product_name
                from marketmax_reports 
                where date>=".$start_time." and date<=".$end_time."
                and publisher_id=".$publisher_id." 
                group by product_id,product_name,date
                order by results desc";
        $data = $this->reports_model->get_report_data($sql);
        $data_list = $data1 = $data1_product = $data1_a_f = $data1_day0 = $data1_day1 = $data1_roi = $data1_product = $data1_spend = $data1_results = $data1_earning = $data1_real_earning = [];
        foreach ($data as $item) {
            $data1_date[$item['date']]           = date('M d', $item['date']);


            $tmp[$item['product_name']]['results'][$item['date']] = $item['results'];            
            $tmp[$item['product_name']]['day0'][$item['date']] = $item['day0'];            
            $tmp[$item['product_name']]['day1'][$item['date']] = $item['day1'];            
            $tmp[$item['product_name']]['earning'][$item['date']] = floatval(sprintf("%.2f", $item['earning']));  
            $tmp[$item['product_name']]['real_earning'][$item['date']] = floatval(sprintf("%.2f", $item['real_earning']));  
            $tmp[$item['product_name']]['spend'][$item['date']] = floatval(sprintf("%.2f", $item['spend']));  
            $tmp[$item['product_name']]['roi'][$item['date']] = floatval(sprintf("%.2f", ($item['real_earning']-$item['spend'])/$item['spend']*100));
            $tmp[$item['product_name']]['cpi'][$item['date']] = $item['results']>0?floatval(sprintf("%.2f", $item['spend']/$item['results'])):0;
            $tmp[$item['product_name']]['a_f'][$item['date']] = $item['results']>0?floatval(sprintf("%.2f", $item['day0']/$item['results']*100)):0;

            $item['roi'] = sprintf("%.2f", ($item['real_earning']-$item['spend'])/$item['spend']*100);
            $item['cpi'] = $item['results']>0?floatval(sprintf("%.2f", $item['spend']/$item['results'])):0;
            $item['date']==$end_time && $data_list[] = $item;
            
        }

        for ($i=0; $i <= 6; $i++) { 
            $start_date = date('Y-m-d', $start_time);
            $d = strtotime("$start_date +$i day");
            !isset($data1_date[$d]) && $data1_date[$d] = date('M d', $d);
        }
        ksort($data1_date);
        $data1_product = array_keys($tmp);

        foreach ($tmp as $key => $value) {
            foreach ($value as $k => $v) {
                for ($i=0; $i <= 6; $i++) { 
                    $start_date = date('Y-m-d', $start_time);
                    $d = strtotime("$start_date +$i day");
                    !isset($v[$d]) && $v[$d] = 0;
                }
                ksort($v);
                $data1[$key][$k] = array_values($v);
            }
        }

        foreach ($data1 as $key => $value) {
            $data1_day0[] = ['name'=>$key, 'type'=>'line', 'data'=>$value['day0']];
            $data1_day1[] = ['name'=>$key, 'type'=>'line', 'data'=>$value['day1']];
            $data1_results[] = ['name'=>$key, 'type'=>'line', 'data'=>$value['results']];
            $data1_earning[] = ['name'=>$key, 'type'=>'line', 'data'=>$value['earning']];
            $data1_real_earning[] = ['name'=>$key, 'type'=>'line', 'data'=>$value['real_earning']];
            $data1_spend[] = ['name'=>$key, 'type'=>'line', 'data'=>$value['spend']];
            $data1_roi[] = ['name'=>$key, 'type'=>'line', 'data'=>$value['roi']];
            $data1_cpi[] = ['name'=>$key, 'type'=>'line', 'data'=>$value['cpi']];
            $data1_a_f[] = ['name'=>$key, 'type'=>'line', 'data'=>$value['a_f']];
        }

        return [$data1_product, $data_list, $data, array_values($data1_date), $data1_day0, $data1_day1, $data1_results, $data1_earning, $data1_real_earning, $data1_spend, $data1_roi, $data1_cpi, $data1_a_f];
    }

    public function daily(){

        $publisher_id = $this->userinfo['user_id'];

        if ($this->userinfo['type']==0) {
            if (!$this->input->get('publisher')) {
                redirect('dashboard');die();
            }
            $publisher_id = $this->input->get('publisher');
        }
        $publisher_info = $this->user_model->get_by_id($publisher_id);

        $publisher_info = $this->user_model->get_by_id($publisher_id);
        if (!$publisher_info) {
            redirect('dashboard');die();
        }
        if (!$publisher_info['token']) {
            redirect('dashboard');die();
        }
        $date = date('Y-m-d');
        if ($this->input->get('date')) {
            $date = $this->input->get('date');
        }
        
        $time = strtotime($date);

        $this->data['current_date'] = $time;

        $this->data['publisher_info'] = $publisher_info;

        $start_time = strtotime("$date -6 day");
        $this->data['current_7date'] = $start_time;

        list($data1_product, $data1_list, $data1, $data1_date, $data1_day0, $data1_day1, $data1_results, $data1_earning, $data1_real_earning, $data1_spend, $data1_roi, $data1_cpi, $data1_a_f) = $this->get_data1($publisher_id, $start_time, $time);
        $this->data['data1'] = ['product'=>json_encode($data1_product), 'date'=>json_encode($data1_date), 'day0'=>json_encode($data1_day0), 'day1'=>json_encode($data1_day1), 'results'=>json_encode($data1_results), 'earning'=>json_encode($data1_earning), 'real_earning'=>json_encode($data1_real_earning), 'spend'=>json_encode($data1_spend), 'roi'=>json_encode($data1_roi), 'cpi'=>json_encode($data1_cpi), 'a_f'=>json_encode($data1_a_f)];
        $this->data['data1_list'] = $data1_list;

        $this->template->set_template('web/publisher_daily');
        $this->template->set_view_dir("web");
        $this->template->build('publisher_daily',$this->data);
    }

}
