<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


/**
 * Send an email
 *
 * @access	public
 * @return	bool
 */

function my_send_email($sendto,$mail_template,$mail_data)
{
	//载入类库
	$ci = &get_instance();
	$ci->load->library('email');
	$ci->load->library('parser');	
	$ci->config->load('setting',TRUE);
	
	//获取配置信息
	$site_info = $ci->config->item('basic','setting');
	$mail_template = $ci->config->item($mail_template,'setting');
	$mailserver = $ci->config->item('mailserver','setting');
	//初使化邮件发送配置
	if($mailserver['protocol'] == 'smtp'){
		$config['protocol'] = 'smtp';
		$config['smtp_host'] = $mailserver['smtp_host'];
		$config['smtp_user'] = $mailserver['smtp_user'];
		$config['smtp_pass'] = $mailserver['smtp_pass'];
		$config['smtp_port'] = $mailserver['smtp_port'];
	}else{
		$config['protocol'] = 'mail';
	}
	$config['mailtype'] = $mail_template['mailtype'];
	$ci->email->initialize($config);

	//邮件内容设置
	$mail['subject'] = $mail_template['subject'];
	$mail['message'] = $ci->parser->parse_string($mail_template['template'], $mail_data, TRUE);
	$mail['from'] = $mailserver['from'];
	$mail['sender'] = $mailserver['sender'];
	//发送邮件
	$ci->email->from($mail['from'], $mail['sender']);
	$ci->email->to($sendto);
	$ci->email->subject($mail['subject']);
	$ci->email->message($mail['message']);
	
	return $ci->email->send();	
}


