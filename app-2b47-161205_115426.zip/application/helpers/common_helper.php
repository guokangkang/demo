<?php

/**
 * 公共函数 小助手
 *
 */


/**
 * url 生成函数
 * 所有参数都用  用 的 顺序查找方式
 * @param $modules 'ask/index'
 * @param $param 'dddd' 随便写
 */
function U($modules='', $param='')
{

    $base=config_item('base_url');
    $baselen=strlen($base) - 1;
    if ($base == '') $base='/';
    elseif ($base != '' && $base[$baselen] != '/') $base=$base . '/';

    if (empty($modules)) return getlasturl($base);
    if (is_array($modules)) {
        $param=empty($modules['p'])?'':$modules['p'];
        $modules=$modules['m'];
    }
    $rewrit=config_item('url_rewrite');
    $mod=explode('/', $modules);
    $module=$mod[0]; //控制器
    $action=empty($mod[1])?'index':$mod[1]; //方法
    $modules=$module . '/' . $action;
    $url='index.php/' . $modules . '/' . $param;

    //伪静态信息  通过路由来实现
    if ($rewrit) {

        //控制器 缩写
        $rmodule=array(
            'index3'=>'',//首页 不用显示控制器

        );
        //方法缩写
        $raction=array(
            'index3'=>'i',

        );
        $rmodule=isset($rmodule[$module])?$rmodule[$module]:$module;
        $raction=isset($raction[$action])?$raction[$action]:$action;
        $rurl=$rmodule . '/' . $raction;

        //单独需要伪静态的
        switch ($modules) {
            case 'index3/news':
                echo 33;
                break;

        }

        $rurl=$modules . '/' . $param;
        $url=$rurl;
    }


    return getlasturl($base . $url);
}

/**
 * url 生成函数
 * 所有参数都用  用 的 顺序查找方式
 * @param $modules 'ask/index'
 * @param $param 'dddd' 随便写
 */
function RU($modules='', $param='')
{
    return config_item('rewrite_url');
}

/**
 * 获取最后的url  末尾没有/
 * @param unknown $url
 * @return Ambigous <unknown, string>
 */
function getlasturl($url)
{
    if ($url == '/') return $url;
    $url=substr($url, -1) == '/'?substr($url, 0, -1):$url;
    return $url;

}

/**
 * 404 等错误页面跳转页
 * 如果传如 $param 就表示检测第$param个参数是否存在
 * @param number $param 需要检测的第几个参数
 * @param string $url 跳转的url
 */
function errmsg($param=0, $url='')
{
    $url=empty($url)?U('index/error404'):$url;
    if (is_numeric($param) && $param > 0) {
        $CI= &get_instance();
        if ($CI->uri->rsegment($param)) {
            header('location: ' . $url);
            die;
        }

    } else {
        header('location: ' . $url);
        die;
    }
}

/**
 * 中文字符 截取   并且添加...
 * @param unknown $str
 * @param number $len
 * @param string $encode
 * @return string
 */
function cutstr($str, $len=10, $dian=0, $encode='utf-8')
{
    if (mb_strlen($str, $encode) > $len) {
        $str=mb_substr($str, 0, $len, $encode);
        if ($dian) $str.='...';
    }
    return $str;
}

/**
 * 中文字符 截取   并且添加...
 * @param unknown $str
 * @param number $len
 * @param string $encode
 * @return string
 */
function dateform($str, $ge)
{
    return date($ge, $str);
}

/**
 * 取得分割符前后的数值
 * @param unknown $str
 * @param number $sep 分割符
 * @param string $flag 0前 1后
 * @return string
 */
function getSepValue($param)
{
    extract($param);
    $pos=strpos($str, $sep);
    if ($pos === false) {
        return false;
    } else {
        $arr=explode($sep, $str);
        if ($flag) {
            return $arr[1];
        } else {
            return $arr[0];
        }
    }

}

/**
 * smarty 局部不缓存函数
 * @param string $arguments
 * @param string $obj
 * @return string
 */
function insert_get_sessionkey($arguments='', $obj=null)
{
    $CI= &get_instance();
    $CI->load->library('session');
    //生成表单验证   防止重复提交
    $checkLoginRepeatSubmit=md5(mt_rand(100, 9999999));
    if ($arguments['ac'] == 'login') {
        $CI->session->set_userdata('logincode', $checkLoginRepeatSubmit);
    } elseif ($arguments['ac'] == 'reg') {
        $CI->session->set_userdata('originator', $checkLoginRepeatSubmit);
    } elseif ($arguments['ac'] == 'que') {
        $CI->session->set_userdata('questionSubmit', $checkLoginRepeatSubmit);
    } else {
        $CI->session->set_userdata($arguments['ac'] . 'Submit', $checkLoginRepeatSubmit);
    }
    return $checkLoginRepeatSubmit;
}

/**
 * smarty 头部登录不缓存
 * @param string $arguments
 * @param string $obj
 * @return string
 */
function insert_get_login()
{
    $CI= &get_instance();
    $CI->load->library('session');
    $uid=$CI->session->userdata('uid');
    $str='<a href="' . site_url() . 'login" class="login">登录</a>|<a href="' . site_url() . 'register">注册</a>';
    if ($uid) {
        $username=$CI->session->userdata('username');
        $str='<a href="' . site_url() . 'user/uzone/" class="login">' . $username . '</a>|<a href="' . site_url() . 'login/logout">退出</a>';
    } elseif (isset($_COOKIE['uid']) && $_COOKIE['uid']) {
        $uid=$_COOKIE['uid'];
        $username=$_COOKIE['username'];
        $str='<a href="' . site_url() . 'login" class="login">' . $username . '</a>|<a href="' . site_url() . 'login/logout">退出</a>';
    }
    return $str;
}

/**
 * 判断变量是否设置
 * @param unknown $str
 * @return int
 */
function _isset($a)
{
    if (isset($a)) {
        return 1;
    } else {
        return 0;
    }
}

function create_guid()
{
    $charid=strtoupper(md5(uniqid(mt_rand(), true)));
    $hyphen=chr(45);// "-"
    $uuid=chr(123);// "{"
    $uuid=substr($charid, 0, 8) . $hyphen
        . substr($charid, 8, 4) . $hyphen
        . substr($charid, 12, 4) . $hyphen
        . substr($charid, 16, 4) . $hyphen
        . substr($charid, 20, 12);
    //.chr(125);// "}"
    return $uuid;
}

/**
 * 检查当前语言环境
 */
function lang($key)
{
    $CI= &get_instance();
    $lang=$_SERVER['HTTP_ACCEPT_LANGUAGE'];

    //把中文先隐藏掉了，直接用英文
    $CI->lang->load('accountmax', 'english');

    return $CI->lang->line($key);

    if ($CI->session->userdata('maxlanguage')) {
        $CI->lang->load('accountmax', $CI->session->userdata('maxlanguage'));
    } else {
        if (preg_match("/zh-c/i", $lang))
            $CI->lang->load('accountmax', 'zh_cn');
        else if (preg_match("/en/i", $lang))
            $CI->lang->load('accountmax', 'english');
        else
            $CI->lang->load('accountmax', 'english');
    }
    //把中文先隐藏掉了，直接用英文
    $CI->lang->load('accountmax', 'english');

    return $CI->lang->line($key);
}


/**
 * 检查当前语言环境
 */
function isenglish()
{
    $lang=$_SERVER['HTTP_ACCEPT_LANGUAGE'];

    if (preg_match("/zh-c/i", $lang))
        return 'zh-cn';
    else
        return 'en';

    return 'en';
}

/**
 * 消息展示
 * @param  string $msg [description]
 * @param  string $url [description]
 * @param  integer $status [description]
 * @param  integer $time [description]
 * @return [type]          [description]
 */
function showerror($msg='', $url='', $status=0, $time=3)
{
    $CI= &get_instance();
    if (empty($msg)) $msg='您请求的页面不存在或者已经删除';
    if (empty($url)) $url=U();
    //if($status==1) $status = '成功了';
    //else $status = '出错了';
    $data['msg']=$msg;
    $data['url']=$url;
    $data['status']=$status;
    $data['time']=$time;
    //强制不缓存
    $data['on']='ask';

    $CI->session->set_userdata('__trip__', $data);
    redirect($url);
}


/**
 * twitter 最终广告商产业
 * @param  string $key [description]
 * @return [type]      [description]
 */
function get_twitter_dict($key='')
{
    $dict=["Agency:Advertising", "Agency:Media", "Agency:PR", "Automotive:Dealership", "Automotive:Industrial & Farm Vehicle", "Automotive:Light Vehicle", "Automotive:Parts & Service", "Automotive:Recreational", "Consumer Packaged Goods:Beverage", "Consumer Packaged Goods:Food", "Consumer Packaged Goods:Home & Office", "Consumer Packaged Goods:Household Goods", "Consumer Packaged Goods:Personal Care", "Consumer Packaged Goods:Pet", "Consumer Packaged Goods:Pharmaceutical", "Consumer Packaged Goods:Tobacco", "Ecommerce:Auctions", "Ecommerce:Catalog", "Ecommerce:Retail", "Education:College & University", "Education:School", "Education:Technical & Trade School", "Energy & Utilities:Energy", "Energy & Utilities:Gasoline & Petroleum", "Energy & Utilities:Other", "Energy & Utilities:Utilities", "Entertainment & Media:Agents & Promoters", "Entertainment & Media:Artists & Performers", "Entertainment & Media:Arts", "Entertainment & Media:Gambling", "Entertainment & Media:Information", "Entertainment & Media:Movies", "Entertainment & Media:Museums & Parks", "Entertainment & Media:Music", "Entertainment & Media:Radio", "Entertainment & Media:Sports & Recreation", "Entertainment & Media:Television", "Financial Services:Credit & Financing", "Financial Services:Insurance", "Financial Services:Investment Bank & Brokerage", "Financial Services:Real Estate", "Financial Services:Retail & Commercial Bank", "Gaming:Canvas", "Gaming:Console", "Gaming:Cross Platform", "Gaming:Game & Toy", "Gaming:Mobile", "Gaming:Online", "Gaming:Real Money", "Gaming:Software", "Government & Politics:Government", "Government & Politics:Political", "Organizations & Associations:Non-Profit", "Organizations & Associations:Other", "Organizations & Associations:Religious", "Other:Agriculture & Farming", "Other:B2B Manufacturing", "Other:Construction & Mining", "Other:Do Not Use - formerly retail", "Other:Transportation Equipment", "Professional Services:Business Support Services", "Professional Services:Career", "Professional Services:Consulting", "Professional Services:Dating", "Professional Services:Engineering & Design", "Professional Services:Facility Services", "Professional Services:Health & Family Care", "Professional Services:Legal & Accounting", "Professional Services:Personal Care", "Professional Services:Photography", "Professional Services:Repair & Maintenance", "Retail:Apparel", "Retail:Department Store", "Retail:Electronics & Appliances", "Retail:Grocery, Drug & Convenience", "Retail:Home & Office", "Retail:Home Improvement", "Retail:Other", "Retail:Pet", "Retail:Rentals", "Retail:Restaurant", "Retail:Sporting, Hobby & Bookstore", "Technology:B2B Hardware", "Technology:Computing & Peripherals", "Technology:Consumer Electronics", "Technology:Consumer Mobile Device", "Technology:Navigation & Measurement", "Technology:Software", "Telecom:Other", "Telecom:Wireless Services", "Telecom:Wireline Services", "Travel:Air", "Travel:Auto Rental", "Travel:Bus & Taxi", "Travel:Convention & Visitors Bureau (CVB)", "Travel:Hotel & Accomodation", "Travel:Operations & Other", "Travel:Rail & Water", "Travel:Travel Agency", "Travel:Truck & Moving"];
    if (isset($dict[$key]))
        return $dict[$key];
    return $dict;
}

/**
 * 解密已经加密
 *
 * @param string $encryptedText
 * @return string
 */
function _decrypt($encryptedText)
{
    $config_key=config_item('encryption_key');
    $cryptText=base64_decode($encryptedText);
    $ivSize=mcrypt_get_iv_size(MCRYPT_RIJNDAEL_256, MCRYPT_MODE_ECB);
    $iv=mcrypt_create_iv($ivSize, MCRYPT_RAND);
    $decryptText=mcrypt_decrypt(MCRYPT_RIJNDAEL_256, $config_key, $cryptText, MCRYPT_MODE_ECB, $iv);
    return trim($decryptText);
}

/**
 * 加密
 *
 * @param string $plainText
 * @return string
 */
function _encrypt($plainText)
{
    $config_key=config_item('encryption_key');
    $ivSize=mcrypt_get_iv_size(MCRYPT_RIJNDAEL_256, MCRYPT_MODE_ECB);
    $iv=mcrypt_create_iv($ivSize, MCRYPT_RAND);
    $encryptText=mcrypt_encrypt(MCRYPT_RIJNDAEL_256, $config_key, $plainText, MCRYPT_MODE_ECB, $iv);
    return trim(base64_encode($encryptText));
}

/**
 * 为excel导入数据处理
 * @param $string
 * @return mixed 返回string 需要匹配的值
 */
function getPattern($string)
{
    if (is_string($string)) {
        $pattern='/[1-9][0-9]{12}/';
        preg_match($pattern, $string, $matches);
        $data=$matches[0];
        return $data;
    }
}


/**
 * 获取分页配置
 * @param  [type]  $config      [description]
 * @param  [type]  $total_rows  [description]
 * @param  integer $uri_segment [description]
 * @param  integer $per_page [description]
 * @return [type]               [description]
 */
function get_web_page($config, $total_rows, $uri_segment=3, $per_page=10)
{
    $config['total_rows']=$total_rows;
    $config['per_page']=$per_page;
    //$config['uri_segment'] = $uri_segment; 
    $config['page_query_string']=true;
    $config['enable_query_strings']=true;
    $config['num_tag_open']='<li class="page">';
    $config['num_tag_close']='</li>';
    $config['cur_tag_open']='<li class="page active"><a>';
    $config['cur_tag_close']='</a></li>';
    $config['full_tag_open']='<ul class="pagination clearfix">';
    $config['full_tag_close']='</p>';
    $config['prev_link']='Front';
    $config['prev_tag_open']='<li class="prev">';
    $config['prev_tag_close']='</li>';
    $config['next_link']='Next';
    $config['next_tag_open']='<li class="next">';
    $config['next_tag_close']='</li>';

    return $config;
}


/**
 * 记录抓取警告信息
 * @param string $value [description]
 */
function fetch_exception($account, $fetch_event, $message, $extend="")
{
    $ci= &get_instance();

    $vars['account']=$account;
    $vars['fetch_event']=$fetch_event;
    $vars['message']=$message;
    $vars['extend']=$extend;

    $vars['date']=strtotime(date('Y-m-d'));
    $ci->load->model('fetch_exception_model');
    return $ci->fetch_exception_model->add_one($vars);
}


/**
 * 图片上传[产品图]
 * @return [type] [description]
 */
function upload_aws($pathStr='')
{
    $ci= &get_instance();
    $ci->load->library('Aws');
    if (!$_FILES) {
        return ['error'=>1, 'message'=>'img empty'];
    }

    $url="";
    $_FILES['filedata']=$_FILES['file'];
    if ($_FILES['filedata']['name']) {
        $ci->load->library('AwsUpload');

        $ci->awsupload->checkUpload();
        $checkinfo=$ci->awsupload->stateInfo;
        $getFileExt=$ci->awsupload->getFileExt();

        if ($checkinfo != 'SUCCESS') {
            return ['error'=>1, 'message'=>$checkinfo];
            die();
        }

        if (!$pathStr) {
            //$pathStr = date( "Ymd" ) .'/'. time() . rand( 1 , 10000 ) . $getFileExt;
            $pathStr="retention_report/" . time() . rand(1, 10000) . $getFileExt;
        }


        $image_info=file_get_contents($_FILES['filedata']['tmp_name']);
        $s3url=$ci->aws->upload(config_item('Marketmax_Generalfile'), $pathStr, $image_info);
        //$url = str_replace(config_item('S3Domain'), "", $url);
        $url=$pathStr;
    }
    return ['error'=>0, 'message'=>$url, 'info'=>$pathStr];
}

/**
 * 获取app 的包名
 *
 * @param string $value [description]
 */
function get_app_id($item)
{
    $app_id="";
    if (strpos($item, "google") !== false) {
        if ($index=strpos($item, "=")) {
            $app_id=$play_id=substr($item, $index + 1);
        }
    } elseif (strpos($item, "itunes") !== false) {
        $index=strpos($item, "/id");
        if ($index=strpos($item, "/id")) {
            if (strpos($item, '?') === false) {
                $app_id=$itunes_id=substr($item, $index + 3);
            } else {
                $end=strpos($item, '?');
                $app_id=$itunes_id=substr($item, $index + 3, $end - ($index + 3));
            }
        }
    }
    return $app_id;
}

/**
 * 获取中英文字母的首个单词
 * @param [type] $str [description]
 */
function get_first_letters($str, $len=1)
{

    if (ord($str) > 128) { //汉字开头

        $str=iconv("UTF-8", "gb2312", $str);//如果程序是gbk的，此行就要注释掉
        if (preg_match("/^[\x7f-\xff]/", $str)) {
            $fchar=ord($str{0});
            if ($fchar >= ord("A") and $fchar <= ord("z")) return strtoupper($str{0});
            $a=$str;
            $val=ord($a{0}) * 256 + ord($a{1}) - 65536;
            if ($val >= -20319 and $val <= -20284) return "A";
            if ($val >= -20283 and $val <= -19776) return "B";
            if ($val >= -19775 and $val <= -19219) return "C";
            if ($val >= -19218 and $val <= -18711) return "D";
            if ($val >= -18710 and $val <= -18527) return "E";
            if ($val >= -18526 and $val <= -18240) return "F";
            if ($val >= -18239 and $val <= -17923) return "G";
            if ($val >= -17922 and $val <= -17418) return "H";
            if ($val >= -17417 and $val <= -16475) return "J";
            if ($val >= -16474 and $val <= -16213) return "K";
            if ($val >= -16212 and $val <= -15641) return "L";
            if ($val >= -15640 and $val <= -15166) return "M";
            if ($val >= -15165 and $val <= -14923) return "N";
            if ($val >= -14922 and $val <= -14915) return "O";
            if ($val >= -14914 and $val <= -14631) return "P";
            if ($val >= -14630 and $val <= -14150) return "Q";
            if ($val >= -14149 and $val <= -14091) return "R";
            if ($val >= -14090 and $val <= -13319) return "S";
            if ($val >= -13318 and $val <= -12839) return "T";
            if ($val >= -12838 and $val <= -12557) return "W";
            if ($val >= -12556 and $val <= -11848) return "X";
            if ($val >= -11847 and $val <= -11056) return "Y";
            if ($val >= -11055 and $val <= -10247) return "Z";
        }
    } else if (ord($str) >= 48 and ord($str) <= 57) { //数字开头

        return iconv_substr($str, 0, $len, 'utf-8');

    } else if (ord($str) >= 65 and ord($str) <= 90) { //大写英文开头

        return iconv_substr($str, 0, $len, 'utf-8');


    } else if (ord($str) >= 97 and ord($str) <= 122) { //小写英文开头

        return iconv_substr($str, 0, $len, 'utf-8');
    }

    return false;
}


        /**
 * 通过
 * @param  [type] $campaign_name [description]
 * @return [type]                [description]
 */
function get_label_by_campaign($campaign_name)
{
    $campaign_name = strtolower($campaign_name);

    $custom_label = config_item('PUBLISHER_LABEL');

    $label = "";
    foreach ($custom_label as $v) {
        if (($index = strpos($campaign_name, $v)) !== false) {
            $label = substr($campaign_name, $index, strlen($v)+3);
            break;
        }
    }
    return $label;
}


/**
 * 转换数字钱币
 * @param $num
 * @return float|string
 */
function nums_format($num)
{
    $x=round($num);
    $x_number_format=number_format($x);
    $x_array=explode(',', $x_number_format);
    $x_parts=array('K', 'M', 'B', 'T');
    $x_count_parts=count($x_array) - 1;
    $x_display=$x;
    $prifix='';
    if (count($x_array)>1) {
        $prifix=((int)$x_array[1][0] !== 0?'.' . $x_array[1][0]:'');
    }
    $key=0;
    if($x_count_parts){
        $key=$x_count_parts - 1;
    }
    $x_display=$x_array[0] .$prifix ;
    $x_display.=$x_parts[$key];
    return $x_display;
}