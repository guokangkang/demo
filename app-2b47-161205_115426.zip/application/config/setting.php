<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config = array (
  'REVIEW_RISK' => 
  array (
    'cpc' => 'ddd',
  ),
);
