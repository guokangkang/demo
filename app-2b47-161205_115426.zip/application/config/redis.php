<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Config for the CodeIgniter Redis library
 *
 * @see ../libraries/Redis.php
 */

switch (getenv('APP_ENVIRONMENT')) {
    case 'development':
        $config['redis_default']['host'] = 'development_poggy-redis_1';         // IP address or host
        $config['redis_default']['port'] = '6379';          // Default Redis port is 6379
        $config['redis_default']['password'] = '';          // Can be left empty when the server does not require AUTH
        $config['redis_default']['select'] = 0;
        break;
    case 'testing':
        $config['redis_default']['host'] = 'redis-poggy.u4po2o.ng.0001.apne1.cache.amazonaws.com';     // IP address or host
        $config['redis_default']['port'] = '6379';          // Default Redis port is 6379
        $config['redis_default']['password'] = '';          // Can be left empty when the server does not require AUTH
        $config['redis_default']['select'] = 11;
        break;
    case 'production':
    default:
        $config['redis_default']['host'] = 'redis-poggy.u4po2o.ng.0001.apne1.cache.amazonaws.com';     // IP address or host
        $config['redis_default']['port'] = '6379';          // Default Redis port is 6379
        $config['redis_default']['password'] = '';          // Can be left empty when the server does not require AUTH
        $config['redis_default']['select'] = 12;
        break;
}
