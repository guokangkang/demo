<?php if (!defined('BASEPATH')) exit('No direct script access allowed');


$config['_site_name']="palmax";

$config['APP_ID']="515261858648099";
$config['APP_SECRET']="58051e59b81bc3f6af48518bed26541a";
$config['APP_VERSION']="v2.7";
$config['APP_URL']="https://graph.facebook.com/";

//授权获取api接口数据的用户id
$config['FacebookID']="119579485108576";

//AWS SNS 消息服务主题 ARN
$config['AWS_SNS_ARN']=(getenv('APP_ENVIRONMENT') == 'production')?'arn:aws:sns:ap-northeast-1:479150241584:MarketMaxNotification':'arn:aws:sns:ap-northeast-1:479150241584:BetaMarketMaxNotification';


//AWS SQS 消息服务主题 NAME
$config['AWS_SQS_NAME']=(getenv('APP_ENVIRONMENT') == 'production')?'awseb-e-2e4ezbmerm-stack-AWSEBWorkerQueue-LOU02S9G3WFZ':'awseb-e-qcsqg5u3gm-stack-AWSEBWorkerQueue-ZFPN6ZGH5378';

//$config['AWS_SQS_NAME'] = '';
//$config['AWS_SQS_NAME'] = '';

$config['Marketmax_Generalfile']="jp-marketmax-generalfile";
$config['Marketmax_Creative']="jp-marketmax-creative";

$config['CDN']="http://cdn1.marketmax.palmax.com/";

$config['MANAGER_ROLE']=['SYS', 'BD', 'AM'];

$config['LIST_EMPTY_DATA']="No Data";

$config['FACEBOOK_TOKEN']="EAAHUoMANECMBAOXS22UMxVaPYCqBXx7DWh1ZCzAncUOvYkcHSkyFQTFXKpFI8ryahetSokdxWCJx329RZA8zZAhUbRnVhgquq2jaJJt7K2Lj7B5ETJVCVEhH3c6sRJkbUhccCShwYMY90uLer10MMUkBp1bgY0ZD";
$config['payto']=[
    2=>[
        'account_name'=>'Toler Network Technology Limited',
        'account_no'=>'817-849-128-838',
        'bank_name'=>'HSBC Hong Kong',
        'swift_code'=>'HSBCHKHHHKH',
        'bank_address'=>'1 Queen\'s Road Central, Hong Kong',
        'company_address'=>'Room 203, Floor 5,Zhongkekeyi Building, Zhonguancunbeiertiao 13, Haidian District, Beijing',
        'tel'=>'01058404490',
        'contact_email'=>'changle@tolernetwork.com',
    ],
    1=>[
        'account_name'=>'Palmax Limited',
        'account_no'=>'801-507443-838',
        'bank_name'=>'HSBC Hong Kong',
        'swift_code'=>'HSBCHKHHHKH',
        'bank_address'=>'1 Queen\'s Road Central, Hong Kong',
        'company_address'=>'Room 203, Floor 5,Zhongkekeyi Building, Zhonguancunbeiertiao 13, Haidian District, Beijing	',
        'tel'=>'01058404490',
        'contact_email'=>'changle@palmax.com',
    ]
];

$config['invoice_pay_period']=[
    1=>30,
    2=>45
];


$config['PUBLISHER_LABEL']=[
    'mid',
    'sid',
    'pid',
    'did'
];

$config['tags']=[
    'TOOLS',
    'SHOPPING',
    'NEWS',
    'GAME',
    'SOCIAL'
];
