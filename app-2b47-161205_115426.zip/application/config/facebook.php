<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['account_status'] = [
    1 =>"ACTIVE",
    2 =>"DISABLED",
    3 =>"UNSETTLED",
    7 =>"PENDING_RISK_REVIEW",
    9 =>"IN_GRACE_PERIOD",
    100 =>"PENDING_CLOSURE",
    101 =>"CLOSED",
    102 =>"PENDING_SETTLEMENT",
    201 =>"ANY_ACTIVE",
    202 =>"ANY_CLOSED"
];

$config['currency'] = [
    'USD'   => '$'
];

