<!DOCTYPE html>
<html class="no-js css-menubar" lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
	<meta name="description" content="bootstrap admin template">
	<meta name="author" content="">
	<title>404</title>
	<link rel="apple-touch-icon" href="<?php echo 'http://'.$_SERVER['HTTP_HOST'];?>/assets/web/assets/images/apple-touch-icon.png">
	<link rel="shortcut icon" href="<?php echo 'http://'.$_SERVER['HTTP_HOST'];?>/assets/web/assets/images/favicon.ico">
	<!-- Stylesheets -->
	<link rel="stylesheet" href="<?php echo 'http://'.$_SERVER['HTTP_HOST'];?>/assets/web/global/css/bootstrap.min.css">
	<link rel="stylesheet" href="<?php echo 'http://'.$_SERVER['HTTP_HOST'];?>/assets/web/global/css/bootstrap-extend.min.css">
	<link rel="stylesheet" href="<?php echo 'http://'.$_SERVER['HTTP_HOST'];?>/assets/web/assets/css/site.min.css">
	<!-- Plugins -->
	<link rel="stylesheet" href="<?php echo 'http://'.$_SERVER['HTTP_HOST'];?>/assets/web/global/vendor/animsition/animsition.css">
	<link rel="stylesheet" href="<?php echo 'http://'.$_SERVER['HTTP_HOST'];?>/assets/web/global/vendor/asscrollable/asScrollable.css">
	<link rel="stylesheet" href="<?php echo 'http://'.$_SERVER['HTTP_HOST'];?>/assets/web/global/vendor/switchery/switchery.css">
	<link rel="stylesheet" href="<?php echo 'http://'.$_SERVER['HTTP_HOST'];?>/assets/web/global/vendor/intro-js/introjs.css">
	<link rel="stylesheet" href="<?php echo 'http://'.$_SERVER['HTTP_HOST'];?>/assets/web/global/vendor/slidepanel/slidePanel.css">
	<link rel="stylesheet" href="<?php echo 'http://'.$_SERVER['HTTP_HOST'];?>/assets/web/global/vendor/flag-icon-css/flag-icon.css">
	<link rel="stylesheet" href="<?php echo 'http://'.$_SERVER['HTTP_HOST'];?>/assets/web/assets/examples/css/tables/location.default.css">
	<!-- 新加css -->

	<!-- Fonts -->
	<link rel="stylesheet" href="<?php echo 'http://'.$_SERVER['HTTP_HOST'];?>/assets/web/global/fonts/font-awesome/font-awesome.css">
	<link rel="stylesheet" href="<?php echo 'http://'.$_SERVER['HTTP_HOST'];?>/assets/web/global/fonts/web-icons/web-icons.min.css">
	<link rel="stylesheet" href="<?php echo 'http://'.$_SERVER['HTTP_HOST'];?>/assets/web/global/fonts/brand-icons/brand-icons.min.css">
	<link rel='stylesheet' href='http://fonts.googleapis.com/css?family=Roboto:300,400,500,300italic'>

	<style>
		.bg_box{position: fixed;left:50%; margin-left:-267px; margin-top:-170px; top: 50%;}
		.bg_404{width:534px; height: 300px; background: url(<?php echo 'http://'.$_SERVER['HTTP_HOST'];?>/assets/web/assets/images/bg404.png) no-repeat; color: #009dc0; line-height: 300px;text-align: center;font-size: 86px;}
	</style>
	<!--[if lt IE 9]>
	<script src="<?php echo 'http://'.$_SERVER['HTTP_HOST'];?>/assets/web/global/vendor/html5shiv/html5shiv.min.js"></script>
	<![endif]-->
	<!--[if lt IE 10]>
	<script src="<?php echo 'http://'.$_SERVER['HTTP_HOST'];?>/assets/web/global/vendor/media-match/media.match.min.js"></script>
	<script src="<?php echo 'http://'.$_SERVER['HTTP_HOST'];?>/assets/web/global/vendor/respond/respond.min.js"></script>
	<![endif]-->
	<!-- Scripts -->
	<script src="<?php echo 'http://'.$_SERVER['HTTP_HOST'];?>/assets/web/global/vendor/modernizr/modernizr.js"></script>
	<script src="<?php echo 'http://'.$_SERVER['HTTP_HOST'];?>/assets/web/global/vendor/breakpoints/breakpoints.js"></script>
	<script>
		Breakpoints();
	</script>
</head>
<body class="site-navbar-small padding-0">
<!--[if lt IE 8]>
<p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
<![endif]-->

<div class="page animsition" style="background:-webkit-radial-gradient(circle,#00A7D0,#26788c); height:100%;position:relative;">
	<div class="bg_box">
		<div class="bg_404 font-weight-600">404</div>
		<p class="margin-top-20" style="color:#fff; text-align:center; font-size:20px;">Sorry...the page doesn't exist!</p>
		<p style="color:#fff; text-align:center;">You can <a href="<?php echo 'http://'.$_SERVER['HTTP_HOST'];?>" class="font-weight-600" style="color:#fff;"> return to home page.</a></p>
	</div>

</div>


<!-- Core  -->
<script src="<?php echo 'http://'.$_SERVER['HTTP_HOST'];?>/assets/web/global/vendor/jquery/jquery.js"></script>
<script src="<?php echo 'http://'.$_SERVER['HTTP_HOST'];?>/assets/web/global/vendor/bootstrap/bootstrap.js"></script>
<script src="<?php echo 'http://'.$_SERVER['HTTP_HOST'];?>/assets/web/global/vendor/animsition/animsition.js"></script>
<script src="<?php echo 'http://'.$_SERVER['HTTP_HOST'];?>/assets/web/global/vendor/asscroll/jquery-asScroll.js"></script>
<script src="<?php echo 'http://'.$_SERVER['HTTP_HOST'];?>/assets/web/global/vendor/mousewheel/jquery.mousewheel.js"></script>
<script src="<?php echo 'http://'.$_SERVER['HTTP_HOST'];?>/assets/web/global/vendor/asscrollable/jquery.asScrollable.all.js"></script>
<script src="<?php echo 'http://'.$_SERVER['HTTP_HOST'];?>/assets/web/global/vendor/ashoverscroll/jquery-asHoverScroll.js"></script>
<!-- Plugins -->
<script src="<?php echo 'http://'.$_SERVER['HTTP_HOST'];?>/assets/web/global/vendor/switchery/switchery.min.js"></script>
<script src="<?php echo 'http://'.$_SERVER['HTTP_HOST'];?>/assets/web/global/vendor/intro-js/intro.js"></script>
<script src="<?php echo 'http://'.$_SERVER['HTTP_HOST'];?>/assets/web/global/vendor/screenfull/screenfull.js"></script>
<script src="<?php echo 'http://'.$_SERVER['HTTP_HOST'];?>/assets/web/global/vendor/slidepanel/jquery-slidePanel.js"></script>
<script src="<?php echo 'http://'.$_SERVER['HTTP_HOST'];?>/assets/web/global/vendor/asrange/jquery-asRange.min.js"></script>
<!-- 新加js -->

<!-- Scripts -->
<script src="<?php echo 'http://'.$_SERVER['HTTP_HOST'];?>/assets/web/global/js/core.js"></script>
<script src="<?php echo 'http://'.$_SERVER['HTTP_HOST'];?>/assets/web/assets/js/site.js"></script>
<script src="<?php echo 'http://'.$_SERVER['HTTP_HOST'];?>/assets/web/assets/js/sections/menu.js"></script>
<script src="<?php echo 'http://'.$_SERVER['HTTP_HOST'];?>/assets/web/assets/js/sections/menubar.js"></script>
<script src="<?php echo 'http://'.$_SERVER['HTTP_HOST'];?>/assets/web/assets/js/sections/sidebar.js"></script>
<script src="<?php echo 'http://'.$_SERVER['HTTP_HOST'];?>/assets/web/global/js/configs/config-colors.js"></script>
<script src="<?php echo 'http://'.$_SERVER['HTTP_HOST'];?>/assets/web/assets/js/configs/config-tour.js"></script>
<script src="<?php echo 'http://'.$_SERVER['HTTP_HOST'];?>/assets/web/global/js/components/asscrollable.js"></script>
<script src="<?php echo 'http://'.$_SERVER['HTTP_HOST'];?>/assets/web/global/js/components/animsition.js"></script>
<script src="<?php echo 'http://'.$_SERVER['HTTP_HOST'];?>/assets/web/global/js/components/slidepanel.js"></script>
<script src="<?php echo 'http://'.$_SERVER['HTTP_HOST'];?>/assets/web/global/js/components/switchery.js"></script>

<script>
	(function(document, window, $) {
		'use strict';
		var Site = window.Site;
		$(document).ready(function() {
			Site.run();
		});
	})(document, window, jQuery);

</script>
</body>
</html>