<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * 基础控制器
 */
class MY_Controller extends CI_Controller {

	var $data = array();
	var $redis;

	var $__tips__;

	/**
	 * 返回json数据
	 * @param $data
	 */
	 /**
	  * Ajax方式返回数据到客户端
	  * @access protected
	  * @param mixed $data 要返回的数据
	  * @param String $type AJAX返回数据格式
	  * @param int $json_option 传递给json_encode的option参数
	  * @return void
	  */
	protected function ajaxReturn($data,$type='',$json_option=0) {
		if(empty($type)) $type  =   'JSON';
		switch (strtoupper($type)){
			case 'JSON' :
			/*  // 被xinnian注释，因为此处有CI集成的方法处理
				// 返回JSON数据格式到客户端 包含状态信息
				header('Content-Type:application/json; charset=utf-8');
				exit(json_encode($data,$json_option));
			*/
				$this->output->set_content_type('application/json')->set_output(json_encode($data,$json_option));
		}
	}

	/**
	 * 清空登陆信息
	 * @return [type] [description]
	 */
	public function clean_login()
    {
        unset($_SESSION['username']);
        unset($_SESSION['source_id']);
        unset($_SESSION['source']);
        unset($_SESSION['gender']);
        unset($_SESSION['source_content']);
        unset($_SESSION['locale']);
        unset($_SESSION['head']);
        unset($_SESSION['facebook_access_token']);

    }

	/**
	 * 成功跳转
	 * @param  [type] $mess [消息]
	 * @param  string $url  [跳转路径]
	 * @return [type]       [description]
	 */
	public function success($mess, $url=''){
		$this->session->set_userdata('__tips__', ['result'=>1, 'msg'=>$mess]);

		redirect($url);
	}
	
	/**
	 * 错误跳转
	 * @param  [type] $mess [消息]
	 * @param  string $url  [跳转路径]
	 * @return [type]       [description]
	 */
	public function error($mess, $url=''){
		$this->session->set_userdata('__tips__', ['result'=>0, 'msg'=>$mess]);
		redirect($url);
	}

	public function msg($errorCode,$mess){
		$this->session->set_flashdata('msg', $mess);
		echo json_encode(['error'=>$errorCode, 'message'=>$mess]);
		exit;
	}

	/**
	* 初使化
	*/
	public function __construct()
	{
		parent::__construct();
		// 载入模板库
		$this->load->spark('template/1.0.0');
		$this->load->library('template');
		$this->load->helper('common');
		$this->load->library('session');

		$this->lang->load('marketmax','zh_cn'); 

	}

}


/**
 * 前台页面根控制器
 */
class Web_Controller extends MY_Controller {


	private function check_user()
	{
		$this->load->model('business_model');
		$userinfo = get_cookie('P_INFO');
		$userinfo = json_decode($userinfo, true);
		if (!$userinfo) {
			if (strpos(site_url(), "addigger.palmax.com")) {
				redirect("advertiser/sign/in");
				die();
			}elseif (strpos(site_url(), "adcaptain.palmax.com")) {
				redirect("publisher/sign/in");
				die();
			}elseif (strpos(site_url(), "management.palmax.com")) {
				redirect("sign/manager_in");
				die();
			}

			redirect("sign/manager_in");die();
		}
		$data = $userinfo;
		if (isset($data['last_name'])) {
			$data['full_name'] = $data['last_name'].' '.$data['first_name'];
		}else{
			$data['full_name'] = $data['user_name'];
		}

		

		if ($data['type']==0 && $data['role']) {
			$data['role'] = json_decode($data['role'], true);
		}else{
			$data['role'] = [];
		}
		$data['business'] = [];
		if ($userinfo['type']!=0) {
			$business = $this->business_model->get_business_admin($userinfo['user_id']);

			$data['business'] = $business;
		}

		//必须激活才可以看其他页面
		if (($this->router->class!='user') && $this->router->class!='active') {
			if ($data['type']==2 && !$data['fb_active']) {
				redirect('user/account');
			}
		}
		
		
		return $data;
	}

	var $userinfo;
	var $categorylist;
	var $lottery_status;//中奖状态
	var $_class;
	var $_method;

	/**
	* 初使化
	*/
	public function __construct()
	{
		parent::__construct();
		header('content-type:text/html;charset=utf-8');


        $this->output->enable_profiler(False);
		$this->_class = $class = $this->router->class;
		$this->_method = $function = $this->router->method;

		if ($class != 'sign') {
			$this->userinfo = $this->check_user();
		}

		


		$layout = 'web';
		if($class=='sign' && $function=='in'){
			$this->template->set_template('web/sign_in');
		}elseif($class=='sign' && $function=='company_in'){
			$this->template->set_template('web/sign_company_in');
		}elseif($class=='sign' && $function=='advertiser_in'){
			$this->template->set_template('web/sign_advertiser_in');
		}elseif($class=='sign' && $function=='manager_in'){
			$this->template->set_template('web/sign_manager_in');
		}elseif ($class=='sign' && $function=='up'){
			$this->template->set_template('web/sign_up');
		}elseif ($class=='sign' && $function=='company_up'){
			$this->template->set_template('web/sign_company_up');
		}elseif ($class=='sign' && $function=='forget'){
			$this->template->set_template('web/sign_forget');
		}elseif ($class=='sign' && $function=='index'){
			$this->template->set_template('web/sign_index');
		}elseif ($class=='bills' && $function=='prints'){
			$this->template->set_template('web/bills_print');
		}
		else{
			$this->template->set_template($layout); 	//路径: application/views/$layout.php
		}

		$title = 'Management - Leading Mobile Advertising Platform';
		if (strpos(site_url(), "addigger.palmax.com")) {
			$title = 'AdDigger - Leading Mobile Advertising Platform';
		}elseif (strpos(site_url(), "adcaptain.palmax.com")) {
			$title = 'AdCaptain - Leading Mobile Advertising Platform';
		}



		$this->template
				->set_base_title($title)
				->add_meta_tag('keywords','')
				->set_view_dir($layout);	//路径： application/views/$layout/

		$this->__tips__ = $this->session->userdata('__tips__');
		//下边传值只能layout文件中获取到值
		//$this->template->set_variable('__tips__', $this->session->userdata('__tips__'));
		$this->session->unset_userdata('__tips__');
	}

}
