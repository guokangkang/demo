<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * 基础控制器
 */
class MY_Model extends CI_Model
{

    var $_table;
    var $_pk;
    var $_table_type;
    var $_pk_type;

    function get_query($sql, $value=[])
    {
        $data=[];
        if ($value) {
            $query=$this->db->query($sql, $value);
        } else {
            $query=$this->db->query($sql);
        }
        if ($query->num_rows() > 0) {
            $data=$query->result_array();
        }
        return $data;
    }

    function get_query_count($sql, $value=[])
    {
        $data=[];
        if ($value) {
            $query=$this->db->query($sql, $value);
        } else {
            $query=$this->db->query($sql);
        }
        return $query->num_rows();
        if ($query->num_rows() > 0) {
            $data=$query->row_array();
        }
        return $data;
    }

    function get_one($sql, $value='')
    {
        $data=[];
        if ($value) {
            $query=$this->db->query($sql, $value);
        } else {
            $query=$this->db->query($sql);
        }

        return $query->row_array();
    }

    function get_by_id($pk_id)
    {
        return $this->db->get_where($this->_table, array($this->_pk=>$pk_id))->row_array();
    }

    function get_by_fields($where)
    {
        return $this->db->get_where($this->_table, $where)->row_array();
    }

    function getwhere($condition)
    {
        $dict=['>', '<', '>=', '<=', 'in', '!='];
        $where=[];
        foreach ($condition as $key=>$value) {
            if (in_array($key, $dict) && is_array($value)) {
                foreach ($value as $k=>$v) {
                    if ($key == 'in') {
                        $this->db->where_in($k, $v);
                    } else {
                        $this->db->where("`" . $k . "` " . $key, $v);
                    }

                }
            } elseif ($key == 'like') {
                foreach ($value as $k=>$v) {
                    $this->db->like($k, $v);
                }
            } else {
                $this->db->where($key, $value);
            }
        }
    }

    function get_total($condition=array())
    {
        $this->getwhere($condition);
        return $this->db->count_all_results($this->_table);
    }

    function get_all($condition=array(), $page=1, $limit=100, $order=['addtime', 'desc'])
    {
        $page=max(1, $page);
        $this->getwhere($condition);
        $this->db->select("{$this->_table}.*");

        $this->db->order_by($order[0], $order[1]);
        $this->db->limit($limit, ($page - 1) * $limit);
        return $this->db->get($this->_table)->result_array();
    }

    function add_one($data)
    {
        $data['addtime']=time();
        $this->db->insert($this->_table, $data);
        return $this->db->insert_id();
    }

    function update_by_query($sql, $value='')
    {
        $data=[];
        if ($value) {
            $query=$this->db->query($sql, $value);
        } else {
            $query=$this->db->query($sql);
        }
        return $this->db->affected_rows();
    }

    function update_row_by_id($pk_id, $data)
    {
        $this->db->where($this->_pk, $pk_id);
        return $this->db->update($this->_table, $data);
    }

    function update_row_by_fields($where, $data)
    {
        $this->db->where($where);
        return $this->db->update($this->_table, $data);
    }

    //更新表中任何字段
    function update_field_by_id($pk_id, $field, $value, $operation)
    {
        $q=$this->db->get_where($this->_table, array($this->_pk=>$pk_id));

        //如果有记录就更新，无记录就新增
        if ($q->num_rows() === 0) {
            $this->db->insert($this->_table, array($this->_pk=>$pk_id, $field=>$value));
            return $this->db->insert_id();
        } else {
            $this->db->set($field, "{$field} {$operation} {$value}", FALSE);
            $this->db->where($this->_pk, $pk_id);
            $this->db->update($this->_table);
            return $pk_id;
        }
    }


    //删除数据
    function delete_by_id($pk_id)
    {
        return $this->db->delete($this->_table, array($this->_pk=>$pk_id));
    }

    function delete_by_fields($where)
    {
        return $this->db->delete($this->_table, $where);
    }


    /**
     * 获取数据
     * @param string $select
     * @param array $where
     * @param int $page
     * @param int $limit
     * @param array $join
     * @param array $group
     * @param array $order
     * @param array $having
     * @return mixed
     */
    public function get_data($select='*', $where='', $page=1, $limit=10, $join=[], $group='', $order=['addtime', 'desc'], $having=[])
    {
        $this->db->select($select)->from($this->_table);
        //where
        if ($where) {
            if (array_key_exists('where_in', $where)) {
                //['user_id',$users]
                $where_in=$where['where_in'];
                //删除in
                unset($where['where_in']);
                $this->db->where_in($where_in[0], $where_in[1]);
            }
            if (array_key_exists('or_where', $where)) {
                $or_where=$where['or_where'];
                unset($where['or_where']);
                $this->db->or_where($or_where);
            }
            if (array_key_exists('where_not_in', $where)) {
                $where_not_in=$where['where_not_in'];
                unset($where['where_not_in']);
                $this->db->where_not_in($where_not_in[0], $where_not_in[1]);
            }
            if (array_key_exists('or_where_in', $where)) {
                $or_where_in=$where['where_not_in'];
                unset($where['or_where_in']);
                $this->db->where_not_in($or_where_in[0], $or_where_in[1]);
            }
            if (array_key_exists('or_where_not_in', $where)) {
                $or_where_not_in=$where['where_not_in'];
                unset($where['or_where_not_in']);
                $this->db->where_not_in($or_where_not_in[0], $or_where_not_in[1]);
            }
            if (array_key_exists('like', $where)) {
                $like=$where['like'];
                unset($where['like']);
                $this->db->like($like[0], $like[1]);
            }
            $this->db->where($where);
        }
        //分页
        if ($page || $limit) {
            if ($page == 1) {
                $this->db->limit($limit);
            } else {
                $pages=($page - 1) * $limit;
                $this->db->limit($pages, $limit);
            }
        }
        //关联
        if ($join) {
            foreach ($join as $k=>$item) {
                $this->db->join($k, $item);
            }
        }
        //排序
        if ($order) {
            if (is_array($order)) {
                $this->db->order_by($order[0], $order[1]);
            } elseif (is_string($order)) {
                $this->db->order_by($order);
            }
        }
        //分组
        if ($group) {
            if (is_string($group)) {
                $this->db->group_by($group);
            }
        }
        //having
        if ($having) {
            if (is_array($having)) {
                $this->db->having($having[0], $having[1]);
            } elseif (is_string($having)) {
                $this->db->having($having);
            }
        }
        $query=$this->db->get();
        //echo  $this->db->last_query();
        return $query->result_array();
    }
}
