<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Adset_country_month_log_model extends MY_Model {

    function __construct(){
        $this -> _table = 'adset_country_month_log';
        $this -> _pk     = 'log_id';
    }

}
 