<?php if (!defined('BASEPATH')) exit('No direct script access allowed');


class Publisher_adaccount_model extends MY_Model
{

    function __construct()
    {
        $this->_table='publisher_adaccount';
        $this->_pk='relation_id';
    }

    public function getAcounts($where)
    {
        $sql="SELECT account_id,account_name FROM {$this->_table} WHERE {$where}";
        return $this->get_query($sql);
    }

    public function get_accounts($select='*', $where=[], $in_where=[])
    {
        $this->db->select($select)
            ->from($this->_table);
        if ($in_where) {
            $this->db->where_in($in_where[0], $in_where[1]);
        }

        if ($where) {
            $this->db->where($where);
        }
        $query=$this->db->get();
        return $query->result_array();
    }

    /**
     * 根据条件获取用户信息的广告的统计
     * @param $where
     * @return mixed
     */
    public function get_all_acounts($where)
    {
        $query=$this->db->select('user.user_name,count(DISTINCT(ad.ad_id)) as ads,(SELECT COUNT(ad.market_ad_id) FROM ad WHERE ad.account_id=publisher_adaccount.account_id AND ad.object_type="SHARE") as images, (SELECT COUNT(ad.market_ad_id) FROM ad WHERE ad.account_id=publisher_adaccount.account_id AND ad.object_type="MORE_SHARE") AS moreshare, (SELECT COUNT(ad.market_ad_id) FROM ad WHERE ad.account_id=publisher_adaccount.account_id AND ad.object_type="VIDEO") AS video,(SELECT COUNT(ad.campaign_id) FROM ad WHERE ad.account_id=publisher_adaccount.account_id) AS campaign,(SELECT COUNT(ad.adset_id) FROM ad WHERE ad.account_id=publisher_adaccount.account_id) AS adsets,(SELECT COUNT(ad.market_ad_id) FROM ad WHERE ad.account_id=publisher_adaccount.account_id AND ad.verify=0) AS pendings,(SELECT COUNT(ad.market_ad_id) FROM ad WHERE ad.account_id=publisher_adaccount.account_id AND ad.verify=1) AS approveds,(SELECT COUNT(ad.market_ad_id) FROM ad WHERE ad.account_id=publisher_adaccount.account_id AND ad.verify=2) AS suspected,(SELECT COUNT(ad.market_ad_id) FROM ad WHERE ad.account_id=publisher_adaccount.account_id AND ad.verify=3) AS illegals')
            ->where($where, false)
            ->from($this->_table)
            ->join('user', 'publisher_adaccount.publisher_id=user.user_id', 'left')
            ->join('ad', 'publisher_adaccount.account_id=ad.account_id', 'left')
            ->group_by('user.user_id')
            ->get();
        //echo $this->db->last_query();die;
        return $query->result_array();
    }


    /**
     * @param $where
     * @param string $select
     * @return mixed
     */
    public function get_all_data($where,$select='*')
    {
        $query=$this->db->select($select)
            ->from($this->_table)
            ->join('ad','ad.account_id='.$this->_table.'.account_id')
            ->where($where)
            //->group_by('publisher_adaccount.account_id')
            ->get();
        //echo $this->db->last_query();die;
        return $query->result_array();
    }
}
