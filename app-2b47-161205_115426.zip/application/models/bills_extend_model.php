<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Bills_extend_model extends MY_Model {

    function __construct(){
        $this -> _table = 'bills_extend';
        $this -> _pk     = 'extend_id';
    }

}
