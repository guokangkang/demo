<?php if (!defined('BASEPATH')) exit('No direct script access allowed');


class Ad_model extends MY_Model
{

    function __construct()
    {
        $this->_table='ad';
        $this->_pk='market_ad_id';
    }

    public function get_count($account_ids, $where=[])
    {
        $query=$this->db->select('*')
            ->where_in('account_id', $account_ids)
            ->where($where)
            ->from($this->_table)
            ->get();
        return $query->num_rows();
    }
}
