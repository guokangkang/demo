<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Campaign_model extends MY_Model {

    var $fields = [
            'account_id',
            'name',
            'objective',
            'status',
            'buying_type',//竞价方式
            'created_time',
            'start_time',
            'backup'
    ];

	function __construct(){
		$this -> _table = 'campaign';
		$this -> _pk     = 'market_campaign_id';
	}

}
