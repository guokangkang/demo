<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Adset_model extends MY_Model {


    var $fields = [
            'account_id',
            'campaign_id',
            'name',
            'objective',
            'status',
            'buying_type',//竞价方式
            'created_time',
            'start_time',
            'offer_name',
            'budget_remaining',
            'daily_budget',
            'billing_event',
            'backup'
    ];

    
	function __construct(){
		$this -> _table = 'adset';
		$this -> _pk     = 'market_adset_id';
	}

}
