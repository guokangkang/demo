<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Agency_account_model extends MY_Model {

    function __construct(){
        $this -> _table = 'agency_account';
        $this -> _pk     = 'relation_id';
    }

}
