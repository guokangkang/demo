<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Publisher_offer_model extends MY_Model {

	function __construct(){
		$this -> _table = 'publisher_offer';
		$this -> _pk     = 'relation_id';
	}

}
