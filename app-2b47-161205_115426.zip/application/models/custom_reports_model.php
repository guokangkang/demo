<?php if (!defined('BASEPATH')) exit('No direct script access allowed');


class Custom_reports_model extends MY_Model
{

    function __construct()
    {
        $this->_table='custom_reports';
        $this->_pk='custom_id';
    }
}
