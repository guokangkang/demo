<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Offer_cpa_log_model extends MY_Model {

    function __construct(){
        $this -> _table = 'offer_cpa_log';
        $this -> _pk     = 'log_id';
    }


    /**
     * 获取当前用户申请的offer的价格
     * @param  [type] $offer_id [description]
     * @param  [type] $user_id  [description]
     * @return [type]           [description]
     */
    public function get_current_cpa($offer_id, $user_id)
    {
        $sql = "SELECT * from offer_cpa_log  
                WHERE offer_id = ".$offer_id." and user_id=".$user_id." 
                ORDER BY log_id desc 
                LIMIT 1";
        $current = $this->get_query($sql);

        return $current;
    }
}
