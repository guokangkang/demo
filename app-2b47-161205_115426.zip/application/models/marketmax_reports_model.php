<?php if (!defined('BASEPATH')) exit('No direct script access allowed');


class Marketmax_reports_model extends MY_Model
{

    function __construct()
    {
        $this->_table='marketmax_reports';
        $this->_pk='extend_id';
    }

}
