<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Business_model extends MY_Model {

    function __construct(){
        $this -> _table = 'business';
        $this -> _pk     = 'market_business_id';
    }

    /**
     * 获取用户名下为管理员的BM
     * @return [type] [description]
     */
    public function get_business_admin($user_id)
    {
        $sql = "select * from business_permissions where user_id=".$user_id." and role='ADMIN' group by market_business_id";
        $business_list = $this->get_query($sql);

        $business = [];
        if ($business_list) {
            foreach ($business_list as $item) {
                $business[] = $item['market_business_id'];
            }
        }
        return $business;
    }
}   
