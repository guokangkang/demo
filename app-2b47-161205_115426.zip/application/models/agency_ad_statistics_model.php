<?php

/**
 * Created by PhpStorm.
 * User: palmax
 * Date: 2016/9/12
 * Time: 16:46
 */
class agency_ad_statistics_model extends MY_Model
{
    public function __construct()
    {
        $this->_pk='statistics_id';
        $this->_table='agency_ad_statistics';
    }
}