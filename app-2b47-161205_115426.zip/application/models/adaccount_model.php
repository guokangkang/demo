<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Adaccount_model extends MY_Model {

    var $fields = [
            'account_id',
            'name',
            'currency',
            'min_daily_budget',
            'owner_business',
            'balance',
            'amount_spent',
            'spend_cap',
            'status',
            'created_time',
            'backup'
    ];

	function __construct(){
		$this -> _table = 'adaccount';
		$this -> _pk     = 'market_account_id';
	}


    public function add_account_by_user_id($user_id, $user_name)
     {
         $this->load->library('facebookapi', ['user_id'=>$user_id]);
 
         $accountlist = $this->facebookapi->getAccounts();

         $this->load->model('adaccount_model');
         $this->load->model('publisher_adaccount_model');
 
         foreach ($accountlist as $account) {
             if ($account['account_status']!=1) {
                $this->adaccount_model->update_row_by_fields(['account_id'=>$account['id']], ['status'=>$account['account_status']]);
                continue;
             }
             $data = [];
             unset($account['account_groups']);
             unset($account['id']);
             foreach ($account as $key => $value) {
                 if ($key=='created_time') {
                    $value = (array)$value;
                     $data[$key] = strtotime($value['date']);
                 }else
                     $data[$key] = $value;
                 if(is_array($value)){
                     $data[$key] = json_encode($value);
                 }
             } 
 
             $fields = $this->adaccount_model->fields;
 
             $newdata = $this->getFieldsData($fields, $data);
             $newdata['status'] = $data['account_status'];
             $newdata['lasttime'] = time();
 
             $accountinfo = $this->adaccount_model->get_by_fields(['account_id'=>$data['account_id']]);

             if($accountinfo){
                 $market_adaccount_id = $accountinfo['market_account_id'];
                 $this->adaccount_model->update_row_by_id($market_adaccount_id, $newdata);
             }else{
                 $market_adaccount_id = $this->adaccount_model->add_one($newdata);
              }

             $publisher_account = $this->publisher_adaccount_model->get_by_fields(['account_id'=>$data['account_id'], 'publisher_id'=>$user_id]);

             if ($publisher_account) {
                $this->publisher_adaccount_model->update_row_by_id($publisher_account['relation_id'], ['account_id'=>$data['account_id'], 'account_name'=>$data['name'], 'publisher_id'=>$user_id, 'publisher_name'=>$user_name, 'market_account_id'=>$market_adaccount_id]);
             }else{
                $this->publisher_adaccount_model->add_one(['account_id'=>$data['account_id'], 'account_name'=>$data['name'], 'publisher_id'=>$user_id, 'publisher_name'=>$user_name, 'market_account_id'=>$market_adaccount_id]);
             }
         }
    }
    public function addAccount($user_id, $user_name, $facebook_id, $business_id)
     {   
        $this->load->model('business_model');
        $business_info = $this->business_model->get_by_fields(['business_id'=>$business_id]);
        $token = $business_info['token'];
        if (!$business_info['token']) {
            $user_info = $this->user_model->get_by_id($user_id);
            $token = $user_info['token'];
        }

        $url = config_item('APP_URL').config_item('APP_VERSION')."/".$facebook_id."/adaccounts?fields=name,id,account_id,currency,min_daily_budget,balance,amount_spent,spend_cap,created_time,timezone_name,timezone_id,account_status&limit=1024&access_token=" . $token;
        $data = $this->curl->simple_get($url);
        
        if (!$data) {
            return [];
        }
        $data = json_decode($data, true);
        $accountlist = $data['data'];

        $this->load->model('adaccount_model');
        $this->load->model('publisher_adaccount_model');

        $accounts = [];
        foreach ($accountlist as $account) {
            $accounts[$account['account_id']] = $account['account_id'];
        }

        foreach ($accountlist as $account) {
            if ($account['account_status']!=1) {
                $this->adaccount_model->update_row_by_fields(['account_id'=>$account['id']], ['status'=>$account['account_status']]);
                continue;
            }
            $data = [];
            unset($account['account_groups']);
            unset($account['id']);
            foreach ($account as $key => $value) {
                if ($key=='created_time') {
                    $data[$key] = strtotime($value);
                }else
                    $data[$key] = $value;
                if(is_array($value)){
                    $data[$key] = json_encode($value);
                }
            } 
 
             $fields = $this->adaccount_model->fields;
 
             $newdata = $this->getFieldsData($fields, $data);
             $newdata['status'] = $data['account_status'];
             $newdata['lasttime'] = time();
    
             $accountinfo = $this->adaccount_model->get_by_fields(['account_id'=>$data['account_id']]);

             if($accountinfo){
                 $market_adaccount_id = $accountinfo['market_account_id'];
                 $this->adaccount_model->update_row_by_id($market_adaccount_id, $newdata);
             }else{
                 $market_adaccount_id = $this->adaccount_model->add_one($newdata);
              }

             $publisher_account = $this->publisher_adaccount_model->get_by_fields(['account_id'=>$data['account_id'], 'publisher_id'=>$user_id]);

             $vars = ['account_id'=>$data['account_id'], 'account_name'=>$data['name'], 'publisher_id'=>$user_id, 'publisher_name'=>$user_name, 'market_account_id'=>$market_adaccount_id];
             
             if ($publisher_account) {
                $this->publisher_adaccount_model->update_row_by_id($publisher_account['relation_id'], $vars);
             }else{
                $this->publisher_adaccount_model->add_one($vars);
             }
         }
    }

    //废除
    public function addAccount_bak($user_id, $user_name, $facebook_id, $business_accounts, $business_id, $role='')
     {   
        $this->load->model('business_model');
        $business_info = $this->business_model->get_by_fields(['business_id'=>$business_id]);
        $token = $business_info['token'];
        if (!$business_info['token']) {
            $user_info = $this->user_model->get_by_id($user_id);
            $token = $user_info['token'];
        }

        $url = "https://graph.facebook.com/v2.5/".$facebook_id."/adaccounts?fields=name,id,account_id,currency,min_daily_budget,balance,amount_spent,spend_cap,created_time,timezone_name,timezone_id,account_status&limit=1024&access_token=" . $token;
        $data = $this->curl->simple_get($url);
        
        if (!$data) {
            return [];
        }
        $data = json_decode($data, true);
        $accountlist = $data['data'];

        $this->load->model('adaccount_model');
        $this->load->model('publisher_adaccount_model');

        $accounts = [];
        foreach ($accountlist as $account) {
            $accounts[$account['account_id']] = $account['account_id'];
        }

        if ($business_info) {//查看是否有账号已经被移除。
            $org_account = $this->publisher_adaccount_model->get_query("select * from publisher_adaccount where publisher_id=".$user_id." and market_business_id=".$business_info['market_business_id']);
            foreach ($org_account as $item) {
                if (!in_array($item['account_id'], $accounts)) {
                    $this->publisher_adaccount_model->update_row_by_id($item['relation_id'], ['status'=>0]);
                }
            }
        }
        foreach ($accountlist as $account) {
            if ($account['account_status']!=1) {
                $this->adaccount_model->update_row_by_fields(['account_id'=>$account['id']], ['status'=>$account['account_status']]);
                continue;
            }
            $data = [];
            unset($account['account_groups']);
            unset($account['id']);
            foreach ($account as $key => $value) {
                if ($key=='created_time') {
                    $data[$key] = strtotime($value);
                }else
                    $data[$key] = $value;
                if(is_array($value)){
                    $data[$key] = json_encode($value);
                }
            } 
             //如果没有在对应的BM里，直接放弃。
             if ($business_accounts && !in_array($data['account_id'], $business_accounts)) {
                 continue;
             }
 
             $fields = $this->adaccount_model->fields;
 
             $newdata = $this->getFieldsData($fields, $data);
             $newdata['status'] = $data['account_status'];
             $newdata['lasttime'] = time();
    
             $accountinfo = $this->adaccount_model->get_by_fields(['account_id'=>$data['account_id']]);

             if($accountinfo){
                 $market_adaccount_id = $accountinfo['market_account_id'];
                 $this->adaccount_model->update_row_by_id($market_adaccount_id, $newdata);
             }else{
                 $market_adaccount_id = $this->adaccount_model->add_one($newdata);
              }

             $publisher_account = $this->publisher_adaccount_model->get_by_fields(['account_id'=>$data['account_id'], 'publisher_id'=>$user_id, 'market_business_id'=>$business_info['market_business_id']]);

             $vars = ['account_id'=>$data['account_id'], 'account_name'=>$data['name'], 'publisher_id'=>$user_id, 'publisher_name'=>$user_name, 'market_account_id'=>$market_adaccount_id];
             if ($business_info) {
                $vars['market_business_id'] = $business_info['market_business_id'];
                $vars['business_id'] = $business_info['business_id'];
                $vars['business_name'] = $business_info['name'];
                $vars['role'] = $role;
             }
             if ($publisher_account) {
                $this->publisher_adaccount_model->update_row_by_id($publisher_account['relation_id'], $vars);
             }else{
                $this->publisher_adaccount_model->add_one($vars);
             }
         }
     }
 
 
     /**
      * 整合对象数据的字段
      * @param  [type] $fields [description]
      * @param  [type] $data   [description]
      * @return [type]         [description]
      */
     public function getFieldsData($fields, $data)
     {
         $return = [];
         foreach ($data as $key => $value) {
             if (in_array($key, $fields)) {
                 $return[$key] = $value;
             }
         }
         $return['backup'] = json_encode($data);
         return $return;
     }

}
