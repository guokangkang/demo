<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Business_permissions_model extends MY_Model {

    function __construct(){
        $this -> _table = 'business_permissions';
        $this -> _pk     = 'permissions_id';
    }

}
