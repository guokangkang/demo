<?php if (!defined('BASEPATH')) exit('No direct script access allowed');


class Product_model extends MY_Model
{


    CONST STATUS_SUCCESS = 1;  //在线
    CONST STATUS_DEL = 0;   //删除

    function __construct()
    {
        $this->_table = 'product';
        $this->_pk = 'product_id';
    }

    /**
     *
     * @param array $data
     * @param int $page
     * @param int $limit
     * @param array $order
     * @return mixed
     */
    public function getAll($data, $page = 1, $limit = 10, $order = ['addtime', 'desc'])
    {
        $data['status'] = $this::STATUS_SUCCESS;
        return $this->get_all($data, $page, $limit, $order);
    }

    /**
     * 更新
     * @param $id
     * @return string
     */
    public function update($where)
    {
        //$where = array('product_id'=>$id);
        $data['status'] = $this::STATUS_DEL;
        $res = $this->update_row_by_fields($where, $data);
        return $res;
    }


    /**
     * 检测用户是否旁注
     * @param $userid
     * @param $product_id
     * @return bool
     */
    public function checkPower($userid, $product_id)
    {
        $where = array('advertiser_id'=>$userid,'product_id'=>$product_id);
        $res = $this->get_all($where);
        if($res){
            return true;
        }else{
            return false;
        }
    }
}
