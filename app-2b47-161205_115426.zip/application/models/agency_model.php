<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Agency_model extends MY_Model {

    function __construct(){
        $this -> _table = 'agency';
        $this -> _pk     = 'agency_id';
    }

}
