<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Offer_rpa_log_model extends MY_Model {

    function __construct(){
        $this -> _table = 'offer_rpa_log';
        $this -> _pk     = 'log_id';
    }

    /**
     * 添加进货价日志
     * @param [type] $offer_id [description]
     * @param [type] $rpa      [description]
     */
    public function add_offer_rpa_log_action($product_id, $offer_id, $rpa, $start_time, $countries, $choose_type)
    {
        $countries = json_decode($countries, true);
        $new_country = ['countries'=>$countries, 'choose_type'=>$choose_type];

        
        $this->offer_rpa_log_model->add_one(['offer_id'=>$offer_id, 'rpa'=>$rpa, 'start_time'=>$start_time, 'country'=>json_encode($new_country), 'product_id'=>$product_id]);
    }


    public function get_current_rpa($offer_id)
    {
        # code...
    }

}
