<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tmp_token_model extends MY_Model {

    function __construct(){
        $this -> _table = 'tmp_token';
        $this -> _pk     = 'token_id';
    }

}
