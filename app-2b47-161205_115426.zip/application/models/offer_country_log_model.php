<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Offer_country_log_model extends MY_Model
{
    public function __construct()
    {
        $this->_table = 'offer_country_log';
        $this->_pk = 'log_id';
    }

    public function update($data)
    {
        $do_type='';
        if(is_array($data)){
            $where= "offer_id = '{$data['offer_id']}' AND advertiser_id= '{$data['advertiser_id']}'";
            $sql="SELECT log_id,countries,offer_id,advertiser_id FROM $this->_table WHERE $where order by log_id desc limit 1";
            $res = $this->get_query($sql);
            $res = $res[0];
            if($res){
                //原数据
                $countries = json_decode($res['countries'],true);
                //unset($data['offer_id'],$data['advertiser_id']);
                //去相同部分
                $add_data=array();
                $new_countries_data = json_decode($data['countries'],true);
                foreach ($new_countries_data as $key => $value) {
                    if(!in_array($value, $countries)){
                        $add_data['countries'][]=$value;
                    }
                }

                if(count($new_countries_data) >count($countries)){
                    $add_data['do_type']='add';
                }else{
                    $add_data['do_type']='del';
                }
                $add_data['countries']=json_encode($add_data['countries']);
                $add_data['offer_id']=$data['offer_id'];
                $add_data['advertiser_id']=$data['advertiser_id'];
                $add_data['addtime']=time();
                return $this->add_one($add_data);
            }
        }
    }


    public function add_offer_country_log($offer_id, $counties, $choose_type, $start_time)
    {
        # code...
    }
}
