<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Ad_insight_model extends MY_Model {

    var $fields = [
            'account_id',
            'adset_id',
            'campaign_id',
            'results',
            'spend',
            'reach',
            'frequency',
            'cost',
            'spend',
            'clicks',
            'ctr',
            'cpc',
            'impressions',
            'cpm',
            'link_clicks',
            'cpc_link',
            'ctr_link'
    ];
	function __construct(){
		$this -> _table = 'ad_insight';
		$this -> _pk     = 'insight_id';
	}

}
