<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * 后台菜单
 */
class Menu_model extends MY_Model {

	function __construct(){
		$this -> _table = 'menu';
		$this -> _pk     = 'menu_id';
	}

    function get_all($condition = array(), $page = 1, $limit = 10, $order = 'asc')
    {
        $page = max(1, $page); 
        $this->db->where($condition);
        $this->db->select("{$this->_table}.*");

        $this->db->order_by('order',$order);
        $this->db->limit($limit, ($page - 1) * $limit);
        return $this->db->get($this->_table)->result_array();
    }
}
