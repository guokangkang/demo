<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Publisher_adaccount2_model extends MY_Model {

    function __construct(){
        $this -> _table = 'publisher_adaccount2';
        $this -> _pk     = 'relation_id';
    }
    public function getAcounts($where)
    {
        $sql = "SELECT account_id,account_name FROM {$this->_table} WHERE {$where}";
        return $this->get_query($sql);
    }
}
