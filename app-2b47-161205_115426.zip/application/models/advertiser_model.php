<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Advertiser_model extends MY_Model {

	function __construct(){
		$this -> _table = 'advertiser';
		$this -> _pk     = 'user_id';
	}

}
