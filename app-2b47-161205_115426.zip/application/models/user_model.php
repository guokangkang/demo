<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class User_model extends MY_Model {

    function __construct(){
        $this -> _table = 'user';
        $this -> _pk     = 'user_id';
    }



    public function get_user_by_business($business_id)
    {
        $sql = "select user_id from business_permissions where user_id != '' and business_id=".$business_id." group by user_id";
        $data = $this->get_query($sql);

        $user_ids =[];
        foreach ($data as $key => $value) {
            $user_ids[] = $value['user_id'];
        }
        return $user_ids;
    }
}
