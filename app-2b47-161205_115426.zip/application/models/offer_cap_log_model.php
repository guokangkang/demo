<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Offer_cap_log_model extends MY_Model {

    function __construct(){
        $this -> _table = 'offer_cap_log';
        $this -> _pk     = 'log_id';
    }

}
