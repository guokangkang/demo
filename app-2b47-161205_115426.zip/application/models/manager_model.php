<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Manager_model extends MY_Model {

    function __construct(){
        $this -> _table = 'manager';
        $this -> _pk     = 'manager_id';
    }

}
