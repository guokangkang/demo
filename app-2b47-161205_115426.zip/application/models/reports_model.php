<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Reports_model extends CI_Model {

    function __construct(){
        $this->db = $this->load->database('default',TRUE);
    }

    public function get_report_data($sql, $is_cache=1, $cache_time=30*60)
    {
        $key = md5($sql);
        if ($this->input->get('_refresh')) {
            $this->redis->del($key);
        }

        $cache_data = $this->redis->get($key);
        
        if ($cache_data && $is_cache) {
            return json_decode($cache_data, true);
        }
        $query = $this->db->conn_id->prepare($sql);
        $query->execute();
        $data = $query->fetchAll(PDO::FETCH_ASSOC);


        $this->redis->set($key, json_encode($data));
        $this->redis->expire($key, $cache_time);
        
        return $data;
    }

}
