<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Adcreative_model extends MY_Model {

	function __construct(){
		$this -> _table = 'adcreative';
		$this -> _pk     = 'market_adcreative_id';
	}

}
