<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Redshift_model extends CI_Model {

    function __construct(){
        $this->db = $this->load->database('default',TRUE);
    }

    public function get_query($sql, $is_cache=1)
    {
        $key = md5($sql);
        if ($this->input->get('_refresh')) {
            $this->redis->del($key);
        }

        $cache_data = $this->redis->get($key);
        
        if ($cache_data && $is_cache) {
            return json_decode($cache_data, true);
        }
        $query = $this->db->conn_id->prepare($sql);
        $query->execute();
        $data = $query->fetchAll(PDO::FETCH_ASSOC);


        $this->redis->set($key, json_encode($data));
        $this->redis->expire($key, 30*60);
        
        return $data;
    }

}
