<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Specific_cap_model extends MY_Model {

    function __construct(){
        $this -> _table = 'specific_cap';
        $this -> _pk     = 'specific_id';

        $this->load->model('user_model');
        $this->load->model('publisher_offer_model');
        $this->load->model('offer_cpa_log_model');
    }

    /**
     * 添加特殊价格日志
     * @param [type] $user_id   [description]
     * @param [type] $user_name [description]
     * @param [type] $cpa       [description]
     * @param [type] $offer_id  [description]
     * @param [type] $note      [description]
     */
    public function add_specific_cap_log_action($user_id, $user_name, $cap, $offer_id, $note, $start_time="")
    {

        $sql = "select * from specific_cap where user_id=".$user_id." and offer_id=".$offer_id." and type=1 and status=1 order by start_time desc limit 1";
        $last_specific = $this->get_query($sql);

        if ($last_specific && $last_specific[0]['cap'] == $cap) {
            return '已经是最新的';
        }

        $specific = ['user_id'=>$user_id, 'user_name'=>$user_name, 'cap'=>$cap, 'note'=>$note, 'offer_id'=>$offer_id, 'start_time'=>$start_time, 'type'=>1];

        $this->add_one($specific);
    }


    /**
     * 取消用户的特殊价格
     * @param  [type] $offer_id [description]
     * @param  [type] $user_id  [description]
     * @return [type]           [description]
     */
    public function cancel_specific_cap_log_action($offer_id, $user_id, $note, $start_time)
    {
        $sql = "select * from specific_cap where offer_id=".$offer_id." and user_id=".$user_id." and status=1 and type=1 order by specific_id desc";
        $data = $this->get_query($sql);//找到此用户这个offer最后一次删除的记录
        
        foreach ($data as $key => $info) {

            $this->update_row_by_id($info['specific_id'], ['status'=>0]);

            $specific = ['user_id'=>$user_id, 'user_name'=>$info['user_name'], 'cap'=>$info['cap'], 'note'=>$note, 'offer_id'=>$offer_id, 'start_time'=>$start_time, 'type'=>0];

            $this->add_one($specific);
        }
    }

}
