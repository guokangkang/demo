<?php if (!defined('BASEPATH')) exit('No direct script access allowed');


class Offer_model extends MY_Model
{

    CONST STATUS_SUCCESS=1;  //在线
    CONST STATUS_DEL=0;   //删除


    public function __construct()
    {
        $this->_table='offer';
        $this->_pk='offer_id';

        $this->load->model('adaccount_model');

    }

    /**
     *
     * @param array $data
     * @param int $page
     * @param int $limit
     * @param array $order
     * @return mixed
     */
    public function getAll($data=array(), $page='1', $limit='10', $order=['addtime', 'desc'])
    {
        if (is_array($data)) {
            $data['status']=$this::STATUS_SUCCESS;
        } else {
            $data.=" AND status =" . $this::STATUS_SUCCESS;
        }
        return $this->get_all($data, $page, $limit, $order);
    }

    /**
     * 更新
     * @param $ids string ex:1,4,6这种格式
     * @return string
     */
    public function updates($ids='', $orWhere='', $data=array())
    {
        if (is_array($ids)) {
            $ids=trim(implode(',', $ids), ',');
            $where="offer_id in ($ids)";
        } else {
            if ($ids) {
                $where="offer_id in ($ids)";
            }
        }

        if ($orWhere) {
            $where=$orWhere;
        }
        if (empty($data)) {
            $content['status']=$this::STATUS_DEL;
        } else {
            $content=$data;
        }

        $res=$this->offer_model->update_row_by_fileds($where, $content);
        return $res?$res:'';
    }


    /**
     * 返回关联产品的Obj
     * @type 1默认为数组,2为对象
     * @return mixed
     */
    public function getWithAll($type=1, $where=array())
    {
        $this->db->select('offer.*,product.title as product_name,product.desc as product_desc,product.advertiser_id')
            ->from('offer')
            ->join('product', 'product.product_id = offer.product_id')
            ->where(array('offer.status'=>$this::STATUS_SUCCESS))
            ->order_by('addtime', 'desc');
        $query=$this->db->get();
        if ($type == 1) {
            return $query->result_array();
        } else {
            return $query->result_object();
        }
    }

    /**
     * 检查是否删除权限
     * @param $userid
     * @param $product_id
     * @return bool
     */
    public function chkUserPower($userid, $offer_id)
    {
        $sql="SELECT offer.offer_id,offer.product_id,product.advertiser_id FROM offer LEFT JOIN product ON product.product_id=offer.product_id WHERE offer.status =1 AND product.advertiser_id ={$userid} AND offer.offer_id ='{$offer_id}'";
        $query=$this->db->query($sql);
        if ($query->result_object()) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * 根据id关联
     * @param $pk_id offer_id
     */
    public function getWithProduct($pk_id)
    {
        $sql="SELECT offer.*,product.title as product_name,product.desc as product_desc,product.advertiser_id FROM offer LEFT JOIN product ON product.product_id = offer.product_id WHERE offer_id={$pk_id}";
        $query=$this->db->query($sql);
        $res=$query->result_array();
        if ($res) {
            return $res[0];
        }

    }

    /**
     * @param $where $where is sql where
     */
    public function getCount($where)
    {
        $sql="SELECT COUNT('offer_id') as c,product_id FROM $this->_table Where $where group by product_id";
        return $this->get_query($sql);
    }


    /**
     * 获取当期、过往、未来的留存率
     * @param  [type] $offer_id [description]
     * @return [type]           [description]
     */
    public function get_payout($offer_id)
    {
        $this->load->model('payout_model');
        $sql="select * from payout where offer_id=" . $offer_id . " and status=1 order by start_time desc, payout_id desc";
        $list=$this->payout_model->get_query($sql);

        $history=$schedule=$current=[];
        foreach ($list as $key=>$value) {
            $value['value']=json_decode($value['value'], true);
            if ($value['value'] && is_array($value['value'])) {
                foreach ($value['value'] as $k=>&$v) {
                    $v['payout']=sprintf("%.2f", $v['payout_rate'] / 100 * $value['cpa']);
                }
            }
            if (!$current && $value['start_time'] < time()) {
                $current=$value;
                //$schedule[] = $value;
                continue;
            }

            if ($value['start_time'] < time()) {
                $history[]=$value;
            }
            if ($value['start_time'] > time()) {
                $schedule[]=$value;
            }
        }
        return [$history, $schedule, $current];
    }

    public function get_payout_log($offer_id)
    {
        $current = [];
        $this->load->model('payout_model');
        $sql="select * from payout where offer_id=" . $offer_id . " and status=1 order by start_time desc, payout_id desc";
        $list=$this->payout_model->get_query($sql);

        foreach ($list as $key=>& $value) {
            $value['value']=json_decode($value['value'], true);
            if ($value['value'] && is_array($value['value'])) {
                foreach ($value['value'] as $k=>&$v) {
                    $v['payout']=sprintf("%.2f", $v['payout_rate'] / 100 * $value['cpa']);
                }
            }

            if (!$current && $value['start_time'] < time()) {
                $current=$value;
                continue;
            }
        }
        return [$current, $list];
    }

    /**
     * 获取当期、过往、未来的留存率
     * @param  [type] $offer_id [description]
     * @return [type]           [description]
     */
    public function get_payouts($offer_id)
    {
        $this->load->model('payout_model');
        $sql="select * from payout where offer_id=" . $offer_id . " and status=1 order by start_time desc, payout_id desc";
        $list=$this->payout_model->get_query($sql);
        //var_dump($list);die;
        $schedule=$current=[];
        foreach ($list as $key=>$value) {
            $value['value']=json_decode($value['value'], true);
            if ($value['value'] && is_array($value['value'])) {
                foreach ($value['value'] as $k=>&$v) {
                    $v['payout']=sprintf("%.2f", $v['payout_rate'] / 100 * $value['cpa']);
                }
            }
            if (!$current && $value['start_time'] < time()) {
                $current=$value;
                $schedule[]=$value;
                continue;
            }
            /* if ($value['start_time'] < time()|| $value['start_time'] > time()|| ($value['start_time'] < time()&&!$current)) {

             }*/
            $schedule[]=$value;
        }
        return [$schedule, $current];
    }

    /**·
     * 获取offer过往日志
     * @param  string $value [description]
     * @return [type]        [description]
     */
    public function get_current_rpa_log($offer)
    {

        if (is_array($offer)) {
            $offer_id=$offer['offer_id'];
            $offer_info=$offer;
        } else {
            $offer_id=$offer;
            $offer_info=$this->get_by_id($offer_id);
        }

        $sql="select * from offer_rpa_log where offer_id=" . $offer_id . " and start_time<=" . time() . " order by start_time desc,log_id desc limit 1";

        $countries=[];
        $choose_type='';
        $rpa=0;
        $this->load->model('offer_rpa_log_model');
        $log=$this->offer_rpa_log_model->get_query($sql);
        if ($log) {
            $rpa=$log[0]['rpa'];
            $start_time=$log[0]['start_time'];
        } else {
            $rpa=$offer_info['rpa'];
            $start_time=$offer_info['start_time'];
        }
        return [$rpa, $start_time];
    }

    /**·
     * 获取offer过往日志
     * @param  string $value [description]
     * @return [type]        [description]
     */
    public function get_current_cpa_log($offer_id, $start_time='')
    {
        if (!$start_time) {
            $start_time=time();
        }
        $this->load->model('payout_model');
        $sql="select * from payout where offer_id=" . $offer_id . " and status=1 and start_time<=" . $start_time . " order by start_time desc,payout_id desc limit 1";
        $data=$this->get_query($sql);

        if ($data) {
            return $data[0];
        }
        return [];
    }

    /**
     * 获取offer cap日志
     * @param $offer_id
     * @param string $start_time
     */
    public function get_current_cap_log($offer_id, $start_time='')
    {
        $this->load->model('offer_cap_log_model');
        if (!$start_time) {
            $start_time=time();
        }
        $where=['offer_id'=>$offer_id, 'start_time <='=>$start_time];
        $query=$this->db->select('*')
            ->from('offer_cap_log')
            ->where($where)
            ->limit(1)
            ->order_by('start_time desc,log_id desc')
            ->get();
        return $query->result_array();

    }

    public function get_rpa_log($offer_id)
    {
        $sql="select * from offer_rpa_log where offer_id=" . $offer_id . " order by start_time desc,log_id desc";

        return $this->get_query($sql);
    }


    public function get_cap_log($offer_id)
    {
        $sql="select * from offer_cap_log where offer_id=" . $offer_id . " order by start_time desc,log_id desc";

        return $this->get_query($sql);
    }

    /**
     * 获取offer下所有特殊cap
     * @param  [type] $offer_id [description]
     * @return [type]           [description]
     */
    public function get_specific_cap($offer_id)
    {
        $sql="select * from specific_cap where offer_id=" . $offer_id . " order by user_id desc, specific_id desc";
        $list=$this->get_query($sql);

        $data=[];
        foreach ($list as $key=>$value) {
            $data[$value['user_id']][]=$value;
        }
        foreach ($data as & $row) {
            $flag=false;
            foreach ($row as $user_id=>& $item) {
                $item['is_current']=false;
                if (!$flag && $item['start_time'] <= time()) {
                    $item['is_current']=true;
                    $flag=true;
                }
            }
        }
        return $data;
    }


    /**
     * 获取offer此时的推广的国家
     * @param  [type] $offer [description]
     * @return [type]        [description]
     */
    public function get_current_country_log($offer)
    {
        $sql="select * from offer_country_log where offer_id=" . $offer['offer_id'] . " and start_time<=" . time() . " order by start_time desc,log_id desc limit 1";
        $log_list=$this->get_query($sql);

        if ($log_list) {
            return [$log_list[0]['choose_type'], json_decode($log_list[0]['country'], true)];
        } else {
            $sql="select * from offer_country_log where offer_id=" . $offer['offer_id'] . " and start_time>=" . time() . " order by start_time asc limit 1";
            $log_list=$this->get_query($sql);
            if ($log_list) {
                return [$log_list[0]['choose_type'], json_decode($log_list[0]['country'], true)];
            }
        }
        return ['', ''];
    }

    /**
     * 申请offer
     * @param  string $value [description]
     * @return [type]        [description]
     */
    public function apply_offer($offer_id, $apply_account, $user_id, $user_name, $status=0)
    {
        $this->load->model('specific_payout_model');
        $this->load->model('publisher_offer_model');
        $this->load->model('publisher_adaccount_model');

        $offer_info=$this->get_by_id($offer_id);
        $vars['product_id']=$offer_info['product_id'];
        $vars['product_name']=$offer_info['product_name'];
        $vars['advertiser_id']=$offer_info['user_id'];
        $vars['advertiser_name']=$offer_info['user_name'];

        $vars['publisher_id']=$user_id;
        $vars['publisher_name']=$user_name;
        $vars['offer_id']=$offer_id;


        //判断用户是否有特殊价格，如果没有应该创建offer_cpa_log日志        
        $specific_payout=$this->get_current_specific_payout($vars['offer_id'], $user_id);


        if ($specific_payout) {//如果有特殊价格，则标示此人申请的这个offer有指定的特殊价格
            $vars['is_specific_payout']=1;
            $vars['cpa']=$specific_payout[0]['payout'];
            $this->getCurrentPayout($vars['offer_id'], $user_id);
        } else {//没有特殊价格，需要设置当前offer的留存价格
            $vars['cpa']=$this->getCurrentPayout($vars['offer_id'], $user_id);
        }

        foreach ($apply_account as $key=>$market_account_id) {
            $account_info=$this->publisher_adaccount_model->get_by_fields(['publisher_id'=>$user_id, 'market_account_id'=>$market_account_id]);

            if (!$account_info) {
                $account_info=$this->publisher_adaccount_model->get_by_fields(['publisher_id'=>$user_id, 'account_id'=>$market_account_id]);
                if (!$account_info) {
                    continue;
                }
                
            }
            $vars['account_id']=$account_info['account_id'];
            $vars['market_account_id']=$account_info['market_account_id'];
            $vars['account_name']=$account_info['account_name'];
            //$vars['market_business_id'] = $account_info['market_business_id'];
            //$vars['business_id'] = $account_info['business_id'];
            //$vars['business_name'] = $account_info['business_name'];

            //验证账号是否有其他人申请已经申请过offer
            // $sql = "select publisher_id from publisher_offer 
            //         where market_account_id=".$vars['market_account_id']." and publisher_id != ".$user_id;

            $sql="select publisher_id from publisher_offer 
                    where market_account_id=" . $vars['market_account_id'] . " and offer_id = " . $offer_id;
            if ($this->publisher_offer_model->get_query_count($sql)) {
                continue;
            }

            //判断之前是否申请过
            // $isexsits = $this->publisher_offer_model->get_by_fields(['publisher_id'=>$this->userinfo['user_id'], 'offer_id'=>$vars['offer_id'], 'market_account_id'=>$market_account_id]);
            // if ($isexsits) {
            //     $vars['status'] = 0;
            //     $this->publisher_offer_model->update_row_by_id($isexsits['relation_id'], $vars);
            // }else{
            //     $this->publisher_offer_model->add_one($vars);
            // }

            $publisher_offer=$this->publisher_offer_model->get_by_fields(['offer_id'=>$vars['offer_id'], 'market_account_id'=>$vars['market_account_id']]);
            //var_dump($publisher_offer);die();
            if ($publisher_offer) {
                $vars['status']=$status;
                $this->publisher_offer_model->update_row_by_id($publisher_offer['relation_id'], $vars);
            } else {
                $vars['status']=$status;
                $this->publisher_offer_model->add_one($vars);

                // $publisher_offer = $this->publisher_offer_model->get_by_fields(['market_account_id'=>$vars['market_account_id']]);
                // if (!$publisher_offer || $publisher_offer['publisher_id']==$user_id) {
                //     $vars['status'] = $status;
                //     $this->publisher_offer_model->add_one($vars);
                // }
            }
        }
    }

    /**
     * 申请offer
     * @param  [type] $offer_id   [description]
     * @param  [type] $account_id [description]
     * @return [type]             [description]
     */
    public function apply_offer_by_account($offer_id, $market_account_id, $publisher_id, $status=0)
    {
        $this->load->model('specific_payout_model');
        $this->load->model('publisher_offer_model');
        $this->load->model('publisher_adaccount_model');

        $offer_info=$this->get_by_id($offer_id);
        $vars['product_id']=$offer_info['product_id'];
        $vars['product_name']=$offer_info['product_name'];
        $vars['advertiser_id']=$offer_info['user_id'];
        $vars['advertiser_name']=$offer_info['user_name'];

        $account_info=$this->publisher_adaccount_model->get_by_fields(['market_account_id'=>$market_account_id, 'publisher_id'=>$publisher_id]);

        $vars['publisher_id']=$account_info['publisher_id'];
        $vars['publisher_name']=$account_info['publisher_name'];
        $vars['offer_id']=$offer_id;

        $user_id=$account_info['publisher_id'];
        $user_name=$account_info['publisher_name'];

        //判断用户是否有特殊价格，如果没有应该创建offer_cpa_log日志
        $specific_payout=$this->specific_payout_model->get_all(['user_id'=>$user_id, 'offer_id'=>$vars['offer_id'], 'type'=>'add'], 1, 1);

        if ($specific_payout) {//如果有特殊价格，则标示此人申请的这个offer有指定的特殊价格
            $vars['is_specific_payout']=1;
            $vars['cpa']=$specific_payout[0]['payout'];
            $this->getCurrentPayout($vars['offer_id'], $user_id);
        } else {//没有特殊价格，需要设置当前offer的留存价格
            $vars['cpa']=$this->getCurrentPayout($vars['offer_id'], $user_id);
        }

        $vars['account_id']=$account_info['account_id'];
        $vars['market_account_id']=$account_info['market_account_id'];
        $vars['account_name']=$account_info['account_name'];
        //$vars['market_business_id'] = $account_info['market_business_id'];
        //$vars['business_id'] = $account_info['business_id'];
        //$vars['business_name'] = $account_info['business_name'];


        //验证账号是否有其他人申请已经申请过offer
        $sql="select publisher_id from publisher_offer 
                where market_account_id=" . $vars['market_account_id'] . " and publisher_id != " . $user_id;
        if ($this->publisher_offer_model->get_query_count($sql)) {
            return [];
        }

        $publisher_offer=$this->publisher_offer_model->get_by_fields(['publisher_id'=>$user_id, 'offer_id'=>$vars['offer_id'], 'market_account_id'=>$vars['market_account_id']]);
        //var_dump($publisher_offer);die();
        if ($publisher_offer) {
            $vars['status']=$status;
            $this->publisher_offer_model->update_row_by_id($publisher_offer['relation_id'], $vars);
        } else {
            $publisher_offer=$this->publisher_offer_model->get_by_fields(['market_account_id'=>$vars['market_account_id']]);
            if (!$publisher_offer || $publisher_offer['publisher_id'] == $user_id) {
                $vars['status']=$status;
                $this->publisher_offer_model->add_one($vars);
            }
        }
    }

    /**
     * 获取当前的留存价格，并添加日志表
     * @param  [type] $offer_id [description]
     * @param  [type] $user_id  [description]
     * @return [type]           [description]
     */
    private function getCurrentPayout($offer_id, $user_id)
    {
        $this->load->model('payout_model');
        $this->load->model('offer_cpa_log_model');
        $this->load->model('publisher_offer_model');

        //获取当前offer的留存价格
        $sql="select * from payout where offer_id=" . $offer_id . " and status=1 and start_time<=" . time() . " order by start_time desc limit 1";

        $retention=$this->payout_model->get_query($sql);
        if ($retention) {
            $retention[0]['value']=json_decode($retention[0]['value'], true);

            $this->offer_cpa_log_model->add_one(['user_id'=>$user_id, 'offer_id'=>$offer_id, 'cpa'=>$retention[0]['cpa'], 'start_time'=>$retention[0]['start_time'], 'type'=>'retention', 'retention'=>json_encode($retention[0])]);

            //更新用户申请的offer记录的当前价格
            //这是冗余字段，为了方便查询
            $this->publisher_offer_model->update_row_by_fields(['publisher_id'=>$user_id, 'offer_id'=>$offer_id], ['cpa'=>$retention[0]['cpa']]);
            return $retention[0]['cpa'];
        }
        return 0;
    }


    /**
     * 获取offer下所有特殊价格
     * @param  [type] $offer_id [description]
     * @return [type]           [description]
     */
    public function get_specific_payout($offer_id)
    {
        $sql="select * from specific_payout where offer_id=" . $offer_id . " order by user_id desc, specific_id desc";
        $list=$this->get_query($sql);

        $data=[];
        foreach ($list as $key=>$value) {
            $data[$value['user_id']][]=$value;
        }
        foreach ($data as & $row) {
            $flag=false;
            foreach ($row as $user_id=>& $item) {
                $item['is_current']=false;
                if (!$flag && $item['start_time'] <= time()) {
                    $item['is_current']=true;
                    $flag=true;
                }
            }
        }
        return $data;
    }


    /**
     * 获取offer下所有特殊价格
     * @param  [type] $offer_id [description]
     * @return [type]           [description]
     */
    public function get_current_specific_payout($offer_id, $user_id, $start_time='')
    {
        if (!$start_time) {
            $start_time=time();
        }
        $sql="select * from specific_payout where offer_id=" . $offer_id . " and user_id=" . $user_id . " and type=1 and status=1 and start_time<=" . $start_time . " order by start_time desc, specific_id desc limit 1";
        $data=$this->get_query($sql);
        if ($data) {
            return $data[0];
        }
        return [];
    }


    /**
     * 获取当前offer状态
     * @param  [type] $offer_id [description]
     * @return [type]           [description]
     */
    public function get_offer_current_status($offer_id)
    {
        $sql="select * from offer_effective_log where offer_id=" . $offer_id . " and effective_time<=" . time() . " order by effective_time desc, log_id desc limit 1";
        $data=$this->get_query($sql);
        if ($data) {
            return $data[0]['status'];
        }
        return -2;
    }

    /**
     * 获取接下来最新的offer状态
     * @param  [type] $offer_id [description]
     * @return [type]           [description]
     */
    public function get_offer_next_status($offer_id)
    {
        $sql="select * from offer_effective_log where offer_id=" . $offer_id . " and effective_time>" . time() . " order by effective_time asc,log_id desc limit 1";
        $data=$this->get_query($sql);
        if ($data) {
            return $data[0];
        }
        return [];
    }

    /**
     * 获取offer所有的过往时间设置
     * @param  [type] $offer_id [description]
     * @return [type]           [description]
     */
    public function get_offer_status($offer_id)
    {
        $sql="select * from offer_effective_log where offer_id=" . $offer_id . " order by effective_time desc, log_id desc";
        $data=$this->get_query($sql);
        $flag=false;
        foreach ($data as $key=>&$item) {
            $item['is_current']=false;
            if (!$flag && $item['effective_time'] <= time()) {
                $item['is_current']=true;
                $flag=true;
            }
        }
        return $data;
    }

    /**
     * 获取offer所有的过往时间设置
     * @param  [type] $offer_id [description]
     * @return [type]           [description]
     */
    public function get_current_offer_status($offer_id)
    {
        $sql="select * from offer_effective_log where offer_id=" . $offer_id . " and effective_time<=" . time() . " order by effective_time desc,log_id desc limit 1";
        $data=$this->get_query($sql);

        return $data?$data[0]['status']:0;
    }
}
