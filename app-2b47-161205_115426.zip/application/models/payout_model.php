<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Payout_model extends MY_Model
{


    CONST STATUS_SUCCESS = 1;  //在线
    CONST STATUS_DEL = 0;   //删除

    function __construct()
    {
        $this->_table = 'payout';
        $this->_pk = 'payout_id';
    }

    /**
     *
     * @param array $data
     * @param int $page
     * @param int $limit
     * @param array $order
     * @return mixed
     */
    public function getAll($data = array(), $page = 1, $limit = 10, $order = ['addtime', 'desc'])
    {
        $data['status'] = $this::STATUS_SUCCESS;
        return $this->get_all($data, $page, $limit, $order);
    }

    /**
     * 更新
     * @param $ids string ex:1,4,6这种格式
     * @return string
     */
    public function updates($ids, $data = array())
    {
        if (is_array($ids)) {
            $ids = trim(implode(',', $ids), ',');
            $where = "retained_id in ($ids)";
        } else {
            $where = "retained_id in ($ids)";
        }
        if (empty($data)) {
            $content['status'] = $this::STATUS_DEL;
        } else {
            $content = $data;
        }
        $res = $this->retained_model->update_row_by_fileds($where, $content);
        return $res ? $res : '';
    }


    /**
     * 检查是否删除权限
     * @param $userid
     * @param $product_id
     * @return bool
     */
    public function chkUserPower($userid, $retained_id)
    {
        $sql = "SELECT retained.retained_id,offer.product_id,product.product_id,product.advertiser_id FROM retained LEFT JOIN offer ON offer.offer_id = retained.offer_id LEFT JOIN product ON product.product_id=offer.product_id WHERE retained.status =1 AND product.advertiser_id ={$userid} AND retained.retained_id ='{$retained_id}'";
        $query = $this->db->query($sql);
        if ($query->result_object()) {
            return true;
        } else {
            return false;
        }
    }


    public function getOne($where){
        $data='';
        if(is_array($where)){
            foreach ($where as $key => $value) {
                $data.= $key.'='.$value.' ';
            }
        }
        $data .='AND status=1';
        $sql = "SELECT retained_id,value,price FROM {$this->_table} WHERE {$data} order by {$this->_pk} desc limit 1";
        $res = $this->get_query($sql);
        return $res?$res[0]:array();
    }

}
