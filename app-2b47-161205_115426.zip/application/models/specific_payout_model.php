<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Specific_payout_model extends MY_Model {

    function __construct(){
        $this -> _table = 'specific_payout';
        $this -> _pk     = 'specific_id';

        $this->load->model('user_model');
        $this->load->model('publisher_offer_model');
        $this->load->model('offer_cpa_log_model');
    }

    /**
     * 添加特殊价格日志
     * @param [type] $user_id   [description]
     * @param [type] $user_name [description]
     * @param [type] $cpa       [description]
     * @param [type] $offer_id  [description]
     * @param [type] $note      [description]
     */
    public function add_specific_payout_log_action($user_id, $user_name, $cpa, $offer_id, $note, $start_time="")
    {

        $sql = "select * from specific_payout where user_id=".$user_id." and offer_id=".$offer_id." and type=1 and status=1 order by start_time desc limit 1";
        $last_specific = $this->get_query($sql);

        if ($last_specific && $last_specific[0]['payout'] == $cpa) {
            return '已经是最新的';
        }

        $specific = ['user_id'=>$user_id, 'user_name'=>$user_name, 'payout'=>$cpa, 'note'=>$note, 'offer_id'=>$offer_id, 'start_time'=>$start_time, 'type'=>1];

        $this->add_one($specific);

        //更新用户的特殊价格状态
        $this->publisher_offer_model->update_row_by_fields(['offer_id'=>$offer_id, 'publisher_id'=>$user_id], ['is_specific_payout'=>1, 'cpa'=>$cpa]);

        $cpa_log = ['user_id'=>$user_id, 'cpa'=>$cpa, 'start_time'=>$start_time, 'offer_id'=>$offer_id, 'type'=>'specific'];
        $this->offer_cpa_log_model->add_one($cpa_log);
    }


    /**
     * 取消用户的特殊价格
     * @param  [type] $offer_id [description]
     * @param  [type] $user_id  [description]
     * @return [type]           [description]
     */
    public function cancel_specific_payout_log_action($offer_id, $user_id, $note, $start_time)
    {
        $sql = "select * from specific_payout where offer_id=".$offer_id." and user_id=".$user_id." and status=1 and type=1 order by specific_id desc";
        $data = $this->get_query($sql);//找到此用户这个offer最后一次删除的记录
        
        foreach ($data as $key => $info) {

            $this->update_row_by_id($info['specific_id'], ['status'=>0]);

            $specific = ['user_id'=>$user_id, 'user_name'=>$info['user_name'], 'payout'=>$info['payout'], 'note'=>$note, 'offer_id'=>$offer_id, 'start_time'=>$start_time, 'type'=>0];

            $this->add_one($specific);
        }
    }

}
