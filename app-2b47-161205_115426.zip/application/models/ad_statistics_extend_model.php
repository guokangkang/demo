<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Ad_statistics_extend_model extends MY_Model {

    function __construct(){
        $this -> _table = 'ad_statistics_extend';
        $this -> _pk     = 'statistics_id';
    }

}
