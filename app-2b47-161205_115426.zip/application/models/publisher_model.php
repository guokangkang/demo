<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Publisher_model extends MY_Model {

    function __construct(){
        $this -> _table = 'publisher';
        $this -> _pk     = 'user_id';
    }

}
