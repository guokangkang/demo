<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Bills_model extends MY_Model {

    function __construct(){
        $this -> _table = 'bills';
        $this -> _pk     = 'bill_id';
    }

}
