<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Adset_retention_model extends MY_Model {

    function __construct(){
        $this -> _table = 'adset_retention';
        $this -> _pk     = 'retention_id';
    }

}
