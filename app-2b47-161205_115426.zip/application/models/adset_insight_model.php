<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Adset_insight_model extends MY_Model {

    var $fields = [
            'account_id',
            'market_account_id',
            'campaign_id',
            'market_campaign_id',
            'date_start',
            'date_stop',
            'results',
            'spend',
            'reach',
            'frequency',
            'cost',
            'spend',
            'clicks',
            'ctr',
            'cpc',
            'impressions',
            'cpm',
            'link_clicks',
            'cpc_link',
            'ctr_link',
            'backup'
    ];
    
	function __construct(){
		$this -> _table = 'adset_insight';
		$this -> _pk     = 'insight_id';
	}

}
