<!DOCTYPE html>
<html lang="en">
  <head>
  
    <style> 
      .divcss5-x0{ padding-bottom:0px; border-bottom:1px solid #2679b5} 
      
    </style> 

<link rel="stylesheet" href="<?php echo base_url();?>assets/admin/css/chosen.css" />

    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <meta charset="utf-8" />
    <title>palmax系统管理后台</title>

    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />

    <!-- bootstrap & fontawesome -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/admin/css/bootstrap.min.css" />
    <link rel="stylesheet" href="<?php echo base_url();?>assets/admin/css/font-awesome.min.css" />

    <!-- text fonts -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/admin/css/ace-fonts.css" />
    
    <link rel="stylesheet" href="<?php echo base_url();?>assets/admin/css/jquery.gritter.css" />

    <!-- ace styles -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/admin/css/ace.min.css" id="main-ace-style" />

    <!--[if lte IE 9]>
      <link rel="stylesheet" href="<?php echo base_url();?>assets/admin/css/ace-part2.min.css" />
    <![endif]-->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/admin/css/ace-skins.min.css" />
    <link rel="stylesheet" href="<?php echo base_url();?>assets/admin/css/ace-rtl.min.css" />
    
    <link rel="stylesheet" href="<?php echo base_url();?>assets/admin/css/page.css" />
    
    
    

    <!--[if lte IE 9]>
      <link rel="stylesheet" href="<?php echo base_url();?>assets/admin/css/ace-ie.min.css" />
    <![endif]-->

    <!-- ace settings handler -->
    <script src="<?php echo base_url();?>assets/admin/js/ace-extra.min.js"></script>
    <!-- <script src="<?php echo base_url();?>assets/admin/js/jquery.min.js"></script> -->

    <!-- basic scripts -->

    <!--[if !IE]> -->
    <script type="text/javascript">
      window.jQuery || document.write("<script src='<?php echo base_url();?>assets/admin/js/jquery.min.js'>"+"<"+"/script>");
    </script>

    <!-- <![endif]-->

    <!--[if IE]>
<script type="text/javascript">
 window.jQuery || document.write("<script src='<?php echo base_url();?>assets/admin/js/jquery1x.min.js'>"+"<"+"/script>");
</script>
<![endif]-->
    <script type="text/javascript">
      if('ontouchstart' in document.documentElement) document.write("<script src='<?php echo base_url();?>assets/admin/js/jquery.mobile.custom.min.js'>"+"<"+"/script>");
    </script>
    <script src="<?php echo base_url();?>assets/admin/js/bootstrap.min.js"></script>

    <!-- alert -->
    <script src="<?php echo base_url();?>assets/admin/js/bootbox.min.js"></script>
    <script src="<?php echo base_url();?>assets/admin/js/jquery.gritter.min.js"></script>

    <!-- ace scripts -->
    <script src="<?php echo base_url();?>assets/admin/js/ace-elements.min.js"></script>
    <script src="<?php echo base_url();?>assets/admin/js/ace.min.js"></script>
    
    
    
    
    <!--[if lte IE 8]>
    <script src="<?php echo base_url();?>assets/admin/js/html5shiv.min.js"></script>
    <script src="<?php echo base_url();?>assets/admin/js/respond.min.js"></script>
    <![endif]-->
    
    
    <script type="text/javascript">
    function confirm_show(info, callback){
      bootbox.confirm({
        message: info,
        buttons: {
          confirm: {
           label: "确定",
           className: "btn-primary btn-sm",
          },
          cancel: {
           label: "取消",
           className: "btn-sm",
          }
        },
        callback: callback
        }
      );
    }
    
    
    function message_show(text){
      $.gritter.add({
        //title: title,
        text: text,
        class_name: 'gritter-info gritter-center gritter-error'
      });
  
      return false;
    }
    function showmessage(status, mess){
      $(".alert-block").hide();
      if(status=='success'){
        $(".alert-block").addClass("alert-success");
        $(".alert-block").children("strong").addClass('green');
        $(".alert-block").children("strong").html(mess);
      }else{
        $(".alert-block").addClass("alert-danger");
        $(".alert-block").children("strong").html(mess);
      }
      $(".alert-block").show();
    }
    
    function error(msg) {
            var html = '<div class="alert alert-danger" style="display:block">\
                            <button type="button" class="close" data-dismiss="alert">\
                                <i class="ace-icon fa fa-times"></i>\
                            </button>\
                            <strong>\
                                    哦，悲剧了!&nbsp;&nbsp;'+msg+'\
                            </strong>\
                            <i class="mess"> </i>   <br>\
                        </div>';
            $(".page-header").after(html);
            //$(document).scrollTop(0);
        }

        function success (msg) {
            var html = '<div class="alert alert-info" style="display:block">\
                            <button type="button" class="close" data-dismiss="alert">\
                                <i class="ace-icon fa fa-times"></i>\
                            </button>\
                            <strong>\
                                    恭喜你!&nbsp;&nbsp;'+msg+'\
                            </strong>\
                            <i class="mess"> </i>   <br>\
                        </div>';
            $(".page-header").after(html);

        }
    </script>
    
  </head>

  <body class="no-skin">
    <?php $this->load->view('admin/header');?>
    <!-- /section:basics/navbar.layout -->
    <div class="main-container" id="main-container">
      <script type="text/javascript">
        try{ace.settings.check('main-container' , 'fixed')}catch(e){}
      </script>

      <!-- #section:basics/sidebar -->
      <?php $this->load->view('admin/left');?>

      <!-- /section:basics/sidebar -->
      <div class="main-content">
        

        <!-- /section:basics/content.breadcrumbs -->
        <div class="page-content">
          <div class="alert alert-block " style="display:none">
              <button type="button" class="close" data-dismiss="alert">
                <i class="ace-icon fa fa-times"></i>
              </button>
              <strong>
                
              </strong>
            </div>
          <div class="page-content-area">
            <?php echo $content;?>
          </div><!-- /.page-content-area -->
        </div><!-- /.page-content -->
      </div><!-- /.main-content -->

      <?php $this->load->view('admin/footer');?>

      <a href="#" id="btn-scroll-up" class="btn-scroll-up btn btn-sm btn-inverse">
        <i class="ace-icon fa fa-angle-double-up icon-only bigger-110"></i>
      </a>
    </div><!-- /.main-container -->

  </body>
</html>
