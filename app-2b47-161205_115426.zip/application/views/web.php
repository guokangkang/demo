<!DOCTYPE html>
<html class="no-js css-menubar" lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
    <meta name="description" content="bootstrap admin template">
    <meta name="author" content="">
    <title><?php echo $title; ?></title>
    <link rel="apple-touch-icon" href="<?php echo base_url();?>assets/web/assets/images/apple-touch-icon.png">
    <link rel="shortcut icon" href="<?php echo base_url();?>assets/web/assets/images/favicon.ico">
    <!-- Stylesheets -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/css/bootstrap-extend.min.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/web/assets/css/site.min.css">
    <!-- Plugins -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/animsition/animsition.min.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/asscrollable/asScrollable.min.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/switchery/switchery.min.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/intro-js/introjs.min.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/slidepanel/slidePanel.min.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/flag-icon-css/flag-icon.min.css">
    <!-- <link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/toastr/toastr.min.css"> -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/web/assets/examples/css/advanced/toastr.min.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/web/assets/examples/css/pages/profile.min.css">

    <!-- Fonts -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/fonts/web-icons/web-icons.min.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/fonts/font-awesome/font-awesome.min.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/fonts/brand-icons/brand-icons.min.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/fonts/brand-icons/brand-icons.min.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/fonts/google/fonts.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/location.default.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/global/fonts/material-design/material-design.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/assets/examples/css/uikit/icon.css">
    
    <!--[if lt IE 9]>
    <script src="<?php echo base_url();?>assets/web/global/vendor/html5shiv/html5shiv.min.js"></script>
    <![endif]-->
    <!--[if lt IE 10]>
    <script src="<?php echo base_url();?>assets/web/global/vendor/media-match/media.match.min.js"></script>
    <script src="<?php echo base_url();?>assets/web/global/vendor/respond/respond.min.js"></script>
    <![endif]-->
    <!-- Scripts -->
    <script src="<?php echo base_url();?>assets/web/global/vendor/modernizr/modernizr.js"></script>
    <script src="<?php echo base_url();?>assets/web/global/vendor/breakpoints/breakpoints.js"></script>
    <script>
        Breakpoints();
    </script>

    <style type="text/css">
        @media (min-width: 768px){
            .site-navbar .navbar-header {
                width: 220px;
            }
        }
    </style>
    <!-- Core  -->
<script src="<?php echo base_url();?>assets/web/global/vendor/jquery/jquery.min.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/bootstrap/bootstrap.min.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/animsition/animsition.min.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/asscroll/jquery-asScroll.min.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/mousewheel/jquery.mousewheel.min.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/asscrollable/jquery.asScrollable.all.min.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/ashoverscroll/jquery-asHoverScroll.min.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/asrange/jquery-asRange.min.js"></script>

  <!-- Plugins -->
  <script src="<?php echo base_url();?>assets/web/global/vendor/switchery/switchery.min.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/intro-js/intro.min.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/screenfull/screenfull.min.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/slidepanel/jquery-slidePanel.min.js"></script>


  <!-- Scripts -->
  <script src="<?php echo base_url();?>assets/web/global/js/core.min.js"></script>
  <script src="<?php echo base_url();?>assets/web/assets/js/site.min.js"></script>
  <script src="<?php echo base_url();?>assets/web/assets/js/sections/menu.min.js"></script>
  <script src="<?php echo base_url();?>assets/web/assets/js/sections/menubar.min.js"></script>
  <script src="<?php echo base_url();?>assets/web/assets/js/sections/sidebar.min.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/js/configs/config-colors.min.js"></script>
  <script src="<?php echo base_url();?>assets/web/assets/js/configs/config-tour.min.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/js/components/asscrollable.min.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/js/components/animsition.min.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/js/components/slidepanel.min.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/js/components/switchery.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>assets/js/moment.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>assets/js/daterangepicker.js"></script>

<script src="<?php echo base_url();?>assets/web/assets/examples/js/uikit/icon.js"></script>
<script src="<?php echo base_url(); ?>assets/web/assets/examples/js/uikit/icon.js"></script>
  
 <script type="text/javascript">
     var base_url = "<?php echo base_url()?>";
     var site_url = "<?php echo site_url()?>";
 </script>
</head>
<body class="site-navbar-small app-projects" >
<!--[if lt IE 8]>
<p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade
    your browser</a> to improve your experience.</p>
<![endif]-->
<nav class="site-navbar navbar navbar-default navbar-fixed-top navbar-mega navbar-inverse"
     role="navigation">
    <div class="navbar-header">
        <button type="button" class="navbar-toggle hamburger hamburger-close navbar-toggle-left hided"
                data-toggle="menubar">
            <span class="sr-only">Toggle navigation</span>
            <span class="hamburger-bar"></span>
        </button>
        <button type="button" class="navbar-toggle collapsed" data-target="#site-navbar-collapse"
                data-toggle="collapse">
            <i class="icon wb-more-horizontal" aria-hidden="true"></i>
        </button>
        <a class="navbar-brand navbar-brand-center" href="<?php echo site_url('dashboard/index'); ?>">
            <img class="navbar-brand-logo navbar-brand-logo-normal" src="<?php echo base_url();?>assets/images/marketmax-white.png"
                 title="Palmax" style="width: 24px;">
            <img class="navbar-brand-logo navbar-brand-logo-special" src="<?php echo base_url();?>assets/web/assets/images/logo-blue.png"
                 title="Palmax">
            <span class="navbar-brand-text hidden-xs">
                <?php if($this->userinfo['type']==1):?>
                    Palmax AdDigger
                <?php elseif($this->userinfo['type']==2):?>
                    Palmax AdCaptain
                <?php else:?>
                    Palmax Management
                <?php endif;?>
            </span>
        </a>
        <button type="button" class="navbar-toggle collapsed" data-target="#site-navbar-search"
                data-toggle="collapse">
            <span class="sr-only">Toggle Search</span>
            <i class="icon wb-search" aria-hidden="true"></i>
        </button>
    </div>
    <div class="navbar-container container-fluid">
        <!-- Navbar Collapse -->
        <div class="collapse navbar-collapse navbar-collapse-toolbar" id="site-navbar-collapse">
            <!-- Navbar Toolbar -->
            <ul class="nav navbar-toolbar">
                <?php if($this->userinfo['type']==0 || $this->userinfo['type']==2):?>
                    <li class="<?php echo $this->_class=='dashboard'?'active':''?>">
                        <a href="<?php echo site_url('dashboard/index'); ?>">Dashboard</a>
                    </li>
                    <?php if($this->userinfo['type']!=0):?>
                        <li class="<?php echo ($this->_class=='manage'&&in_array($this->_method, ['offer', 'offer_detail']))||$this->_class=='product'?'active':''?>">
                            <a href="<?php echo site_url('product/listview') ?>">Marketplace</a>
                        </li>
                    <?php endif;?>
                    <?php if($this->userinfo['type']==2):?>
                        <!-- <li class="<?php echo $this->_class=='statistics'?'active':''?>">
                            <a href="<?php echo site_url('statistics/account') ?>">Statistics</a>
                        </li> -->
                    <?php endif;?>

                    <?php if($this->userinfo['type']==0):?>
                        <li class="<?php echo $this->_class=='agency'?'active':''?>">
                            <a href="<?php echo site_url('agency/index')?>">Agency</a>
                        </li>
                    <?php endif;?>

                    <li class="<?php echo $this->_class=='report'?'active':''?>">
                        <a href="<?php echo site_url('report') ?>">Reports</a>
                    </li>
                    <!-- <li>
                        <a href="#">Bills</a>
                    </li> -->
                    <?php if($this->userinfo['type']==0):?>
                    
                    <li class="<?php echo $this->_class=='review'?'active':''?>">
                        <a href="<?php echo site_url('review') ?>">Review</a>
                    </li>
                    
                    <?php endif;?>

                    <?php if($this->userinfo['type']==0):?>
                        <li class="<?php echo $this->_class=='bills'&&($this->_method=='listview'||$this->_method=='detail')?'active':''?>">
                            <a href="<?php echo site_url('bills/listview') ?>">Bills</a>
                        </li>
                    <?php else:?>
                        <li class="<?php echo $this->_class=='bills'&&($this->_method=='listview'||$this->_method=='detail')?'active':''?>">
                            <a href="<?php echo site_url('bills/detail') ?>">Bills</a>
                        </li>
                    <?php endif;?>
                    <?php if($this->userinfo['business']):?>
                        <li class="<?php echo $this->_class=='business'?'active':''?>">
                            <a href="<?php echo site_url('business/users')?>">Business Manager</a>
                        </li>
                    <?php endif;?>
                <?php elseif($this->userinfo['type']==1):?>
                    <li class="<?php echo $this->_class=='product'?'active':''?>">
                        <a href="<?php echo site_url('product/listview')?>">Marketing</a>
                    </li>
                    <li class="<?php echo $this->_class=='agency'?'active':''?>">
                        <a href="<?php echo site_url('agency/index')?>">Agency</a>
                    </li>
                    <li class="<?php echo $this->_class=='report'?'active':''?>">
                        <a href="<?php echo site_url('report/')?>">Reports</a>
                    </li>
                    <li class="<?php echo $this->_class=='review'?'active':''?>">
                        <a href="<?php echo site_url('review/index')?>">Creative</a>
                    </li>
                <?php endif;?>

                <?php if($this->userinfo['type']==0):?>
                
                <li class="<?php echo $this->uri->segment(1)=='manager'?'active':''?>">
                    <a href="<?php echo site_url('manager/product/listview')?>">Management</a>
                </li>
                <?php endif;?>

            </ul>
            <!-- End Navbar Toolbar -->
            <!-- Navbar Toolbar Right -->
            <ul class="nav navbar-toolbar navbar-right navbar-toolbar-right">
                <?php if($this->userinfo['type']==0):?>
                    <li class="dropdown <?php echo ($this->_class=='manage'||($this->_class=='setup'&&$this->_method!='password')||$this->_class=="product")?"active":""?>">
                        <!-- <a data-toggle="dropdown" href="#" aria-expanded="false" data-animation="scale-up" role="button">
                            <i class="icon wb-settings" aria-hidden="true"></i>
                        </a> -->
                        <ul class="dropdown-menu" role="menu">
                            
                            <li role="presentation" class="<?php echo (($this->_class=='product')||(in_array($this->_method, ['offer', 'offer_detail'])&&$this->_class=='manage')||($this->_class=='setup'&&$this->_method=='product'))?"active":''?>">
                                <a href="<?php echo site_url('setup/product')?>" role="menuitem">
                                    <i class="icon fa-street-view" aria-hidden="true"></i>
                                    Products Management
                                </a>
                            </li>
                            

                            <?php if(in_array('AM', $this->userinfo['role']) || in_array('SYS', $this->userinfo['role'])):?>
                                <li class="divider" role="presentation"></li>
                                <li role="presentation" class="<?php echo ((in_array($this->_method, ['accounts', 'applications'])&&$this->_class=='manage')||($this->_method=='offer'&&$this->_class=='setup'))?"active":''?>">
                                    <a href="<?php echo site_url('manage/applications')?>" role="menuitem">
                                        <i class="icon fa-leaf" aria-hidden="true"></i>
                                        Offers Assignment
                                    </a>
                                </li>
                                <li class="divider" role="presentation"></li>
                                <li role="presentation" class="<?php echo (($this->_method=='index'&&$this->_class=='setup'))?"active":''?>">
                                    <a href="<?php echo site_url('setup/index')?>" role="menuitem">
                                        <i class="icon fa-umbrella" aria-hidden="true"></i>
                                        Retetion Management
                                    </a>
                                </li>
                                
                            <?php endif;?>

                            <?php if(in_array('SYS', $this->userinfo['role'])):?>
                                <li class="divider" role="presentation"></li>
                                <li role="presentation" class="<?php echo in_array($this->_method, ['manager', 'advertiser', 'publisher','company'])?"active":''?>">
                                    <a href="<?php echo site_url('setup/manager')?>" role="menuitem" >
                                        <i class="icon wb-user" aria-hidden="true"></i>
                                        User Management
                                    </a>
                                </li>
                                
                            <?php endif;?>
                            
                        </ul>
                    </li>
                <?php endif;?>


                <li class="dropdown">
                    <a class="navbar-avatar dropdown-toggle" data-toggle="dropdown" href="#" aria-expanded="false"
                       data-animation="scale-up" role="button">
                        <span class="avatar avatar-online">
                            <?php if($this->userinfo['head']):?>
                                 <img src="<?php echo base_url("./avatar/".$this->userinfo['user_id'].".jpg");?>" alt="..." onerror="javascript:this.src='<?php echo base_url();?>assets/images/default_avatar.jpg'">
                            <?php else:?>
                                <img src="<?php echo base_url();?>assets/images/default_avatar.jpg" alt="...">
                            <?php endif;?>
                        </span>
                    </a>
                    <ul class="dropdown-menu" role="menu">
                        <?php if($this->userinfo['type']==2):?>
                            <li role="presentation">
                                <a href="<?php echo site_url('user/account')?>" role="menuitem">
                                    <i class="icon wb-user" aria-hidden="true"></i>
                                    Facebook Connect
                                </a>
                            </li>
                            <li class="divider" role="presentation"></li>
                        <?php endif;?>
                        <li role="presentation">
                            <a href="<?php echo site_url('setup/password')?>" role="menuitem">
                                <i class="icon fa-cog" aria-hidden="true"></i>
                                Edit Password
                            </a>
                        </li>
                        <li class="divider" role="presentation"></li>
                        
                        <li role="presentation">
                            <a href="<?php echo site_url('sign/logout')?>" role="menuitem">
                                <i class="icon wb-power" aria-hidden="true"></i> 
                                Logout
                            </a>
                        </li>
                    </ul>
                </li>

                
                
            </ul>
            <ul class="nav navbar-toolbar navbar-right">
                <li class="hidden-xs" id="toggleFullscreen">
                    <a class="icon icon-fullscreen" data-toggle="fullscreen" href="#" role="button">
                        <span class="sr-only">Toggle fullscreen</span>
                    </a>
                </li>
            </ul>
            <!-- End Navbar Toolbar Right -->
        </div>
        <!-- End Navbar Collapse -->
        
    </div>
</nav>

<?php echo $top_menu; ?>

<!-- Page -->
<?php echo $content;?>
<!-- End Page -->

<script type="text/javascript">
    function error(msg) {
        var html = "<div class='col-md-offset-4 col-sm-6 col-md-4 alert dark alert-warning alert-dismissible oBox_alert' role='alert' style='z-index: 1700;position: fixed;top: 15%;'>"+
                "<button type='button' class='close' data-dismiss='alert' aria-label='Close'>"+
                    "<span aria-hidden='true'>×</span>"+
                "</button>"+
                "<h4>Error</h4>"+
                "<p>"+
                    "Lorem ipsum dolor sit amet, consectetur adipiscing elit."+
                    "<a class='alert-link' href='javascript:void(0)'>"+msg+"</a>"+
                "</p>"+
            "</div>";
        $("body").append(html); 
        //event.stopPropagation();
    }

    function success (msg) {
        var html = "<div class='col-md-offset-4 col-sm-6 col-md-4 alert dark alert-success alert-dismissible oBox_alert' role='alert' style='z-index: 1700;position: fixed;top: 15%;'>"+
                "<button type='button' class='close' data-dismiss='alert' aria-label='Close'>"+
                    "<span aria-hidden='true'>×</span>"+
                "</button>"+
                "<h4>Success</h4>"+
                "<p>"+
                    "Lorem ipsum dolor sit amet, consectetur adipiscing elit."+
                    "<a class='alert-link' href='javascript:void(0)'>"+msg+"</a>"+
                "</p>"+
            "</div>";
        $("body").append(html); 
        //event.stopPropagation();
    }
</script>

<!-- Footer -->
<footer class="site-footer">
    <div class="site-footer-legal"><a
            href="<?php echo base_url();?>">Leading Mobile Advertising Platform</a></div>
    <div class="site-footer-right">
        © 2015 - 2016, Palmax Limited, All rights reserved.
    </div>
</footer>
  <script src="<?php echo base_url();?>assets/js/location.default.js"></script>

<script type="text/javascript">
    
    <?php if($this->__tips__['msg']): ?>
    <?php if($this->__tips__['result'] === 1): ?>
    success("<?php echo $this->__tips__['msg']; ?>");
    <?php else: ?>
    error("<?php echo $this->__tips__['msg']; ?>");
    <?php endif;?>
    <?php endif; ?>
</script>

</body>
</html>