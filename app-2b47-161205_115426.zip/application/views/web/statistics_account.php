<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/datatables-bootstrap/dataTables.bootstrap.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/datatables-fixedheader/dataTables.fixedHeader.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/datatables-responsive/dataTables.responsive.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/assets/examples/css/tables/datatable.css">
<script type="text/javascript" src="<?php echo base_url();?>assets/web/js/async.min.js"></script>

<script src="https://connect.facebook.com/en_US/sdk.js"></script>


<script type="text/javascript">
    
    

    $(function(){

        var token="<?php echo $this->userinfo['token']?>";
        var account_status = '<?php echo $account_status?>';
        account_status = eval("("+account_status+")");

        var account_ids = '<?php echo $account?>';
        account_ids = eval("("+account_ids+")");

        var currency = '<?php echo $currency?>';
        currency = eval("("+currency+")");
        
        FB.init({ 
            appId: '515261858648099', 
            version: 'v2.7'
        });

        var data = function(account_id, time) {
            
            FB.api(account_id+'/insights?fields=clicks,ctr,impressions,spend&date_preset='+time, {'access_token':token}, function(response) {
                var insights = response.data;
                if (insights!='') {
                    insights = insights[0];
                    
                    $("."+account_id+" td").eq(4).html(insights.clicks);
                    $("."+account_id+" td").eq(5).html(insights.impressions);
                    $("."+account_id+" td").eq(6).html(insights.ctr.toFixed(2)+"%");
                    $("."+account_id+" td").eq(7).html(currency[$("."+account_id).attr('data-currency')]+insights.spend.toFixed(2));
                }
            });
            
        };
        $.each(account_ids, function(i, v){
            data("act_"+v, 'today');
        });


        $(".choosedate li a").click(function(){
            $(".loading").show();
            $(".table").addClass('fetching');
            var date = $(this).html();
            var data_v = $(this).attr('data-v');
            $("#exampleHoverDropdown3").html(date+'<span class="icon wb-calendar"></span>');
            $(".choosedate li").removeClass('active');
            $(this).parent('li').addClass('active');
            $.each(account_ids, function(i, v){
                data("act_"+v, data_v);
            });
            setTimeout(function(){
                $(".table").removeClass('fetching');
                $(".loading").hide();
            }, 500);
            
        });

        $(".btn-reload").click(function(){
            $(".loading").show();
            $(".table").addClass('fetching');
            $.ajax({
                url:"<?php echo site_url('statistics/reload')?>",
                type:'post',
                datatype:'json',
                success:function(result){
                    result = eval("("+result+")");
                    var html = "";

                    async.each(result, function(item, callback) {

                        var url = "<?php echo site_url('statistics/campaign')?>/"+item.account_id;
                        
                        FB.api("act_"+item.account_id+'/insights?fields=clicks,ctr,impressions,spend&date_preset=today', {'access_token':token}, function(response) {
                            var insights = response.data;
                            window["tr"+item.account_id] = "<tr>";

                            window["tr"+item.account_id] += "<td><a href="+url+">"+item.name+"</a></td>";
                            window["tr"+item.account_id] += "<td>"+item.account_id+"</td>";
                            window["tr"+item.account_id] += "<td>"+item.timezone+"</td>";
                            window["tr"+item.account_id] += "<td>"+item.status+"</td>";
                            if (insights!='') {
                                insights = insights[0];
                                window["tr"+item.account_id] += "<td>"+insights.clicks+"</td>";
                                window["tr"+item.account_id] += "<td>"+insights.impressions+"</td>";
                                window["tr"+item.account_id] += "<td>"+insights.ctr.toFixed(2)+"%</td>";
                                window["tr"+item.account_id] += "<td>"+currency[item.currency]+insights.spend.toFixed(2)+"</td>";
                            }else{
                                window["tr"+item.account_id] += "<td>0</td>";
                                window["tr"+item.account_id] += "<td>0</td>";
                                window["tr"+item.account_id] += "<td>0</td>";
                                window["tr"+item.account_id] += "<td>0</td>";
                            }
                            window["tr"+item.account_id] += "</tr>";

                            html += window["tr"+item.account_id];
                            
                            callback(null);
                        });
                    }, function(){
                        $(".table").removeClass('fetching');
                        $(".loading").hide();

                        $("tbody").html();
                        $("tbody").html(html);
                    });
                    //console.log(html);
                    
                }
            });
        });


        var defaults = $.components.getDefaults("dataTable");
        var options = $.extend(true, {}, defaults, {
            //"bSort" : false,
            'iDisplayLength':100,
            "order": [[ 4, "desc" ]]
        });
        $('#exampleTableTools111').DataTable(options);
    });
    
    
</script>
<!-- Page -->
<div class="page animsition">
    <div class="page-header ">
        <h1 class="page-title">My accounts</h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo site_url('statistics/account');?>">Statistics</a></li>
            <li class="active">Accounts</li>
        </ol>
        <div class="page-header-actions" style="z-index: 999;">
            <button type="button" class="btn btn-icon btn-primary btn-outline btn-round btn-reload" data-original-title="Reload" data-toggle="tooltip">
                <i class="icon wb-refresh" aria-hidden="true"></i></button>
            <button type="button" class="btn btn-primary dropdown-toggle" id="exampleHoverDropdown3"
                    data-toggle="dropdown" aria-expanded="false" data-hover="dropdown">Today
                <span class="icon wb-calendar"></span>
            </button>
            <ul class="dropdown-menu animate dropdown-menu-right choosedate" aria-labelledby="exampleHoverDropdown3" role="menu">
                <li role="presentation"><a href="javascript:void(0)" role="menuitem" data-v="lifetime">Lifetime</a></li>
                <li role="presentation" class="active"><a href="javascript:void(0)" role="menuitem" data-v="today">Today</a></li>
                <li role="presentation"><a href="javascript:void(0)" role="menuitem" data-v="yesterday">Yesterday</a></li>
                <li role="presentation"><a href="javascript:void(0)" role="menuitem"  data-v="last_7_days">Last 7 days</a></li>
                <li role="presentation"><a href="javascript:void(0)" role="menuitem" data-v="last_14_days">Last 14 days</a></li>
                <li role="presentation"><a href="javascript:void(0)" role="menuitem" data-v="last_30_days">Last 30 days</a></li>
                <li role="presentation"><a href="javascript:void(0)" role="menuitem" data-v="last_month">Last month</a></li>
                <li role="presentation"><a href="javascript:void(0)" role="menuitem" data-v="this_month">This month</a></li>
            </ul>
        </div>
    </div>
    <div class="page-content">
        <div class="panel">
            <div class="panel-body">
                <style type="text/css">
                    .loading{
                        display: none;
                    }
                    table.fetching{
                        opacity: 0.5;
                    }
                    .example-well{
                        background-color:#fff;
                    }
                    @keyframes loader-ellipsis{
                        0%, 100%, 80% {
                            -webkit-box-shadow: 0 .625em 0 -.325em #a3afb7;
                            box-shadow: 0 .625em 0 -.325em #4397e6;
                        }
                        40% {
                            -webkit-box-shadow: 0 .625em 0 0 #a3afb7;
                            box-shadow: 0 .625em 0 0 #4397e6;
                        }
                    }
                    animation: loader-ellipsis 1.8s infinite ease-in-out;

                </style>
                <div class="col-md-12 example-loading example-well height-350 vertical-align text-center loading" style="position: absolute;">
                    <div class="loader vertical-align-middle" style="z-index: 999" data-type="ellipsis"></div>
                </div>

                <table class="table table-hover dataTable table-striped width-full" id="exampleTableTools111">
                    <thead>
                      <tr>
                        <th>Account name</th>
                        <th>Account ID</th>
                        <th>Timezone</th>
                        <th>Status</th>
                        <th>Clicks</th>
                        <th>Impressions</th>
                        <th>CTR</th>
                        <th>Spend</th>
                      </tr>
                    </thead>
                    <tfoot>
                      <tr>
                        <th>Account name</th>
                        <th>Account ID</th>
                        <th>Timezone</th>
                        <th>Status</th>
                        <th>Clicks</th>
                        <th>Impressions</th>
                        <th>CTR</th>
                        <th>Spend</th>
                      </tr>
                    </tfoot>
                    <tbody>
                        <?php if($accountlist):?>
                            <?php foreach($accountlist as $item):?>
                                <tr class="act_<?php echo $item['account_id']?>" data-currency="<?php echo $item['currency']?>">
                                    <td><a href="<?php echo site_url('statistics/campaign/'.$item['account_id'])?>"><?php echo $item['name']?></a></td>
                                    <td><?php echo $item['account_id']?></td>
                                    <td><?php echo $item['timezone']?></td>
                                    <td><?php echo $item['status']?></td>
                                    <td>0</td>
                                    <td>0</td>
                                    <td>0</td>
                                    <td>0</td>
                                </tr>
                            <?php endforeach;?>
                        <?php else:?>
                            <tr>
                                <td colspan="8">
                                    <div class="panel margin-bottom-0 height-500">
                                        <div class="text-center padding-top-80">
                                            <img src="<?php echo base_url();?>assets/images/no_data.png">
                                            <h4 class="margin-top-30">NO DATA HERE</h4>
                                            <p style="line-height: 18px;">I hate peeping Toms. For one thing they usually step all over<br>the hedges and plants on the side of someone's house killing</p>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endif;?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<!-- End Page -->
<script src="<?php echo base_url();?>assets/web/global/vendor/datatables/jquery.dataTables.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/datatables-fixedheader/dataTables.fixedHeader.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/datatables-bootstrap/dataTables.bootstrap.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/datatables-responsive/dataTables.responsive.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/datatables-tabletools/dataTables.tableTools.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/asrange/jquery-asRange.min.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/bootbox/bootbox.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/js/components/datatables.js"></script>
<script src="<?php echo base_url();?>assets/web/assets/examples/js/advanced/animation.js"></script>
  
<!--    <script src="<?php echo base_url();?>assets/web/js/account.js"></script>
 -->