<!-- 新加css -->
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/assets/examples/css/advanced/masonry.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/global/vendor/select2/select2.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/global/vendor/asscrollable/asScrollable.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/assets/examples/css/advanced/scrollable.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/global/vendor/jquery-labelauty/jquery-labelauty.css">
<style>
    .table>tbody>tr>td{vertical-align: middle;}
    .form-group label{width: 100%;}
    input.labelauty + label{border-radius: 0; background-color:#fff;}
    input.labelauty:checked + label{background-color:#12abc5;}
    input.labelauty:checked:not([disabled]) + label:hover{background-color:#0890a7;}
    input.labelauty:not(:checked):not([disabled]) + label:hover{background-color: #fff;}
    .review_search{border: 1px solid #12abc5; color:#12abc5!important; background-color: #fff;}
    .labelauty-unchecked,.labelauty-checked{width: 90%;height: 16px;overflow: hidden;}
</style>
<!-- Page -->
<div class="page animsition">
    <div class="page-header clearfix">
        <ol class="breadcrumb pull-left" style="line-height:36px;">
            <li><a href="<?php echo site_url('manager/product/listview')?>">Manager Management</a></li>
            <li><a href="<?php echo site_url('manager/offer/applications')?>">Offer Assignment</a></li>
            <li class="active">Offer Bulk Assign</li>
        </ol>
        <div class="pull-right">
            <div  class="btn btn-primary btn-round btn_self margin-right-15 upload" style="position: relative;}">
                <i class="icon md-cloud-upload" aria-hidden="true"></i>
                Upload
                <input type="file" id="apply_offer" name="" value="" class="padding-0" style="position:absolute;left: 0;top: 0; height: 36px;width: 98px;opacity: 0;cursor: pointer;">
            </div>
            <div class="btn btn-primary btn-round btn_self margin-right-15 uploading hide" style="position: relative;}">
                Uploading
            </div>
        </div>
    </div>
    <div class="page-content padding-30 blue-grey-500 padding-top-0">
        <div class="panel">
            <form autocomplete="off" id="set_publiser_offers" action="<?php echo site_url('manager/offer/add_publisher_offer_action')?>" method="post">
                <div class="panel-body container-fluid">
                <ul class="blocks blocks-100 blocks-xlg-3 blocks-lg-3 blocks-md-3 blocks-sm-2" data-plugin="masonry">
                    <li class="masonry-item">
                        <h5>Advertiser *</h5>
                        <div class="widget-article widget-border bg-white">
                            <div class="input-search margin-0 margin-bottom-20 clearfix">
                                <button type="button" class="input-search-btn" style="left:0;cursor: auto;">
                                    <i class="icon wb-search" aria-hidden="true"></i>
                                </button>
                                <input type="text" class="form-control padding-left-30 filterinput"
                                       id="exampleTypeaheadStyle" name="exampleTypeaheadStyle[]" placeholder=""
                                       style="border-radius:0;border:0; border-bottom:1px solid #e4eaec;">
                            </div>
                            <div class="height-300" data-plugin="scrollable">
                                <div data-role="container">
                                    <ul data-role="content" id="radiao_box" style="list-style:none;padding-left: 0;">
                                        <?php foreach ($advertiser_list as $advertiser): ?>
                                            <li class="form-group  margin-bottom-0">
                                                <input type="radio" value="<?php echo $advertiser['user_id'] ?>"
                                                       class="to-labelauty advertiser_list" name="select_advertiser"
                                                       data-plugin="labelauty"
                                                       data-labelauty="<?php echo $advertiser['user_name'] . '|' . $advertiser['user_name'] ?>"/>
                                            </li>
                                        <?php endforeach; ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </li>
                    <li class="masonry-item">
                        <h5>Offers</h5>
                        <div class="widget-article widget-border bg-white">
                            <div class="input-search margin-0 margin-bottom-20 clearfix">
                                <button type="button" class="input-search-btn" style="left:0;cursor: auto;">
                                    <i class="icon wb-search" aria-hidden="true"></i>
                                </button>
                                <input type="text" class="form-control padding-left-30 filterinput1"
                                       id="exampleTypeaheadStyle" name="exampleTypeaheadStyle" placeholder=""
                                       style="border-radius:0;border:0; border-bottom:1px solid #e4eaec;">
                            </div>
                            <div class="height-300" data-plugin="scrollable">
                                <div data-role="container">
                                    <ul data-role="content" id="checkbox_frist"
                                        style="list-style:none;padding-left: 0;">
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </li>
                    <li class="masonry-item">
                        <h5>Accounts *</h5>
                        <div class="widget-article widget-border bg-white">
                            <div class="input-search margin-0 margin-bottom-20 clearfix">
                                <button type="button" class="input-search-btn" style="left:0;cursor: auto;">
                                    <i class="icon wb-search" aria-hidden="true"></i>
                                </button>
                                <input type="text" class="form-control padding-left-30 filterinput2"
                                       id="exampleTypeaheadStyle" name="exampleTypeaheadStyle" placeholder=""
                                       style="border-radius:0;border:0; border-bottom:1px solid #e4eaec;">
                            </div>
                            <div class="height-300" data-plugin="scrollable">
                                <div data-role="container">
                                    <ul data-role="content" id="checkbox_secound"
                                        style="list-style:none;padding-left: 0;">
                                        <?php foreach($account_list as $account):?>
                                            <li class="form-group margin-bottom-0">
                                                <input type="checkbox" class="to-labelauty" name="select_accounts[]"
                                                       data-plugin="labelauty"
                                                       data-account="<?php echo $account['market_account_id']?>"
                                                       data-labelauty="<?php echo $account['account_id'].' - '.$account['name']?>|<?php echo $account['account_id'].' - '.$account['name']?>"
                                                        value="<?php echo $account['account_id']?>"
                                                />
                                            </li>
                                        <?php endforeach;?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </li>
                </ul>
                <div class="text-center margin-vertical-0">
                    <button type="submit" class="btn btn-info" id="set_publiser_offers_button">Submit</button>
                </div>
            </div>
            </form>
        </div>
    </div>
</div>
<!-- 新加js -->
<script src="<?php echo base_url(); ?>assets/web/global/vendor/masonry/masonry.pkgd.min.js"></script>
<!-- 新加js -->
<script src="<?php echo base_url(); ?>assets/web/global/js/components/switchery.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/js/components/masonry.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/vendor/select2/select2.min.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/js/components/select2.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/vendor/jquery-labelauty/jquery-labelauty.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/js/components/jquery-labelauty.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/js/components/asscrollable.js"></script>
<script src="<?php echo base_url(); ?>assets/web/assets/examples/js/advanced/scrollable.js"></script>

<script type="text/javascript"
        src="<?php echo base_url(); ?>assets/js/jQueryFileUpload/js/vendor/jquery.ui.widget.js"></script>
<script type="text/javascript"
        src="<?php echo base_url(); ?>assets/js/jQueryFileUpload/js/jquery.iframe-transport.js"></script>

<script type="text/javascript"
    src="<?php echo base_url(); ?>assets/js/jQueryFileUpload/js/jquery.fileupload.js"></script>
<script type="text/javascript"
        src="<?php echo base_url(); ?>assets/js/jQueryFileUpload/js/jquery.fileupload-validate.js"></script>
<script type="text/javascript"
        src="<?php echo base_url(); ?>assets/js/jQueryFileUpload/js/jquery.fileupload-validate.js"></script>
<script type="text/javascript"
        src="<?php echo base_url(); ?>assets/js/upload_excel.js"></script>
<!-- 新加js结束 -->
<script>
    //过滤函数
    (function ($) {
        $.expr[":"].Contains = function (a, i, m) {
            return (a.textContent || a.innerText || "").toUpperCase().indexOf(m[3].toUpperCase()) >= 0;
        };
        function filterList(className, list) {
            $(className).change(function () {
                var filter = $(this).val();
                if (filter) {
                    $matches = $(list).find("span:Contains(" + filter + ")").parent().parent();
                    $("li", list).not($matches).slideUp('fast');
                    $matches.slideDown('fast');
                } else {
                    $(list).find("li").slideDown('fast');
                }
                return false;
            }).keyup(function () {
                $(this).change();
            });
        }
        $(function () {
            filterList($(".filterinput"), $("#radiao_box"));
            filterList($(".filterinput1"), $("#checkbox_frist"));
            filterList($(".filterinput2"), $("#checkbox_secound"));
        });
    })(jQuery);
</script>