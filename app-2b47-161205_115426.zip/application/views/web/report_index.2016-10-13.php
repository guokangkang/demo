<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/datatables-bootstrap/dataTables.bootstrap.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/datatables-fixedheader/dataTables.fixedHeader.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/datatables-responsive/dataTables.responsive.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/assets/examples/css/tables/datatable.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/select2/select2.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/bootstrap-select/bootstrap-select.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/fonts/material-design/material-design.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/assets/examples/css/uikit/icon.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/multi-select/multi-select.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/footable/footable.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/index_select.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/daterangepicker.css" />
<style type="text/css">
    .dropdown-menu{z-index: 2000;}
    
</style>
<div class="page animsition">
    <div class="page-header">
        <ol class="breadcrumb"> 
            <li><a href="<?php echo site_url('report/index');?>">Report</a></li>
            <li class="active">Conversion</li>
        </ol>
    </div>
    <div class="page-content"> 
        <div class="row">
            <div class="clearfix visible-md-block visible-lg-block"></div>
            <div class="col-md-12">
                <div class="panel" style="box-shadow:none;border: 1px solid #e3eaec;">
                    <div class="panel-heading">
                        <h3 class="panel-title">Filter</h3>
                        <div class="panel-actions">
                            <a class="panel-action icon wb-minus" data-toggle="panel-collapse" aria-hidden="true"></a>
                        </div>
                    </div>
                    <div class="panel-body">
                        <div class="example" style="margin-bottom: 0; margin-top: 0;">
                            <div class="col-md-4">
                                <div class="example-wrap margin-bottom-30">
                                    <div class="example">

                                        <form>
                                            <?php if($this->userinfo['type']==2 || $this->userinfo['type']==0):?>
                                                <div class="diy_select filter-form advertiser-filter form-group">
                                                    <!--【存】当前选中的值-->
                                                    <input type="hidden" name="" class="diy_select_input filter_advertiser" value="">
                                                    <!--【显示】当前选中的值-->
                                                    <input type="text" class="diy_select_txt filterinput_1" placeholder="Advertiser">
                                                    <!--下拉三角形-->
                                                    <span class="caret" style="right: 14px;position: absolute;top: 50%;margin-top: -2px;"></span>
                                                    <!--数据列表-->
                                                    <ul class="diy_select_list" style="display:none;" id="radiaobox_1">
                                                        <?php if(isset($advertiserlist)):?>
                                                            <?php foreach($advertiserlist as $advertiser):?>
                                                                <li data-key="<?php echo $advertiser['advertiser_id']?>">
                                                                    <span><?php echo $advertiser['advertiser_id']."(".$advertiser['advertiser_name'].')'?></span>
                                                                    <b class="icon wb-check check-mark"></b>
                                                                </li>
                                                            <?php endforeach;?>
                                                        <?php endif;?>
                                                    </ul>
                                                </div>
                                                    <!--<select class="form-control select2-hidden-accessible filter_advertiser" multiple="" data-plugin="select2" tabindex="-1" aria-hidden="true" data-placeholder="Advertiser">
                                                            <option value="<?php /*echo $advertiser['advertiser_id']*/?>"><?php /*echo $advertiser['advertiser_id']."(".$advertiser['advertiser_name'].')'*/?></option>

                                                    </select>-->
                                            <?php endif;?>
                                            <?php if($this->userinfo['type']==1 || $this->userinfo['type']==0):?>
                                                    <div class="diy_select form-group filter-form publisher-filter">
                                                        <!--【存】当前选中的值-->
                                                        <input type="hidden" name="" class="diy_select_input filter_publisher" value="">
                                                        <!--【显示】当前选中的值-->
                                                        <input type="text" class="diy_select_txt filter_input_1" placeholder="Publisher">
                                                        <!--下拉三角形-->
                                                        <span class="caret" style="right: 14px;position: absolute;top: 50%;margin-top: -2px;"></span>
                                                        <!--数据列表-->
                                                        <ul class="diy_select_list" style="display:none;" id="radiao_box_1">
                                                            <?php if(isset($publisherlist)):?>
                                                            <?php foreach($publisherlist as $publisher):?>
                                                                <li data-key="<?php echo $publisher['publisher_id']?>">
                                                                    <span><?php echo $publisher['publisher_id']."(".$publisher['publisher_name'].')';?></span>
                                                                    <b class="icon wb-check check-mark"></b>
                                                                </li>
                                                            <?php endforeach;?>
                                                            <?php endif;?>
                                                        </ul>
                                                    </div>
                                                    <!--<select class="form-control select2-hidden-accessible filter_publisher" multiple="" data-plugin="select2" tabindex="-1" aria-hidden="true" data-placeholder="Publisher">
                                                        <?php /*foreach($publisherlist as $publisher):*/?>
                                                            <option value="<?php /*echo $publisher['publisher_id']*/?>"><?php /*echo $publisher['publisher_id']."(".$publisher['publisher_name'].')'*/?></option>
                                                        <?php /*endforeach;*/?>
                                                    </select>-->
                                            <?php endif;?>


                                                <div class="diy_select form-group filter-form agency-filter">
                                                    <!--【存】当前选中的值-->
                                                    <input type="hidden" name="" class="diy_select_input filter_agency" value="">
                                                    <!--【显示】当前选中的值-->
                                                    <input type="text" class="diy_select_txt filter_input_2" placeholder="Agency">
                                                    <!--下拉三角形-->
                                                    <span class="caret" style="right: 14px;position: absolute;top: 50%;margin-top: -2px;"></span>
                                                    <!--数据列表-->
                                                    <ul class="diy_select_list" style="display:none;" id="radiao_box_2">
                                                        <?php if(isset($agency_list)):?>
                                                            <?php foreach($agency_list as $agency):?>
                                                                <li data-key="<?php echo $agency['publisher_id']?>">
                                                                    <span><?php echo $agency['publisher_name']?></span>
                                                                    <b class="icon wb-check check-mark"></b>
                                                                </li>
                                                            <?php endforeach;?>
                                                        <?php endif;?>
                                                    </ul>
                                                </div>
                                                <!--<select class="form-control select2-hidden-accessible filter_agency" multiple="" data-plugin="select2" tabindex="-1" aria-hidden="true" data-placeholder="Agency">
                                                    <?php /*foreach($agency_list as $agency):*/?>
                                                        <option value="<?php /*echo $agency['publisher_id']*/?>"><?php /*echo $agency['publisher_name']*/?></option>
                                                    <?php /*endforeach;*/?>
                                                </select>-->

                                            <div class="diy_select form-group filter-form product-filter">
                                                <!--【存】当前选中的值-->
                                                <input type="hidden" name="" class="diy_select_input filter_product" value="">
                                                <!--【显示】当前选中的值-->
                                                <input type="text" class="diy_select_txt filterinput_2" placeholder="Product">
                                                <!--下拉三角形-->
                                                <span class="caret" style="right: 14px;position: absolute;top: 50%;margin-top: -2px;"></span>
                                                <!--数据列表-->
                                                <ul class="diy_select_list" style="display:none;" id="radiaobox_2">
                                                    <?php if(isset($productlist)):?>
                                                        <?php foreach($productlist as $product):?>
                                                            <li data-key="<?php echo $product['product_id']?>">
                                                                <span><?php echo "(".$product['product_id'].")".$product['product_name']?></span>
                                                                <b class="icon wb-check check-mark"></b>
                                                            </li>
                                                        <?php endforeach;?>
                                                    <?php endif;?>
                                                </ul>
                                            </div>
                                           <!-- <div class="form-group filter-form product-filter" style="margin-bottom:15px;padding-left: 0;">
                                                <select class="form-control select2-hidden-accessible filter_product" multiple="" data-plugin="select2" tabindex="-1" aria-hidden="true" data-placeholder="Product">
                                                    <?php /*foreach($productlist as $product):*/?>
                                                        <option value="<?php /*echo $product['product_id']*/?>"><?php /*echo "(".$product['product_id'].")".$product['product_name']*/?></option>
                                                    <?php /*endforeach;*/?>
                                                </select>
                                            </div>-->

                                        </form>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-4">
                                <div class="example-wrap margin-bottom-30">
                                    <div class="example">
                                        <form>
                                            <div class="diy_select form-group filter-form offer-filter">
                                                <!--【存】当前选中的值-->
                                                <input type="hidden" name="" class="diy_select_input filter_offer" value="">
                                                <!--【显示】当前选中的值-->
                                                <input type="text" class="diy_select_txt filter_input_3" placeholder="Offer">
                                                <!--下拉三角形-->
                                                <span class="caret" style="right: 14px;position: absolute;top: 50%;margin-top: -2px;"></span>
                                                <!--数据列表-->
                                                <ul class="diy_select_list" style="display:none;" id="radiao_box_3">
                                                    <?php if(isset($offerlist)):?>
                                                        <?php foreach($offerlist as $offer):?>
                                                            <li data-key="<?php echo $offer['offer_id']?>">
                                                                <span><?php echo $offer['offer_id'].'-'.$offer['product_name']?></span>
                                                                <b class="icon wb-check check-mark"></b>
                                                            </li>
                                                        <?php endforeach;?>
                                                    <?php endif;?>
                                                </ul>
                                            </div>
                                            <!--<div class="form-group filter-form offer-filter" style="margin-bottom:15px;padding-left: 0;">
                                                <select class="form-control select2-hidden-accessible filter_offer" multiple="" data-plugin="select2" tabindex="-1" aria-hidden="true" data-placeholder="Offer">
                                                    <?php /*foreach($offerlist as $offer):*/?>
                                                        <option value="<?php /*echo $offer['offer_id']*/?>"><?php /*echo $offer['offer_id'].'-'.$offer['product_name']*/?></option>
                                                    <?php /*endforeach;*/?>
                                                </select>
                                            </div>-->

                                            <div class="diy_select form-group filter-form account-filter">
                                                <!--【存】当前选中的值-->
                                                <input type="hidden" name="" class="diy_select_input filter_account" value="">
                                                <!--【显示】当前选中的值-->
                                                <input type="text" class="diy_select_txt filterinput_3" placeholder="Account">
                                                <!--下拉三角形-->
                                                <span class="caret" style="right: 14px;position: absolute;top: 50%;margin-top: -2px;"></span>
                                                <!--数据列表-->
                                                <ul class="diy_select_list" style="display:none;" id="radiaobox_3">
                                                    <?php if(isset($accountlist)):?>
                                                    <?php foreach($accountlist as $account):?>
                                                        <li data-key="<?php echo $account['account_id']?>">
                                                            <span><?php echo $account['account_id']."(".$account['account_name'].')'?></span>
                                                            <b class="icon wb-check check-mark"></b>
                                                        </li>
                                                    <?php endforeach;?>
                                                    <?php endif;?>
                                                </ul>
                                            </div>
                                           <!-- <div class="form-group filter-form account-filter" style="margin-bottom:15px;padding-left: 0;">
                                                <select class="form-control select2-hidden-accessible filter_account" multiple="" data-plugin="select2" tabindex="-1" aria-hidden="true" data-placeholder="Account">
                                                    <?php /*foreach($accountlist as $account):*/?>
                                                        <option value="<?php /*echo $account['account_id']*/?>"><?php /*echo $account['account_id']."(".$account['account_name'].')'*/?></option>
                                                    <?php /*endforeach;*/?>
                                                </select>
                                            </div>-->

                                            <div class="diy_select form-group filter-form country-filter">
                                                <!--【存】当前选中的值-->
                                                <input type="hidden" name="" class="diy_select_input filter_country" value="">
                                                <!--【显示】当前选中的值-->
                                                <input type="text" class="diy_select_txt filter_input_4" placeholder="Country">
                                                <!--下拉三角形-->
                                                <span class="caret" style="right: 14px;position: absolute;top: 50%;margin-top: -2px;"></span>
                                                <!--数据列表-->
                                                <ul class="diy_select_list" style="display:none;" id="radiao_box_4">
                                                    <?php if(isset($config_country)):?>
                                                        <?php foreach($config_country['country'] as $key=> $country):?>
                                                            <li data-key="<?php echo $key?>">
                                                                <span><?php echo $key.'-'.$country?></span>
                                                                <b class="icon wb-check check-mark"></b>
                                                            </li>
                                                        <?php endforeach;?>
                                                    <?php endif;?>
                                                </ul>
                                            </div>
                                            <!--<div class="form-group filter-form country-filter" style="margin-bottom:15px;padding-left: 0;">
                                                <select class="form-control select2-hidden-accessible filter_country" multiple="" data-plugin="select2" tabindex="-1" aria-hidden="true" data-placeholder="Country">
                                                    <?php /*foreach($config_country['country'] as $key=> $country):*/?>
                                                        <option value="<?php /*echo $key*/?>"><?php /*echo $key.'-'.$country*/?></option>
                                                    <?php /*endforeach;*/?>
                                                </select>
                                            </div>-->
                                        </form>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-1 text-center">
                                <span class="inline-block margin-top-20" style="width:1px; height:180px; border-right:1px dashed #d1d1d1;"></span>
                            </div>
                            <div class="col-md-3">
                                
                                <div class="form-group margin-vertical-0 margin-top-15" style="margin-top:-5px;">
                                    <div class="input-search margin-0">
                                        <button class="input-search-btn" style="cursor: auto;
;"><i class="icon wb-search" aria-hidden="true"></i></button>
                                        <input type="text" class="form-control keywords" name="" placeholder="Campaign Name">
                                    </div>
                                </div>
                                <div class="example-wrap margin-bottom-0">
                                    <div class="example">
                                        <form>  
                                            <div class="form-group col-lg-3 col-xlg-3 filter-form account-filter" style="margin-bottom:15px;padding-left: 0;text-align: center;">
                                                <div class="form-control" style="width: 225px;">
                                                    
                                                    <div id="reportrange" class="pull-left">
                                                        <i class="glyphicon glyphicon-calendar fa fa-calendar"></i>&nbsp;
                                                        <span></span> <b class="caret"></b>

                                                        <input type="hidden" value="" class="date_start" />
                                                        <input type="hidden" value="" class="date_end" />
                                                    </div>
                                                </div>
                                            </div> 
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>   
                        <a  id="ad_list" name="ad_list"></a>                         
                        <div class="example example-buttons text-center margin-vertical-0">
                            <button type="button" class="btn btn-outline btn-primary create_report_action">Search</button>
                            <button type="button" class="btn btn-outline btn-info reports_reset">Reset</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>  
        <!-- Panel Table Tools -->
        <div class="panel" style="box-shadow:none;border: 1px solid #e3eaec;">
            <header class="panel-heading clearfix">
                <h3 class="panel-title pull-left">Details</h3>
                <div class="pull-right col-md-6 margin-top-15 padding-right-30">
                    <button type="button" class="pull-right btn btn-outline btn-default excel_report hover_btn"><i class="icon md-download" aria-hidden="true"></i> Export</button>
                    <!-- <div class="pull-right padding-right-15">
                        <form>                                    
                            <div class="form-group filter-form advertiser-filter" style="margin-bottom:15px;padding-left: 0;">
                                <select data-plugin="selectpicker">
                                    <option>Mustard</option>
                                    <option>Ketchup</option>
                                    <option>Relish</option>
                                    <option>Onions</option>
                                </select>
                            </div>
                        </form>
                    </div> -->
                    <div class="pull-right padding-right-15">
                        <form>                                    
                            <div class="form-group filter-form advertiser-filter" style="margin-bottom:15px;padding-left: 0;">
                                <div class="example margin-0">
                                    <select data-plugin="selectpicker" multiple data-selected-text-format="count > 3" class="select_fields">
                                        <optgroup label="Interval">
                                            <option value="year">Year</option>
                                            <option value="month">Month</option>
                                            <option value="date" selected="">Date</option>
                                        </optgroup>
                                        
                                        <optgroup label="Breakdown">
                                            <option value="product_name">Product</option>
                                            <!-- <option value="offer_id">Offer</option> -->
                                            <option value="advertiser_id">Advertiser</option>
                                            <option value="publisher_id">Publisher</option>
                                            <option value="agency_id">Agency</option>
                                            <option value="country">Country</option>
                                            <option value="account_id">Account</option>
                                            <option value="campaign_id">Campaign</option>
                                            <!-- <option value="adset_id">Ad Set</option> -->
                                        </optgroup>

                                        <optgroup label="Statistics">
                                            <?php if($this->userinfo['type']=='2' || $this->userinfo['type']=='0'):?>
                                                <option value="impressions">Impressions</option>
                                                <option value="clicks" <?php echo $this->userinfo['type']!=0?"selected=''":''?>>Clicks(All)</option>
                                                <option value="clicks_link">Clicks(Link)</option>
                                                <option value="facebook_cpi">Facebook CPI</option>
                                                <option value="spend">Amount Spent</option>
                                                <option value="anticipated_income" <?php echo $this->userinfo['type']==0?"selected=''":''?>><?php echo $this->userinfo['type']==2?'Earning':'Media Buy Earning'?></option>
                                                <option value="revenue" <?php echo $this->userinfo['type']==0?"selected=''":''?>><?php echo $this->userinfo['type']==2?'Real Earning':'Real MB Earning'?></option>
                                                <option value="profit" <?php echo $this->userinfo['type']==0?"selected=''":''?>><?php echo $this->userinfo['type']==2?'Profit':'Media Buy Profit'?></option>
                                                <option value="real_profit" <?php echo $this->userinfo['type']==0?"selected=''":''?>>Real Profit</option>
                                            <?php endif;?>

                                            <option value="results" selected="">Results</option>
                                            <option value="epa">EPA(Earning Per Action)</option>
                                            <?php if($this->userinfo['type']=='1'):?>
                                                <option value="amount_cost" selected="">Amount Cost</option>
                                            <?php endif;?>
                                            
                                            
                                        </optgroup>
                                        <?php if($this->userinfo['type']=='2' || $this->userinfo['type']=='0'):?>
                                            <optgroup label="Calculations">
                                                <option value="ctr_all">CTR(All)</option>
                                                <option value="ctr_link">CTR(Link)</option>
                                                <option value="cvr_all">CVR(All)</option>
                                                <option value="cvr_link">CVR(Link)</option>
                                                <option value="cpc_all">CPC(All)</option>
                                                <option value="cpc_link">CPC(Link)</option>
                                                <option value="cpm">CPM</option>
                                            </optgroup>
                                        <?php endif;?>

                                        
                                    </select>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </header>
            <div class="panel-body">
                <div class="table-responsive">
                    <div class='text-center report_loading' style="display:none;position: absolute;top: 50px;left: 50%;margin-left: -11px;"><div class='loader vertical-align-middle loader-ellipsis' data-type='ellipsis'></div></div>
                    <table class="table dataTable table-striped width-full" id="facebook_report">
                        
                        <thead class="thead" id="thead">
                            <?php if($data):?>
                            <tr class="change_thead">
                                <th>Date</th>
                                

                                <?php if($this->userinfo['type']=='0'):?>
                                    <th>Media Buy Earning</th>
                                    <th>Real MB Earning</th>
                                    <th>Media Buy Profit</th>
                                    <th>Real Profit</th>
                                <?php endif;?>

                                <?php if($this->userinfo['type']=='2'):?>
                                    <th>Clicks(All)</th>
                                <?php endif;?>
                                <th>Results</th>
                                <?php if($this->userinfo['type']=='1'):?>
                                    <th>Amount Cost</th>
                                <?php endif;?>
                            </tr>
                            <?php else:?>
                                <tr>
                                    <td class="text-center"> No Data</td>
                                </tr>
                            <?php endif;?>

                        </thead>
                        <tbody class="tbody">
                            <?php for($i=1; $i<=$days; $i++):?>
                                <tr>
                                    <td><?php echo date('Y-m-d', strtotime("-".$i." day"))?></td>
                                    <td>-</td>
                                    <td>-</td>
                                    <?php if($this->userinfo['type']=='0'):?>
                                        <td>-</td>
                                        <td>-</td>
                                        <td>-</td>
                                    <?php endif;?>
                                    
                                </tr>
                            <?php endfor;?>
                            
                            <?php foreach($data as $item):?>

                                <tr class="gradeA">
                                    <td><?php echo $item['date']?></td>

                                    <?php if($this->userinfo['type']=='0'):?>
                                        
                                        <td><?php echo "$".sprintf("%.2f", $item['expect_revenue'])?></td>
                                        <?php if(isset($retentions[$item['date']])):?>
                                            <td><?php echo "$".sprintf("%.2f", $item['real_earning'])?></td>
                                        <?php else:?>
                                            <td>-</td>
                                        <?php endif;?>
                                        <td><?php echo "$".sprintf("%.2f", ($item['expect_revenue']-$item['spend']))?></td>
                                        <?php if(isset($retentions[$item['date']])):?>
                                            <td><?php echo "$".sprintf("%.2f", ($item['real_earning']-$item['spend']))?></td>
                                        <?php else:?>
                                            <td>-</td>
                                        <?php endif;?>
                                    <?php endif;?>

                                    <?php if($this->userinfo['type']=='2'):?>
                                        <td><?php echo $item['clicks']?></td>
                                    <?php endif;?>
                                    <td><?php echo $item['results']?></td>
                                    <?php if($this->userinfo['type']=='1'):?>
                                        <td><?php echo "$".sprintf("%.2f", $item['amount_cost'])?></td>
                                    <?php endif;?>
                                </tr>
                            <?php endforeach;?>
                            
                        </tbody>
                    </table>
                </div>
            </div>  
        </div>
        <!-- End Panel Table Tools -->
    </div>
</div>
<style type="text/css">
    .loader.loader-default{
        background-color:inherit;
    }
</style>

 <script src="<?php echo base_url();?>assets/web/global/vendor/datatables/jquery.dataTables.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/datatables-fixedheader/dataTables.fixedHeader.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/datatables-bootstrap/dataTables.bootstrap.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/datatables-responsive/dataTables.responsive.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/datatables-tabletools/dataTables.tableTools.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/components/datatables.js"></script>
  <script src="<?php echo base_url();?>assets/web/assets/examples/js/tables/datatable.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/select2/select2.min.js"></script>  
  <script src="<?php echo base_url();?>assets/web/global/js/components/select2.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/js/components/panel.js"></script>
  <script src="<?php echo base_url();?>assets/web/assets/examples/js/uikit/panel-actions.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/bootstrap-select/bootstrap-select.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/js/components/bootstrap-select.js"></script>
  <script src="<?php echo base_url();?>assets/web/assets/examples/js/uikit/icon.js"></script>
<script src="<?php echo base_url();?>assets/js/jquery.tabletoCSV.js" type="text/javascript" charset="utf-8"></script>
<script src="<?php echo base_url();?>assets/js/jquery.tablesorter.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/moment.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/daterangepicker.js"></script>
<script src="<?php echo base_url();?>assets/js/jquery.daterange.js"></script>
<script src="<?php echo base_url();?>assets/js/index_select.js"></script>
  