
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/icheck/icheck.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/bootstrap-select/bootstrap-select.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/index_select.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/select2/select2.css">
<style type="text/css">
    .example-wrap{
        margin: 0;
    }
    .item_bg{
        background-color: #f2f7f9;
    }
</style>
<div class="page animsition">
    <div class="page-header ">
        <h1 class="page-title">My Offers</h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo site_url('product/listview')?>">Marketplace</a></li>
            <li class="active">My Offers</li>
        </ol>
    </div>
    <div class="page-content">
        <div class="panel">
            <div class="panel-body container-fluid" style=" padding-bottom: 0;">
                <div class="row row-lg">
                    <div class="clearfix visible-md-block visible-lg-block"></div>
                    <div class="col-md-12">

                        <div class="example-wrap" style="margin-bottom:0;">
                            <h4>Conditions</h4>
                            <!-- <div class="nav-tabs"></div> -->
                            <div class="example" style="margin-bottom: 0; margin-top: 0;">
                                
                                <div class="col-md-12">
                                    <!-- Example Multi Balue -->
                                    <div class="example-wrap">
                                        <div class="example">
                                            <form class="form-inline">                                                
                                                <div class="form-group col-lg-1 filter-form advertiser-filter">
                                                    <label class="control-label">Filter: </label>
                                                </div>
                                                <div class="form-group col-lg-3 filter-form product-filter">
                                                    <div class="diy_select  filter-form product-filter">
                                                        <!--【存】当前选中的值-->
                                                        <input type="hidden" name="" class="diy_select_input filter_product" value="<?php echo $product_params?implode(',',$product_params).',':'';?>">
                                                        <!--【显示】当前选中的值-->
                                                        <input type="text" class="diy_select_txt filter_input_1" placeholder="<?php echo count($product_params)?count($product_params).' items selected':'Product Filter';?>">
                                                        <!--下拉三角形-->
                                                        <span class="caret" style="right: 14px;position: absolute;top: 50%;margin-top: -2px;"></span>
                                                        <!--数据列表-->
                                                        <ul class="diy_select_list" style="display:none;" id="radiao_box_1">
                                                            <?php if(isset($product_list)):?>
                                                                <?php foreach($product_list as $product):?>
                                                                    <li data-key="<?php echo $product['product_id']?>" <?php echo in_array($product['product_id'],$product_params)?'class="show_list"':'';?>>
                                                                        <span><?php echo "(".$product['product_id'].")".$product['name']?></span>
                                                                        <b class="icon wb-check check-mark"></b>
                                                                    </li>
                                                                <?php endforeach;?>
                                                            <?php endif;?>
                                                        </ul>
                                                      </div>
                                                 </div>
                                                 <!--   <select class="form-control select2-hidden-accessible filter_product" multiple="" data-plugin="select2" tabindex="-1" aria-hidden="true" data-placeholder="Product Filter">
                                                        <?php /*foreach($product_list as $product):*/?>
                                                            <option value="<?php /*echo $product['product_id']*/?>" <?php /*echo (in_array($product['product_id'], $product_params))?"selected='selected'":''*/?>><?php /*echo "(".$product['product_id'].")".$product['name']*/?></option>
                                                        <?php /*endforeach;*/?>
                                                    </select>
-->

                                                <div class="form-group col-lg-3">
                                                    <div class="diy_select filter-form country-filter">
                                                        <!--【存】当前选中的值-->
                                                        <input type="hidden" name="" class="diy_select_input filter_country" value="<?php echo $country_params?implode(',',$country_params).',':'';?>">
                                                        <!--【显示】当前选中的值-->
                                                        <input type="text" class="diy_select_txt filter_input_4" placeholder="<?php echo count($country_params)?count($country_params).' items selected':'Country Filter';?>">
                                                        <!--下拉三角形-->
                                                        <span class="caret" style="right: 14px;position: absolute;top: 50%;margin-top: -2px;"></span>
                                                        <!--数据列表-->
                                                        <ul class="diy_select_list" style="display:none;" id="radiao_box_4">
                                                            <?php if(isset($country_list)):?>
                                                                <?php $country_params=$this->input->get('country')?explode(',',$this->input->get('country')):[];?>
                                                                <?php foreach($country_list['country'] as $key=> $country):?>
                                                                    <li data-key="<?php echo $key?>" <?php echo $country_params&&in_array($key,$country_params)?'class="show_list"':'';?>>
                                                                        <span><?php echo $key.'-'.$country?></span>
                                                                        <b class="icon wb-check check-mark"></b>
                                                                    </li>
                                                                <?php endforeach;?>
                                                            <?php endif;?>
                                                        </ul>
                                                    </div>
                                                  <!--  <select class="form-control select2-hidden-accessible filter_country" multiple="" data-plugin="select2" tabindex="-1" aria-hidden="true" data-placeholder="Country Filter">
                                                        <?php /*foreach($country_list['country'] as $key=> $country):*/?>
                                                            <option value="<?php /*echo $key*/?>" <?php /*echo (in_array($key, $country_params))?"selected='selected'":''*/?>><?php /*echo $key.'-'.$country*/?></option>
                                                        <?php /*endforeach;*/?>
                                                    </select>-->
                                                </div>

                                                <div class="form-group col-lg-3 filter-form padding-5">
                                                    <span class="checkbox-custom checkbox-primary">
                                                        <input class="selectable-all" type="checkbox" id="approved_filter" name='approved_filter' value="1" <?php echo $this->input->get('approved')==1?"checked=''":''?>>
                                                        <label for="approved_filter">Only Approved</label>
                                                    </span>
                                                </div>
                                                
                                                <div class="form-group col-lg-2 filter-form">
                                                    <button type="button" class="btn btn-outline btn-primary offer_search_offer" data-type="my_offer">Search</button>
                                                </div>
        
                                            </form>

                                        </div>
                                    </div>
                                    <!-- End Example Multi Balue -->
                                </div>
                            </div>   

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="panel panel-bordered panel-default">
            <div class="panel-body">
                <table class="table table-hover dataTable table-striped width-full verticaltop" id="productlist" data-selectable="selectable" data-row-selectable="true">
                    <thead>
                      <tr>
                        <th style="width: 10%">Offer ID</th>
                        <th style="width: 20%">Product</th>
                        <th style="width: 25%">Countries</th>
                        <!-- <th style="width: 10%">RPA</th> -->
                        <th style="width: 10%">CPA</th>
                        <th style="width: 10%">Status</th>
                      </tr>
                    </thead>
                    <tbody>
                        <?php if($listview):?>
                            <?php foreach($listview as $item):?>
                            <tr>
                                <td><?php echo $item['offer_id']?></td>
                                <td><?php echo $item['product_name']?></td>
                                <td>
                                    <?php if($item['choose_type']=='include'):?>
                                        <span class="label label-table label-success">Include</span>
                                    <?php else:?>
                                        <span class="label label-table label-danger">Exclude</span>
                                    <?php endif;?>
                                    &nbsp;
                                    <a data-content="<?php echo $item['country_info']?implode(', ', $item['country_info']):'All Countries';?>" data-trigger="hover" data-toggle="popover" data-original-title="Countries" tabindex="0" title="" type="button" data-placement="top">
                                        <?php if($item['country_size']<=10 && $item['country_size']>0):?>
                                            <?php echo implode(', ', $item['countries'])?>
                                        <?php elseif($item['country_size']==0):?>
                                            All Countries
                                        <?php else:?>
                                            <?php echo implode(', ', array_slice($item['countries'], 0, 10))?>
                                        <?php endif;?>
                                    </a>
                                </td>  
                                <!-- <td>$<?php echo sprintf("%.2f", $item['rpa'])?></td> -->
                                <td>
                                    
                                    <?php if($item['current']):?>
                                    <a href="#" data-toggle="modal" data-target="#examplePositionCenter<?php echo $item['offer_id']?>">
                                        <?php if($item['specific_payout']):?>
                                            $<?php echo $item['specific_payout']['payout']?>
                                        <?php else:?>
                                            $<?php echo sprintf("%.2f", $item['current']['cpa']); ?>
                                        <?php endif;?>
                                    </a>
                                    &nbsp;
                                    <span class="bucket_payout_type">(
                                        <?php 
                                            if($item['specific_payout']){
                                                echo "Specific";
                                            }else{
                                                echo $config_product['offer_category'][$item['current']['category']];
                                            }
                                        ?>
                                    )</span>
                                    <?php else:?>
                                        0
                                    <?php endif;?>
                                    <!-- <span class="bucket_payout_type">(<?php echo $config_product['offer_category'][$item['category']];?>)</span> -->
                                    
                                      <!-- Modal -->
                                    <div class="modal fade" id="examplePositionCenter<?php echo $item['offer_id']?>" aria-hidden="true" aria-labelledby="exampleModalTabs"
                                      role="dialog" tabindex="-1">
                                        <div class="modal-dialog">
                                          <div class="modal-content">
                                            <div class="modal-header">
                                                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">×</span>
                                                  </button>
                                                  <h4 class="modal-title" id="exampleModalTabs">Payouts</h4>
                                            </div>
                                            <?php if($item['current']):?>
                                            <div class="col-md-12">
                                              <!-- Example Single Images Lightbox -->
                                              <div class="example-wrap text-center">
                                                <h4 class="example-title bucket-payout-current-title">Current Payout</h4>
                                                <?php if($item['current']['category']==2):?>
                                                    <?php foreach($item['current']['value'] as $val):?>  
                                                        <p><?php echo "If RT > <strong>".$val['retention_rate']."%</strong>, ";?>
                                                        <?php echo "Payout will be <strong>".$val['payout_rate']."%</strong> = ";?>
                                                        <strong><?php echo "$".$val['payout'];?></strong></p>
                                                    <?php endforeach;?>
                                                <?php elseif($item['current']['category']==1):?>
                                                    <strong>$<?php echo $item['current']['cpa']?></strong>
                                                <?php else:?>
                                                    <p>Payout will be proportional to the retention rate.</p>
                                                    <p>If RR > <strong><?php echo $item['current']['value']?>%</strong>, Full Payout.</p>
                                                    <p>If RR = x, payout = x/<strong><?php echo $item['current']['value']?>%</strong>*Full Payout.</p>
                                                <?php endif;?>
                                              </div>
                                              <!-- End Example Single Images Lightbox -->
                                            </div>
                                            <?php endif;?>
                                            <ul class="nav nav-tabs nav-tabs-line bucket-nav-tabs-line" data-plugin="nav-tabs" role="tablist">
                                              <li class="active" role="presentation"><a data-toggle="tab" href="#exampleLine<?php echo $item['offer_id']?>_1" aria-controls="<?php echo $item['offer_id']?>_1"
                                                role="tab">Schedule</a></li>
                                              <li role="presentation"><a data-toggle="tab" href="#exampleLine<?php echo $item['offer_id']?>_2" aria-controls="exampleLine<?php echo $item['offer_id']?>_2"
                                                role="tab">History</a></li>
                                              
                                            </ul>
                                            <div class="modal-body">
                                                <div class="tab-content">
                                                    <div class="tab-pane active" id="exampleLine<?php echo $item['offer_id']?>_1" role="tabpanel">
                                                        <div class="row">
                                                            <div class="col-sm-12">
                                                                <table class="editable-table table table-striped" id="editableTable">
                                                                    <thead>
                                                                      <tr>
                                                                        <th>Effective time</th>
                                                                        <th>Payout</th>
                                                                        <th>Retention</th>
                                                                        <th>Action</th>
                                                                      </tr>
                                                                    </thead>
                                                                    <tbody>
                                                                        <?php foreach($item['schedule'] as $schedule):?>
                                                                            <tr>
                                                                                <td><?php echo date('m/d/Y g:i a', $schedule['start_time'])?></td>
                                                                                <td>$<?php echo $schedule['cpa']?></td>
                                                                                <?php if($schedule['category']==1):?>
                                                                                    <td><strong>$<?php echo $schedule['cpa']?></strong></td>
                                                                                <?php elseif($schedule['category']==2):?>
                                                                                
                                                                                    <td>
                                                                                        <?php foreach($schedule['value'] as $val):?>    
                                                                                            <?php echo "If RT > <strong>".$val['retention_rate']."%</strong>, ";?>
                                                                                            <?php echo "Payout will be <strong>".$val['payout_rate']."%</strong> = ";?>
                                                                                            <?php echo "<strong>$".$val['payout']."</strong><br>";?>
                                                                                        <?php endforeach;?>
                                                                                    </td>
                                                                                <?php else:?>
                                                                                    <td>
                                                                                        Payout will be proportional to the retention rate.<br/>
                                                                                        If RR > <strong><?php echo $schedule['value']?>%</strong>, Full Payout.<br/>
                                                                                        If RR = x, payout = x/<strong><?php echo $schedule['value']?>%</strong>*Full Payout.
                                                                                    </td>
                                                                                <?php endif;?>
                                                                                <td>
                                                                                    <a data-toggle="popover" href="javascript:void(0)" class="btn btn-sm btn-icon btn-pure btn-default on-default remove-bucket-payout popover-rotate" data-toggle="tooltip" data-original-title="Remove" data-val="<?php echo $schedule['payout_id']?>"><i class="icon fa-remove" aria-hidden="true"></i></a>
                                                                                    
                                                                                </td>
                                                                            </tr>
                                                                        <?php endforeach;?>
                                                                    </tbody>
                                                                </table>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="tab-pane" id="exampleLine<?php echo $item['offer_id']?>_2" role="tabpanel">
                                                        <div class="row">

                                                            <div class="col-sm-12">
                                                                <table class="editable-table table table-striped" id="editableTable">
                                                                    <thead>
                                                                      <tr>
                                                                        <th>Effective time</th>
                                                                        <th>Payout</th>
                                                                        <th>Retention</th>
                                                                      </tr>
                                                                    </thead>
                                                                    <tbody>
                                                                        <?php foreach($item['history'] as $schedule):?>
                                                                            <tr>
                                                                                <td><?php echo date('m/d/Y g:i a', $schedule['start_time'])?></td>
                                                                                <td>$<?php echo $schedule['cpa']?></td>
                                                                                <?php if($schedule['category']==1):?>
                                                                                    <td><strong>$<?php echo $schedule['cpa']?></strong></td>
                                                                                <?php elseif($schedule['category']==2):?>
                                                                                
                                                                                    <td>
                                                                                        <?php foreach($schedule['value'] as $val):?>    
                                                                                            <?php echo "If RT > <strong>".$val['retention_rate']."%</strong>, ";?>
                                                                                            <?php echo "Payout will be <strong>".$val['payout_rate']."%</strong> = ";?>
                                                                                            <?php echo "<strong>$".$val['payout']."</strong><br>";?>
                                                                                        <?php endforeach;?>
                                                                                    </td>
                                                                                <?php else:?>
                                                                                    <td>
                                                                                        Payout will be proportional to the retention rate.<br/>
                                                                                        If RR > <strong><?php echo $schedule['value']?>%</strong>, Full Payout.<br/>
                                                                                        If RR = x, payout = x/<strong><?php echo $schedule['value']?>%</strong>*Full Payout.
                                                                                    </td>
                                                                                <?php endif;?>
                                                                            </tr>
                                                                        <?php endforeach;?>
                                                                    </tbody>
                                                                </table>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                      <!-- End Modal -->
                                </td>
                                
                                <td>
                                        <?php if($item['apply_status']==1):?>
                                          <span class="label label-table label-success"><?php echo $apply_status[$item['apply_status']]?></span>
                                        <?php elseif($item['apply_status']==-10):?>
                                          <span class="label label-table label-primary"><?php echo $apply_status[$item['apply_status']]?></span>
                                        <?php elseif($item['apply_status']==0):?>
                                          <span class="label label-table label-danger"><?php echo $apply_status[$item['apply_status']]?></span>
                                        <?php elseif($item['apply_status']==-1):?>
                                          <span class="label label-dark"><?php echo $apply_status[$item['apply_status']]?></span>
                                        <?php endif;?>
                                </td>
                            </tr>
                        <?php endforeach?>
                        <?php else:?>
                            <tr>
                                <td colspan="5">
                                    <div class="panel margin-bottom-0 height-500">
                                        <div class="text-center padding-top-80">
                                            <img src="<?php echo base_url();?>assets/images/no_data.png">
                                            <h4 class="margin-top-30">NO DATA HERE</h4>
                                            <p style="line-height: 18px;">I hate peeping Toms. For one thing they usually step all over<br>the hedges and plants on the side of someone's house killing</p>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endif;?>
                    </tbody>
                </table>
                
            </div>
        </div>


    </div>
</div>
<script type="text/javascript">
</script>

<script src="<?php echo base_url();?>assets/web/global/js/plugins/selectable.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/components/selectable.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/icheck/icheck.min.js"></script>

<script src="<?php echo base_url();?>assets/web/global/js/components/icheck.js"></script>

<script src="<?php echo base_url();?>assets/web/global/vendor/bootstrap-select/bootstrap-select.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/select2/select2.min.js"></script>
    
<script src="<?php echo base_url();?>assets/web/global/js/components/bootstrap-select.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/components/select2.js"></script>
<script src="<?php echo base_url();?>assets/js/index_select.js"></script>



