
<div class="page animsition">
    <div class="page-header">
        <ol class="breadcrumb">
            <li><a href="<?php echo site_url('manager/product/listview') ?>">Manager Management</a></li>
            <li><a href="<?php echo site_url('manager/setting/daily') ?>">Daily</a></li>
            <li class="active">Index</li>
        </ol>
    </div>
    <div class="page-content padding-30 blue-grey-500 padding-top-0">
        <div class="nav-tabs-horizontal">
            <div class="tab-content widget-border">
                <div class="tab-pane active" id="exampleTabsOne" role="tabpanel">
                    <div class="panel margin-bottom-0">
                        <header class="panel-heading margin-bottom-0 clearfix">
                            <h3 class="panel-title pull-left">Details</h3>
                            
                        </header>
                        <div class="panel-body table-responsive">
                            <table class="table dataTable table-striped width-full" id="facebook_report"
                                   data-selectable="selectable" data-row-selectable="true">
                                <thead class="change_thead">
                                <tr>
                                    <th style="width: 15%">Date</th>
                                    <th style="width: 15%">Link</th>
                                </tr>
                                </thead>
                                <tbody>
                                    <?php foreach($list as $key=>$val):?>
                                    <tr>
                                        
                                        <td><?php echo $key?></td>
                                        <td><a target="_blank" href="<?php echo $val?>"><?php echo $val?></a></td>
                                    </tr>
                                    <?php endforeach;?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="tab-pane panel margin-bottom-0 height-200" id="exampleTabsTwo" role="tabpanel"></div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="add_bills" aria-hidden="false" aria-labelledby="add_bucket_Label" role="dialog"
         tabindex="-1" style="display: none;">
        <div class="modal-dialog">
            <form class="modal-content" autocomplete="off" method="post" id="add_advertiser"
                  action="<?php echo site_url('manager/setting/add_bills_extend'); ?>">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                    <h4 class="modal-title" id="add_bucket_Label">Add Adjust</h4>
                </div>
                <input type="hidden" name="data[user_id][]" class="input_manager" value="">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-lg-12 form-group ">
                            <label class="control-label" for="first_name">
                                Type
                                <span class="required">*</span>
                            </label>
                            <div class="radio-custom radio-primary">
                                <input type="radio" name="data[user_type]" id="advertiser" value="1" checked>
                                <label for="advertiser" style="margin-right: 40px;">Advertiser</label>
                                <input type="radio" name="data[user_type]" id="publisher" value="2">
                                <label for="publisher">Publisher</label>
                            </div>
                        </div>
                        <div class="col-lg-12 form-group ">
                            <label class="control-label">
                                User ID
                                <span class="required">*</span>
                            </label>
                            <div class="form-group filter-form bills-filter">
                                <div class="diy_select">
                                    <!--【存】当前选中的值-->
                                    <input type="hidden" name="data[user_id]" class="diy_select_input filter_publisher"
                                           value="">
                                    <!--【显示】当前选中的值-->
                                    <input type="text" class="diy_select_txt filter_input_1" placeholder="Nothing selected"
                                           value="">
                                    <!--下拉三角形-->
                                    <span class="caret"
                                          style="right: 14px;position: absolute;top: 50%;margin-top: -2px;"></span>
                                    <!--数据列表-->
                                    <ul class="diy_select_list" style="display:none;" id="radiao_box_1">
                                        <?php if ($users): ?>
                                            <?php foreach ($users as $user): ?>
                                                <li data-key="<?php echo $user['user_id']; ?>">
                                                    <span><?php echo $user['user_id']; ?>(<?php echo $user['user_name']; ?>)</span>
                                                    <b class="icon wb-check check-mark"></b>
                                                </li>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12 form-group ">
                            <label class="control-label" for="first_name">
                                Date
                                <span class="required">*</span>
                            </label>
                            <input type="text" class="form-control" id="date" name="data[extend_date]" placeholder="" autocomplete="off">
                        </div>

                        <div class="col-lg-12 form-group ">
                            <label class="control-label" for="email">
                                Adjust Type
                                <span class="required">*</span>
                            </label>
                            <div class="radio-custom radio-primary">
                                <input type="radio" name="data[money_type]" id="money_type_1" value="1" checked>
                                <label for="money_type_1" style="margin-right: 40px;">扣罚</label>
                                <input type="radio" name="data[money_type]" id="money_type_2" value="2">
                                <label for="money_type_2">奖励</label>
                            </div>
                        </div>
                        <div class="col-lg-12 form-group ">
                            <label class="control-label" for="first_name">
                                Money
                                <span class="required">*</span>
                            </label>
                            <input type="text" class="form-control" id="first_name" name="data[money]" placeholder=""
                                   autocomplete="off">
                        </div>

                        <div class="col-lg-12 form-group">
                            <label class="control-label" for="first_name">
                                Reason
                                <span class="required">*</span>
                            </label>
                            <textarea cols="5" class="form-control" name="data[reason]"></textarea>
                        </div>

                        <div class="col-lg-12 form-group ">
                            <button type="submit" class="btn btn-primary" id="add_advertiser_button">Submit</button>
                        </div>

                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
