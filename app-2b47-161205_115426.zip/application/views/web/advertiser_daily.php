<!DOCTYPE html>
<html class="no-js css-menubar" lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
<meta name="description" content="bootstrap admin template">
<meta name="author" content="">
<title><?php echo $advertiser_info?$advertiser_info['user_name']:'Unkown'." Daily Reports"?></title>
<link rel="apple-touch-icon" href="<?php echo base_url();?>assets/web/assets/images/apple-touch-icon.png">
<link rel="shortcut icon" href="<?php echo base_url();?>assets/web/assets/images/favicon.ico">
<!-- Stylesheets -->
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/css/bootstrap-extend.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/assets/css/site.min.css">
<!-- Plugins -->
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/animsition/animsition.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/asscrollable/asScrollable.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/switchery/switchery.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/intro-js/introjs.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/slidepanel/slidePanel.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/flag-icon-css/flag-icon.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/advertiser_daily.css">
<!-- 新加css -->
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/datatables-bootstrap/dataTables.bootstrap.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/datatables-fixedheader/dataTables.fixedHeader.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/datatables-responsive/dataTables.responsive.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/assets/examples/css/tables/datatable.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/fonts/font-awesome/font-awesome.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/select2/select2.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/bootstrap-datepicker/bootstrap-datepicker.css">
<link href="<?php echo base_url();?>assets/css/video-js.css" rel="stylesheet"> 
<!-- Fonts -->
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/fonts/web-icons/web-icons.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/fonts/brand-icons/brand-icons.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/fonts/web-icons/web-icons.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/fonts/font-awesome/font-awesome.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/fonts/brand-icons/brand-icons.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/fonts/brand-icons/brand-icons.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/fonts/google/fonts.css">

<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/global/vendor/owl-carousel/owl.carousel.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/global/vendor/slick-carousel/slick.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/assets/examples/css/uikit/carousel.css">


<style>
    .table-bordered>thead:first-child>tr:first-child>th{border: 0;}
    .table>tbody>tr>td{vertical-align: middle; border-top: 0;}
    .table-striped>tbody>tr:nth-of-type(odd){
        background-color: rgba(247,252,255,1);
    }
    .special_table>tbody>tr>td{
        padding: 0;
    }
    .video-js .vjs-big-play-button{
            font-size: 40px;
            line-height: 50px;
            height: 50px;
            width: 50px;
            margin-left: -25px;
            margin-top: -25px;
            border-radius: 50%;
            position: absolute;
            left: 50%;
            top: 50%;
            background: #c73434;
            border: none;
    }
    .video-js:hover .vjs-big-play-button{background-color: #b90606;}
    .overlay figcaption .btn {
        margin-left: 4px;
    }

</style>
<!--[if lt IE 9]>
  <script src="<?php echo base_url();?>assets/web/global/vendor/html5shiv/html5shiv.min.js"></script>
  <![endif]-->
<!--[if lt IE 10]>
  <script src="<?php echo base_url();?>assets/web/global/vendor/media-match/media.match.min.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/respond/respond.min.js"></script>
  <![endif]-->
<!-- Scripts -->
<script src="<?php echo base_url();?>assets/web/global/vendor/modernizr/modernizr.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/breakpoints/breakpoints.js"></script>
<script>
Breakpoints();
</script>
</head>
<body class="site-navbar-small padding-top-0">
<!--[if lt IE 8]>
    <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
<![endif]-->
<div style="height:200px; background:#26bfd6; width:100%; overflow:hidden;">
    <div style="width:74%; height:110px; margin:52px auto 0;position: relative;">
        <h3 class="margin-top-0" style="font-size:40px;color:#fff;"><?php echo $advertiser_info?$advertiser_info['user_name']:'Unkown'?></h3>
        <p style="color: #fff;font-size: 92px;font-weight: bold; opacity: 0.1;position: absolute;left: 42px;top: -15px;letter-spacing: 6px;">DAILY</p>
        <p class="text-center" style="position: absolute;right:0;bottom:0;">
            <span class="block" style="color:#fff;">海外推广管理日报</span>
            <a href="#" class="block" style="color:#fff;text-decoration:none;">&copy; PALMAX LIMITED</a>
        </p>
    </div>
</div>
<div style="height:84px; background:#004753; width:100%; overflow:hidden;">
    <div style="width:74%; margin:0 auto;">
        <p class="pull-right margin-0 padding-right-10" style="color:#fff; line-height:84px;"><?php echo date('M d Y', $current_date)?></p>
        <!-- <div class="filter">
            <div class="dropdown pull-right" style="line-height: 84px;">
                <button type="button" id="input_date" class="btn btn-pure" style="color:#fff;">
                    <?php //echo date('M d Y', $current_date)?>
                    <span class="icon wb-chevron-down-mini" aria-hidden="true"></span>
                </button>
            </div>
        </div> -->
    </div>
</div>
<!-- Page -->
<div class="page animsition">
    <div class="page-content padding-top-0"> 
        <div class="panel">
            <div class="panel-body container-fluid" style=" padding-bottom: 0; padding-top:66px;">
                <div class="row">
                    <!-- 第一个表格 -->
                    <div class="col-md-12">
                        <h4 class="example-title margin-bottom-0" style="padding-left:66px; font-size:24px;">1.推广渠道</h4>
                        <div class="col-md-10 col-md-offset-1">
                            <div class="example-wrap"> 
                                <div class="example table-responsive" style="box-shadow:0 3px 8px 0 #f1f6f7; margin-bottom:50px;">
                                    <table class="table text-center dataTable width-full " id="facebook_report">
                                        <thead class="thead" id="thead">
                                            <tr style="background:#00b1c9;">
                                                <th class="text-center" style="color:#fff;">Agency Name</th>
                                                <th class="text-center" style="color:#fff;">Ad Accounts</th>
                                            </tr>
                                        </thead>
                                        <tbody class="tbody">
                                            <?php foreach($data1 as $agency=>$item):?>
                                                <tr>
                                                    <td rowspan="<?php echo count($item)?>" style="background:#f7fcff;"><?php echo $agency?></td>
                                                    <td style="background:#f7fcff;"><?php echo $item[0]['account_id'].' - '.$item[0]['account_name']?></td>
                                                </tr>
                                                <?php foreach($item as $key=>$val):?>
                                                    <?php if($key>0):?>
                                                        <tr>
                                                            <td style="background:#f7fcff;"><?php echo $val['account_id'].' - '.$val['account_name']?></td>
                                                        </tr>
                                                    <?php endif;?>
                                                <?php endforeach;?>
                                            <?php endforeach;?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- 第二个表格 -->
                    <div class="col-md-12">
                        <h4 class="example-title margin-bottom-0" style="padding-left:66px; font-size:24px;">2.推广任务</h4>
                        <div class="col-md-10 col-md-offset-1">
                            <div class="example-wrap" style="margin-bottom:50px;"> 
                                <div class="example table-responsive margin-bottom-10" style="box-shadow:0 3px 8px 0 #f1f6f7;">
                                    <table class="table text-center dataTable width-full " id="facebook_report">
                                        <thead class="thead" id="thead">
                                            <tr style="background:#00b1c9;">
                                                <th class="text-center" style="color:#fff;">Product</th>
                                                <th class="text-center" style="color:#fff;">Geo</th>
                                                <th class="text-center" style="color:#fff;">CPI</th>
                                                <th class="text-center" style="color:#fff;">Status</th>
                                            </tr>
                                        </thead>
                                        <tbody class="tbody">
                                            <?php foreach($data2 as $item):?>
                                                <?php 
                                                    if (!isset($item['country'])) {
                                                        continue;
                                                    }
                                                ?>
                                                <tr>
                                                    <td rowspan="<?php echo count($item['country'])?>" style="background:#f7fcff;"><?php echo $item['product_name']=='Kika Pro US'?"Kika Pro":$item['product_name']?></td>
                                                    <td style="background:#f7fcff;"><?php echo $item['country'][0]['name']?></td>
                                                    <td style="background:#f7fcff;"><?php echo $item['country'][0]['cpa']?'$'.$item['country'][0]['cpa']:'-'?></td>
                                                    <td style="background:#f7fcff;">
                                                        <?php if(is_numeric($item['country'][0]['results'])):?>
                                                            <button type="button" class="btn btn-icon tooltip-success btn-success btn-round font-size-12" style="padding:2px;">
                                                                <i class="icon fa-check" aria-hidden="true"></i>
                                                            </button>
                                                        <?php else:?>
                                                            <button type="button" class="btn btn-icon tooltip-danger btn-danger btn-round font-size-12" style="padding:2px;">
                                                                <i class="icon fa-close" aria-hidden="true"></i>
                                                            </button>
                                                        <?php endif;?>
                                                    </td>
                                                </tr>
                                                <?php foreach($item['country'] as $key=>$val):?>
                                                    <?php if($key>0):?>
                                                    <tr>
                                                        <td><?php echo $val['name']?></td>
                                                        <td><?php echo $val['cpa']?'$'.$val['cpa']:'-'?></td>
                                                        <td>
                                                            <?php if(is_numeric($val['results'])):?>
                                                                <button type="button" class="btn btn-icon tooltip-success btn-success btn-round font-size-12" style="padding:2px;">
                                                                    <i class="icon fa-check" aria-hidden="true"></i>
                                                                </button>
                                                            <?php else:?>
                                                                <button type="button" class="btn btn-icon tooltip-danger btn-danger btn-round font-size-12" style="padding:2px;">
                                                                    <i class="icon fa-close" aria-hidden="true"></i>
                                                                </button>
                                                            <?php endif;?>
                                                        </td>
                                                    </tr>
                                                    <?php endif;?>
                                                <?php endforeach;?>
                                            <?php endforeach;?>
                                            
                                        </tbody>
                                    </table>                                   
                                </div>
                                <div class="pull-right">
                                    <p class="inline margin-right-15"> 
                                        <button type="button" class="btn btn-icon tooltip-danger btn-success btn-round font-size-12" style="padding:2px;">
                                            <i class="icon fa-check" aria-hidden="true"></i>
                                        </button>
                                        在推广
                                    </p>
                                    <p class="inline"> 
                                        <button type="button" class="btn btn-icon tooltip-danger btn-danger btn-round font-size-12" style="padding:2px;">
                                            <i class="icon fa-close" aria-hidden="true"></i>
                                        </button>
                                        未推广
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- 第三个表格 -->
                    <div class="col-md-12">
                        <h4 class="example-title margin-bottom-0" style="padding-left:66px; font-size:24px;">3.基础数据</h4>

                        <div class="col-md-10 col-md-offset-1 margin-bottom-10">
                            <h4 class="margin-bottom-10 margin-top-15">①每日转化数据</h4>
                            <p class="text-center font-size-12" style="width:200px;height:46px;background:#005f6b;padding-top:4px;color:#fff;margin-bottom: -61px;margin-left: 59px;"><?php echo date('d/m', $current_7date)?> - <?php echo date('d/m',$current_date)?><br/>转化总量走势图</p>
                            <div id="broken_line" style="height:350px;" data-date='<?php echo json_encode($data3_date);?>' data-results='<?php echo json_encode($data3_results);?>'></div>
                        </div>
                        <div class="col-md-10 col-md-offset-1">
                            <div class="example-wrap" style="margin-bottom:50px;"> 
                                <h4 class="example-title font-size-12" style="padding-left:40px;">7日转化详情</h4>
                                <div class="example table-responsive margin-bottom-10" style="box-shadow:0 3px 8px 0 #f1f6f7;">
                                    <table class="table text-center dataTable table-striped width-full ">
                                        <thead class="thead" id="thead">
                                            <tr style="background:#00b1c9;">
                                                <?php foreach($data3_date as $date):?>
                                                    <th class="text-center" style="color:#fff;"><?php echo $date?></th>
                                                <?php endforeach;?>
                                            </tr>
                                        </thead>
                                        <tbody class="tbody">
                                            <tr>
                                                <?php foreach($data3_results as $results):?>
                                                    <td><?php echo $results?></td>
                                                <?php endforeach;?>
                                            </tr>
                                        </tbody>
                                    </table>                                   
                                </div>
                            </div>
                        </div>
                    </div>

                    

                    <div class="col-md-12">
                        <div class="col-md-10 col-md-offset-1 margin-bottom-10">
                            <h4 class="margin-bottom-10 margin-top-15">②分渠道转化数据</h4>
                            <p class="text-center font-size-12" style="width:200px;height:46px;background:#005f6b;padding-top:4px;color:#fff;margin-bottom: -61px;margin-left: 59px;"><?php echo date('d/m', $current_7date)?> - <?php echo date('d/m',$current_date)?><br/>渠道转化走势图</p>
                            <div id="two_broken_line" style="height:350px;" data-date='<?php echo json_encode($data4_date)?>' data-results='<?php echo json_encode($data4_results)?>'></div>
                        </div>
                        <div class="col-md-10 col-md-offset-1">
                            <div class="example-wrap" style="margin-bottom:50px;"> 
                                <h4 class="example-title font-size-12" style="padding-left:40px;">渠道转化详情</h4>
                                <div class="example table-responsive margin-bottom-10" style="box-shadow:0 3px 8px 0 #f1f6f7;">
                                    <table class="table text-center dataTable table-striped width-full " id="facebook_report">
                                        <thead class="thead" id="thead">
                                            <tr style="background:#00b1c9;">
                                                <th class="text-center" style="color:#fff;">Date</th>
                                                <th class="text-center" style="color:#fff;">Agency</th>
                                                <th class="text-center" style="color:#fff;">Results</th>
                                            </tr>
                                        </thead>
                                        <tbody class="tbody">
                                            <?php foreach($data4 as $item):?>
                                                <tr>
                                                    <td><?php echo date('d/m', $item['date'])?></td>
                                                    <td><?php echo $item['publisher_name']?></td>
                                                    <td><?php echo number_format($item['results'])?></td>
                                                </tr>
                                            <?php endforeach;?>
                                        </tbody>
                                    </table>                                   
                                </div>
                            </div>
                        </div>
                    </div>


                    <div class="col-md-12">
                        <div class="col-md-10 col-md-offset-1 margin-bottom-10">
                            <h4 class="margin-bottom-10 margin-top-15">③分产品转化数据</h4>
                            <p class="text-center font-size-12" style="width:200px;height:46px;background:#005f6b;padding-top:4px;color:#fff;margin-bottom: -61px;margin-left: 59px;"><?php echo date('d/m', $current_7date)?> - <?php echo date('d/m',$current_date)?><br/>产品转化走势图</p>
                            <div id="product_two_broken_line" style="height:350px;" data-date='<?php echo json_encode($data5_date)?>' data-results='<?php echo json_encode($data5_results)?>'></div>
                        </div>
                        <div class="col-md-10 col-md-offset-1">
                            <div class="example-wrap" style="margin-bottom:50px;"> 
                                <h4 class="example-title font-size-12" style="padding-left:40px;">产品转化详情</h4>
                                <div class="example table-responsive margin-bottom-10" style="box-shadow:0 3px 8px 0 #f1f6f7;">
                                    <table class="table text-center dataTable table-striped width-full " id="facebook_report">
                                        <thead class="thead" id="thead">
                                            <tr style="background:#00b1c9;">
                                                <th class="text-center" style="color:#fff;">Date</th>
                                                <th class="text-center" style="color:#fff;">Product</th>
                                                <th class="text-center" style="color:#fff;">Results</th>
                                            </tr>
                                        </thead>
                                        <tbody class="tbody">
                                            <?php foreach($data5 as $item):?>
                                                <tr>
                                                    <td><?php echo date('d/m', $item['date'])?></td>
                                                    <td><?php echo $item['product_name']?></td>
                                                    <td><?php echo number_format($item['results'])?></td>
                                                </tr>
                                            <?php endforeach;?>
                                        </tbody>
                                    </table>                                   
                                </div>
                            </div>
                        </div>
                    </div>


                    <div class="col-md-12">
                        <div class="col-md-10 col-md-offset-1">
                            <div class="example-wrap" style="margin-bottom:50px;"> 
                                <h4 class="margin-bottom-10 margin-top-15">④分账户转化数据(<?php echo date('d/m',$current_date)?>)</h4>
                                <div class="example table-responsive margin-bottom-10" style="box-shadow:0 3px 8px 0 #f1f6f7;">
                                    <table class="table text-center dataTable table-striped width-full ">
                                        <thead class="thead" id="thead">
                                            <tr style="background:#00b1c9;">
                                                <th class="text-center" style="color:#fff;">Agency</th>
                                                <th class="text-center" style="color:#fff;">Product</th>
                                                <th class="text-center" style="color:#fff;">Account</th>
                                                <th class="text-center" style="color:#fff;">Results</th>
                                            </tr>
                                        </thead>
                                        <tbody class="tbody">
                                            <?php foreach($data6 as $item):?>
                                                <tr>
                                                    <td><?php echo $item['publisher_name']?></td>
                                                    <td><?php echo $item['product_name']?></td>
                                                    <td><?php echo $item['account_id'].' - '.$item['account_name']?></td>
                                                    <td><?php echo number_format($item['results'])?></td>
                                                </tr>
                                            <?php endforeach;?>
                                        </tbody>
                                    </table>                                   
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- 每行两个图型 -->
                    <div class="col-md-12">
                        <div class="clearfix col-md-10 col-md-offset-1 margin-bottom-15">
                            <form class="pull-right">
                                <div class="form-group col-md-12 filter-form advertiser-filter margin-bottom-25 padding-horizontal-0 margin-top-15">
                                        <select class="form-control select2-hidden-accessible filter_agency" data-plugin="select2" tabindex="-1" aria-hidden="true" data-placeholder="Publisher Filter" data-date="<?php echo $current_7date?>" data-publisher="<?php echo $publisher_id?>">
                                            <option value="0">ALL</option>
                                            <?php foreach($agency_list as $item):?>
                                            <option value="<?php echo $item['publisher_id']?>" ><?php echo $item['publisher_name']?></option>
                                            <?php endforeach;?>
                                        </select>
                                    </div>
                            </form>
                        </div>
                        <div class="row">
                            <div class="col-md-5 col-md-offset-1 margin-bottom-10">
                                <p class="text-center font-size-12" style="width:200px;height:46px;background:#550054;padding-top:4px;color:#fff;margin-bottom: -61px;margin-left: 59px;">CTR<span class="block" style="height:2px;width:40px; margin:10px auto 0; background:#f72c6a;"></span></p>
                                <div id="broken_line_left" style="height:350px;" data-date='<?php echo json_encode($data7_date)?>' data-results='<?php echo json_encode($data7_ctr_results)?>'></div>
                            </div>
                            <div class="col-md-5 margin-bottom-10">
                                <p class="text-center font-size-12" style="width:200px;height:46px;background:#005f6b;padding-top:4px;color:#fff;margin-bottom: -61px;margin-left: 59px;">CVR<span class="block" style="height:2px;width:40px; margin:10px auto 0; background:#f72c6a;"></span></p>
                                <div id="broken_line_right" style="height:350px;" data-date='<?php echo json_encode($data7_date)?>' data-results='<?php echo json_encode($data7_cvr_results)?>'></div>
                            </div>
                        </div>
                    </div>

                    <!-- 每行两个图表 -->
                    <div class="col-md-12">
                        <div class="col-md-10 col-md-offset-1">
                            <div class="example-wrap" style="margin-bottom:50px;"> 
                                <h4 class="example-title font-size-12" style="padding-left:40px;">渠道及产品转化率</h4>
                                <div class="example table-responsive margin-bottom-10" style="box-shadow:0 3px 8px 0 #f1f6f7;">
                                    <table class="table text-center dataTable table-striped width-full " id="facebook_report">
                                        <thead class="thead" id="thead">
                                            <tr style="background:#00b1c9;">
                                                <th class="text-center" style="color:#fff;">Agency</th>
                                                <th class="text-center" style="color:#fff;">Product</th>
                                                <th class="text-center" style="color:#fff;">Impressions</th>
                                                <th class="text-center" style="color:#fff;">Clicks</th>
                                                <th class="text-center" style="color:#fff;">Results</th>
                                                <th class="text-center" style="color:#fff;">CTR</th>
                                                <th class="text-center" style="color:#fff;">CVR</th>
                                            </tr>
                                        </thead>
                                        <tbody class="tbody">
                                            <?php foreach($data7 as $item):?>
                                                <tr>
                                                    <td><?php echo $item['publisher_name']?></td>
                                                    <td><?php echo $item['product_name']?></td>
                                                    <td><?php echo number_format($item['impressions'])?></td>
                                                    <td><?php echo number_format($item['clicks'])?></td>
                                                    <td><?php echo number_format($item['results'])?></td>
                                                    <td><?php echo sprintf("%.2f", $item['clicks']/$item['impressions']*100)?>%</td>
                                                    <td><?php echo sprintf("%.2f", $item['results']/$item['clicks']*100)?>%</td>
                                                </tr>
                                            <?php endforeach;?>
                                        </tbody>
                                    </table>                                   
                                </div>
                            </div>
                        </div>
                        
                    </div>
                    


                    <!-- 第四块 -->

                    <div class="col-md-12">
                        <h4 class="example-title margin-bottom-0" style="padding-left:66px; font-size:24px;">4.投放监控</h4>
                        <div class="col-md-10 col-md-offset-1 margin-bottom-10">
                            <h4 class="margin-bottom-10 margin-top-15">①七日广告数量趋势</h4>
                            <p class="text-center font-size-12" style="width:200px;height:46px;background:#005f6b;padding-top:4px;color:#fff;margin-bottom: -61px;margin-left: 59px;"><?php echo date('d/m', $current_7date)?> - <?php echo date('d/m',$current_date)?><br/>七日广告数量趋势</p>
                            <div id="ad_chart" style="height:350px;" data-date='<?php echo json_encode($data8_date);?>' data-results='<?php echo json_encode($data8);?>'></div>
                        </div>
                    </div> 

                    <div class="col-md-12">
                        <div class="col-md-10 col-md-offset-1 margin-bottom-10">
                            <h4 class="margin-bottom-10 margin-top-15">②七日各渠道广告数量</h4>
                            <p class="text-center font-size-12" style="width:200px;height:46px;background:#005f6b;padding-top:4px;color:#fff;margin-bottom: -61px;margin-left: 59px;"><?php echo date('d/m', $current_7date)?> - <?php echo date('d/m',$current_date)?><br/>七日各渠道广告数量</p>
                            <div id="ad_agency_chart" style="height:350px;" data-date='<?php echo json_encode($data9_date);?>' data-results='<?php echo json_encode($data9);?>'></div>
                        </div>
                    </div> 

                    <div class="col-md-12">
                        <div class="col-md-10 col-md-offset-1 margin-bottom-10">
                            <h4 class="margin-bottom-10 margin-top-15">③七日各产品广告数量</h4>
                            <p class="text-center font-size-12" style="width:200px;height:46px;background:#005f6b;padding-top:4px;color:#fff;margin-bottom: -61px;margin-left: 59px;"><?php echo date('d/m', $current_7date)?> - <?php echo date('d/m',$current_date)?><br/>七日各产品广告数量</p>
                            <div id="ad_product_chart" style="height:350px;" data-date='<?php echo json_encode($data10_date);?>' data-results='<?php echo json_encode($data10);?>'></div>
                        </div>
                    </div>  


                    <div class="col-md-12">
                        <div class="col-md-10 col-md-offset-1">
                            <div class="example-wrap" style="margin-bottom:50px;"> 
                                <h4 class="example-title margin-top-10">④各渠道主要广告内容（<?php echo date('d/m',$current_date)?>）</h4>
                                <div class="example table-responsive margin-bottom-10" style="box-shadow:0 3px 8px 0 #f1f6f7;">
                                    <table class="table text-center dataTable width-full " id="facebook_report">
                                        <thead class="thead" id="thead">
                                            <tr style="background:#00b1c9;">
                                                <th class="text-center" style="color:#fff;">Agency</th>
                                                <th class="text-center" style="color:#fff;">Account ID</th>
                                                <th class="text-center" style="color:#fff;">Campaign Name</th>
                                                <th class="text-center" style="color:#fff;">Adset Name</th>
                                                <th class="text-center" style="color:#fff;">Ad Name</th>
                                                <th class="text-center" style="color:#fff;">Results</th>
                                            </tr>
                                        </thead>
                                        <tbody class="tbody">
                                            <?php foreach($data11 as $agency=>$data):?>
                                                <?php $data = array_values($data);?>
                                                <tr>
                                                    <td rowspan="<?php echo count($data)?>" style="background:#f7fcff;"><?php echo $agency?></td>
                                                    <td><?php echo $data[0]['account_id']?></td>
                                                    <td><?php echo $data[0]['campaign_name']?></td>
                                                    <td><?php echo $data[0]['adset_name']?></td>
                                                    <td><?php echo $data[0]['ad_name']?></td>
                                                    <td><?php echo number_format($data[0]['results'])?></td>
                                                </tr>
                                                <?php foreach($data as $k=>$v):?>
                                                    <?php if($k>0):?>
                                                        <tr>
                                                            <td><?php echo $v['account_id']?></td>
                                                            <td><?php echo $v['campaign_name']?></td>
                                                            <td><?php echo $v['adset_name']?></td>
                                                            <td><?php echo $v['ad_name']?></td>
                                                            <td><?php echo number_format($v['results'])?></td>
                                                        </tr>
                                                    <?php endif;?>
                                                <?php endforeach;?>
                                            <?php endforeach;?>
                                        </tbody>
                                    </table>                                   
                                </div>
                            </div>
                        </div>
                    </div>    

                    <div class="col-md-10 col-md-offset-1 margin-bottom-30">
                        <ul class="blocks blocks-100 blocks-xlg-2 blocks-lg-2 blocks-md-2 blocks-sm-1" id="click_btn" data-plugin="masonry" data-plugin="animateList" data-child=">li">
                            <?php foreach($data11 as $value):foreach($value as $item):?>
                                <li class="masonry-item padding-horizontal-40">
                                    <div class="padding-top-20 row" style="box-shadow:1px 2px 8px 0 #f1f6f7;">
                                        <div class="clearfix padding-horizontal-15">
                                            <?php if($item['object_type']=='SHARE' || $item['object_type']=='MORE_SHARE'):?>
                                                <div class="pull-left review-cover-images margin-right-15">
                                                    <img class="cover-image" src="<?php echo $item['org_image_url']?>" alt="" onerror="javascript:this.src='<?php echo $item['image_url']?>'">
                                                </div>
                                            <?php else:?>
                                                <div class="pull-left review-cover-images margin-right-15">
                                                    <video id="my-video" class="video-js" controls preload="auto" height="155"
                                                      poster="<?php echo $item['org_image_url']?>" data-setup="{}">
                                                        <source src="<?php echo $item['video_url']?>" type='video/mp4'>
                                                        <p class="vjs-no-js">
                                                          To view this video please enable JavaScript, and consider upgrading to a web browser that
                                                          <a href="http://videojs.com/html5-video-support/" target="_blank">supports HTML5 video</a>
                                                        </p>
                                                    </video>
                                                </div>
                                            <?php endif;?>
                                            <div class="pull-left width_device">
                                                <p class="margin-bottom-0" style="height:25px;line-height:25px;overflow:hidden;" title="<?php echo $item['ad_name']?>"><span class="font-size-16 margin-right-10">Ad Name:</span><?php echo $item['ad_name']?></p>
                                                <h3 class="font-size-14 margin-0" style="height:16px;line-height:16px;overflow:hidden;" title="<?php echo $item['title']?>"><?php echo $item['title']?></h3>
                                                <p class="margin-bottom-0" style="line-height: 18px;height:36px;overflow:hidden;" title="<?php echo $item['message']?>"><?php echo $item['message']?></p>
                                                <p class="pull-right margin-bottom-0">
                                                    <a target="_blank" href="https://translate.google.co.jp/?hl=en&tab=wT#auto/zh-CN/<?php echo $item['title']."%0A".$item['message']?>" class="margin-left-10" style="color:#ffa8b3;">See translate</a>
                                                </p>
                                            </div>
                                        </div>
                                        <div class="col-md-12 margin-vertical-20">
                                            <table  class="font-size-16 table text-center dataTable width-full special_table" id="facebook_report">
                                                <tbody>
                                                    <tr>
                                                        <td><?php echo number_format($item['results'])?></td>
                                                        <td><?php echo number_format($item['impressions'])?></td>
                                                        <td><?php echo number_format($item['clicks'])?></td>
                                                        <td><?php echo $item['impressions']?sprintf("%.2f",$item['clicks']/$item['impressions']*100):0?>%</td>
                                                        <td><?php echo $item['clicks']?sprintf("%.2f",$item['results']/$item['clicks']*100):0?>%</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Results</td>
                                                        <td>Impressions</td>
                                                        <td>Clicks</td>
                                                        <td>CTR</td>
                                                        <td>CVR</td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </li>
                            <?php endforeach;?>
                            <?php endforeach;?>

                        </ul>
                    </div>

                    <!-- 饼状图 -->
                    <div class="col-md-12">
                        <h4 class="example-title margin-bottom-10" style="padding-left:66px; font-size:24px;">5.用户画像</h4>
                        <div class="col-md-4 col-md-offset-1 margin-bottom-10">
                            <div id="gender_chart" style="height:300px;" data-results='<?php echo json_encode($data12_chart)?>'></div>
                        </div>
                        <div class="col-md-6">
                            <div class="example-wrap" style="margin-bottom:50px;"> 
                                <div class="example table-responsive margin-bottom-10" style="box-shadow:0 3px 8px 0 #f1f6f7;">
                                    <table class="table text-center dataTable table-striped width-full " id="facebook_report">
                                        <thead class="thead" id="thead">
                                            <tr style="background:#00b1c9;">
                                                <th class="text-center" style="color:#fff;">Gender</th>
                                                <th class="text-center" style="color:#fff;">Impressions</th>
                                                <th class="text-center" style="color:#fff;">Clicks</th>
                                                <th class="text-center" style="color:#fff;">Results</th>
                                                <th class="text-center" style="color:#fff;">CTR</th>
                                                <th class="text-center" style="color:#fff;">CVR</th>
                                            </tr>
                                        </thead>
                                        <tbody class="tbody">
                                            <?php foreach($data12 as $item):?>
                                                <tr>
                                                    <td><?php echo ucwords($item['gender'])?></td>
                                                    <td><?php echo number_format($item['impressions'])?></td>
                                                    <td><?php echo number_format($item['clicks'])?></td>
                                                    <td><?php echo number_format($item['results'])?></td>
                                                    <td><?php echo $item['impressions']?sprintf("%.2f",$item['clicks']/$item['impressions']*100):0?>%</td>
                                                    <td><?php echo $item['clicks']?sprintf("%.2f",$item['results']/$item['clicks']*100):0?>%</td>
                                                </tr>
                                            <?php endforeach;?>
                                        </tbody>
                                    </table>                                   
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-12">
                        <div class="col-md-4 col-md-offset-1 margin-bottom-10">
                            <div id="age_chart" style="height:300px;" data-results='<?php echo json_encode($data13_chart)?>'></div>
                        </div>
                        <div class="col-md-6">
                            <div class="example-wrap" style="margin-bottom:50px;"> 
                                <div class="example table-responsive margin-bottom-10" style="box-shadow:0 3px 8px 0 #f1f6f7;">
                                    <table class="table text-center dataTable table-striped width-full " id="facebook_report">
                                        <thead class="thead" id="thead">
                                            <tr style="background:#00b1c9;">
                                                <th class="text-center" style="color:#fff;">Age</th>
                                                <th class="text-center" style="color:#fff;">Impressions</th>
                                                <th class="text-center" style="color:#fff;">Clicks</th>
                                                <th class="text-center" style="color:#fff;">Results</th>
                                                <th class="text-center" style="color:#fff;">CTR</th>
                                                <th class="text-center" style="color:#fff;">CVR</th>
                                            </tr>
                                        </thead>
                                        <tbody class="tbody">
                                            <?php foreach($data13 as $item):?>
                                                <tr>
                                                    <td><?php echo $item['age']?></td>
                                                    <td><?php echo number_format($item['impressions'])?></td>
                                                    <td><?php echo number_format($item['clicks'])?></td>
                                                    <td><?php echo number_format($item['results'])?></td>
                                                    <td><?php echo $item['impressions']?sprintf("%.2f",$item['clicks']/$item['impressions']*100):0?>%</td>
                                                    <td><?php echo $item['clicks']?sprintf("%.2f",$item['results']/$item['clicks']*100):0?>%</td>
                                                </tr>
                                            <?php endforeach;?>
                                        </tbody>
                                    </table>                                   
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-12">
                        <div class="col-md-4 col-md-offset-1 margin-bottom-10">
                            <div id="placement_chart" style="height:300px;" data-results='<?php echo json_encode($data14_chart)?>'></div>
                        </div>
                        <div class="col-md-6">
                            <div class="example-wrap" style="margin-bottom:50px;"> 
                                <div class="example table-responsive margin-bottom-10" style="box-shadow:0 3px 8px 0 #f1f6f7;">
                                    <table class="table text-center dataTable table-striped width-full " id="facebook_report">
                                        <thead class="thead" id="thead">
                                            <tr style="background:#00b1c9;">
                                                <th class="text-center" style="color:#fff;">Placement</th>
                                                <th class="text-center" style="color:#fff;">Impressions</th>
                                                <th class="text-center" style="color:#fff;">Clicks</th>
                                                <th class="text-center" style="color:#fff;">Results</th>
                                                <th class="text-center" style="color:#fff;">CTR</th>
                                                <th class="text-center" style="color:#fff;">CVR</th>
                                            </tr>
                                        </thead>
                                        <tbody class="tbody">
                                            <?php foreach($data14 as $item):?>
                                                <tr>
                                                    <td><?php echo ucwords($item['placement'])?></td>
                                                    <td><?php echo number_format($item['impressions'])?></td>
                                                    <td><?php echo number_format($item['clicks'])?></td>
                                                    <td><?php echo number_format($item['results'])?></td>
                                                    <td><?php echo $item['impressions']?sprintf("%.2f",$item['clicks']/$item['impressions']*100):0?>%</td>
                                                    <td><?php echo $item['clicks']?sprintf("%.2f",$item['results']/$item['clicks']*100):0?>%</td>
                                                </tr>
                                            <?php endforeach;?>
                                        </tbody>
                                    </table>                                   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>   
    </div>
</div>
  
<!-- Footer -->
<footer class="site-footer">
    <div class="site-footer-legal"><a href="http://marketmax.palmax.com">Palmax AdDigger Build 2016</a></div>
    <div class="site-footer-right">
        © 2015 - 2016, Palmax Limited, All rights reserved.
    </div>
</footer>
 <script type="text/javascript">
 var base_url = "<?php echo base_url()?>";
 var site_url = "<?php echo site_url()?>";
</script>
<!-- Core  -->
<script src="<?php echo base_url();?>assets/web/global/vendor/jquery/jquery.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/bootstrap/bootstrap.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/animsition/animsition.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/asscroll/jquery-asScroll.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/mousewheel/jquery.mousewheel.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/asscrollable/jquery.asScrollable.all.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/ashoverscroll/jquery-asHoverScroll.js"></script>
<!-- Plugins -->
<script src="<?php echo base_url();?>assets/web/global/vendor/switchery/switchery.min.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/intro-js/intro.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/screenfull/screenfull.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/slidepanel/jquery-slidePanel.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/asrange/jquery-asRange.min.js"></script>
<!-- 新加js -->
<script src="<?php echo base_url();?>assets/web/global/vendor/datatables/jquery.dataTables.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/datatables-bootstrap/dataTables.bootstrap.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/datatables-responsive/dataTables.responsive.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/datatables-tabletools/dataTables.tableTools.js"></script>
<!-- Scripts -->
<script src="<?php echo base_url();?>assets/web/global/js/core.js"></script>
<script src="<?php echo base_url();?>assets/web/assets/js/site.js"></script>
<script src="<?php echo base_url();?>assets/web/assets/js/sections/menu.js"></script>
<script src="<?php echo base_url();?>assets/web/assets/js/sections/menubar.js"></script>
<script src="<?php echo base_url();?>assets/web/assets/js/sections/sidebar.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/configs/config-colors.js"></script>
<script src="<?php echo base_url();?>assets/web/assets/js/configs/config-tour.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/components/asscrollable.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/components/animsition.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/components/slidepanel.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/echart/echarts-all-3.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/echart/dataTool.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/echart/china.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/echart/world.js"></script>
<script type="text/javascript" src="http://api.map.baidu.com/api?v=2.0&ak=ZUONbpqGBsYGXNIYHicvbAbM"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/echart/bmap.min.js"></script>
<!-- 新加js -->
<script src="<?php echo base_url();?>assets/web/global/js/components/datatables.js"></script>
<script src="<?php echo base_url();?>assets/web/assets/examples/js/tables/datatable.js"></script>
<script src="<?php echo base_url();?>assets/js/advertiser_daily.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/select2/select2.min.js"></script>  
<script src="<?php echo base_url();?>assets/web/global/js/components/select2.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/bootstrap-datepicker/bootstrap-datepicker.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/components/bootstrap-datepicker.js"></script>
<!-- If you'd like to support IE8 -->
<script src="<?php echo base_url();?>assets/js/videojs-ie8.min.js"></script>
<script src="<?php echo base_url();?>assets/js/video.js"></script>

 <script src="<?php echo base_url();?>assets/web/global/vendor/owl-carousel/owl.carousel.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/slick-carousel/slick.js"></script>

  <script src="<?php echo base_url();?>assets/web/global/js/components/owl-carousel.js"></script>
  <script src="<?php echo base_url();?>assets/web/assets/examples/js/uikit/carousel.js"></script>

<script>
    $(function() {
        function getLocalTime(nS) {     
            return new Date(parseInt(nS)).toLocaleString().substr(0,17);
        } 

        $('#input_date').datepicker({
            format: "MM dd yyyy",
            viewMode: "months", 
            minViewMode: 0
        }).datepicker("setDate", "<?php echo date('M d Y', $current_date)?>")
        .on('changeDate', function (ev) {
            var date = ev.date.valueOf();
            var newDate = new Date();
            newDate.setTime(date);

            date = newDate.toLocaleDateString()

            date = date.replace(/\//gm,'-');;
            location.href = site_url + "advertiser/daily?date="+date;
        }).val();

     }); 
</script>
</body>
</html>