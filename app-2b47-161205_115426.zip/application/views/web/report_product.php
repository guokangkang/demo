<!-- 新加css -->
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/global/vendor/datatables-bootstrap/dataTables.bootstrap.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/global/vendor/datatables-fixedheader/dataTables.fixedHeader.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/global/vendor/datatables-responsive/dataTables.responsive.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/assets/examples/css/tables/datatable.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/global/fonts/material-design/material-design.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/assets/examples/css/uikit/icon.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/global/vendor/bootstrap-datepicker/bootstrap-datepicker.css">
<style type="text/css">
    .table>tbody>tr>td {
    vertical-align: middle;
}
</style>
<div class="page animsition">
    <div class="page-header">
        <ol class="breadcrumb">
            <li><a href="<?php echo site_url('report/index');?>">Reports</a></li>
            <li class="active">Product</li>
        </ol>
    </div>
    <div class="page-content"> 
        <div class="panel" style="box-shadow:none;border: 1px solid #e3eaec;">
            <div class="panel-heading">
                <h3 class="panel-title">Products</h3>
                <div class="panel-actions">
                    <div class="filter">
                        <div class="dropdown pull-right" style="line-height: 84px;">
                            <button type="button" id="input_date" class="btn btn-pure">
                                <?php echo $this->input->get('date')?$this->input->get('date'):date('M Y')?>
                                <span class="icon wb-chevron-down-mini" aria-hidden="true"></span>
                            </button>
                        </div>
                    </div>  
                </div>
            </div>
            <div class="panel-body">
                <div class="table-responsive">
                    <table class="table dataTable width-full" id="facebook_report">
                        <thead>
                            <tr class="change_thead">
                                <th class="text-center">Product Logo</th>
                                <th class="text-center">Name</th>
                                <th class="text-center">Installs</th>
                                <th class="text-center">Retention Day</th>
                                <!-- <th class="text-center">Campaign</th> -->
                                <th class="text-center">Adset</th>
                                <th class="text-center">Country</th>
                            </tr>
                        </thead>
                        <tbody class="text-center">
                            <?php if($product_list):?>
                                <?php foreach ($product_list as $item):?>
                                    <tr class="gradeA">
                                        <td>
                                        <img class="img-rounded" src="<?php echo $item['logo']?>" alt="" style="width:50px; height:50px;">
                                        </td>
                                        <td><?php echo $item['name']?></td>
                                        <td><?php echo $item['install']?number_format($item['install']):0?></td>
                                        <td><?php echo $item['retention_day']?$item['retention_day']:'-'?></td>
                                        <!-- <td>
                                            <button type="button" class="btn btn-icon btn-warning padding-5">
                                                <i class="icon fa-external-link" aria-hidden="true"></i>
                                            </button>
                                        </td> -->
                                        <td>
                                            <a href="<?php echo site_url('report/retention/?product_id='.$item['product_id']."&time=".$this->input->get('date')."&start=".$date_start."&end=".$date_end)?>" class="btn btn-icon btn-warning padding-5">
                                                <i class="icon fa-external-link" aria-hidden="true"></i>
                                            </a>
                                        </td>
                                        <td>
                                            <?php if($item['retention']):?>
                                                <button type="button" class="btn btn-icon btn-success padding-5 show_retention">
                                                    <i class="icon fa-angle-double-down" aria-hidden="true"></i>
                                                </button>
                                            <?php endif;?>
                                        </td>
                                    </tr>
                                    <tr style="background-color: rgba(243,247,249,.3);display:none;">
                                <td colspan='7'>
                                    <?php if($item['retention']):?>
                                    <ul class="blocks blocks-100 blocks-xlg-4 blocks-md-6 blocks-sm-2 margin-horizontal-0 padding-top-20">
                                        <?php foreach($item['retention']['country'] as $key=>$row):?>
                                            <li class="text-center"><h5><?php echo $key?> : <?php echo $row['set_retention']."%"?>  - <span style="color:<?php echo $row['set_retention']>$row['value']?'#ff6477':'#c1e682';?>"><?php echo $row['value']."%"?></span></h5></li>
                                        <?php endforeach;?>
                                    </ul>
                                    <?php endif;?>
                                </td>
                            </tr>
                                <?php endforeach;?>
                            <?php else:?>
                            <tr class="gradeA">
                                <td>
                                </td>
                                <td>
                                </td>
                                <td>
                                <img src="<?php echo base_url();?>assets/images/no_data.png">
                                <h4 class="margin-top-30">NO DATA HERE</h4>
                                <p style="line-height: 18px;">I hate peeping Toms. For one thing they usually step all over<br>the hedges and plants on the side of someone's house killing</p>
                                </td>
                            </tr>
                            <?php endif;?>
                        </tbody>
                    </table> 
                </div>
            </div>  
        </div>
        <!-- End Panel Table Tools -->
    </div>
</div>


<!-- 报错就加上 -->
  <script src="<?php echo base_url(); ?>assets/web/global/vendor/asrange/jquery-asRange.min.js"></script>

<!-- 新加js -->
<script src="<?php echo base_url(); ?>assets/web/global/vendor/datatables/jquery.dataTables.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/vendor/datatables-fixedheader/dataTables.fixedHeader.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/vendor/datatables-bootstrap/dataTables.bootstrap.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/vendor/datatables-responsive/dataTables.responsive.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/vendor/datatables-tabletools/dataTables.tableTools.js"></script>
<!-- 新加js -->
<script src="<?php echo base_url(); ?>assets/web/global/js/components/datatables.js"></script>
<script src="<?php echo base_url(); ?>assets/web/assets/examples/js/tables/datatable.js"></script>
<script src="<?php echo base_url(); ?>assets/web/assets/examples/js/uikit/icon.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/vendor/bootstrap-datepicker/bootstrap-datepicker.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/js/components/bootstrap-datepicker.js"></script>
  <script>
   $(function() {
    var curr_date='<?php echo $this->input->get('date')?$this->input->get('date'):date('M Y',time())?>';
    $('#input_date').datepicker({
        format: "MM yyyy",
        viewMode: "months", 
        minViewMode: "months"
    }).datepicker("setDate", curr_date)
    .on('changeDate', function (ev) {
        var month = $(".datepicker-months span.active").text();
        var year = $('.datepicker-months .datepicker-switch').text();
        var params=encodeURIComponent(month+' '+year);
        console.log(params);
        location.href = '<?php echo site_url('report/product?date=');?>'+params;
    }).val();

    $(".table tr").click(function(){
        //location.href = site_url + "report/detail?product_id="+$(this).attr('data-val')+"&time="+$(this).attr('data-date');
    });

    $(".show_retention").click(function(){
        $(this).parents("tr").next("tr").toggle();
    });
 }); 
</script>



