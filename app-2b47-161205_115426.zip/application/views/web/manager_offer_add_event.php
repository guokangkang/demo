<style type="text/css">
    .select2-container--open{
        z-index: 9999;
    }
    .ui-timepicker-wrapper{
        z-index: 1700;
    }
</style>
<div class="modal fade" id="add_event" aria-hidden="false" aria-labelledby="add_event_Label" role="dialog" tabindex="-1">
    <div class="modal-dialog">
        <form class="modal-content form-horizontal" autocomplete="off" action="<?php echo site_url('manager/offer/add_batch_offer_effective_action')?>" method="post" id="offer_event_form">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
                <h4 class="modal-title" id="add_bucket_Label">Event</h4>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-sm-12">
                        <input type="hidden" name="offer_id" value="">

                        <div class="col-lg-12 form-group ">
                            <label class="control-label" for="select_country">    Status
                                <span class="required">*</span>
                            </label>
                            <div class="input-group">
                                <div class="radio-custom radio-default radio-inline">
                                    <input type="radio" value="0" id="input_pause" name="status">
                                    <label for="input_pause">Pause</label>
                                </div>
                                <div class="radio-custom radio-default radio-inline">
                                    <input type="radio" value="1" id="input_active" name="status">
                                    <label for="input_active">Start</label>
                                </div>

                                <div class="radio-custom radio-default radio-inline">
                                    <input type="radio" value="-1" id="input_delete" name="status">
                                    <label for="input_delete">Delete</label>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-12 form-group starttime_class">
                            <label class="control-label" for="description">
                                Effective Time
                                <span class="required">*</span>
                            </label>
                            <div class="input-daterange-wrap">
                                <div class="input-daterange">
                                    <div class="input-group">
                                        <span class="input-group-addon">
                                            <i class="icon wb-calendar" aria-hidden="true"></i>
                                        </span>
                                            <input type="text" class="form-control datepair-date datepair-start" data-plugin="datepicker" name="input_date" id="inputdate" value="<?php echo date('m/d/Y')?>">
                                    </div>
                                    <div class="input-group ">
                                        <span class="input-group-addon">
                                            <i class="icon wb-time" aria-hidden="true"></i>
                                        </span>
                                        <input type="text" class="form-control datepair-time datepair-start" data-plugin="timepicker" name="input_time" id="inputtime"
                                            value="<?php echo date('H:i a')?>" />
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="form-group">
                            <div class="col-sm-9">
                            <button type="submit" class="btn btn-info hover_btn" id="offer_event_button">Submit</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>