<div class="panel margin-bottom-0">
    <div class="row padding-top-30">
        <div class="col-sm-6"> 
            <form class="form-horizontal" autocomplete="off" id="manager_offer_detail_country"  method="post" action="<?php echo site_url('manager/offer/set_offer_country_action')?>">
                <input type="hidden" name="offer_id" value="<?php echo $offer_info['offer_id']?>">

                <div class="form-group">
                    <label class="col-sm-3 control-label" for="contact">Category</label>
                    <div class="col-sm-9">
                        <div class="margin-right-20">
                            <div class="radio-custom radio-default radio-inline">
                                <input type="radio" value="include" id="input_include" name="category" checked="">
                                <label for="input_include">Include</label>
                            </div>
                            <div class="radio-custom radio-default radio-inline">
                                <input type="radio" value="exclude" id="input_exclude" name="category" >
                                <label for="input_exclude">Exclude</label>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label class="col-sm-3 control-label" for="contact">Countries</label>
                    <div class="col-sm-9">
                        <select id="select_publisher" class="form-control bucket_country_select" multiple="" data-plugin="select2" name="select_country[]" data-placeholder="Counties">
                            <?php foreach($config_product['countries'] as $k=>$val):?>
                                <option value="<?php echo $k?>" <?php echo $offer_info['countries']&&in_array($k, $offer_info['countries'])?"selected='selected'":""?>><?php echo $val."(".$k.")"?></option>
                            <?php endforeach;?>
                        </select>
                    </div>
                </div>

                <div class="form-group">
                    <label class="col-sm-3 control-label" for="contact">Effective Time</label>
                    <div class="col-sm-9">
                        <div class="input-daterange">
                            <div class="input-group">
                                <span class="input-group-addon">
                                    <i class="icon wb-calendar" aria-hidden="true"></i>
                                </span>
                                    <input type="text" class="form-control datepair-date datepair-start" data-plugin="datepicker" name="input_date" id="inputdate" value="<?php echo date('m/d/Y')?>">
                            </div>
                            <div class="input-group ">
                                <span class="input-group-addon">
                                    <i class="icon wb-time" aria-hidden="true"></i>
                                </span>
                                <input type="text" class="form-control datepair-time datepair-start" data-plugin="timepicker" name="input_time" id="inputtime"
                                    value="<?php echo date('H:i a')?>" />
                            </div>
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label class="col-sm-3 control-label" for="contact"></label>
                    <div class="col-sm-9">
                        <button class="btn btn-info product_bucket_payout_save" data-dismiss="" type="submit" id="manager_offer_detail_country_button">Submit</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <header class="panel-heading margin-bottom-0 clearfix">
        <h3 class="panel-title pull-left">Details</h3>
    </header>
    <div class="panel-body table-responsive">
        <table class="table dataTable table-striped width-full" id="facebook_report">
            <thead class="change_thead">
                <tr>
                    <th>Effective Time</th>
                    <th>Category</th>
                    <th>Countries</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($offer_country as $start_time=>$item):?>
                    <tr>
                        <td><?php echo date('m/d/Y H:i', $start_time)?></td>
                        <td><?php echo strtoupper($item['choose_type'])?></td>
                        <td>
                            <?php echo implode(', ', $item['countries'])?>
                        </td>
                        <?php if($item['is_current']):?>
                            <td><span class="label label-table label-success">Current</span></td>
                        <?php else:?>
                            <td></td>
                        <?php endif;?>
                    </tr>
                <?php endforeach;?>
            </tbody>
        </table>
    </div>
</div>