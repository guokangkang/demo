<!-- 新加css -->
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/assets/examples/css/advanced/masonry.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/select2/select2.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/webui-popover/webui-popover.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/toolbar/toolbar.css">

<!-- Page -->
<div class="page animsition">
    <div class="page-header">
        <ol class="breadcrumb">
            <li><a href="<?php echo site_url('manager/user/index');?>">Management</a></li>
            <li class="active">Publisher</li>
        </ol>
        <div class="clearfix">
            <div class="pull-right">
                <button type="button" data-target="#add_publisher_div" data-toggle="modal" class="btn btn-primary btn-round margin-right-15 pull-left" style="background:#12abc5;">
                    <i class="icon wb-plus" aria-hidden="true"></i>
                    Publisher
                </button>
                <div class="form-group pull-right margin-bottom-0">
                    <div class="input-search margin-bottom-0">
                        <i class="input-search-icon wb-search" aria-hidden="true"></i>
                        <input type="text" class="form-control" name="q" value="<?php echo $this->input->get('q')?$this->input->get('q'):''; ?>" placeholder="Search...">
                        <button type="button" class="input-search-close icon wb-close" aria-label="Close"></button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="page-content padding-30 blue-grey-500 padding-top-0">
        <ul class="blocks blocks-100 blocks-xlg-3 blocks-lg-3 blocks-md-3 blocks-sm-2" data-plugin="masonry">
            <?php foreach($data as $item):?>
                <li class="masonry-item">
                <div class="widget-article widget-border bg-white">
                    <div class="widget-header padding-30 clearfix" style="position:relative;">
                        <a class="avatar avatar-lg pull-left margin-right-20 bg-white" href="javascript:void(0)" style="height: 50px;border: 1px solid #26788C;text-align: center;line-height: 50px;font-size:18px; color:#26788C;">
                            <?php echo $item['head'];?>
                        </a>
                        <div class="font-size-16" style="color:#444c52;"><?php echo $item['user_name']?></div>
                        <div class="font-size-14" style="color:#79848e;"><?php echo $item['email']?></div>
                        <p class="pull-right" style="color:#79848e;position: absolute;right: 30px;top: 35px;">#<?php echo $item['user_id']?></p>
                        <div class="clearfix">
                            <div class="font-size-14 pull-left" style="color:#79848e;"><?php echo $item['company_name']?$item['company_name']:'-'?></div>
                            <div class="pull-right">
                                <button data-uid="<?php echo $item['user_id']?>" data-target="#edit_publisher_div" data-toggle="modal" class="btn btn-sm wz-edit-publisher btn-icon btn-pure btn-default on-default edit-row padding-0 margin-right-10" >
                                    <i class="icon md-edit" aria-hidden="true"></i>
                                </button>
                                <button data-val="<?php echo $item['user_id']?>" class="btn btn-sm btn-icon btn-pure btn-default on-default remove-row remove_publisher_button padding-0" data-toggle="Popover">
                                    <i class="icon wb-trash" aria-hidden="true"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </li>
            <?php endforeach;?>
        </ul>

        <div class="fixed-table-pagination clearfix">
            <div class="pull-right">
                <?php echo $page_links?>
            </div>
        </div>
    </div>
    <div class="modal fade" id="add_publisher_div" aria-hidden="false" aria-labelledby="add_bucket_Label" role="dialog" tabindex="-1">
        <div class="modal-dialog">
            <form class="modal-content" autocomplete="off" method="post" id="add_advertiser" action="<?php echo site_url('manager/user/add_publisher_action')?>">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                    <h4 class="modal-title" id="add_bucket_Label">Add Publisher</h4>
                </div>
                <div class="modal-body">
                    <div class="row">

                        <input type="hidden" name="input_type" value="2">

                        <div class="col-lg-12 form-group ">
                            <label class="control-label" for="first_name">
                                Name
                                <span class="required">*</span>
                            </label>
                            <input type="text" class="form-control" name="input_first_name" placeholder="" autocomplete="off">
                        </div>

                        <div class="col-lg-12 form-group ">
                            <label class="control-label" for="email">
                                Email
                                <span class="required">*</span>
                            </label>
                            <input type="text" class="form-control" name="input_email" placeholder="" autocomplete="off">
                        </div>

                        <div class="col-lg-12 form-group ">
                            <label class="control-label" for="company">
                                Company
                                <!-- <span class="required">*</span> -->
                            </label>
                            <select class="form-control"  name="select_company">
                                <option></option>
                                <?php foreach($company_data as $key=>$val):?>
                                    <option value="<?php echo $val['company_id']?>" ><?php echo $val['name']?></option>
                                <?php endforeach;?>
                            </select>
                        </div>


                        <div class="col-lg-12 form-group ">
                            <label class="control-label" for="email">
                                Country
                                <!-- <span class="required">*</span> -->
                            </label>
                            <select class="form-control"  name="select_country">
                                <option></option>
                                <?php foreach($config_product['countries'] as $key=>$val):?>
                                    <option value="<?php echo $key?>" <?php echo $key=='CN'?"selected='selected'":''?>><?php echo $val?></option>
                                <?php endforeach;?>
                            </select>
                        </div>

                        <div class="col-lg-12 form-group ">
                            <label class="control-label" for="contact">
                                Contact
                                <!-- <span class="required">*</span> -->
                            </label>
                            <input type="text" class="form-control"  name="input_contact" placeholder="" autocomplete="off">
                        </div>
                        <div class="col-lg-12 form-group ">
                            <label class="control-label" for="Conversion_Rate">
                                Conversion Rate
                            </label>
                            <input type="text" class="form-control" id="Conversion_Rate" name="chart[input_conversion_rate]" placeholder="" autocomplete="off" maxlength="2">
                        </div>

                        <div class="col-lg-12 form-group ">
                            <label class="control-label" for="next_day">
                                Retention Of Next Day
                            </label>
                            <input type="text" class="form-control" id="next_day" name="chart[input_next_day]" placeholder="" autocomplete="off" maxlength="2">
                        </div>

                        <div class="col-lg-12 form-group ">
                            <label class="control-label" for="7days">
                                Retention Of 7 Days
                            </label>
                            <input type="text" class="form-control" id="7days" name="chart[input_7days]" placeholder="" autocomplete="off" maxlength="2">
                        </div>

                        <div class="col-lg-12 form-group ">
                            <label class="control-label" for="30days">
                                Retention Of 30 Days
                            </label>
                            <input type="text" class="form-control" id="30days" name="chart[input_30days]" placeholder="" autocomplete="off" maxlength="2">
                        </div>
                        <div class="col-lg-12 form-group ">
                            <label class="control-label" for="30days">
                                Score
                            </label>
                            <input type="text" class="form-control" name="score" placeholder="" autocomplete="off">
                        </div>
                        <div class="col-lg-12 form-group ">
                            <label class="control-label" for="30days">
                                Tags
                            </label>
                            <select class="form-control"  name="tags">
                                <option></option>
                                <?php foreach(config_item('tags') as $val):?>
                                    <option value="<?php echo $val?>"><?php echo $val?></option>
                                <?php endforeach;?>
                            </select>
                        </div>
                        <div class="col-lg-12 form-group ">
                            <label class="control-label" for="contact">
                                Label
                                <!-- <span class="required">*</span> -->
                            </label>
                            <input type="text" class="form-control"  name="input_label" placeholder="" autocomplete="off">
                        </div>


                        <div class="col-lg-12 form-group">
                            <label class="control-label" for="inputBasicRemember">Default Password : <b>123456</b></label>
                        </div>


                        <div class="col-lg-12 form-group ">
                            <button type="submit" class="btn btn-primary" id="add_advertiser_button">Submit</button>
                        </div>

                    </div>
                </div>
            </form>
        </div>
    </div>
    <div class="modal fade" id="edit_publisher_div" aria-hidden="false" aria-labelledby="add_bucket_Label" role="dialog" tabindex="-1">
        <div class="modal-dialog">
            <form class="modal-content" autocomplete="off" method="post" id="edit_publisher" action="<?php echo site_url('manager/user/publisher_edit_action')?>">
                <input type="hidden" class="form-control" id="user_id" name="user_id">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                    <h4 class="modal-title" id="edit_bucket_Label">Edit Publisher</h4>
                </div>
                <div class="modal-body">
                    <div class="row">

                        <input type="hidden" name="input_type" value="2">

                        <div class="col-lg-12 form-group ">
                            <label class="control-label" for="first_name">
                                Name
                                <span class="required">*</span>
                            </label>
                            <input type="text" class="form-control" id="input_user_name" name="input_user_name" placeholder="" autocomplete="off">
                        </div>

                        <div class="col-lg-12 form-group ">
                            <label class="control-label" for="email">
                                Email
                                <span class="required">*</span>
                            </label>
                            <input type="text" class="form-control" id="email" name="input_email" placeholder="" autocomplete="off">
                        </div>

                        <div class="col-lg-12 form-group ">
                            <label class="control-label" for="company">
                                Company
                                <!-- <span class="required">*</span> -->
                            </label>
                            <select class="form-control" id="companys" name="select_company">
                                <option></option>
                                <?php foreach($company_data as $key=>$val):?>
                                    <option value="<?php echo $val['company_id']?>" ><?php echo $val['name']?></option>
                                <?php endforeach;?>
                            </select>
                        </div>


                        <div class="col-lg-12 form-group ">
                            <label class="control-label" for="email">
                                Country
                                <!-- <span class="required">*</span> -->
                            </label>
                            <select class="form-control" id="select" name="select_country">
                                <option></option>
                                <?php foreach($config_product['countries'] as $key=>$val):?>
                                    <option value="<?php echo $key?>" <?php echo $key=='CN'?"selected='selected'":''?>><?php echo $val?></option>
                                <?php endforeach;?>
                            </select>
                        </div>

                        <div class="col-lg-12 form-group ">
                            <label class="control-label" for="contact">
                                Contact
                                <!-- <span class="required">*</span> -->
                            </label>
                            <input type="text" class="form-control" id="contact" name="input_contact" placeholder="" autocomplete="off">
                        </div>
                        <div class="col-lg-12 form-group ">
                            <label class="control-label" for="Conversion_Rate">
                                Conversion Rate
                            </label>
                            <input type="text" class="form-control" id="input_conversion_rate" name="chart[input_conversion_rate]" placeholder="" autocomplete="off" maxlength="2">
                        </div>

                        <div class="col-lg-12 form-group ">
                            <label class="control-label" for="next_day">
                                Retention Of Next Day
                            </label>
                            <input type="text" class="form-control" id="input_next_day" name="chart[input_next_day]" placeholder="" autocomplete="off" maxlength="2">
                        </div>

                        <div class="col-lg-12 form-group ">
                            <label class="control-label" for="7days">
                                Retention Of 7 Days
                            </label>
                            <input type="text" class="form-control" id="input_7days" name="chart[input_7days]" placeholder="" autocomplete="off" maxlength="2">
                        </div>

                        <div class="col-lg-12 form-group ">
                            <label class="control-label" for="30days">
                                Retention Of 30 Days
                            </label>
                            <input type="text" class="form-control" id="input_30days" name="chart[input_30days]" placeholder="" autocomplete="off" maxlength="2">
                        </div>
                        <div class="col-lg-12 form-group ">
                            <label class="control-label" for="30days">
                                Score
                            </label>
                            <input type="text" class="form-control" id="score" name="score" placeholder="" autocomplete="off">
                        </div>
                        <div class="col-lg-12 form-group ">
                            <label class="control-label" for="30days">
                                Tags
                            </label>
                            <select class="form-control" id="tags" name="tags">
                                <option></option>
                                <?php foreach(config_item('tags') as $val):?>
                                    <option value="<?php echo $val?>"><?php echo $val?></option>
                                <?php endforeach;?>
                            </select>
                        </div>
                        <div class="col-lg-12 form-group ">
                            <label class="control-label" for="contact">
                                Label
                                <!-- <span class="required">*</span> -->
                            </label>
                            <input type="text" class="form-control" id="label" name="input_label" placeholder="" autocomplete="off">
                        </div>

                        <div class="col-lg-12 form-group">
                            <label class="control-label" for="inputBasicRemember">Default Password : <b>123456</b></label>
                        </div>


                        <div class="col-lg-12 form-group ">
                            <button type="submit" class="btn btn-primary" id="add_advertiser_button">Submit</button>
                        </div>

                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<script src="<?php echo base_url();?>assets/web/global/js/components/switchery.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/components/masonry.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/select2/select2.min.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/components/select2.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/webui-popover/jquery.webui-popover.min.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/toolbar/jquery.toolbar.min.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/components/webui-popover.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/components/toolbar.js"></script>
<script src="<?php echo base_url();?>assets/web/assets/examples/js/uikit/tooltip-popover.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/masonry/masonry.pkgd.min.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/formvalidation/formValidation.min.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/formvalidation/framework/bootstrap.min.js"></script>
<script src="<?php echo base_url();?>assets/js/my_valiation.js"></script>
<!-- 新加js结束 -->
<script>
 $('.input-search').keydown(function (e) {
     var curKey = e.which;
     if (curKey == 13) {
         var url = '<?php echo site_url('manager/user/publisher?q=');?>';
         var data = $('input[name=q]').val();
         url = url + data;
         location.href = url;
     }
 });
 $('.input-search-close').click(function () {
     location.href='<?php echo site_url('manager/user/publisher');?>';
 });
</script>
