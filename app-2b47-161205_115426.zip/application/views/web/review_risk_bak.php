<!-- 新加css -->
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/assets/examples/css/advanced/masonry.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/global/vendor/select2/select2.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/global/vendor/bootstrap-select/bootstrap-select.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/global/vendor/bootstrap-datepicker/bootstrap-datepicker.css">
<style>
    .table > tbody > tr > td {
        vertical-align: middle;
        border-top: 0;
        padding: 0;
    }
</style>
<!-- Page -->
<div class="page animsition">
    <div class="page-header">
        <ol class="breadcrumb">
            <li><a href="<?php echo site_url('review')?>" style="text-decoration:none;">Creative</a></li>
            <li class="active">Risk</li>
        </ol>
    </div>
    <div class="page-content blue-grey-500">
        <!-- 过滤条件 -->
        <div class="row">
            <div class="clearfix visible-md-block visible-lg-block"></div>
            <div class="col-md-12">
                <div class="panel is-collapse widget-border">
                    <div class="panel-heading">
                        <h3 class="panel-title">Filter</h3>
                        <div class="panel-actions">
                            <a class="panel-action icon wb-plus" data-toggle="panel-collapse" aria-hidden="true"></a>
                        </div>
                    </div>
                    <div class="panel-body">
                        <div class="example table-responsive" style="margin-bottom: 0; margin-top: 0;">
                            <div class="col-md-4">
                                <div class="example-wrap margin-bottom-30">
                                    <div class="example">
                                        <form>
                                            <div class="form-group filter-form advertiser-filter"
                                                 style="margin-bottom:15px;padding-left: 0;">
                                                <select class="form-control select2-hidden-accessible" multiple=""
                                                        data-plugin="select2" tabindex="-1" aria-hidden="true"
                                                        data-placeholder="Publisher">
                                                    <option value="CA">California</option>
                                                    <option value="NV">Nevada</option>
                                                    <option value="OR">Oregon</option>
                                                    <option value="WA">Washington</option>
                                                </select>
                                            </div>

                                            <div class="form-group filter-form advertiser-filter"
                                                 style="margin-bottom:15px;padding-left: 0;">
                                                <select class="form-control select2-hidden-accessible filter_publisher"
                                                        multiple="" data-plugin="select2" tabindex="-1"
                                                        aria-hidden="true" data-placeholder="Publisher">
                                                    <option value="CA">California</option>
                                                    <option value="NV">Nevada</option>
                                                    <option value="OR">Oregon</option>
                                                    <option value="WA">Washington</option>
                                                </select>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-4">
                                <div class="example-wrap margin-bottom-30">
                                    <div class="example">
                                        <form>

                                            <div class="form-group filter-form advertiser-filter"
                                                 style="margin-bottom:15px;padding-left: 0;">
                                                <select class="form-control select2-hidden-accessible filter_publisher"
                                                        multiple="" data-plugin="select2" tabindex="-1"
                                                        aria-hidden="true" data-placeholder="Publisher">
                                                    <option value="CA">California</option>
                                                    <option value="NV">Nevada</option>
                                                    <option value="OR">Oregon</option>
                                                    <option value="WA">Washington</option>
                                                </select>
                                            </div>

                                            <div class="form-group filter-form advertiser-filter"
                                                 style="margin-bottom:15px;padding-left: 0;">
                                                <select class="form-control select2-hidden-accessible filter_publisher"
                                                        multiple="" data-plugin="select2" tabindex="-1"
                                                        aria-hidden="true" data-placeholder="Publisher">
                                                    <option value="CA">California</option>
                                                    <option value="NV">Nevada</option>
                                                    <option value="OR">Oregon</option>
                                                    <option value="WA">Washington</option>
                                                </select>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-1 text-center">
                                <span class="inline-block margin-top-20"
                                      style="width:1px; height:88px; border-right:1px dashed #d1d1d1;"></span>
                            </div>
                            <div class="col-md-3">
                                <div class="example-wrap">
                                    <div class="example">
                                        <form>
                                            <div class="form-group col-lg-3 col-xlg-3 filter-form account-filter"
                                                 style="margin-bottom:15px;padding-left: 0;text-align: center;">
                                                <div class="form-control" style="width: 227px;">
                                                    <div id="reportrange" class="pull-right">
                                                        <i class="glyphicon glyphicon-calendar fa fa-calendar"></i>&nbsp;
                                                        <span>08/07/2016 - 08/10/2016</span> <b class="caret"></b>

                                                        <input type="hidden" value="" class="date_start"/>
                                                        <input type="hidden" value="" class="date_end"/>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <a id="ad_list" name="ad_list"></a>
                        <div class="example example-buttons text-center margin-vertical-0">
                            <button type="button" class="btn btn-outline btn-primary review_search">Search</button>
                            <button type="button" class="btn btn-outline btn-info review_rest">Reset</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- 列表 -->
        <ul class="blocks blocks-100 blocks-xlg-4 blocks-lg-3 blocks-md-3 blocks-sm-2" data-plugin="masonry">
            <li class="masonry-item">
                <div class="padding-top-10 widget widget-article widget-shadow" style="padding-bottom:1px;">
                    <div class="clearfix padding-horizontal-15">
                        <div class="pull-left review-cover-images margin-right-15">
                            <img class="cover-image"
                                 src="<?php echo base_url(); ?>assets/web/assets/images/safe_image.png" alt="">
                        </div>
                        <div class="pull-left width_device">
                            <p class="margin-bottom-0"><span class="font-size-16 margin-right-10">AdName:</span>xxxxxxxx
                            </p>
                            <h3 class="font-size-14 margin-0 margin-top-10 margin-right-15"
                                style="height:16px;overflow:hidden;">Stop Using Boring Keyboard</h3>
                            <p class="margin-bottom-0"
                               style="line-height: 18px;height:36px;overflow:hidden;word-break: break-all;">Look! I made
                                this custom keyboard of Supernatural</p>
                            <p class="pull-right margin-bottom-0">
                                <a href="#" class="margin-left-10" style="color:#ffa8b3;">See translate</a>
                            </p>
                        </div>
                    </div>
                    <div class="margin-top-15">
                        <table class="font-size-16 table text-center dataTable width-full special_table"
                               id="facebook_report">
                            <tbody style="color:#707070;">
                            <tr>
                                <td>3434</td>
                                <td>23K</td>
                                <td>234K</td>
                                <td>1.03%</td>
                                <td>70.09%</td>
                            </tr>
                            <tr class="font-size-14">
                                <td>Installs</td>
                                <td>Impressions</td>
                                <td>Clicks</td>
                                <td>CTR</td>
                                <td>CVR</td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </li>
            <li class="masonry-item">
                <div class="padding-top-10 widget widget-article widget-shadow" style="padding-bottom:1px;">
                    <div class="clearfix padding-horizontal-15">
                        <div class="pull-left review-cover-images margin-right-15">
                            <img class="cover-image"
                                 src="<?php echo base_url(); ?>assets/web/assets/images/safe_image.png" alt="">
                        </div>
                        <div class="pull-left width_device">
                            <p class="margin-bottom-0"><span class="font-size-16 margin-right-10">AdName:</span>xxxxxxxx
                            </p>
                            <h3 class="font-size-14 margin-0 margin-top-10 margin-right-15"
                                style="height:16px;overflow:hidden;">Stop Using Boring Keyboard</h3>
                            <p class="margin-bottom-0"
                               style="line-height: 18px;height:36px;overflow:hidden;word-break: break-all;">Look! I made
                                this custom keyboard of Supernatural</p>
                            <p class="pull-right margin-bottom-0">
                                <a href="#" class="margin-left-10" style="color:#ffa8b3;">See translate</a>
                            </p>
                        </div>
                    </div>
                    <div class="margin-top-15">
                        <table class="font-size-16 table text-center dataTable width-full special_table"
                               id="facebook_report">
                            <tbody style="color:#707070;">
                            <tr>
                                <td>3434</td>
                                <td>23K</td>
                                <td>234K</td>
                                <td>1.03%</td>
                                <td>70.09%</td>
                            </tr>
                            <tr class="font-size-14">
                                <td>Installs</td>
                                <td>Impressions</td>
                                <td>Clicks</td>
                                <td>CTR</td>
                                <td>CVR</td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </li>
            <li class="masonry-item">
                <div class="padding-top-10 widget widget-article widget-shadow" style="padding-bottom:1px;">
                    <div class="clearfix padding-horizontal-15">
                        <div class="pull-left review-cover-images margin-right-15">
                            <img class="cover-image"
                                 src="<?php echo base_url(); ?>assets/web/assets/images/safe_image.png" alt="">
                        </div>
                        <div class="pull-left width_device">
                            <p class="margin-bottom-0"><span class="font-size-16 margin-right-10">AdName:</span>xxxxxxxx
                            </p>
                            <h3 class="font-size-14 margin-0 margin-top-10 margin-right-15"
                                style="height:16px;overflow:hidden;">Stop Using Boring Keyboard</h3>
                            <p class="margin-bottom-0"
                               style="line-height: 18px;height:36px;overflow:hidden;word-break: break-all;">Look! I made
                                this custom keyboard of Supernatural</p>
                            <p class="pull-right margin-bottom-0">
                                <a href="#" class="margin-left-10" style="color:#ffa8b3;">See translate</a>
                            </p>
                        </div>
                    </div>
                    <div class="margin-top-15">
                        <table class="font-size-16 table text-center dataTable width-full special_table"
                               id="facebook_report">
                            <tbody style="color:#707070;">
                            <tr>
                                <td>3434</td>
                                <td>23K</td>
                                <td>234K</td>
                                <td>1.03%</td>
                                <td>70.09%</td>
                            </tr>
                            <tr class="font-size-14">
                                <td>Installs</td>
                                <td>Impressions</td>
                                <td>Clicks</td>
                                <td>CTR</td>
                                <td>CVR</td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </li>
        </ul>
    </div>
</div>
<!-- 新加js -->
<script src="<?php echo base_url(); ?>assets/web/global/vendor/masonry/masonry.pkgd.min.js"></script>
<!-- 新加js -->
<script src="<?php echo base_url(); ?>assets/web/global/js/components/masonry.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/vendor/select2/select2.min.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/js/components/select2.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/js/components/panel.js"></script>
<script src="<?php echo base_url(); ?>assets/web/assets/examples/js/uikit/panel-actions.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/vendor/bootstrap-select/bootstrap-select.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/js/components/bootstrap-select.js"></script>
<script type="text/javascript"
        src="<?php echo base_url(); ?>assets/web/assets/examples/js/tables/moment.min.js"></script>
<script type="text/javascript"
        src="<?php echo base_url(); ?>assets/web/assets/examples/js/tables/daterangepicker.js"></script>

<script>
    (function (document, window, $) {
        'use strict';
        var Site = window.Site;
        $(document).ready(function () {
            Site.run();
        });
    })(document, window, jQuery);
</script>