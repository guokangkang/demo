<!DOCTYPE html>
<html>
<head>
    <title></title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/base.css">
    <style>
        .table-bordered td{padding:8px;}
    </style>
</head>
<body>
<div style="margin:0 auto; padding:40px 50px; font-family:'Microsoft YaHei','yahei';">
    <h2 style="height:32px; width:100%; border-bottom:1px solid #000;">
        <div style="display:inline-block;width:49%;font-size:16px;font-weight:bold;color:#000;">PALMAX LIMITED</div>
        <p style="display:inline-block;font-size:16px;width:50%; padding-top:5px;font-weight:bold;color:#000;">INVOICE</p>
    </h2>
    <div class="title" style="width:100%;margin-top:20px;">
        <div style="width:49%;display:inline-block;">
            <div style="width:100%;font-size:14px;line-height:20px;color:#000;">Due Date : <?php echo $invoice_end_time;?></div>

        </div>
        <div style="width:49%;display:inline-block;vertical-align: top;">
            <div style="width:100%;font-size:14px;line-height:18px;color:#000;">Invoice Number : <?php echo $invoice_number;?></div>
            <div style="width:100%;font-size:14px;line-height:18px;color:#000;">Invoice Date : <?php echo date('M d Y',$invoice_start_time);?></div>
            <div style="width:100%;font-size:14px;line-height:18px;color:#000;">Invoice Amount : $<?php echo $amounts?number_format($amounts,2):0.00;?></div>
        </div>
        <?php if($invoice_company_name):?>
            <div style="width:100%;font-size:14px;line-height:22px;">
                <span style="display:inline-block;width:18%; vertical-align:top;height:22px;color:#000;">Bill To : </span>
            </div>
            <div style="width:100%;font-size:14px;">
                <span style="display:inline; vertical-align:top;color:#000;">Company Name : </span>
                <span style="display:inline-block;width:80%;line-height: 16px;color:#000;"><?php echo $invoice_company_name;?></span>
            </div>
        <?php endif;?>
        <?php if($invoice_address):?>
            <p style="width:100%;">
                <div style="display:inline;vertical-align:top;font-size:14px; margin-right:5px;color:#000;">Address:</div>
                <div style="display:inline-block;width:87%;">
                    <p style="width:100%;line-height:16px;font-size:14px;color:#000;"> <?php echo $invoice_address;?></p>
                </div>
            </p>
        <?php endif;?>
        <?php if($invoice_phone):?>
            <div style="width:100%;">
                <p style="width:100%;font-size:14px;line-height:18px;display:inline-block;color:#000;">Contact Phone: <?php echo $invoice_phone;?></p>
            </div>
        <?php endif;?>
    </div>
    <div style="margin-top:30px;">
        <table class="table-bordered" style="text-align: center;font-size:14px;color:#000;width:100%;">
            <thead>
            <tr style="height:60px; background:#f0f0f0;">
                <th colspan="2" class="text-center" style="border-right:0;color:#000;padding:8px;">DESCRIPTION</th>
                <th class="text-center" style="border-left:0;color:#000;">Note</th>
            </tr>
            </thead>
            <tbody class="text-center">
            <tr style="height:60px;">
                <td style="width:26%;padding:8px; color:#000;">Type</td>
                <td style="width:26%;padding:8px; color:#000;">Cost</td>
                <td rowspan="3" style="width:26%;padding:8px; color:#000;">Billing Period :<br/> <?php echo $start_time.' ~ '.date('M d Y',time())?></td>
            </tr>
            <tr style="height:60px;">
                <td style="width:26%;padding:8px;color:#000;">Facebook Online Marketing</td>
                <td style="width:26%;padding:8px;color:#000;">$<?php echo $amounts?number_format($amounts,2):0.00;?></td>
            </tr>
            <tr style="height:70px;">
                <td colspan="1" style="border-right:0; text-align:left;color:#000;">Total Amount</td>
                <td style="border-left:0;color:#000;text-align: center;">$<?php echo $amounts?number_format($amounts,2):0.00;?></td>
            </tr>
            </tbody>
        </table>
    </div>
    <h2 style="font-size:14px; margin:30px 0 20px;">Pay To :</h2>
    <div>
        <table class="table-bordered" style="font-size:14px;color:#767c80;width:100%;">
            <tbody>
            <tr style="height:60px;">
                <td style="width:26%;background:#f0f0f0; color:#000;">Account Name</td>
                <td style="width:75%;color:#000;"><?php echo $payto['account_name'];?></td>
            </tr>
            <tr style="height:60px;">
                <td style="width:26%;background:#f0f0f0; color:#000;">Account No.</td>
                <td style="color:#000;"><?php echo $payto['account_no'];?></td>
            </tr>
            <tr style="height:60px;">
                <td style="width:26%;background:#f0f0f0; color:#000;">Bank Name</td>
                <td style="color:#000;"><?php echo $payto['bank_name'];?></td>
            </tr>
            <tr style="height:60px;">
                <td style="width:26%;background:#f0f0f0; color:#000;">Swift Name</td>
                <td style="color:#000;"><?php echo $payto['swift_code'];?></td>
            </tr>
            <tr style="height:60px;">
                <td style="width:26%;background:#f0f0f0; color:#000;">Bank Address</td>
                <td style="color:#000;"><?php echo $payto['bank_address'];?></td>
            </tr>
            <tr style="height:60px;">
                <td style="width:26%;background:#f0f0f0; color:#000;">Comany Address</td>
                <td style="color:#000;line-height:16px;"><?php echo $payto['company_address'];?> </td>
            </tr>
            <tr style="height:60px;">
                <td style="width:26%;background:#f0f0f0; color:#000;">Tel</td>
                <td style="color:#000;"><?php echo $payto['tel'];?></td>
            </tr>
            <tr style="height:60px;">
                <td style="width:26%;background:#f0f0f0; color:#000;">Contact Email</td>
                <td style="color:#000;"><?php echo $payto['contact_email'];?></td>
            </tr>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>