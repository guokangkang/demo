<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/formvalidation/formValidation.css">

<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/icheck/icheck.css">
<div class="page animsition">
    <div class="page-header ">
        <h1 class="page-title">Business Users</h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo site_url('business/users')?>">Business</a></li>
            <li class="active">Business Users</li>
        </ol>
        
    </div>
    <div class="page-content">
        <div class="panel panel-bordered panel-default">
            <div class="panel-body">
                <table class="table table-hover dataTable table-striped width-full verticaltop" id="productlist" data-selectable="selectable" data-row-selectable="true">
                    <thead>
                      <tr>
                        <th style="width: 15%">Business ID</th>
                        <th style="width: 20%">Business Name</th>
                        <th style="width: 15%">Facebook User ID</th>
                        <th style="width: 15%">Facebook User Name</th>
                        <th style="width: 10%">Facebook User Email</th>
                        <th style="width: 20%">MarketMax User Name</th>
                        <th style="width: 10%">Role</th>
                        <th style="width: 20%">Status</th>
                      </tr>
                    </thead>
                    <tbody>
                        <?php foreach($publisher_list as $item):?>
                            <tr>
                                <td><?php echo $item['business_id']?></td>
                                <td><?php echo $item['business_name']?></td>
                                <td><?php echo $item['facebook_id']?></td>
                                <td><?php echo $item['facebook_name']?></td>
                                <td><?php echo $item['email']?></td>
                                <td>
                                    <?php if($item['user_id']):?>
                                        <?php echo $item['user_name'];?>
                                    <?php else:?>
                                        <a class="related_publisher" type="button" data-target="#add_related_publisher" data-toggle="modal" data-facebook="<?php echo $item['facebook_id']?>" data-business="<?php echo $item['business_id']?>" data-email="<?php echo $item['email']?>">
                                            Bind Publisher Account
                                        </a>
                                    <?php endif;?>  
                                </td>
                                <td>
                                    <?php if($item['role']=='ADMIN'):?>
                                        <b style="color:#62a8ea"><?php echo $item['role']?></b>
                                    <?php else:?>
                                        <?php echo $item['role']?>
                                    <?php endif;?>
                                </td>
                                <td>
                                    <?php if($item['user_id']):?>
                                        <span class="label label-round label-success">Active</span> 
                                    <?php else:?>  
                                        <span class="label label-round label-danger">Inactive</span>     
                                    <?php endif;?> 
                                </td>
                                
                            </tr>
                        <?php endforeach?>
                    </tbody>
                </table>
                
            </div>
        </div>
    </div>
</div>

<style type="text/css">
    .select2-container--open{
        z-index: 9999;
    }
</style>
<div class="modal fade" id="add_related_publisher" aria-hidden="false" aria-labelledby="add_related_publisher" role="dialog" tabindex="-1">
    <div class="modal-dialog">
        <form class="modal-content " autocomplete="off" id="add_related_publisher_form"  method="post" action="<?php echo site_url('business/add_related_publisher_action')?>">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
                <h4 class="modal-title" id="add_related_publisher">Bind Publisher Account</h4>
            </div>
            <input type="hidden" name="facebook_id" value="">
            <input type="hidden" name="business_id" value="">
            <div class="modal-body">
                <div class="row"> 
                    
                    <div class="col-lg-12 form-group ">
                        <div class="radio-custom radio-default radio-inline">
                            <input type="radio" class="icheckbox-primary bind_publisher" id="create_publisher" name="bind_publisher"
                            checked value="1" 
                            />
                            <label for="create_publisher">Create Publisher Account</label>
                        </div>
                        <div class="radio-custom radio-default radio-inline">
                            <input type="radio" class="icheckbox-primary bind_publisher" id="bind_publisher" name="bind_publisher"
                            value="2" 
                            />
                            <label for="bind_publisher">Bind Publisher Account</label>
                        </div>
                    </div>

                    <div class="col-lg-12 form-group select_publisher_div " style="display:none">
                        <label class="control-label" for="select_publisher">Publisher
                            <span class="required">*</span>
                        </label>
                        <select class="form-control select_publisher" name="select_publisher">
                            <?php foreach($user_list as $val):?>
                                <option value="<?php echo $val['user_id']?>" ><?php echo $val['user_name']?></option>
                            <?php endforeach;?>
                        </select>
                    </div>

                    <div class="col-lg-12 form-group create_publisher_div">
                        <label class="control-label" for="input_first">First Name
                            <span class="required">*</span>
                        </label>
                        <input type="text" class="form-control" id='input_first' name="input_first">
                    </div>
                    <div class="col-lg-12 form-group create_publisher_div">
                        <label class="control-label" for="input_last">Last Name
                            <span class="required">*</span>
                        </label>
                        <input type="text" class="form-control" id='input_last' name="input_last">
                    </div>
                    <div class="col-lg-12 form-group create_publisher_div">
                        <label class="control-label" for="input_email">Email
                            <span class="required">*</span>
                        </label>
                        <input type="text" class="form-control" id='input_email' name="input_email">
                    </div>

                

                    <div class="col-sm-12 pull-right">
                      <button class="btn btn-primary btn-outline pull-right" data-dismiss="" type="submit" id="add_related_publisher_button">Save</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>

<script src="<?php echo base_url();?>assets/web/global/js/plugins/selectable.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/components/selectable.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/icheck/icheck.min.js"></script>

<script src="<?php echo base_url();?>assets/web/global/js/components/icheck.js"></script>

  <script src="<?php echo base_url();?>assets/web/global/vendor/formvalidation/formValidation.min.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/formvalidation/framework/bootstrap.min.js"></script>
<script src="<?php echo base_url();?>assets/js/my_valiation.js"></script>

