
<div class="panel panel-bordered panel-default">
    <div class="panel-body padding-0">
        <table class="table table-hover dataTable table-striped width-full verticaltop" id="productlist" data-selectable="selectable" data-row-selectable="true">
        
            <thead>
              <tr>
                <th style="width: 10%">Offer ID</th>
                <th style="width: 20%">Countries</th>
                <th style="width: 10%">Payout</th>
                <th style="width: 10%">Offer Status</th>
                <th style="width: 25%">Event</th>
                
                <?php if($this->userinfo['type']==2):?>
                    <th style="width: 10%">Apply Status</th>
                    <th style="width: 10%">Action</th>
                    <th style="width: 5%">
                        <span class="checkbox-custom checkbox-primary">
                                    <input class="selectable-all" type="checkbox">
                                    <label></label>
                                </span>
                    </th>
                <?php endif;?>
              </tr>
            </thead>
            <tbody>
                <?php foreach($list as $item):?>
                    <tr>
                        <td><?php echo $item['offer_id']?></td>
                        <td>
                            <?php if($item['choose_type']=='include'):?>
                                <span class="label label-table label-success">Include</span>
                            <?php else:?>
                                <span class="label label-table label-danger">Exclude</span>
                            <?php endif;?>
                            &nbsp;
                            <a data-content="<?php echo $item['countries']?implode(', ', $item['countries']):'All Countries';?>" data-trigger="hover" data-toggle="popover" data-original-title="Countries" tabindex="0" title="" type="button" data-placement="top">
                                <?php if($item['country_size']<=10 && $item['country_size']>0):?>
                                    <?php echo implode(', ', $item['countries'])?>
                                <?php elseif($item['country_size']==0):?>
                                    All Countries
                                <?php else:?>
                                    <?php echo implode(', ', array_slice($item['countries'], 0, 10))?>
                                <?php endif;?>
                            </a>
                        </td>
                        <td>
                            
                            <a href="#" data-toggle="modal" data-target="#examplePositionCenter<?php echo $item['offer_id']?>">
                                <?php if($item['specific_payout']):?>
                                    $<?php echo $item['specific_payout']['payout']?>
                                <?php else:?>
                                    $<?php echo sprintf("%.2f", $item['current']['cpa']); ?>
                                <?php endif;?>
                            </a>
                            &nbsp;
                            <span class="bucket_payout_type">(
                                <?php 
                                    if($item['specific_payout']){
                                        echo "Specific";
                                    }else{
                                        echo $config_product['offer_category'][$item['current']['category']];
                                    }
                                ?>
                            )</span>
                            
                              <!-- Modal -->
                            <div class="modal fade" id="examplePositionCenter<?php echo $item['offer_id']?>" aria-hidden="true" aria-labelledby="exampleModalTabs"
                              role="dialog" tabindex="-1">
                                <div class="modal-dialog">
                                  <div class="modal-content">
                                    <div class="modal-header">
                                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">×</span>
                                          </button>
                                          <h4 class="modal-title" id="exampleModalTabs">Payouts</h4>
                                    </div>
                                    <?php if($item['current']):?>
                                    <div class="col-md-12">
                                      <!-- Example Single Images Lightbox -->
                                      <div class="example-wrap text-center">
                                        <h4 class="example-title bucket-payout-current-title">Current Payout</h4>
                                        <?php if($item['current']['category']==2):?>
                                            <?php foreach($item['current']['value'] as $val):?>  
                                                <p><?php echo "If RT > <strong>".$val['retention_rate']."%</strong>, ";?>
                                                <?php echo "Payout will be <strong>".$val['payout_rate']."%</strong> = ";?>
                                                <strong><?php echo "$".$val['payout'];?></strong></p>
                                            <?php endforeach;?>
                                        <?php elseif($item['current']['category']==1):?>
                                            <strong>$<?php echo $item['current']['cpa']?></strong>
                                        <?php else:?>
                                            <p>Payout will be proportional to the retention rate.</p>
                                            <p>If RR > <strong><?php echo $item['current']['value']?>%</strong>, Full Payout.</p>
                                            <p>If RR = x, payout = x/<strong><?php echo $item['current']['value']?>%</strong>*Full Payout.</p>
                                        <?php endif;?>
                                      </div>
                                      <!-- End Example Single Images Lightbox -->
                                    </div>
                                    <?php endif;?>
                                    <ul class="nav nav-tabs nav-tabs-line bucket-nav-tabs-line" data-plugin="nav-tabs" role="tablist">
                                      <li class="active" role="presentation"><a data-toggle="tab" href="#exampleLine<?php echo $item['offer_id']?>_1" aria-controls="<?php echo $item['offer_id']?>_1"
                                        role="tab">Schedule</a></li>
                                      <li role="presentation"><a data-toggle="tab" href="#exampleLine<?php echo $item['offer_id']?>_2" aria-controls="exampleLine<?php echo $item['offer_id']?>_2"
                                        role="tab">History</a></li>
                                      
                                    </ul>
                                    <div class="modal-body">
                                        <div class="tab-content">
                                            <div class="tab-pane active" id="exampleLine<?php echo $item['offer_id']?>_1" role="tabpanel">
                                                <div class="row">
                                                    <div class="col-sm-12">
                                                        <table class="editable-table table table-striped" id="editableTable">
                                                            <thead>
                                                              <tr>
                                                                <th>Effective time</th>
                                                                <th>Payout</th>
                                                                <th>Retention</th>
                                                              </tr>
                                                            </thead>
                                                            <tbody>
                                                                <?php foreach($item['schedule'] as $schedule):?>
                                                                    <tr>
                                                                        <td><?php echo date('m/d/Y g:i a', $schedule['start_time'])?></td>
                                                                        <td>$<?php echo $schedule['cpa']?></td>
                                                                        <?php if($schedule['category']==1):?>
                                                                            <td><strong>$<?php echo $schedule['cpa']?></strong></td>
                                                                        <?php elseif($schedule['category']==2):?>
                                                                        
                                                                            <td>
                                                                                <?php foreach($schedule['value'] as $val):?>    
                                                                                    <?php echo "If RT > <strong>".$val['retention_rate']."%</strong>, ";?>
                                                                                    <?php echo "Payout will be <strong>".$val['payout_rate']."%</strong> = ";?>
                                                                                    <?php echo "<strong>$".$val['payout']."</strong><br>";?>
                                                                                <?php endforeach;?>
                                                                            </td>
                                                                        <?php else:?>
                                                                            <td>
                                                                                Payout will be proportional to the retention rate.<br/>
                                                                                If RR > <strong><?php echo $schedule['value']?>%</strong>, Full Payout.<br/>
                                                                                If RR = x, payout = x/<strong><?php echo $schedule['value']?>%</strong>*Full Payout.
                                                                            </td>
                                                                        <?php endif;?>
                                                                    </tr>
                                                                <?php endforeach;?>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="tab-pane" id="exampleLine<?php echo $item['offer_id']?>_2" role="tabpanel">
                                                <div class="row">

                                                    <div class="col-sm-12">
                                                        <table class="editable-table table table-striped" id="editableTable">
                                                            <thead>
                                                              <tr>
                                                                <th>Effective time</th>
                                                                <th>Payout</th>
                                                                <th>Retention</th>
                                                              </tr>
                                                            </thead>
                                                            <tbody>
                                                                <?php foreach($item['history'] as $schedule):?>
                                                                    <tr>
                                                                        <td><?php echo date('m/d/Y g:i a', $schedule['start_time'])?></td>
                                                                        <td>$<?php echo $schedule['cpa']?></td>
                                                                        <?php if($schedule['category']==1):?>
                                                                            <td><strong>$<?php echo $schedule['cpa']?></strong></td>
                                                                        <?php elseif($schedule['category']==2):?>
                                                                        
                                                                            <td>
                                                                                <?php foreach($schedule['value'] as $val):?>    
                                                                                    <?php echo "If RT > <strong>".$val['retention_rate']."%</strong>, ";?>
                                                                                    <?php echo "Payout will be <strong>".$val['payout_rate']."%</strong> = ";?>
                                                                                    <?php echo "<strong>$".$val['payout']."</strong><br>";?>
                                                                                <?php endforeach;?>
                                                                            </td>
                                                                        <?php else:?>
                                                                            <td>
                                                                                Payout will be proportional to the retention rate.<br/>
                                                                                If RR > <strong><?php echo $schedule['value']?>%</strong>, Full Payout.<br/>
                                                                                If RR = x, payout = x/<strong><?php echo $schedule['value']?>%</strong>*Full Payout.
                                                                            </td>
                                                                        <?php endif;?>
                                                                    </tr>
                                                                <?php endforeach;?>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                              <!-- End Modal -->
                        </td>
                        <td>
                            <b>
                            <?php 
                                if ($item['status']==0) {
                                    echo "Paused";
                                }elseif ($item['status']==1) {
                                    echo "Started";
                                }elseif ($item['status']==-2) {
                                    echo "Pending";
                                }else{
                                    echo "Deleted";
                                }
                            ?>
                            </b>
                        </td>
                        <td>
                            <?php 
                                if (!$item['next_status']) {
                                    echo "-";
                                }else{
                                    if ($item['next_status']['status']==0) {
                                        echo "Will pause at:".date('m/d/Y H:i a', $item['next_status']['effective_time']);
                                    }elseif ($item['next_status']['status']==-1) {
                                        echo "Will delete at:".date('m/d/Y H:i a', $item['next_status']['effective_time']);
                                    }elseif ($item['next_status']['status']==1) {
                                        echo "Will start at:".date('m/d/Y H:i a', $item['next_status']['effective_time']);
                                    }
                                }
                            ?>
                        </td>
                        <?php if($this->userinfo['type']==2):?>
                        <td> 
                            <?php if(isset($publisher_offer_account[$item['offer_id']])):?>
                                <?php if($publisher_offer_account[$item['offer_id']]['status']==0):?>
                                    <span class="label label-table label-danger">Applied</span><!--Applied  - 已申请-->
                                <?php elseif($publisher_offer_account[$item['offer_id']]['status']==1):?>
                                    <span class="label label-table label-success">Approved</span><!--Approved  - 已批准-->
                                <?php else:?>
                                    <span class="label label-dark">Disapproved</span><!--Disapproved  - 已否决-->
                                <?php endif;?>
                            <?php else:?>
                                <span class="label label-primary">Need Approval</span><!--Need Approval   - 需要审批-->
                            <?php endif;?>


                        </td>
                        <td class="actions">
                            <?php if(in_array($item['offer_id'], $apply_publisher_offer) && ($publisher_offer_account[$item['offer_id']]['status']==0 || $publisher_offer_account[$item['offer_id']]['status']==1)):?>
                                <button type="button" class="btn btn-raised btn-primary btn-sm disabled">Applied</button>
                            <?php else:?>
                                <button type="button" class="btn btn-sm btn-primary apply_offer_modal" data-target="#product_apply_offer" data-toggle="modal" data-id="<?php echo $item['offer_id']?>" data-country="<?php echo $item['countries']?implode(', ', $item['countries']):'All Countries';?>" data-include="<?php echo $item['choose_type']?>">Apply</button>
                            <?php endif;?>
                        </td>
                        <td>
                            <?php if(in_array($item['offer_id'], $apply_publisher_offer) && ($publisher_offer_account[$item['offer_id']]['status']==0 || $publisher_offer_account[$item['offer_id']]['status']==1)):?>
                            
                            <?php else:?>
                                <span class="checkbox-custom checkbox-primary">
                                    <input class="selectable-item checkbox_offer" type="checkbox" id="offer-<?php echo $item['offer_id']?>" value="<?php echo $item['offer_id']?>" >
                                    <label for="offer-<?php echo $item['offer_id']?>"></label>
                                </span>
                            <?php endif;?>
                        </td>
                        <?php endif;?>
                    </tr>
                <?php endforeach?>
            </tbody>
        </table>
        <div class="form-inline padding-bottom-15">
          <div class="row">
            <div class="pull-right" style="padding-right:15px">
              <div class="form-group">
                <?php if($this->userinfo['business']):?>
                <button class="btn btn-outline btn-primary btn-sm apply_offer_for_team" style="margin-right:6px;"><i class="icon wb-plus" aria-hidden="true"></i>Apply For Team
                                        </button>   
                <?php endif;?>


              </div>
            </div>
          </div>
        </div>
    </div>
</div>
<style type="text/css">
    .select2-container{
        z-index: 9999;
    }
    .select2-search__field{
        width: 100%;
    }
    .ui-timepicker-wrapper{
        z-index: 1700;
    }
</style>

<script src="<?php echo base_url();?>assets/web/global/vendor/icheck/icheck.min.js"></script>

<script src="<?php echo base_url();?>assets/web/global/js/components/icheck.js"></script>
