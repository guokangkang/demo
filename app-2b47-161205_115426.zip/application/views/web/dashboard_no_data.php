<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/assets/examples/css/pages/errors.css">
<div class="page animsition vertical-align text-center">
<div class="page-content vertical-align-middle">
    <header>
      <p class="margin-top-50">No Data !</p>
    </header>
  </div>
  </div>