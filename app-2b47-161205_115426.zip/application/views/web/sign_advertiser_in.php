<!DOCTYPE html>
<html class="no-js css-menubar" lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
  <meta name="description" content="bootstrap admin template">
  <meta name="author" content="">
  <title>Login Advertiser</title>
  <link rel="apple-touch-icon" href="<?php echo base_url();?>assets/web/assets/images/apple-touch-icon.png">
  <link rel="shortcut icon" href="<?php echo base_url();?>assets/web/assets/images/favicon.ico">
  <!-- Stylesheets -->
  <link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/css/bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/css/bootstrap-extend.min.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/web/assets/css/site.min.css">
  <!-- Plugins -->
  <link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/animsition/animsition.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/asscrollable/asScrollable.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/switchery/switchery.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/intro-js/introjs.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/slidepanel/slidePanel.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/flag-icon-css/flag-icon.css">
  <!-- 新加css -->
  <link rel="stylesheet" href="<?php echo base_url();?>assets/web/assets/examples/css/pages/login-v2.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/web/assets/examples/css/tables/location.default.css">
  <!-- Fonts -->
  <link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/fonts/web-icons/web-icons.min.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/fonts/brand-icons/brand-icons.min.css">
  <link rel='stylesheet' href='http://fonts.googleapis.com/css?family=Roboto:300,400,500,300italic'>
  <style>
    .page-login-v2:before {
      background-image: url("<?php echo base_url();?>assets/images/bg_advertiser.jpg")!important;
      z-index: 0!important;
    }
    .page-login-v2 .page{background: 0!important;}
    .page-login-v2 .page{max-width: 100%!important;}
  </style>
  <!--[if lt IE 9]>
    <script src="<?php echo base_url();?>assets/web/global/vendor/html5shiv/html5shiv.min.js"></script>
    <![endif]-->
  <!--[if lt IE 10]>
    <script src="<?php echo base_url();?>assets/web/global/vendor/media-match/media.match.min.js"></script>
    <script src="<?php echo base_url();?>assets/web/global/vendor/respond/respond.min.js"></script>
    <![endif]-->
  <!-- Scripts -->
  <script src="<?php echo base_url();?>assets/web/global/vendor/modernizr/modernizr.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/breakpoints/breakpoints.js"></script>
  <script>
  Breakpoints();
  </script>
</head>
<body class="page-login-v2 layout-full page-dark">
  <!--[if lt IE 8]>
        <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
    <![endif]-->
  <!-- Page -->
<div class="page animsition" data-animsition-in="fade-in" data-animsition-out="fade-out">
  <div class="page-content">
    <div class="page-brand-info margin-0">
      <div class="brand text-center" style="position:fixed;left: 50%;margin-left: -368px;bottom: 0;">
        <img class="brand-img" src="<?php echo base_url();?>assets/images/marketmax-white.png" alt="..." style="width:60px; height:48px;vertical-align: top;">
        <h3 class="inline-block font-size-24 margin-left-10" style="color:#fff; line-height:20px;">Palmax AdDigger</h3>
        <p class="margin-bottom-0" style="color:#fff;opacity:1;max-width:100%;">© 2016 PALMAX LIMITED</p>
        <p class="margin-bottom-0" style="color:#fff;opacity:1;max-width:100%;">All RIGHT RESERVED.</p>
      </div>
    </div>
    <div class="page-login-main" style="padding:150px 40px 180px; background:rgba(255,255,255,.4)">
      <div class="brand visible-xs">
        <img class="brand-img" src="<?php echo base_url();?>assets/images/marketmax-white.png" alt="..." style="width:60px; height:48px;vertical-align: top;">
        <h3 class="inline-block font-size-24 margin-left-10" style="color:#fff; line-height:20px;">Palmax AdDigger</h3>
      </div>
      <h3 class="font-size-28 text-center font-weight-600" style="color:#fff;">Advertiser</h3>
      <form class="margin-top-20" method="post" action="<?php echo site_url('sign/form_in')?>" id="signUpForm">
        <input type="hidden" name="type" value="advertiser">
        <div class="form-group">
          <div class="input-group input-group-icon">
            <span class="input-group-addon" style="background: rgba(255,255,255,0.6); border-right:0;">
              <span class="icon wb-user" aria-hidden="true" style="color:#3b434a;"></span>
            </span>
            <input type="text" class="form-control" id="inputEmail" name="input_email"  style="background:rgba(255,255,255,0.6);">
          </div>
        </div>
        <div class="form-group">
          <div class="input-group input-group-icon">
            <span class="input-group-addon" style="background: rgba(255,255,255,0.6); border-right:0;">
              <span class="icon wb-lock" aria-hidden="true" style="color:#3b434a;"></span>
            </span>
            <input type="password" class="form-control"  id="inputPassword" name="input_password" style="background:rgba(255,255,255,0.6);">
          </div>
        </div>
        <div class="form-group clearfix">
          <div class="checkbox-custom checkbox-inline checkbox-primary pull-left">
            <input type="checkbox" id="remember" name="checkbox" value="1">
            <label for="remember" style="color:#fff;">Remember me</label>
          </div>
        </div>
        <button type="submit" id="signUpButton" class="btn btn-primary btn_self btn-block" style="padding: 10px 15px;
    font-size: 16px; background:#12abc5;border:1px solid #12abc5;">Sign in</button>
      </form> 
    </div>
  </div>
</div>
  <!-- End Page -->
  <!-- Core  -->
  <script src="<?php echo base_url();?>assets/web/global/vendor/jquery/jquery.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/bootstrap/bootstrap.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/animsition/animsition.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/asscroll/jquery-asScroll.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/mousewheel/jquery.mousewheel.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/asscrollable/jquery.asScrollable.all.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/ashoverscroll/jquery-asHoverScroll.js"></script>
  <!-- Plugins -->
  <script src="<?php echo base_url();?>assets/web/global/vendor/switchery/switchery.min.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/intro-js/intro.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/screenfull/screenfull.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/slidepanel/jquery-slidePanel.js"></script>
  <!-- 新加js -->
  <script src="<?php echo base_url();?>assets/web/global/vendor/jquery-placeholder/jquery.placeholder.js"></script>
  <!-- Scripts -->
  <script src="<?php echo base_url();?>assets/web/global/js/core.js"></script>
  <script src="<?php echo base_url();?>assets/web/assets/js/site.js"></script>
  <script src="<?php echo base_url();?>assets/web/assets/js/sections/menu.js"></script>
  <script src="<?php echo base_url();?>assets/web/assets/js/sections/menubar.js"></script>
  <script src="<?php echo base_url();?>assets/web/assets/js/sections/sidebar.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/js/configs/config-colors.js"></script>
  <script src="<?php echo base_url();?>assets/web/assets/js/configs/config-tour.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/js/components/asscrollable.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/js/components/animsition.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/js/components/slidepanel.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/js/components/switchery.js"></script>
  <!-- 新加js -->
  <script src="<?php echo base_url();?>assets/web/global/js/components/jquery-placeholder.js"></script>
  <script>
  (function(document, window, $) {
    'use strict';
    var Site = window.Site;
    $(document).ready(function() {
      Site.run();
    });
    $('input').keydown(function(e){
      if(e.keyCode==13){
        $("#signUpButton").trigger("click");
      }
    });
  })(document, window, jQuery);
  </script>
</body>
</html>