<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/datatables-bootstrap/dataTables.bootstrap.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/datatables-fixedheader/dataTables.fixedHeader.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/datatables-responsive/dataTables.responsive.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/assets/examples/css/tables/datatable.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/bootstrap-select/bootstrap-select.css">

    <link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/select2/select2.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/bootstrap-datepicker/bootstrap-datepicker.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/bootstrap-select/bootstrap-select.css">

<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/select2/select2.css">

<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/bootstrap-datepicker/bootstrap-datepicker.css">
 <link rel="stylesheet" href="<?php echo base_url();?>assets/web/assets/examples/css/uikit/buttons.css">

<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/daterangepicker.css" />

<div class="page animsition">
    <div class="page-header ">
        <h1 class="page-title">Retention Report</h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo site_url('report')?>">Reports</a></li>
            <li class="active">Retention Report</li>
        </ol>
    </div>
    <div class="page-content">
        <div class="panel">
            
        </div>
        <?php if($month_list):?>
            <div class="panel panel-bordered animation-scale-up">
                <div class="panel-heading" style="border:0">
                  <h4 class="panel-title">Month Retention Rate (<?php echo $product_info['name']?>)</h4>
                  <div class="page-header-actions">
                      Date : <?php echo $time_region?>
                  </div>
                </div>
                <div class="panel-body container-fluid">
                    <div class="row row-lg">
                        <div class="col-sm-12">
                            <ul class="blocks blocks-100 blocks-xlg-6 blocks-md-4 blocks-lg-5 blocks-sm-2 month_ul"> 
                                <?php foreach($month_list as $key=>$row):?> 
                                    <li class="text-center"><h5><?php echo $row['country']?> : <?php echo $row['set_retention']."%"?> - <span <?php echo $row['ration']<$row['set_retention']?"style='color:#f96868'":"style='color:#3aa99e'"?>><?php echo $row['ration']."%"?></span></h5></li>
                                <?php endforeach;?> 
                            </ul>
                        </div>
                    </div>
                </div>
                
            </div>
        <?php endif;?>

        <div class="panel table-responsive">
            <div class="panel-heading" style="border:0">
              <h4 class="panel-title">Detail</h4>
              <div class="page-header-actions">
                  <a style="margin:0" href="<?php echo site_url('report/retention_report?product='.$this->input->get('product_id')."&country=".$this->input->get('country')."&account=".$this->input->get('account')."&time=".$this->input->get('time'))?>" class="btn btn-outline btn-primary pull-right excel_retention_report" type="button" >
                    <i class="icon wb-plus" aria-hidden="true"></i> Excel
                </a>
              </div>
            </div>
            <input type="hidden" class="params_data" data-product="<?php echo $this->input->get('product')?>" data-account="<?php echo $this->input->get('account')?>" data-country="<?php echo $this->input->get('country')?>" data-time="<?php echo $this->input->get('time')?>">
            <div class="panel-body container-fluid" style=" padding-bottom: 0;">
                <div class="row row-lg">
                    <div class="clearfix visible-md-block visible-lg-block"></div>
                    <div class="col-md-12">

                        <div class="example-wrap" style="margin-bottom:0;">
                            <!-- <div class="nav-tabs"></div> -->
                            <div class="example table-responsive" style="margin-bottom: 0; margin-top: 0;">
                                
                                <div class="col-md-12 col-lg-12">
                                    <!-- Example Multi Balue -->
                                    <div class="example-wrap">
                                        <div class="example">
                                            <form>                                                
                                                <div class="form-group filter-form advertiser-filter col-lg-1 col-md-1 col-xlg-1" style="margin-bottom:15px;line-height:36px;">
                                                    <label class="col-md-12 control-label">Filter: </label>
                                                </div> 
                                                
                                                <?php if($this->userinfo['type']==0 || $this->userinfo['type']==1):?>
                                                <div class="form-group filter-form product-filter col-lg-2 col-md-2 col-xlg-2" style="margin-bottom:15px;padding-left: 0;">
                                                    <select class="form-control select2-hidden-accessible filter_product" multiple="" data-plugin="select2" tabindex="-1" aria-hidden="true" data-placeholder="Agency Filter">
                                                        <?php foreach($agency_list as $product):?>
                                                            <option value="<?php echo $product['publisher_id']?>"  <?php echo (in_array($product['publisher_id'], $publisher_params))?"selected='selected'":''?>><?php echo $product['publisher_name']?></option>
                                                        <?php endforeach;?>
                                                    </select>
                                                </div>
                                                <?php endif;?>
                                                <div class="form-group filter-form account-filter col-lg-3 col-md-2 col-xlg-3" style="margin-bottom:15px;padding-left: 0;">
                                                    <select class="form-control select2-hidden-accessible filter_account" multiple="" data-plugin="select2" tabindex="-1" aria-hidden="true" data-placeholder="Account Filter">
                                                        <?php foreach($accountlist as $account):?>
                                                            <option value="<?php echo $account['account_id']?>" <?php echo (in_array($account['account_id'], $account_params))?"selected='selected'":''?>><?php echo $account['account_id']."(".$account['account_name'].')'?></option>
                                                        <?php endforeach;?>
                                                    </select>
                                                </div>
                                                <div class="form-group filter-form advertiser-filter col-lg-3 col-xlg-3 col-md-3" style="margin-bottom:15px;padding-left: 0;">
                                                    <select class="form-control select2-hidden-accessible filter_country" multiple="" data-plugin="select2" tabindex="-1" aria-hidden="true" data-placeholder="Country Filter">
                                                        <?php foreach($config_country['country'] as $key=> $country):?>
                                                            <option value="<?php echo $key?>" <?php echo (in_array($key, $country_params))?"selected='selected'":''?>><?php echo $key.'-'.$country?></option>
                                                        <?php endforeach;?>
                                                    </select>
                                                </div>

                                                <div class="form-group filter-form account-filter col-lg-3 col-md-3 col-xlg-3" style="text-align: center;padding-left: 0;">
                                                        <div id="reportrange" class="pull-left" style="background: #fff; cursor: pointer; padding: 5px 10px; border: 1px solid #ccc; ">
                                                            <i class="glyphicon glyphicon-calendar fa fa-calendar"></i>&nbsp;
                                                            <span></span> <b class="caret"></b>

                                                            <input type="hidden" value="" class="date_start" />
                                                            <input type="hidden" value="" class="date_end" />
                                                        <!-- <span class="input-group-addon">
                                                            <i class="icon wb-calendar" aria-hidden="true"></i>
                                                        </span>
                                                        <input type="text" class="form-control" id="input_date" value="<?php echo $this->input->get('time')?>"> -->
                                                    </div>
                                                </div>
        
                                            </form>

                                        </div>
                                    </div>
                                    <!-- End Example Multi Balue -->
                                </div>

                                
                            </div>   
                            <a  id="ad_list" name="ad_list"></a>                         
                            <div class="example example-buttons text-center" style="margin-bottom: 0;">
                                <button type="button" class="btn btn-outline btn-primary retention_report_search" data-val="<?php echo $this->input->get('product_id')?>">Search</button>

                                <button type="button" class="btn btn-outline btn-info retention_report_rest">Rest</button>

                            </div>

                        </div>
                    </div>
                </div>
            </div>
            <div class="panel-body container-fluid" style="padding-top: 0;" id="">
                <!-- <div class="example example-buttons text-center">
                    <button style="margin:0" class="btn btn-outline btn-primary pull-right excel_report" type="button" data-target="#add_bucket" data-toggle="modal">
                    <i class="icon wb-plus" aria-hidden="true"></i> Excel
                </button>
                </div> -->
                
                <table class="table table-hover dataTable table-striped width-full" id="facebook_retention">
                    <thead class="thead" id="thead">
                        <tr>
                            <th>Account</th>
                            <!-- <th class="text-right">Country</th> -->
                            <th class="text-right">CPA</th>
                            <th class="text-right">Payouts</th>
                            <th class="text-right">RR</th>
                            <th class="text-right">Results</th>
                            <!-- <th class="text-right">Amount Spent</th>
                            <th class="text-right">Real Earning</th>
                            <th class="text-right">Earning</th>
                            <th class="text-right">Real Profit</th>
                            <th class="text-right">Profit</th> -->
                            <th class="text-right">Payment Ratio</th>
                        </tr>
                    </thead>
                    
                    <tbody class="tbody">
                        <?php foreach($adset_data as $item):?>
                            <tr style="background-color: #f3f7f9;" class="report_retention_adset_tr">
                                <td style="color:#62a8ea">
                                    <?php echo $item['adset_name']."<br/>".
                                                $item['campaign_name']."<br/>".
                                                $item['account_id']
                                    ?>
                                </td>
                               <!--  <td class="text-right">
                                    <a class='tooltip-primary tooltip-rotate'  data-toggle='tooltip' data-original-title='<?php echo $item['country_info']?>' data-placement='top'><?php echo $item['country']?></a>
                                </td> -->
                                <td class="text-right">-</td>
                                <td class="text-right">-</td>
                                <td class="text-right">-</td>
                                <td class="text-right"><?php echo number_format($item['results'])?></td>
                                <!-- <td class="text-right">$<?php echo $item['spend']?></td>
                                <td class="text-right">$<?php echo $item['revenue']?></td>
                                <td class="text-right">$<?php echo $item['expect_revenue']?></td>
                                <td class="text-right" style="<?php echo $item['profit']<0?'color:#f96868':''?>">$<?php echo $item['profit']?></td>
                                <td class="text-right">$<?php echo $item['expect_profit']?></td> -->
                                <td class="text-right">-</td>
                            </tr>
                            <?php foreach($item['country'] as $val):?>
                                <tr>
                                    <td><?php echo $val['date'].'   '.$val['country'].' - '.$val['country_info']?></td>

                                    <td class="text-right">$<?php echo $val['cpa']?></td>
                                    <td class="text-right"><?php echo $val['payouts'];?></td>
                                    
                                    <?php if(isset($retentions[$val['adset_id']]) && isset($retentions[$val['adset_id']][strtotime($val['date'])]) && isset($retentions[$val['adset_id']][strtotime($val['date'])][$val['country']])):?>
                                        <td class="text-right" style="<?php echo $val['earning']<$val['expect_revenue']?'color:#f96868':'color:#3aa99e'?>"><?php echo $val['retention']?>%</td>
                                    <?php else:?>
                                        <td class="text-right">-</td>
                                    <?php endif;?>
                                    
                                    <td class="text-right"><?php echo number_format($val['results'])?></td>
                                    <!-- <td class="text-right">$<?php echo $val['spend']?></td>
                                    
                                    <td class="text-right">$<?php echo $val['revenue']?></td>
                                    
                                    <td class="text-right">$<?php echo $val['expect_revenue']?></td>
                                    
                                    <td class="text-right" style="<?php echo $val['profit']<0?'color:#f96868':''?>">$<?php echo $val['profit']?></td>
                                    
                                    
                                    <td class="text-right">$<?php echo $val['expect_profit']?></td> -->
                                    <td class="text-right"><?php echo $val['payment_ratio']==0?'-':$val['payment_ratio']."%"?></td>
                                </tr>
                            <?php endforeach;?>
                        <?php endforeach;?>

                    </tbody>
                </table>
                <div class="col-md-12">
                    <div class="fixed-table-pagination" style="display: block;">
                        <!-- <div class="pull-left pagination-detail">
                            <span class="pagination-info">Showing <?php echo $offer?> to <?php echo $limit?> of <?php echo $total_rows?> rows</span>
                            
                        </div> -->
                        <div class="pull-right pagination">
                            <?php echo $page_links?>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
</div>
<style type="text/css">
    .table-responsive{
        overflow-x:visible;
    }
    .datepicker-days { 
        display: none; 
    }  
</style>
<script type="text/javascript">
     $(function() {
        $('#input_date').datepicker({
            format: "MM yyyy",
            viewMode: "months", 
            minViewMode: "months"
        }).on('changeDate', function (ev) {
            var month = $(".datepicker-months span.active").html();
            var year = $(".datepicker-years span.active").html();
            //$(this).val(month+' '+year);
            $(this).datepicker('hide');
        }).val();
     });            
</script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/bootstrap-select/bootstrap-select.min.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/select2/select2.min.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/datatables/jquery.dataTables.min.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/datatables-fixedheader/dataTables.fixedHeader.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/datatables-bootstrap/dataTables.bootstrap.min.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/datatables-responsive/dataTables.responsive.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/datatables-tabletools/dataTables.tableTools.js"></script>

  <!--Custom-->
  <script src="<?php echo base_url();?>assets/web/global/vendor/jquery-placeholder/jquery.placeholder.min.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/formvalidation/formValidation.min.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/formvalidation/framework/bootstrap.min.js"></script>

  <script src="<?php echo base_url();?>assets/web/global/js/components/bootstrap-select.min.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/js/components/select2.min.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/js/components/bootstrap-datepicker.min.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/js/components/datatables.min.js"></script>
  <script src="<?php echo base_url();?>assets/web/assets/examples/js/tables/datatable.min.js"></script>
  <!--Custom-->
  <script src="<?php echo base_url();?>assets/web/global/js/components/jquery-placeholder.min.js"></script>
  <script src="<?php echo base_url();?>assets/web/assets/examples/js/forms/validation.js"></script>
  <script src="<?php echo base_url();?>assets/js/jquery.tabletoCSV.js" type="text/javascript" charset="utf-8"></script>



<script src="<?php echo base_url();?>assets/web/global/vendor/bootstrap-select/bootstrap-select.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/select2/select2.min.js"></script>
    
<script src="<?php echo base_url();?>assets/web/global/js/components/bootstrap-select.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/components/select2.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/bootstrap-datepicker/bootstrap-datepicker.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/js/components/bootstrap-datepicker.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/js/components/buttons.js"></script>

<script type="text/javascript" src="<?php echo base_url();?>assets/js/moment.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/daterangepicker.js"></script>
  


<script type="text/javascript">
    function cb(start, end) {
        $('#reportrange span').html(start.format('MM/DD/YYYY') + ' - ' + end.format('MM/DD/YYYY'));
        $(".date_start").val(start.format('MM/DD/YYYY'));
        $(".date_end").val(end.format('MM/DD/YYYY'));
    }

    cb(moment().subtract(3, 'days'), moment());

    <?php if($this->input->get('start')):?>
        $('#reportrange').daterangepicker({
            "startDate": "<?php echo urldecode($this->input->get('start'))?>",
            "endDate": "<?php echo urldecode($this->input->get('end'))?>",
            ranges: {
               'Today': [moment(), moment()],
               'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
               'Last 7 Days': [moment().subtract(6, 'days'), moment()],
               'Last 30 Days': [moment().subtract(29, 'days'), moment()],
               'This Month': [moment().startOf('month'), moment().endOf('month')],
               'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
            }
        }, cb); 
        $('#reportrange span').html("<?php echo urldecode($this->input->get('start'))?>" + ' - ' + "<?php echo urldecode($this->input->get('end'))?>");
        $(".date_start").val("<?php echo urldecode($this->input->get('start'))?>");
        $(".date_end").val("<?php echo urldecode($this->input->get('end'))?>");
    <?php else:?>
        $('#reportrange').daterangepicker({
            ranges: {
               'Today': [moment(), moment()],
               'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
               'Last 7 Days': [moment().subtract(6, 'days'), moment()],
               'Last 30 Days': [moment().subtract(29, 'days'), moment()],
               'This Month': [moment().startOf('month'), moment().endOf('month')],
               'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
            }
        }, cb); 
    <?php endif;?>

    
</script>


