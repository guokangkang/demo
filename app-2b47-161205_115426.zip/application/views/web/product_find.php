<link rel="stylesheet" href="<?php echo base_url();?>assets/web/assets/examples/css/forms/layouts.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/formvalidation/formValidation.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/assets/examples/css/forms/validation.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/select2/select2.css">
 <link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/bootstrap-datepicker/bootstrap-datepicker.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/jt-timepicker/jquery-timepicker.css">
<style>
  .pearl-icon{width: 30px; height: 30px; line-height: 30px; font-size: 14px;}
  .pearl:after, .pearl:before{top:15px;height:2px;}
  .pearl.current:after, .pearl.current:before{background-color:#12abc5;}
  .pearl.current .pearl-icon, .pearl.current .pearl-number{border:1px solid #12abc5;color:#12abc5;-webkit-transform: scale(1);transform: scale(1);}
  .form-control:focus{
    border:1px solid #12abc5;
  }
</style>
<div class="page animsition" style="animation-duration: 800ms; opacity: 1;">
    <div class="page-header ">
        <h1 class="page-title">Find Product</h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo site_url('setup/product')?>">Products Management</a></li>
            <li class="active">Find Product</li>
        </ol>
    </div>

    
    <div class="page-content">
        <div class="panel">
            <div class="panel-body container-fluid">
                <div class="pearls row col-xs-offset-3">
                <div class="pearl current col-xs-3">
                  <div class="pearl-icon"><i class="icon md-plus" aria-hidden="true"></i></div>
                </div>
                <div class="pearl col-xs-2">
                  <div class="pearl-icon"><i class="icon md-edit" aria-hidden="true"></i></div>
                </div>
                <div class="pearl col-xs-2">

                  <div class="pearl-icon"><i class="icon md-check" aria-hidden="true"></i></div>
                </div>
              </div>
                <div class="row row-lg row-form">
                    <div class="col-sm-offset-3 col-sm-6">
                        <!-- Example Basic Form -->
                        <div class="example-wrap" style="margin-bottom: 0;">
                             <h4 class="example-title"></h4>
     
                            <div class="example">
                                <form autocomplete="off" id="exampleStandardForm">
                                    <div class="form-group">
                                        <label class="control-label" for="app_id">
                                            Add a new product
                                            <!-- <span class="required">*</span> -->
                                        </label>
                                        <input type="text" class="form-control" id="app_id" name="input_object_stroy_url" placeholder="Add Store Url" autocomplete="off">
                                    </div>


                                    
                                    <div class="form-group form-submit">
                                        <button type="submit" class="btn btn_self btn-primary" id="validateButton2">Get Item</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <!-- End Example Basic Form -->
                    </div>

                </div>


                <div class="row loading_product" style="display:none">
                  <div class="col-sm-offset-3 col-md-6">
                    <div class="widget text-center">
                      <div class='text-center report_loading' style=""><div class='loader vertical-align-middle loader-ellipsis' data-type='ellipsis'></div></div>
                      
                    </div>
                  </div>
                </div>
                
            </div>
        </div>
    </div>
</div>
<style type="text/css">
    .loader.loader-default{
        background-color:inherit;
    }
</style>

<script type="text/javascript">
    function confirmsubmit(self) {
        var data = $(self).attr('data-value');
        var logo = $("#app_item").attr('data-logo');
        var name = $("#app_item").attr('data-name');
        var app_id = $("#app_item").attr('data-app_id');
        var object_store_url = $("#app_item").attr('data-object_store_url');
        var desc = $("#app_item").attr('data-desc');
        var category = $("#app_item").attr('data-category');
        var play_category = $("#app_item").attr('data-play_category');
        var score_info = $("#app_item").attr('data-score-info');
        var score = $("#app_item").attr('data-score');
        $.ajax({
            url:"<?php echo site_url('product/add_product_action')?>",
            type:'post',
            datatype:'json',
            data:{'data':data, 'logo':logo, 'name':name, 'app_id':app_id, object_store_url:object_store_url, 'desc':desc, 'category':category, 'play_category':play_category,'score':score,'score_info':score_info},
            success:function(data){
                if (data.success) {
                    location.href=data.url;
                }else{
                    error(data.msg);
                }
            }
        });
    }
    $(function(){
        $("#validateButton2").click(function(){
            
            var item_id = $("#app_id").val();
            if (item_id=='') {
              return false;
            }
            $(this).html('Loading');
            $(".loading_product").show();
            $.ajax({
                url:"<?php echo site_url('product/app_item')?>",
                type:'get',
                datatype:'json',
                data:{'item_id':item_id},
                success:function(data){
                    $("#validateButton2").html('Get Item');
                    $(".loading_product").hide();
                    if (!data.success) {
                        error(data.msg);
                        return false;
                    }else{
                        var html = "<div class='row' data-plugin='masonry' style='position: relative; height: 1342px;'>"+
                                    "<div class='col-sm-offset-3 col-md-6' >"+
                                      "<div class='widget'>"+
                                        "<div class='widget-header white bg-cyan-600 padding-30 clearfix'>"+
                                          "<a class='avatar avatar-100 pull-left margin-right-20' href='javascript:void(0)'>"+
                                            "<img src='"+data.data.logo+"' alt=''>"+
                                          "</a>"+
                                          "<div class='pull-left' style='width:76%;'>"+
                                            "<div class='font-size-20 margin-bottom-15'>"+data.data.name+"</div>"+
                                            "<p class='margin-bottom-5 text-nowrap'><i class='icon wb-large-point margin-right-10' aria-hidden='true' ></i>"+
                                              "<span class='text-break'>"+data.data.app_id+"</span>"+
                                            "</p>"+
                                            "<p class='margin-bottom-5 text-nowrap'><i class='icon wb-large-point margin-right-10' aria-hidden='true'></i>"+
                                              "<span class='text-break'>"+data.data.category+"</span>"+
                                            "</p>"+
                                            "<p class='margin-bottom-5 text-nowrap'><i class='icon wb-large-point margin-right-10' aria-hidden='true'></i>"+
                                              "<span class='text-break'><a style='color:#fff' href='"+data.data.object_store_url+"' target='_blank'>Obejct Store Url</a></span>"+
                                            "</p>"+
                                          "</div>"+
                                        "</div>"+
                                        "<button type='button' class='btn btn_self btn-primary btn-success margin-top-20' onclick='confirmsubmit(this)'>Next</button>"+
                                      "</div>"+
                                      "<input type='hidden' id='app_item' data-logo='"+data.data.logo+"' data-name='"+data.data.name+"' data-app_id='"+data.data.app_id+"' data-object_store_url='"+data.data.object_store_url+"' data-desc='"+data.data.desc+"' data-category='"+data.data.category+"' data-play_category='"+data.data.play_category+"' data-score='"+data.data.score+"' data-score-info='"+JSON.stringify(data.data.score_info)+"'>"+
                                    "</div>";

                        $(".row-form").after(html);
                    }
                }
            });
        });

    });
</script>

<!--Plugins-->
  <script src="<?php echo base_url();?>assets/web/global/vendor/jquery-placeholder/jquery.placeholder.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/formvalidation/formValidation.min.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/formvalidation/framework/bootstrap.min.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/select2/select2.min.js"></script>

    <script src="<?php echo base_url();?>assets/web/global/vendor/bootstrap-datepicker/bootstrap-datepicker.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/jt-timepicker/jquery.timepicker.min.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/datepair-js/datepair.min.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/datepair-js/jquery.datepair.min.js"></script>


   <!--Custom-->
  <script src="<?php echo base_url();?>assets/web/global/js/components/jquery-placeholder.js"></script>
  <script src="<?php echo base_url();?>assets/web/assets/examples/js/forms/validation.js"></script>
    
    <script src="<?php echo base_url();?>assets/web/global/js/components/bootstrap-datepicker.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/js/components/jt-timepicker.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/js/components/datepair-js.js"></script>

  <script src="<?php echo base_url();?>assets/web/global/js/components/select2.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/js/components/multi-select.js"></script>
  <script src="<?php echo base_url();?>assets/web/assets/examples/js/forms/advanced.js"></script>