<div class="site-menubar site-menubar-light">
    <div class="site-menubar-body">
        <div>
            <div>
                <ul class="site-menu">
                    <li class="site-menu-category">General</li>
                    <li class="site-menu-item <?php echo ($this->router->class=='agency'&&$this->router->method=='index')?'active':''?>">
                        <a href="<?php echo site_url('agency')?>">
                            <i class="site-menu-icon md-accounts-list-alt" aria-hidden="true"></i>
                            <span class="site-menu-title">Agency List</span>
                        </a>
                    </li>

                    <li class="site-menu-item <?php echo ($this->router->class=='agency'&&$this->router->method=='task')?'active':''?>">
                        <a href="<?php echo site_url('agency/task')?>">
                            <i class="site-menu-icon md-assignment" aria-hidden="true"></i>
                            <span class="site-menu-title">Agency Task</span>
                        </a>
                    </li>

                    <!-- <li class="site-menu-item <?php echo ($this->router->class=='agency'&&$this->router->method=='publisher')?'active':''?>">
                        <a href="<?php echo site_url('agency/publisher')?>">
                            <i class="site-menu-icon md-accounts-list" aria-hidden="true"></i>
                            <span class="site-menu-title">Publisher List</span>
                        </a>
                    </li> -->
                </ul>
            </div>
        </div>
    </div>
</div>