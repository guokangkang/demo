<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/fonts/font-awesome/font-awesome.css">

<div class="page animsition">
    <div class="page-header">        
        <ol class="breadcrumb">
            <li><a href="<?php echo site_url('user/account')?>">User</a></li>
            <li class="active">Facebook Connect</li>
        </ol> 
    </div>
    <div class="page-content"> 
        <?php if($userinfo['fb_active']):?>
        <?php if($this->userinfo['token_expires']>time()):?>
        <div class="panel widget-border">
            <header class="panel-heading">
                <h3 class="panel-title">Details</h3>
            </header>
            <div class="panel-body container-fluid table-responsive">
                <table class="table dataTable table-striped width-full" id="facebook_report">
                    <thead class="change_thead">
                        <tr>
                            <th>Account ID</th>
                            <th>Account Name</th>
                            <th>Currency</th>
                            <th>Timezone</th>
                            <th>Created Time</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($list as $item):?>
                            <tr>
                                <th><?php echo $item['account_id']?></th>
                                <th><?php echo $item['name']?></th>
                                <th><?php echo $item['currency']?></th>
                                <th><?php echo $item['backup']['created_time']['timezone']?></th>
                                <th><?php echo $item['backup']['created_time']['date']?></th>
                                <th>
                                    <a class="btn btn-sm btn-icon btn-pure btn-default on-default remove-row remove_account_button padding-0 padding-left-15" data-toggle="webuiPopover" data-target="webuiPopover0" data-val="<?php echo $item['account_id']?>">
                                        <i class="icon fa-trash" aria-hidden="true"></i>
                                    </a>
                                </th>
                            </tr>
                        <?php endforeach;?>
                        
                    </tbody>
                </table>
                <div class="text-center margin-top-30">
                    <span class="margin-right-20 block margin-bottom-10">
                        The token will be expired on <br/> <?php echo date('m/d/Y', $this->userinfo['token_expires'])?>
                    </span>
                    <a onclick="javascript:ToUrl(this, 2);return false;" class="btn btn-icon btn-round btn_self social-twitter" style="color:#fff!important;"><i class="icon md-facebook margin-right-5" aria-hidden="true"></i>Reconnect with Facebook</a>
                </div>
            </div>
        </div>
        <?php else:?> 
        <!-- 连接失败页面 -->
        <div class="text-center" style="padding-top:120px;">
            <img src="<?php echo base_url();?>assets/images/repeat.png">
            <h4 class="margin-top-30">Welcome To Palmax AdDigger</h4>
            <p style="line-height: 18px;">Please,log in with you Facebook account <br>to get started with Palmax AdDigger</p>
            <div class="col-md-2 col-md-offset-5 margin-top-20">
                <a onclick="javascript:ToUrl(this, 1);return false;" class="btn btn-icon btn_self btn-block social-twitter"><i class="icon md-facebook margin-right-5" aria-hidden="true"></i>Connect with Facebook</a>
            </div>
        </div>
        <?php endif;?>  
        <?php else:?> 
        <div class="text-center padding-top-80">
            <img src="<?php echo base_url();?>assets/images/welcome_pic.png">
            <h4 class="margin-top-30">Welcome To Palmax AdDigger</h4>
            <p style="line-height: 18px;">Please,log in with you Facebook account <br>to get started with Palmax AdDigger</p>
            <div class="col-md-2 col-md-offset-5 margin-top-20">
                <a onclick="javascript:ToUrl(this, 1);return false;" class="btn btn-icon btn_self btn-block social-twitter"><i class="icon md-facebook margin-right-5" aria-hidden="true"></i>Connect with Facebook</a>
            </div>
        </div>  
        <?php endif;?>       
    </div>
</div>

<script src="<?php echo base_url();?>assets/web/global/vendor/datatables/jquery.dataTables.js"></script>

<script src="<?php echo base_url();?>assets/web/global/js/components/datatables.js"></script>
<script src="<?php echo base_url();?>assets/web/assets/examples/js/tables/datatable.js"></script>

<script type="text/javascript">   
function ToUrl(self, type)   
{   
    $(".loading_facebook").show();
    if (type==2) {
        $(self).html('<i class="icon md-facebook margin-right-5" aria-hidden="true"></i>Connecting...');
    }else{
        $(self).html('<i class="icon md-facebook margin-right-5" aria-hidden="true"></i>Connecting...');
    }
    
    $(self).addClass('disabled');
    location.href="<?php echo $facebook_url?>";   
}   
</script>  

