<!-- 新加css -->
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/global/vendor/datatables-bootstrap/dataTables.bootstrap.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/global/vendor/datatables-fixedheader/dataTables.fixedHeader.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/global/vendor/datatables-responsive/dataTables.responsive.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/assets/examples/css/tables/datatable.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/global/fonts/material-design/material-design.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/assets/examples/css/uikit/icon.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/global/vendor/bootstrap-datepicker/bootstrap-datepicker.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/daterangepicker.css"/>

<style type="text/css">
    .table>tbody>tr>td {
    vertical-align: middle;
}
</style>
<div class="page animsition">
    <div class="page-header clearfix">
        <ol class="breadcrumb pull-left">
            <li><a href="<?php echo site_url('report/index');?>">Reports</a></li>
            <li class="active">Publisher</li>
        </ol>
        <div class="pull-right">
            <form>  
                <div class="form-group col-lg-3 col-xlg-3 filter-form account-filter margin-bottom-0" style="padding-left: 0;text-align: center;">
                    <div class="form-control" style="width: 227px;">
                        <div id="reportrange" class="pull-right">
                            <i class="glyphicon glyphicon-calendar fa fa-calendar"></i>&nbsp;
                            <span>08/07/2016 - 08/10/2016</span> <b class="caret"></b>

                            <input type="hidden" value="" class="date_start"/>
                            <input type="hidden" value="" class="date_end"/>
                        </div>
                    </div>
                </div> 
            </form>
        </div>
    </div>
    <div class="page-content"> 
        <div class="panel" style="box-shadow:none;border: 1px solid #e3eaec;">
            <div class="panel-heading">
                <h3 class="panel-title">Details</h3>
            </div>
            <div class="panel-body">
                <div class="table-responsive">
                   <table class="table table-hover dataTable table-striped" id="exampleFixedHeader">
                        <thead class="thead">
                            <tr>
                                <th>Publisher</th>
                                <th>Results</th>
                                <th>Spend</th>
                                <th>Earning</th>
                                <th>Real Earning</th>
                                <th>Real Profit</th>
                                <th>ROI</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody class="tbody">
                            <?php foreach($publisher_data as $item):?>
                                <tr>
                                    <td><?php echo $item['publisher_name']?></td>
                                    <td><?php echo number_format($item['results'])?></td>
                                    <td>
                                        <?php echo "$".sprintf("%.2f", $item['spend'])?>
                                        <?php 
                                            if ($item['real_data']) {
                                                echo " / <span style='color:red'>$".$item['real_data']['spend']."<span>";
                                            }
                                        ?>
                                    </td>
                                    <td>
                                        <?php echo "$".sprintf("%.2f", $item['earning'])?>
                                          
                                    </td>
                                    <td>
                                        <?php //echo "$".sprintf("%.2f", $item['real_earning'])?>
                                        <?php 
                                            if ($item['real_data']) {
                                                echo "<span style='color:red'>$".$item['real_data']['real_earning']."<span>";
                                            }
                                        ?>      
                                    </td>
                                    <td>
                                        <?php 
                                            if ($item['real_data']) {
                                                if ($item['real_data']['real_profit']>0) {
                                                    echo "$".$item['real_data']['real_earning']." - $".$item['real_data']['spend']." = <span style='color:green'>$".($item['real_data']['real_profit'])."</span>";
                                                }else{
                                                    echo "$".$item['real_data']['real_earning']." - $".$item['real_data']['spend']." = <span style='color:red'>$".($item['real_data']['real_profit'])."</span>";
                                                }
                                            }
                                        ?>
                                    </td>
                                    <td class="<?php echo $item['roi']>0?'green-600':'red-600'?>"><?php echo $item['roi']?>%</td>
                                    <td><a href="<?php echo site_url('publisher/daily?publisher='.$item['publisher_id'].'&start='.$start.'&end='.$end)?>" target="_blank">Detail</a></td>
                                </tr>
                            <?php endforeach;?>
                        </tbody>
                    </table>
                </div>
            </div> 
        </div>
        <!-- End Panel Table Tools -->
    </div>
</div>


<!-- 报错就加上 -->
  <script src="<?php echo base_url(); ?>assets/web/global/vendor/asrange/jquery-asRange.min.js"></script>

<!-- 新加js -->
<script src="<?php echo base_url(); ?>assets/web/global/vendor/datatables/jquery.dataTables.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/vendor/datatables-fixedheader/dataTables.fixedHeader.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/vendor/datatables-bootstrap/dataTables.bootstrap.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/vendor/datatables-responsive/dataTables.responsive.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/vendor/datatables-tabletools/dataTables.tableTools.js"></script>
<!-- 新加js -->
<script src="<?php echo base_url(); ?>assets/web/global/js/components/datatables.js"></script>
<script src="<?php echo base_url(); ?>assets/web/assets/examples/js/tables/datatable.js"></script>
<script src="<?php echo base_url(); ?>assets/web/assets/examples/js/uikit/icon.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/moment.min.js"></script>

<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/daterangepicker.js"></script>
<script>
    function cb(start, end, d) {
        $('#reportrange span').html(start.format('MM/DD/YYYY') + ' - ' + end.format('MM/DD/YYYY'));
        $(".date_start").val(start.format('MM/DD/YYYY'));
        $(".date_end").val(end.format('MM/DD/YYYY'));
        if (d!=undefined) {
            location.href = site_url + "report/publisher?start="+start.format('MM/DD/YYYY')+"&end="+end.format('MM/DD/YYYY');
        }
    }

    cb(moment().subtract(6, 'days'), moment());

    <?php if($this->input->get('start')):?>
        $('#reportrange').daterangepicker({
            "startDate": "<?php echo urldecode($this->input->get('start'))?>",
            "endDate": "<?php echo urldecode($this->input->get('end'))?>",
            ranges: {
                'Today': [moment(), moment()],
                'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                'This Month': [moment().startOf('month'), moment().endOf('month')],
                'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
            }
        }, cb);
        $('#reportrange span').html("<?php echo urldecode($this->input->get('start'))?>" + ' - ' + "<?php echo urldecode($this->input->get('end'))?>");
        $(".date_start").val("<?php echo urldecode($this->input->get('start'))?>");
        $(".date_end").val("<?php echo urldecode($this->input->get('end'))?>");
    <?php else:?>
    $('#reportrange').daterangepicker({
        ranges: {
            'Today': [moment(), moment()],
            'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
            'Last 7 Days': [moment().subtract(6, 'days'), moment()],
            'Last 30 Days': [moment().subtract(29, 'days'), moment()],
            'This Month': [moment().startOf('month'), moment().endOf('month')],
            'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
        }
    }, cb);
    <?php endif;?>    
</script>



