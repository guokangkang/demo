<!-- 新加css -->


<style>
    .table > thead > tr > th, .table > tbody > tr > td {
        padding: 4px;
        border: none;
    }

    @media (max-width: 767px) {
        .padding_right {
            padding-right: 40px !important
        }
    }

    @media (max-width: 476px) {
        .xs_row {
            margin-left: -6px;
            margin-right: -35px !important;
        }
    }
    .a_title:hover{color:#79848e;}
</style>
<!-- Page -->
<div class="page animsition">
    <div class="page-header clearfix">
        <ol class="breadcrumb pull-left">
            <li><a href="<?php echo site_url('product/listview'); ?>">Marketing</a></li>
            <li class="active">Products</li>
        </ol>
        <div class="pull-right">
            <?php if ($this->userinfo['type'] == 0): ?>
                <a href="<?php echo site_url('product/find'); ?>" class="btn btn-primary btn-round margin-right-15"
                   style="background:#12abc5;color:#fff!important;">
                    <i class="icon wb-plus" aria-hidden="true"></i>
                    Add product
                </a>
            <?php endif; ?>
            <div class="form-group pull-right margin-bottom-0">
                <div class="input-search margin-bottom-0">
                    <i class="input-search-icon wb-search" aria-hidden="true"></i>
                    <input type="text" class="form-control" name="q" placeholder="Search..."
                           value="<?php echo $this->input->get('q')?$this->input->get('q'):''; ?>">
                    <button type="button" class="input-search-close icon wb-close" aria-label="Close"></button>
                </div>
            </div>
        </div>
    </div>
    <div class="page-content">
        <?php if ($lists): ?>
            <?php foreach ($lists as &$list): ?>
                <?php $list['score_info']=$list['score_info']?json_decode($list['score_info'], true):0; ?>
                <div class="panel" style="border:1px solid #f2f2f2;">
                    <div class="panel-body padding-vertical-0 container-fluid">
                        <div class="row xs_row" style="margin-right:-45px;">
                            <div class="col-md-2 col-xs-12 text-center padding-top-30 padding_right">
                                <a href="<?php echo site_url('/product/detail/' . $list['product_id']); ?>"
                                   target="_blank"> <img style="border:0" class="img img-thumbnail"
                                                         src="<?php echo $list['logo']; ?>"></a>
                            </div>
                            <div class="col-md-8 col-xs-12 padding-top-30 padding-bottom-30 padding_right">
                                <div>
                                    <h3 class="panel-title padding-0 inline-block vertical-align-middle font-size-18"
                                        style="color:#3b434a;"><a
                                            href="<?php echo site_url('/product/detail/' . $list['product_id']); ?>"
                                            target="_blank" class="a_title"><?php echo $list['name']; ?></a></h3>
                                    <span
                                        class="label label-sm <?php echo $list['category'] == 'ios'?'label-warning':'label-success'; ?> inline-block"><?php echo strtoupper($list['category']); ?></span>
                                </div>
                                <p class="margin-bottom-0">ID : <?php echo $list['product_id']; ?></p>
                                <p class="margin-bottom-0" style="color:#79848e;"><strong
                                        style="color:#454d54;">Package</strong>
                                    : <?php echo $list['app_id']; ?></p>
                                <p class="margin-bottom-10 padding-right-10"
                                   style="color:#79848e; height:110px;overflow:hidden;"><strong style="color:#454d54; ">Description</strong>
                                    : <?php echo $list['description']; ?></p>
                                <p class="margin-bottom-0 btn btn-round btn-outline btn-default"
                                   style="white-space: initial;">
                                    <a href="<?php echo $list['object_store_url']; ?>" target="_blank" class="icondemo"
                                       style="color:#76838f!important;text-decoration: none;word-break: break-all;">
                                        <i class="md-link" aria-hidden="true"></i>
                                        <?php echo $list['object_store_url']; ?></a>
                                </p>
                            </div>
                            <div class="col-md-2 col-xs-12 padding-top-30"
                                 style="border-left:1px solid #f2f2f2; background:#fbfbfb; padding-bottom:37px; margin-left:-15px;">
                                <div class="text-center padding-top-10 margin-bottom-5" style="height:40px;">
                                    <div class="inline-block" style="height: 40px;vertical-align: middle;">
                                        <img class="img vertical-align-middle"
                                             src="<?php echo site_url() . ($list['category'] == 'android'?'assets/images/right_pic.png':'assets/images/apple_pic.png'); ?>">
                                    </div>
                                    <div class="inline-block">
                                        <span class="block" style="color:#a9b9b9;">Total Rate</span>
                                        <span class="block" style="margin-top:-5px;color:#a9b9b9;">
                                            <?php
                                            if ($list['score_info']) {
                                                if ($list['category'] == 'ios') {
                                                    echo $list['score_info'];
                                                } else {
                                                    echo $list['score_info']['total_count'];
                                                }
                                            } else {
                                                echo '-';
                                            }?>
                                        </span>
                                    </div>
                                </div>
                                <p class="<?php echo $list['category'] == 'ios'?'':'font-size-40'; ?> text-center margin-bottom-0" <?php echo $list['category'] == 'ios'?'style="font-size:64px;margin-top:20px;margin-bottom:14px;"':''; ?>><?php echo $list['score']?$list['score']:'-'; ?></p>
                                <!--星星-->
                                <p class="text-center"
                                   style="margin-top:-8px;<?php echo $list['category'] == 'ios'?'margin-bottom:42px;':''; ?>">
                                    <?php
                                    for ($i=1; $i <= 5; $i++) {
                                        if ($list['score'] > $i) {
                                            echo '<span class="icondemo margin-right-5"><i class="md-star" aria-hidden="true"></i> </span>';
                                        } else {
                                            echo '<span class="icondemo margin-right-5" style="color:#d8d8d8;"><i class="md-star" aria-hidden="true"></i> </span>';
                                        }
                                    }; ?>
                                </p>
                                <?php if ($list['category'] == 'android'): ?>
                                    <div>
                                        <div class="contextual-progress" style="position: relative; margin:14px auto;">
                                            <span class="font-size-12"
                                                  style="position:absolute;left: 0;top: -8px;">5</span>
                                            <div class="progress margin-left-15" data-goal="60" data-plugin="progress"
                                                 style="background:#d8d8d8;">
                                                <div class="progress-bar progress-bar-indicating active"
                                                     aria-valuemin="15" aria-valuemax="115" aria-valuenow="25"
                                                     role="progressbar"
                                                     style="width:<?php echo $list['score_info']['total_count']?round((int)str_replace(',', '', $list['score_info']['5']) / (int)str_replace(',', '', $list['score_info']['total_count']), 2) * 100:0; ?>%;background:#707070;">
                                                    <span
                                                        class="progress-label"><?php echo $list['score_info']['5']; ?></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="contextual-progress" style="position: relative; margin:14px auto;">
                                            <span class="font-size-12"
                                                  style="position:absolute;left: 0;top: -8px;">4</span>
                                            <div class="progress margin-left-15" data-goal="60" data-plugin="progress"
                                                 style="background:#d8d8d8;">
                                                <div class="progress-bar progress-bar-indicating active"
                                                     aria-valuemin="15" aria-valuemax="115" aria-valuenow="25"
                                                     role="progressbar"
                                                     style="width:<?php echo $list['score_info']['total_count']?round((int)str_replace(',', '', $list['score_info']['4']) / (int)str_replace(',', '', $list['score_info']['total_count']), 2) * 100:0; ?>%;background:#707070;">
                                                    <span class="progress-label"><?php echo $list['score_info']['4']; ?></span>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="contextual-progress" style="position: relative; margin:14px auto;">
                                            <span class="font-size-12"
                                                  style="position:absolute;left: 0;top: -8px;">3</span>
                                            <div class="progress margin-left-15" data-goal="60" data-plugin="progress"
                                                 style="background:#d8d8d8;">
                                                <div class="progress-bar progress-bar-indicating active"
                                                     aria-valuemin="15" aria-valuemax="115" aria-valuenow="25"
                                                     role="progressbar"
                                                     style="width:<?php echo $list['score_info']['total_count']?round((int)str_replace(',', '', $list['score_info']['3']) / (int)str_replace(',', '', $list['score_info']['total_count']), 2) * 100:0; ?>%;background:#707070;">
                                                    <span
                                                        class="progress-label"><?php echo $list['score_info']['3']; ?></span>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="contextual-progress" style="position: relative; margin:14px auto;">
                                            <span class="font-size-12"
                                                  style="position:absolute;left: 0;top: -8px;">2</span>
                                            <div class="progress margin-left-15" data-goal="60" data-plugin="progress"
                                                 style="background:#d8d8d8;">
                                                <div class="progress-bar progress-bar-indicating active"
                                                     aria-valuemin="15" aria-valuemax="115" aria-valuenow="25"
                                                     role="progressbar"
                                                     style="width:<?php echo $list['score_info']['total_count']?round((int)str_replace(',', '', $list['score_info']['2']) / (int)str_replace(',', '', $list['score_info']['total_count']), 2) * 100:0; ?>%;background:#707070;">
                                                    <span
                                                        class="progress-label"><?php echo $list['score_info']['2']; ?></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="contextual-progress" style="position: relative; margin:14px auto;">
                                            <span class="font-size-12"
                                                  style="position:absolute;left: 0;top: -8px;">1</span>
                                            <div class="progress margin-left-15" data-goal="60" data-plugin="progress"
                                                 style="background:#d8d8d8;">
                                                <div class="progress-bar progress-bar-indicating active"
                                                     aria-valuemin="15" aria-valuemax="115" aria-valuenow="25"
                                                     role="progressbar"
                                                     style="width:<?php echo $list['score_info']['total_count']?round((int)str_replace(',', '', $list['score_info']['1']) / (int)str_replace(',', '', $list['score_info']['total_count']), 2) * 100:0; ?>%;background:#707070;">
                                                    <span
                                                        class="progress-label"><?php echo $list['score_info']['1']; ?></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>

                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<!-- 新加js -->
<script src="<?php echo base_url(); ?>assets/web/global/vendor/datatables/jquery.dataTables.js"></script>

<!-- 新加js -->
<script src="<?php echo base_url(); ?>assets/web/global/js/components/datatables.js"></script>
<script src="<?php echo base_url(); ?>assets/web/assets/examples/js/tables/datatable.js"></script>
<script src="<?php echo base_url(); ?>assets/js/new_js.js"></script>

<script>
    $('.input-search').keydown(function (e) {
        var curKey = e.which;
        if (curKey == 13) {
            var url = '<?php echo site_url('product/listview?q=');?>';
            var data = $('input[name=q]').val();
            url = url + data;
            location.href = url;
        }
    });

    $('.input-search-close').click(function () {
        //$('.input-search-close').siblings('input').val('');
        location.href='<?php echo site_url('product/listview');?>';
    });
</script>