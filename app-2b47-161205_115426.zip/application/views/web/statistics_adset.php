<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/datatables-bootstrap/dataTables.bootstrap.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/datatables-fixedheader/dataTables.fixedHeader.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/datatables-responsive/dataTables.responsive.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/assets/examples/css/tables/datatable.css">
<script type="text/javascript" src="<?php echo base_url();?>assets/web/js/async.min.js"></script>


<script src="https://connect.facebook.com/en_US/sdk.js"></script>


<script type="text/javascript">
    $(function(){
        var token="<?php echo $this->userinfo['token']?>";
        var account_id = "<?php echo $this->uri->segment(3)?>";

        var currency = '<?php echo $currency?>';
        var facebookurl = "<?php echo $facebookurl?>";

        FB.init({ 
            appId: '515261858648099', 
            version: 'v2.7'
        });
        var html = [];
        var install = clicks = impressions = ctr = spend = cost = amount = 0;

        FB.api(
            facebookurl,
            'GET',
            {"fields":"name,status,campaign_id",'access_token':token, "limit":1000},
            function(response) {
                var data = response.data;
                var i=0;
                var campaigns = [];
                async.each(data, function(item, callback) {
                    async.waterfall([
                        function(callback) {//获取campaign名称
                            //因为异步问题，将其注释了，因为还没拿出数据，但是window定义的变量已经赋值了所以为空了
                            //
                            // if($.inArray(item.campaign_id, campaigns)<0) {
                            //     campaigns.push(item.campaign_id);
                            //     FB.api(item.campaign_id, 
                            //         'GET', 
                            //         {"fields":"name",'access_token':token, "limit":1000},
                            //         function(campaigninfo){
                            //             window['campaign'+item.campaign_id] = campaigninfo.name;
                            //             callback(null, campaigninfo.name, item);
                            //         }
                                    
                            //     );
                            // }else{
                            //     callback(null, window['campaign'+item.campaign_id], item);
                            // }
                            FB.api(item.campaign_id, 
                                'GET', 
                                {"fields":"name",'access_token':token, "limit":1000},
                                function(campaigninfo){
                                    window['campaign'+item.campaign_id] = campaigninfo.name;
                                    callback(null, campaigninfo.name, item);
                                }
                                
                            );
                        },
                        function(campaign_name, item, callback) {//获取adset统计
                            if (item.status=='ACTIVE') {
                                FB.api(item.id+'/insights?fields=clicks,ctr,impressions,spend,actions&date_preset=today', {'access_token':token}, function(response) {
                                    var url = "<?php echo site_url('statistics/ad/')?>/"+account_id+'/'+item.id;

                                    var tr = ["<a data-status='"+item.status+"' data-id='"+item.id+"' href='"+url+"'>"+item.name+"</a>", campaign_name, item.status, 0, 0, 0, 0, 0];
                                    var insights = response.data;
                                    
                                    if (insights!='') {
                                         insights = insights[0];
                                         var mobile_app_install = 0;
                                         if (insights.actions!='') {
                                            $.each(insights.actions, function(key, val){
                                                if (val.action_type=='mobile_app_install') {
                                                    mobile_app_install = parseInt(val.value);
                                                }
                                            });
                                         }
                                         
                                        tr[3] = mobile_app_install;
                                        tr[4] = insights.clicks;
                                        tr[5] = insights.impressions;
                                        tr[6] = insights.ctr.toFixed(2)+"%";
                                        tr[7] = currency+insights.spend.toFixed(2);

                                        if (parseInt(insights.impressions)>0) {
                                            install += mobile_app_install;
                                            clicks += parseInt(insights.clicks);
                                            impressions += parseInt(insights.impressions);
                                            ctr += parseFloat(insights.ctr);
                                            spend += parseFloat(insights.spend);

                                            amount += 1;
                                        }
                                     }else{
                                        tr[3] = tr[4] = tr[5] = tr[6] = tr[7] = 0;
                                     }
                                    html[i++] = tr;
                                    callback(null, html);
                                });
                            }else{
                                var url = "<?php echo site_url('statistics/ad/')?>/"+account_id+'/'+item.id;
                                    var tr = ["<a data-status='"+item.status+"' data-id='"+item.id+"' href='"+url+"'>"+item.name+"</a>", campaign_name, item.status, 0, 0, 0, 0, 0];
                                html[i++] = tr;
                                callback(null, html);
                            }
                        }
                    ], function (err) {
                        callback();
                    });
                    
                    
                }, function(){
                    // console.log(html);
                    $(".impressionsNum").html(impressions);
                    $(".clicksNum").html(clicks);
                    $(".ctrNum").html((ctr/amount).toFixed(2)+"%");
                    $(".spendNum").html("$"+spend.toFixed(2));
                    $(".costNum").html("$"+((spend/install).toFixed(2)));

                    var defaults = $.components.getDefaults("dataTable");
                    var options = $.extend(true, {}, defaults, {
                        //"bSort" : false,
                        'iDisplayLength':50,
                        "data"  : html,
                        "order": [[ 3, "desc" ]],
                        columnDefs: [
                            {
                              targets: 0, 
                              className: 'campaignname'
                            }
                          ]
                    });
                    $('#exampleTableTools1').DataTable(options);
                });
                
            }
        );


        $(".choosedate li a").click(function(){
            var install = clicks = impressions = ctr = spend = cost = amount = 0;
            $(".loading").show();
            $(".table").addClass('fetching');
            var date = $(this).html();
            var data_v = $(this).attr('data-v');
            $("#exampleHoverDropdown3").html(date+'<span class="icon wb-calendar"></span>');
            $(".choosedate li").removeClass('active');
            $(this).parent('li').addClass('active');

            /**
             * 这块有bug
             * 分页的数据拿不到，
             * 应该使用原始campaign数据来读取数据整个替换掉
             * @type {Array}
             */
            var datalist = [];
            $(".campaignname a").each(function(i){
                if ($(this).attr('data-status') == 'ACTIVE') {
                    datalist[i] = {'data_id':$(this).attr('data-id'), 'data_status':$(this).attr('data-status'), 'self':$(this)};
                }
                
            });
            
            async.each(datalist, function(item, callback) {
                if (item.data_status=='ACTIVE') {

                    FB.api(item.data_id+'/insights?fields=clicks,ctr,impressions,actions,spend&date_preset='+data_v, {'access_token':token}, function(response) {
                        var insights = response.data;
                        if (insights!='') {
                            insights = insights[0];

                            var mobile_app_install = 0;
                            if (insights.actions!='') {
                                $.each(insights.actions, function(key, val){
                                    if (val.action_type=='mobile_app_install') {
                                        mobile_app_install = parseInt(val.value);
                                    }
                                });
                            }

                            if (parseInt(insights.impressions)>0) {
                                install += mobile_app_install;
                                clicks += parseInt(insights.clicks);
                                impressions += parseInt(insights.impressions);
                                ctr += parseFloat(insights.ctr);
                                spend += parseFloat(insights.spend);

                                amount += 1;
                            }
                            

                            
                            item.self.parents('tr').children().eq(3).html(mobile_app_install);
                            item.self.parents('tr').children().eq(4).html(insights.clicks);
                            item.self.parents('tr').children().eq(5).html(insights.impressions);
                            item.self.parents('tr').children().eq(6).html(insights.ctr.toFixed(2)+"%");
                            item.self.parents('tr').children().eq(7).html(currency+insights.spend.toFixed(2));
                        }
                        callback(null);
                    });

                    //console.log(impressions);
                }
            }, function(ss){
                $(".impressionsNum").html(impressions);
                $(".clicksNum").html(clicks);
                $(".ctrNum").html((ctr/amount).toFixed(2)+"%");
                $(".spendNum").html("$"+spend.toFixed(2));
                $(".costNum").html("$"+((spend/install).toFixed(2)));
                $(".loading").hide();
                $(".table").removeClass('fetching');

            });

            
            
            
        });
    });
    

</script>
<!-- Page -->
<div class="page animsition">
    <div class="page-header page-header-bordered page-header-tabs">
        <!-- <ol class="breadcrumb">
            <li><a href="../index.html">Home</a></li>
            <li class="active">Pages</li>
        </ol> -->
        <h1 class="page-title">Adset</h1>
        <div class="page-header-actions" style="z-index: 999;">
            <button type="button" class="btn btn-primary dropdown-toggle" id="exampleHoverDropdown3"
                    data-toggle="dropdown" aria-expanded="false" data-hover="dropdown">Today
                <span class="icon wb-calendar"></span>
            </button>
            <ul class="dropdown-menu animate dropdown-menu-right choosedate" aria-labelledby="exampleHoverDropdown3" role="menu">
                <li role="presentation"><a href="javascript:void(0)" role="menuitem" data-v="lifetime">Lifetime</a></li>
                <li role="presentation" class="active"><a href="javascript:void(0)" role="menuitem" data-v="today">Today</a></li>
                <li role="presentation"><a href="javascript:void(0)" role="menuitem" data-v="yesterday">Yesterday</a></li>
                <li role="presentation"><a href="javascript:void(0)" role="menuitem"  data-v="last_7_days">Last 7 days</a></li>
                <li role="presentation"><a href="javascript:void(0)" role="menuitem" data-v="last_14_days">Last 14 days</a></li>
                <li role="presentation"><a href="javascript:void(0)" role="menuitem" data-v="last_30_days">Last 30 days</a></li>
                <li role="presentation"><a href="javascript:void(0)" role="menuitem" data-v="last_month">Last month</a></li>
                <li role="presentation"><a href="javascript:void(0)" role="menuitem" data-v="this_month">This month</a></li>
            </ul>
        </div>
        <ul class="nav nav-tabs nav-tabs-line" role="tablist">
            <li role="presentation">
                <a href="<?php echo site_url('statistics/campaign/'.$this->uri->segment(3))?>" aria-controls="exampleList" aria-expanded="true" role="tab" data-filter="*">Campaigns</a>
            </li>
            <li class="active" role="presentation">
                <a href="<?php echo site_url('statistics/adset/'.$this->uri->segment(3))?>" aria-expanded="false" role="tab" data-filter="object">AdSets</a>
            </li>
            <li role="presentation">
                <a href="<?php echo site_url('statistics/ad/'.$this->uri->segment(3))?>" aria-expanded="false" role="tab" data-filter="city">Ads</a>
            </li>
        </ul>
    </div>
    <div class="page-content">
        <div class="panel panel-bordered animation-scale-up">
            <div class="panel-heading" style="padding: 20px 10px;">
                <div class="row no-space hidden-xs">
                    
                    <div class="col-xs-1">
                        <div class="counter">
                            <span class="counter-number font-weight-medium impressionsNum">-</span>
                            <div class="counter-label">Impressions</div>
                        </div>
                    </div>
                    <div class="col-xs-1">
                        <div class="counter">
                            <span class="counter-number font-weight-medium clicksNum">-</span>
                            <div class="counter-label">Clicks</div>
                        </div>
                    </div>
                    <div class="col-xs-1">
                        <div class="counter">
                            <span class="counter-number font-weight-medium ctrNum">-</span>
                            <div class="counter-label">CTR</div>
                        </div>
                    </div>
                    <div class="col-xs-1">
                        <div class="counter">
                            <span class="counter-number font-weight-medium spendNum">-</span>
                            <div class="counter-label">Spend</div>
                        </div>
                    </div>
                    <div class="col-xs-1">
                        <div class="counter">
                            <span class="counter-number font-weight-medium costNum">-</span>
                            <div class="counter-label">cost</div>
                        </div>
                    </div>
                    
                </div>
            </div>
            
        </div>
        <div class="panel">
            <div class="panel-body">
                <style type="text/css">
                    .loading{
                        display: none;
                    }
                    table.fetching{
                        opacity: 0.5;
                    }
                    .example-well{
                        background-color:#fff;
                    }
                    @keyframes loader-ellipsis{
                        0%, 100%, 80% {
                            -webkit-box-shadow: 0 .625em 0 -.325em #a3afb7;
                            box-shadow: 0 .625em 0 -.325em #4397e6;
                        }
                        40% {
                            -webkit-box-shadow: 0 .625em 0 0 #a3afb7;
                            box-shadow: 0 .625em 0 0 #4397e6;
                        }
                    }
                    animation: loader-ellipsis 1.8s infinite ease-in-out;

                </style>
                <div class="col-md-12 example-loading example-well height-350 vertical-align text-center loading" style="position: absolute;">
                    <div class="loader vertical-align-middle" style="z-index: 999" data-type="ellipsis"></div>
                </div>
                <table class="table table-hover dataTable table-striped width-full" id="exampleTableTools1">
                    <thead>
                      <tr>
                        <th>Ad set name</th>
                        <th>Campaign name</th>
                        <th>Status</th>
                        <th>Results</th>
                        <th>Clicks</th>
                        <th>Impressions</th>
                        <th>CTR</th>
                        <th>Spend</th>
                      </tr>
                    </thead>
                    <tfoot>
                      <tr>
                        <th>Ad set name</th>
                        <th>Campaign name</th>
                        <th>Status</th>
                        <th>Results</th>
                        <th>Clicks</th>
                        <th>Impressions</th>
                        <th>CTR</th>
                        <th>Spend</th>
                      </tr>
                    </tfoot>
                    <tbody>
                      
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<!-- End Page -->
<script src="<?php echo base_url();?>assets/web/global/vendor/datatables/jquery.dataTables.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/datatables-fixedheader/dataTables.fixedHeader.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/datatables-bootstrap/dataTables.bootstrap.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/datatables-responsive/dataTables.responsive.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/datatables-tabletools/dataTables.tableTools.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/asrange/jquery-asRange.min.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/bootbox/bootbox.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/js/components/datatables.js"></script>

  <script src="<?php echo base_url();?>assets/web/assets/examples/js/tables/datatable.js"></script>
  <script src="<?php echo base_url();?>assets/web/assets/examples/js/advanced/animation.js"></script>

