<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/select2/select2.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/bootstrap-select/bootstrap-select.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/webui-popover/webui-popover.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/toolbar/toolbar.css">
<style>
    .table>thead>tr>th,.table>tbody>tr>td{padding:4px;border:none;}
    @media (max-width: 767px) {
        .padding_right{padding-right: 40px!important}
    }
    @media (max-width:476px) {
        .xs_row{margin-left: -6px;margin-right: -35px!important;}
    }
    .bootstrap-select:not([class*="col-"]):not([class*="form-control"]):not(.input-group-btn) {
        width: 100px;
    }
    .popover{z-index: 1000;}
    a.btn-sm{color:#79848e;}
    a.btn-sm:hover{color:#3b434a;}
    .btn-group.open .btn-select, .btn-select:focus{border-color: #12abc5 !important;}
    .dropdown-menu a {color:#76838f!important;}
    .dropdown-menu .selected a{color:#12abc5!important;}
</style>
<div class="page animsition">
    <div class="page-header clearfix">        
        <ol class="breadcrumb">
            <li><a href="<?php echo site_url('manager/product/listview')?>">Manager Management</a></li>
            <li><a href="<?php echo site_url('manager/product/listview')?>">Products Management</a></li>
            <li class="active">Listview</li>
        </ol> 
        <div class="clearfix margin-top-30">
            <div class="pull-left">
                <select data-plugin="selectpicker" class="search_status">
                    <option value="" <?php echo $this->input->get('status')==''?"selected=''":''?>>All</option>
                    <option value="1" <?php echo $this->input->get('status')==1?"selected=''":''?>>Active</option>
                    <option value="-1" <?php echo is_numeric($this->input->get('status')) && $this->input->get('status')==0?"selected=''":''?>>Paused</option>
                </select>
            </div>
            <div class="pull-right">
                <a href="<?php echo site_url('manager/product/find')?>" class="btn btn-primary btn-round margin-right-15 pull-left" style="background:#12abc5;color:#fff!important;">
                    <i class="icon wb-plus" aria-hidden="true"></i>
                    Add product
                </a>
                <div class="form-group pull-right margin-bottom-0">
                    <div class="input-search margin-bottom-0">
                        <i class="input-search-icon wb-search" aria-hidden="true"></i>
                        <input type="text" class="form-control search_product" name="" placeholder="Search..." value="<?php echo trim($this->input->get('q'))?>">
                        <button type="button" class="input-search-close icon wb-close close_search_product" aria-label="Close"></button>
                    </div>
                </div>
            </div>
        </div>    
    </div>
    <div class="page-content"> 
        <?php foreach($listview as $item):?>
            <div class="panel" style="border:1px solid #f2f2f2;">
                <div class="panel-body padding-vertical-0 container-fluid">
                    <div class="row xs_row" style="margin-right:-45px;">
                        <div class="col-md-2 col-xs-12 text-center padding-top-30 padding_right">
                            <a href="<?php echo site_url('manager/offer/listview?product='.$item['product_id'])?>" target="_blank">
                                <img style="border:0" class="img img-thumbnail" src="<?php echo $item['logo']; ?>" >
                            </a>
                        </div>
                        <div class="col-md-8 col-xs-12 padding-top-30 padding-bottom-30 padding_right">
                            <div class="clearfix">
                                <div class="pull-left">
                                    <a href="<?php echo site_url('manager/offer/listview?product='.$item['product_id'])?>" target="_blank">
                                        <h3 class="panel-title padding-0 inline-block vertical-align-middle font-size-18" style="color:#3b434a;"><?php echo $item['name']?></h3>
                                    </a>
                                    <span class="label label-sm label-success inline-block"><?php echo strtoupper($item['category'])?></span>
                                </div>
                                
                                <div class="pull-right margin-right-10">
                                    <span style="<?php echo $item['status']==1?'color:#b1cf92':'color:#79848E'?>; margin-right:8px;"><?php echo $item['status']==1?'Active':'Paused'?></span>
                                    <?php if($item['status']==1 || $item['status']==0):?>
                                        <a href="<?php echo site_url('manager/product/confirm?product='.$item['product_id'])?>" class="btn btn-sm btn-icon btn-pure btn-default on-default edit-row" >   
                                            <i class="icon md-edit" aria-hidden="true"></i>
                                        </a>
                                        <a class="btn btn-sm btn-icon btn-pure btn-default on-default remove-row remove_product_button" data-toggle="popover" data-val="<?php echo $item['product_id']?>">
                                            <i class="icon wb-trash" aria-hidden="true"></i>
                                        </a>
                                    <?php endif;?>
                                </div>
                                
                            </div>
                            <p class="margin-bottom-0">ID : <?php echo $item['product_id']?></p>
                            <p class="margin-bottom-0" style="color:#79848e;"><strong style="color:#454d54; ">Advertiser</strong> : <?php echo $item['user_name']?></p>
                            <p class="margin-bottom-10 padding-right-10" style="color:#79848e; height:110px;overflow:hidden;"><strong style="color:#454d54; ">Description</strong> : <?php echo $item['description']?></p>
                            <p class="margin-bottom-0 btn btn-round btn-outline btn-default" style="white-space: initial;">
                                <a href="<?php echo $item['object_store_url']?>" target="_blank" class="icondemo" style="color:#76838f!important;text-decoration: none;word-break: break-all;">
                                    <i class="md-link" aria-hidden="true"></i>
                                    <?php echo $item['object_store_url']?>
                                </a>
                            </p>
                        </div>
                        <div class="col-md-2 col-xs-12 padding-top-30" style="border-left:1px solid #f2f2f2; background:#fbfbfb; padding-bottom:37px; margin-left:-15px;">
                            <div class="text-center padding-top-10 margin-bottom-5" style="height:40px;">
                                <div class="inline-block" style="height: 40px;vertical-align: middle;">
                                    <img class="img vertical-align-middle" src="<?php echo base_url() . ($item['category'] == 'android'?'assets/images/right_pic.png':'assets/images/apple_pic.png'); ?>">
                                </div>
                                <div class="inline-block">
                                    <span class="block" style="color:#a9b9b9;">Total Rate</span>
                                    <span class="block" style="margin-top:-5px;color:#a9b9b9;">
                                        <?php
                                            if ($item['score_info']) {
                                                if ($item['category'] == 'ios') {
                                                    echo number_format($item['score_info']);
                                                } else {
                                                    echo number_format($item['score_info']['total_count']);
                                                }
                                            } else {
                                                echo '-';
                                            }?>
                                    </span>
                                </div>
                            </div>
                            <?php if($item['category']=='android'):?>
                                <p class="font-size-40 text-center margin-bottom-0"><?php echo $item['score']?$item['score']:'-'?></p>
                            <?php else:?>
                                <p class="text-center" style="font-size:64px;margin-top:20px;margin-bottom:14px;"><?php echo $item['score']?$item['score']:'-'?></p>
                            <?php endif;?>
                            <p class="text-center" style="margin-top:-8px;<?php echo ($item['category']=='android')?'margin-bottom:28px;':''?>">
                                <?php for($i=1; $i<=$item['score']; $i++):?>
                                    <span class="icondemo margin-right-5">
                                        <i class="md-star" aria-hidden="true"></i>
                                    </span>
                                <?php endfor;?>
                                <?php for($i=$item['score']; $i<5; $i++):?>
                                    <span class="icondemo margin-right-5" style="color:#d8d8d8;">
                                        <i class="md-star" aria-hidden="true"></i>
                                    </span>
                                <?php endfor;?>
                                
                            </p>
                            <?php if($item['category']=='android' && $item['score_info']):?>
                                <div>
                                    <?php for($i=5; $i>=1; $i--):?>
                                        <div class="contextual-progress" style="position: relative; margin:14px auto;">
                                            <span class="font-size-12" style="position:absolute;left: 0;top: -8px;"><?php echo $i?></span>
                                            <div class="progress margin-left-15" data-goal="60" data-plugin="progress" style="background:#d8d8d8;">
                                                <div class="progress-bar progress-bar-indicating active" aria-valuemin="15" aria-valuemax="115" aria-valuenow="25" role="progressbar" style="width:<?php echo $item['score_info'][$i]/$item['score_info']['total_count']*100?>%;background:#707070;">
                                                    <span class="progress-label"><?php echo $item['score_info'][$i]/$item['score_info']['total_count']*100?></span>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endfor;?>
                                </div>
                            <?php endif;?>
                        </div>
                    </div>
                </div>
            </div> 
        <?php endforeach;?>
        <div class="fixed-table-pagination clearfix">
            <div class="pull-right">
                <?php echo $page_links?>
            </div>
        </div>
    </div>
</div>

<script src="<?php echo base_url();?>assets/web/global/vendor/datatables/jquery.dataTables.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/components/datatables.js"></script>
<script src="<?php echo base_url();?>assets/web/assets/examples/js/tables/datatable.js"></script>
<script src="<?php echo base_url();?>assets/js/new_js.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/select2/select2.min.js"></script>  
<script src="<?php echo base_url();?>assets/web/global/js/components/select2.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/bootstrap-select/bootstrap-select.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/components/bootstrap-select.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/webui-popover/jquery.webui-popover.min.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/toolbar/jquery.toolbar.min.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/components/webui-popover.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/components/toolbar.js"></script>
<script src="<?php echo base_url();?>assets/web/assets/examples/js/uikit/tooltip-popover.js"></script>
<script>
    $(function(){
        $('.search_product').keydown(function(e){
            if(e.keyCode==13){
                var keyword = $(this).val();
                var status = $(".search_status").val();
                location.href = site_url + 'manager/product/listview?q=' + keyword + '&status=' + status;
            }
        });
        $(".close_search_product").click(function(){
            var status = $(".search_status").val();
            location.href = site_url + 'manager/product/listview?status='+status;
        });
        $(".search_status").change(function(){
            var status = $(this).val();
            var keyword = $('.search_product').val();
            
            location.href = site_url + 'manager/product/listview?q=' + keyword + '&status=' + status;
            return false;    
        });
    });
</script>



