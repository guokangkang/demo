
<div class="page animsition">
    <div class="page-header ">
        <h1 class="page-title">Business Accounts</h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo site_url('business/users')?>">Business Manager</a></li>
            <li class="active">Business Accounts</li>
        </ol>
    </div>
    <div class="page-content">
        <div class="panel panel-bordered panel-default table-responsive">
            <div class="panel-body">
                
                <table class="table table-hover dataTable table-striped width-full verticaltop" id="business_accounts" data-selectable="selectable" data-row-selectable="true">
                    <thead>
                      <tr>
                        <th style="width: 20%">Business ID</th>
                        <th style="width: 20%">Business Name</th>
                        <th style="width: 20%">Publisher Name</th>
                        <th style="width: 40%">Account</th>
                      </tr>
                    </thead>
                    <tbody>
                        <?php foreach($account_list as $item):?>
                            <tr>
                                <td>
                                    <?php echo $item['business_id']?>
                                </td>
                                <td>
                                    <?php echo $item['business_name']?>
                                </td>
                                <td>
                                    <?php echo $item['publisher_name']?>
                                </td>
                                <td>
                                    <div style="overflow: hidden;height: 20px;">
                                        <?php foreach($item['account_id'] as $key=>$account_id):?>
                                            <?php if($key==0):?>
                                                (<?php echo count($item['account_id'])?> Accounts)
                                                <a class="show_account_details" href="javascript:void(0)">More</a>
                                            <?php endif;?>
                                            <br/>
                                            <?php echo $account_id?>
                                            
                                        <?php endforeach;?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
