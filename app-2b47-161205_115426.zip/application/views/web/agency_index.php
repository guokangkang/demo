<!-- 新加css -->
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/assets/examples/css/advanced/masonry.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/assets/examples/css/charts/pie-progress.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/global/vendor/aspieprogress/asPieProgress.css">
<style>
    .table > tbody > tr > td {
        vertical-align: middle;
    }

    .ad_circle {
        width: 100px;
        height: 100px;
        border-radius: 50%;
        background: rgba(255, 255, 255, 0.2);
        position: absolute;
        left: -16px;
        top: -29px;
        font-size: 54px;
        font-weight: bold;
        line-height: 100px;
        text-align: center;
    }

    .tool_label {
        width: 10px;
        height: 16px;
        background: url(<?php echo base_url();?>assets/images/white_half.png) no-repeat;
    }

    .text_label {
        color: #929ba3;
        padding: 4px 6px 4px 4px;
        background: #fff;
        border-radius: 0 3px 3px 0;
        font-size: 12px;
        line-height: 8px;
    }

    .btn_detail {
        border: 1px solid #fff;
        color: #fff;
        padding: 0px 13px;
    }

    .btn_detail:hover {
        background-color: #6D8E9C;
        color: #fff;
    }

    .leaf_box i {
        display: block;
        width: 18px;
        height: 4px;
        margin-bottom: 3px;
    }

    .leaf_box i.leaf_all {
        background: url(<?php echo base_url();?>assets/images/leaf_all.png) no-repeat;
    }

    .leaf_box i.leaf_half {
        background: url(<?php echo base_url();?>assets/images/leaf_half.png) no-repeat;
    }

    .leaf_box i.leaf_grey {
        background: url(<?php echo base_url();?>assets/images/leaf_grey.png) no-repeat;
    }

    .publisher_btn_detail {
        border: 1px solid #79848e;
        color: #79848e;
        padding: 0px 13px;
    }

    .publisher_btn_detail:hover {
        background-color: #d8d8d8;
    }

    .publisher_tool_label {
        width: 10px;
        height: 16px;
        background: url(<?php echo base_url();?>assets/images/grey_half.png) no-repeat;
    }

    .publisher_text_label {
        color: #fff;
        padding: 4px 6px 4px 4px;
        background: #b0bdc6;
        border-radius: 0 3px 3px 0;
        font-size: 12px;
        line-height: 8px;
    }
</style>

<div class="page animsition">
    <div class="page-header">
      <ol class="breadcrumb">
        <li><a href="<?php echo site_url('agency')?>">Agency</a></li>
        <li class="active">Agency List</li>
      </ol>
    </div>
    <!--Agency -->
    <?php if ($agency_list): ?>
    <div class="page-content padding-30 blue-grey-500 padding-vertical-0">
        <h2 class="margin-top-0 margin-bottom-20" style="color:#738096;">Agency</h2>
        <ul class="blocks blocks-100 blocks-xlg-3 blocks-lg-3 blocks-md-2 blocks-sm-2" data-plugin="masonry">
            
                <?php foreach ($agency_list as $item): ?>
                    <li class="masonry-item">
                        <div class="widget widget-article widget-shadow widget-border">
                            <div class="widget-header cover">
                                <div class="">
                                    <div class="widget margin-bottom-0"
                                         style="height:140px; background:#546e7a;position: relative;border-radius:3px 3px 0 0;">
                                        <span class="ad_circle" style="color:#546e7a;">AD</span>
                                        <div class="clearfix padding-horizontal-30" style="padding-top:15px;">
                                            <h4 class="margin-top-0 pull-left"
                                                style="color:#fff;position: relative;z-index:10; font-size:24px;">
                                                <?php echo $item['publisher_name']?></h4>
                                            <p class="pull-left margin-bottom-0"
                                               style="margin-top:7px; margin-left:10px;">
                                                <span class="clearfix"><i class="pull-left tool_label"></i><b
                                                        class="text_label pull-left"><?php echo $item['tags']?$item['tags']:'TOOLS';?></b></span>
                                            </p>
                                            <a href="<?php echo $item['publisher_id']?site_url('report?agency='.$item['publisher_id']):'';?>"
                                               class="btn btn-round btn-outline pull-right margin-top-3 btn_detail" target="_blank">Detail</a>
                                        </div>
                                        <div class="clearfix padding-horizontal-30">
                                            <div class="pull-left">
                                                <div class="font-size-12 white">Results</div>
                                                <div class="white font-weight-400"
                                                     style="font-size:48px;line-height:40px;">
                                                    <?php echo nums_format($item['results']);?>
                                                </div>
                                            </div>
                                            <div class="pull-right">
                                                <span class="white pull-left"
                                                      style="font-size:48px;font-style: italic;margin-right:8px;"><?php echo $item['score']?number_format($item['score'],1):5;?></span>
                                                <span class="leaf_box pull-left margin-top-20">
                                                  <?php if($item['score']):?>
                                                      <?php
                                                      $s = $item['score']-intval($item['score']);
                                                      $t=5-intval($item['score']);
                                                      for ($k=1;$k<$t;$k++){
                                                          echo '<i class="leaf_grey"></i>';
                                                      }

                                                      if ($s>=0.5) {
                                                          echo '<i class="leaf_half"></i>';
                                                      }else if($s!=0&&$t){
                                                          echo '<i class="leaf_grey"></i>';
                                                      }else if($s==0&&$t){
                                                          echo '<i class="leaf_grey"></i>';
                                                      }

                                                      for ($i=1; $i <= intval($item['score']); $i++) {
                                                          echo '<i class="leaf_all"></i>';
                                                      }
                                                      ?>
                                                  <?php else:?>
                                                      <i class="leaf_all"></i>
                                                      <i class="leaf_all"></i>
                                                      <i class="leaf_all"></i>
                                                      <i class="leaf_all"></i>
                                                      <i class="leaf_all"></i>
                                                  <?php endif;?>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="widget-footer padding-horizontal-15 padding-vertical-20"
                                         style="background:#78909c;height:85px; border-radius:0;">
                                        <div class="row no-space white">
                                            <div class="col-xs-3">
                                                <div class="counter">
                                                    <div class="counter-label"
                                                         style="opacity:0.4;filter:alpha(opacity=40);">Products
                                                    </div>
                                                    <span class="counter-number white"><?php echo $item['product']?></span>
                                                </div>
                                            </div>
                                            <div class="col-xs-3">
                                                <div class="counter">
                                                    <div class="counter-label"
                                                         style="opacity:0.4;filter:alpha(opacity=40);">AdAccounts
                                                    </div>
                                                    <span class="counter-number white"><?php echo number_format($item['account_id'])?></span>
                                                </div>
                                            </div>
                                            <div class="col-xs-3">
                                                <div class="counter">
                                                    <div class="counter-label"
                                                         style="opacity:0.4;filter:alpha(opacity=40);">Illegal Rate
                                                    </div>
                                                    <span class="counter-number white"><?php echo $item['illegal_rate']?>%</span>
                                                </div>
                                            </div>
                                            <div class="col-xs-3">
                                                <div class="counter">
                                                    <div class="counter-label"
                                                         style="opacity:0.4;filter:alpha(opacity=40);">Illegals
                                                    </div>
                                                    <span class="counter-number white"><?php echo number_format($item['illegal'])?></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="widget padding-0 margin-bottom-0" style="height:120px;overflow:hidden;">
                                        <div class="row no-space padding-top-20">
                                            <div class="col-xs-3 text-center">
                                                <div class="pie-progress pie-progress-xs" data-plugin="pieProgress"
                                                     data-barcolor="#A5C882" data-size="60" data-barsize="4"
                                                     data-goal="<?php echo $item['chart']['input_conversion_rate']?>" aria-valuenow="<?php echo $item['chart']['input_conversion_rate']?>"
                                                     role="progressbar">
                                                    <div class="pie-progress-content"
                                                         style="font-size: 12px;color: #76838F;"><?php echo $item['chart']['input_conversion_rate']?>%
                                                    </div>
                                                </div>
                                                <p style="font-size: 12px;color: #76838F;margin-top:10px;">
                                                    Conversion</p>
                                            </div>
                                            <div class="col-xs-3 text-center">
                                                <div class="pie-progress pie-progress-xs" data-plugin="pieProgress"
                                                     data-barcolor="#A5C882" data-size="60" data-barsize="4"
                                                     data-goal="<?php echo $item['chart']['input_next_day']?>" aria-valuenow="<?php echo $item['chart']['input_next_day']?>"
                                                     role="progressbar">
                                                    <div class="pie-progress-content"
                                                         style="font-size: 12px;color: #76838F;"><?php echo $item['chart']['input_next_day']?>%
                                                    </div>
                                                </div>
                                                <p style="font-size: 12px;color: #76838F;margin-top:10px;">The Next
                                                    Day</p>
                                            </div>
                                            <div class="col-xs-3 text-center">
                                                <div class="pie-progress pie-progress-xs" data-plugin="pieProgress"
                                                     data-barcolor="#A5C882" data-size="60" data-barsize="4"
                                                     data-goal="<?php echo $item['chart']['input_7days']?>" aria-valuenow="<?php echo $item['chart']['input_7days']?>"
                                                     role="progressbar">
                                                    <div class="pie-progress-content"
                                                         style="font-size: 12px;color: #76838F;"><?php echo $item['chart']['input_7days']?>%
                                                    </div>
                                                </div>
                                                <p style="font-size: 12px;color: #76838F;margin-top:10px;">7 Days</p>
                                            </div>
                                            <div class="col-xs-3 text-center">
                                                <div class="pie-progress pie-progress-xs" data-plugin="pieProgress"
                                                     data-barcolor="#A5C882" data-size="60" data-barsize="4"
                                                     data-goal="<?php echo $item['chart']['input_30days']?>" aria-valuenow="<?php echo $item['chart']['input_30days']?>"
                                                     role="progressbar">
                                                    <div class="pie-progress-content"
                                                         style="font-size: 12px;color: #76838F;"><?php echo $item['chart']['input_30days']?>%
                                                    </div>
                                                </div>
                                                <p style="font-size: 12px;color: #76838F;margin-top:10px;">31 Days</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </li>
                <?php endforeach; ?>
            
        </ul>
    </div>
    <?php endif; ?>
    <!-- Publisher -->
    <?php if($publisher_list):?>
    <div class="page-content padding-30 blue-grey-500 padding-top-0">
        <h2 class="margin-top-0 margin-bottom-20" style="color:#738096;">Publisher</h2>
        <ul class="blocks blocks-100 blocks-xlg-3 blocks-lg-3 blocks-md-3 blocks-sm-2" data-plugin="masonry">
            
                <?php foreach($publisher_list as $item):?>
                <li class="masonry-item">
                    <div class="widget widget-article widget-shadow widget-border">
                        <div class="widget-header cover">
                            <div>
                                <div class="widget margin-bottom-0" style="height:190px;border-radius:3px 3px 0 0;">
                                    <div class="padding-horizontal-30" style="padding-top:15px;margin-bottom:10px;">
                                        <div class="clearfix">
                                            <h4 class="margin-vertical-0 pull-left"
                                                style="color:#3B434A; font-size:24px; height:56px;width:59%;overflow:hidden;">
                                                <?php echo $item['publisher_name']?></h4>
                                            <a href="<?php echo $item['publisher_id']?site_url('report?publisher='.$item['publisher_id']):'';?>"
                                               class="btn btn-round btn-outline pull-right margin-top-3 publisher_btn_detail" target="_blank">Detail</a>
                                        </div>
                                        <div class="clearfix">
                                            <p class="pull-left margin-bottom-0" style="margin-top:7px; margin-right:10px;">
                                                <span class="clearfix"><i class="pull-left publisher_tool_label"></i><b
                                                        class="publisher_text_label pull-left"><?php echo $item['tags']?$item['tags']:'TOOLS';?></b></span>
                                            </p>
                                        </div>
                                    </div>
                                    <div class="clearfix padding-horizontal-30">
                                        <div class="pull-left">
                                            <div class="font-size-12" style="color:#79848E;">Results</div>
                                            <div class="font-weight-400"
                                                 style="font-size:48px;line-height:40px;color: #3B434A;"> <?php echo nums_format($item['results'])?>
                                            </div>
                                        </div>
                                        <div class="pull-right">
                                            <span class="pull-left"
                                                  style="font-size:48px;font-style: italic;margin-right:8px;color:#3B434A;"><?php echo $item['score']?number_format($item['score'],1):number_format(4,1);?></span>
                                            <span class="leaf_box pull-left margin-top-20">
                                                <?php if($item['score']):?>
                                                    <?php
                                                    $t=5-intval($item['score']);
                                                    for ($k=1;$k<$t;$k++){
                                                        echo '<i class="leaf_grey"></i>';
                                                    }

                                                    $s = $item['score']-intval($item['score']);
                                                    if ($s>=0.5) {
                                                        echo '<i class="leaf_half"></i>';
                                                    }else if($s!=0&&$t){
                                                        echo '<i class="leaf_grey"></i>';
                                                    }else if($s==0&&$t){
                                                        echo '<i class="leaf_grey"></i>';
                                                    }

                                                    for ($i=1; $i <= intval($item['score']); $i++) {
                                                        echo '<i class="leaf_all"></i>';
                                                    }
                                                    ?>
                                                <?php else:?>
                                                    <i class="leaf_grey"></i>
                                                    <i class="leaf_all"></i>
                                                    <i class="leaf_all"></i>
                                                    <i class="leaf_all"></i>
                                                    <i class="leaf_all"></i>
                                                <?php endif;?>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <div class="widget-footer padding-horizontal-15 padding-vertical-20"
                                     style="background:#90d8e7;height:85px; border-radius:0;">
                                    <div class="row no-space white">
                                        <div class="col-xs-3">
                                            <div class="counter">
                                                <div class="counter-label" style="opacity:0.8;filter:alpha(opacity=80);">
                                                    Products
                                                </div>
                                                <span class="counter-number white"><?php echo $item['product']?></span>
                                            </div>
                                        </div>
                                        <div class="col-xs-3">
                                            <div class="counter">
                                                <div class="counter-label" style="opacity:0.8;filter:alpha(opacity=80);">
                                                    AdAccounts
                                                </div>
                                                <span class="counter-number white"> <?php echo number_format($item['account_id'])?></span>
                                            </div>
                                        </div>
                                        <div class="col-xs-3">
                                            <div class="counter">
                                                <div class="counter-label" style="opacity:0.8;filter:alpha(opacity=80);">
                                                    Illegal Rate
                                                </div>
                                                <span class="counter-number white"><?php echo $item['illegal_rate']?>%</span>
                                            </div>
                                        </div>
                                        <div class="col-xs-3">
                                            <div class="counter">
                                                <div class="counter-label" style="opacity:0.8;filter:alpha(opacity=80);">
                                                    Illegals
                                                </div>
                                                <span class="counter-number white"><?php echo number_format($item['illegal'])?></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="widget padding-0 margin-bottom-0">
                                    <div class="example-wrap padding-horizontal-30 margin-vertical-25">
                                        <div class="contextual-progress">
                                            <div class="clearfix">
                                                <div class="progress-title margin-bottom-15">Conversion</div>
                                                <div class="progress-label"><?php echo $item['chart']?$item['chart']['input_conversion_rate']:86?>%</div>
                                            </div>
                                            <div class="progress progress-xs">
                                                <div class="progress-bar progress-bar-danger progress-bar-indicating active"
                                                     style="width: <?php echo $item['chart']?$item['chart']['input_conversion_rate']:86?>%;" role="progressbar">
                                                    <span class="sr-only"><?php echo $item['chart']?$item['chart']['input_conversion_rate']:86?>% Complete</span>
                                                </div>
                                            </div>
                                        </div>


                                        <div class="contextual-progress">
                                            <div class="clearfix">
                                                <div class="progress-title margin-bottom-15">The Next Day</div>
                                                <div class="progress-label"><?php echo $item['chart']?$item['chart']['input_next_day']:75;?>%</div>
                                            </div>
                                            <div class="progress progress-xs">
                                                <div class="progress-bar progress-bar-warning progress-bar-indicating active"
                                                     style="width: <?php echo $item['chart']?$item['chart']['input_next_day']:75?>%;" role="progressbar">
                                                    <span class="sr-only"><?php echo $item['chart']?$item['chart']['input_next_day']:75?>% Complete</span>
                                                </div>
                                            </div>

                                        </div>


                                        <div class="contextual-progress">
                                            <div class="clearfix">
                                                <div class="progress-title margin-bottom-15">7 Days</div>
                                                <div class="progress-label"><?php echo $item['chart']?$item['chart']['input_7days']:40?>%</div>
                                            </div>
                                            <div class="progress progress-xs">
                                                <div
                                                    class="progress-bar progress-bar-success progress-bar-indicating active"
                                                    style="width:<?php echo $item['chart']?$item['chart']['input_7days']:40;?>%;" role="progressbar">
                                                    <span class="sr-only"><?php echo $item['chart']?$item['chart']['input_7days']:40?>% Complete</span>
                                                </div>
                                            </div>
                                        </div>



                                        <div class="contextual-progress">
                                            <div class="clearfix">
                                                <div class="progress-title margin-bottom-15">31 Days</div>
                                                <div class="progress-label"><?php echo $item['chart']?$item['chart']['input_30days']:10?>%</div>
                                            </div>
                                            <div class="progress progress-xs">
                                                <div
                                                    class="progress-bar progress-bar-default progress-bar-indicating active"
                                                    style="width:<?php echo $item['chart']?$item['chart']['input_30days']:10?>%;background-color:#0890a7;" role="progressbar">
                                                    <span class="sr-only"><?php echo $item['chart']?$item['chart']['input_30days']:10?>% Complete</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>


                            </div>
                        </div>
                    </div>
                </li>
                <?php endforeach;?>
            
        </ul>
    </div>
</div>
<?php endif;?>

<!-- 新加js -->
<script src="<?php echo base_url(); ?>assets/web/global/vendor/masonry/masonry.pkgd.min.js"></script>
<!-- 新加js -->
<script src="<?php echo base_url(); ?>assets/web/global/vendor/aspieprogress/jquery-asPieProgress.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/js/components/masonry.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/js/components/aspieprogress.js"></script>
<script src="<?php echo base_url(); ?>assets/web/assets/examples/js/charts/pie-progress.js"></script>
<!-- 新加js结束 -->
