<!DOCTYPE html>
<html class="no-js css-menubar" lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta name="description" content="bootstrap admin template">
    <meta name="author" content="">
    <title>Advertiser Subscription</title>
    <link rel="apple-touch-icon" href="<?php echo base_url();?>assets/web/assets/images/apple-touch-icon.png">
    <link rel="shortcut icon" href="<?php echo base_url();?>assets/web/assets/images/favicon.ico">
    <!-- Stylesheets -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/css/bootstrap-extend.min.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/web/assets/css/site.min.css">
    <!-- Plugins -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/animsition/animsition.min.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/asscrollable/asScrollable.min.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/switchery/switchery.min.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/intro-js/introjs.min.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/slidepanel/slidePanel.min.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/flag-icon-css/flag-icon.min.css">
    <!-- <link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/toastr/toastr.min.css"> -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/web/assets/examples/css/advanced/toastr.min.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/web/assets/examples/css/pages/profile.min.css">

    <!-- Fonts -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/fonts/web-icons/web-icons.min.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/fonts/font-awesome/font-awesome.min.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/fonts/brand-icons/brand-icons.min.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/fonts/brand-icons/brand-icons.min.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/fonts/google/fonts.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/location.default.css">

    
    <!--[if lt IE 9]>
    <script src="<?php echo base_url();?>assets/web/global/vendor/html5shiv/html5shiv.min.js"></script>
    <![endif]-->
    <!--[if lt IE 10]>
    <script src="<?php echo base_url();?>assets/web/global/vendor/media-match/media.match.min.js"></script>
    <script src="<?php echo base_url();?>assets/web/global/vendor/respond/respond.min.js"></script>
    <![endif]-->
    <!-- Scripts -->
    <script src="<?php echo base_url();?>assets/web/global/vendor/modernizr/modernizr.js"></script>
    <script src="<?php echo base_url();?>assets/web/global/vendor/breakpoints/breakpoints.js"></script>
    <script>
        Breakpoints();
    </script>


    <!-- Core  -->
<script src="<?php echo base_url();?>assets/web/global/vendor/jquery/jquery.min.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/bootstrap/bootstrap.min.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/animsition/animsition.min.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/asscroll/jquery-asScroll.min.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/mousewheel/jquery.mousewheel.min.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/asscrollable/jquery.asScrollable.all.min.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/ashoverscroll/jquery-asHoverScroll.min.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/asrange/jquery-asRange.min.js"></script>

  <!-- Plugins -->
  <script src="<?php echo base_url();?>assets/web/global/vendor/switchery/switchery.min.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/intro-js/intro.min.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/screenfull/screenfull.min.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/slidepanel/jquery-slidePanel.min.js"></script>


  <!-- Scripts -->
  <script src="<?php echo base_url();?>assets/web/global/js/core.min.js"></script>
  <script src="<?php echo base_url();?>assets/web/assets/js/site.min.js"></script>
  <script src="<?php echo base_url();?>assets/web/assets/js/sections/menu.min.js"></script>
  <script src="<?php echo base_url();?>assets/web/assets/js/sections/menubar.min.js"></script>
  <script src="<?php echo base_url();?>assets/web/assets/js/sections/sidebar.min.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/js/configs/config-colors.min.js"></script>
  <script src="<?php echo base_url();?>assets/web/assets/js/configs/config-tour.min.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/js/components/asscrollable.min.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/js/components/animsition.min.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/js/components/slidepanel.min.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/js/components/switchery.min.js"></script>

  <script src="<?php echo base_url();?>assets/js/location.default.js"></script>
<script src="<?php echo base_url();?>assets/web/assets/examples/js/uikit/icon.js"></script>
  
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/global/vendor/owl-carousel/owl.carousel.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/global/vendor/slick-carousel/slick.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/assets/examples/css/uikit/carousel.css">



 <script type="text/javascript">
     var base_url = "<?php echo base_url()?>";
     var site_url = "<?php echo site_url()?>";
 </script>

 <link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/bootstrap-datepicker/bootstrap-datepicker.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/daterangepicker.css" />

<style type="text/css">
    .overlay figcaption .btn {
        margin-left: 4px;
    }

    .exampleVariableWidth img {
        border-top: none;
        border-bottom: none;
    }

    .exampleVariableWidth {
        margin: 0;
    }

    .exampleVariableWidth .slick-prev {
        left: 4px;
        z-index: 12;
    }

    .exampleVariableWidth .slick-next {
        right: 4px;
    }
</style>
</head>
<body class="site-navbar-small app-projects" >
<!--[if lt IE 8]>
<p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade
    your browser</a> to improve your experience.</p>
<![endif]-->
<nav class="site-navbar navbar navbar-default navbar-fixed-top navbar-mega navbar-inverse"
     role="navigation">
    <div class="navbar-header" style="width:300px;">
        <button type="button" class="navbar-toggle hamburger hamburger-close navbar-toggle-left hided"
                data-toggle="menubar">
            <span class="sr-only">Toggle navigation</span>
            <span class="hamburger-bar"></span>
        </button>
        <button type="button" class="navbar-toggle collapsed" data-target="#site-navbar-collapse"
                data-toggle="collapse">
            <i class="icon wb-more-horizontal" aria-hidden="true"></i>
        </button>
        <a class="navbar-brand navbar-brand-center">
            <img class="navbar-brand-logo navbar-brand-logo-normal" src="<?php echo base_url();?>assets/images/marketmax-white.png"
                 title="Palmax" style="width: 24px;">
            <img class="navbar-brand-logo navbar-brand-logo-special" src="<?php echo base_url();?>assets/web/assets/images/logo-blue.png"
                 title="Palmax">
            <span class="navbar-brand-text hidden-xs"> Palmax Creative Library</span>
        </a>
        <button type="button" class="navbar-toggle collapsed" data-target="#site-navbar-search"
                data-toggle="collapse">
            <span class="sr-only">Toggle Search</span>
            <i class="icon wb-search" aria-hidden="true"></i>
        </button>
    </div>
    <div class="navbar-container container-fluid">
        <!-- Navbar Collapse -->
        <div class="collapse navbar-collapse navbar-collapse-toolbar" id="site-navbar-collapse">
            <!-- Navbar Toolbar -->
            
            
            <ul class="nav navbar-toolbar navbar-right">
                <li class="hidden-xs" id="toggleFullscreen">
                    <a class="icon icon-fullscreen" data-toggle="fullscreen" href="#" role="button">
                        <span class="sr-only">Toggle fullscreen</span>
                    </a>
                </li>
            </ul>
            <!-- End Navbar Toolbar Right -->
        </div>
        <!-- End Navbar Collapse -->
        
    </div>
</nav>



<!-- Page -->
<div class="page animsition">
    <div class="page-content">

        <div class="panel">
            <div class="panel-body container-fluid" style=" padding-bottom: 0;">
                <div class="row row-lg">
                    <div class="clearfix visible-md-block visible-lg-block"></div>
                    <div class="col-md-12">

                        <div class="example-wrap" style="margin-bottom:0;">
                            <h4>Conditions</h4>
                            <!-- <div class="nav-tabs"></div> -->
                            <div class="example table-responsive" style="margin-bottom: 0; margin-top: 0;">
                                
                                <div class="col-md-12">
                                    <!-- Example Multi Balue -->
                                    <div class="example-wrap">
                                        <div class="example">
                                            <form>                                   
                                                <div class="form-group col-md-1 col-lg-1 col-xlg-1 filter-form advertiser-filter" style="margin-bottom:15px;line-height:36px;">
                                                    <label class="control-label">Filter: </label>
                                                </div> 

                                                <input type="hidden" class="advertiser" value="<?php echo $this->input->get('advertiser')?>">

                                                <div class="form-group col-md-4 col-lg-4 col-xlg-4 filter-form account-filter" style="margin-bottom:15px;padding-left: 0;">
                                                    <select class="form-control select2-hidden-accessible filter_account" multiple="" data-plugin="select2" tabindex="-1" aria-hidden="true" data-placeholder="Account Filter">
                                                        <?php foreach($account as $a):?>
                                                            <option value="<?php echo $a['account_id']?>" <?php echo (in_array($a['account_id'], $account_params))?"selected='selected'":''?>><?php echo $a['account_id']."(".$a['name'].')'?></option>
                                                        <?php endforeach;?>
                                                    </select>
                                                </div>

                                                <div class="form-group col-md-4 col-lg-4 col-xlg-4 filter-form account-filter" style="margin-bottom:15px;padding-left: 0;">
                                                    <select class="form-control select2-hidden-accessible filter_status" data-plugin="select2" tabindex="-1" aria-hidden="true" data-placeholder="Effective Status">
                                                        <option value="">Effective Status</option>
                                                        <?php foreach($status as $s):?>
                                                            <option value="<?php echo $s?>" <?php echo $this->input->get('status')==$s?"selected='selected'":''?>><?php echo $s?></option>
                                                        <?php endforeach;?>
                                                    </select>
                                                </div>

                                                <div class="form-group col-md-2 col-lg-2 col-xlg-2">
                                                    <button type="button" class="btn btn-outline btn-primary advertiser_search">Search</button>
                                                    <button type="button" class="btn btn-outline btn-info advertiser_rest">Reset</button>
                                                </div>
                                            </form>

                                        </div>
                                    </div>
                                    <!-- End Example Multi Balue -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="panel">
            <div class="panel-body">
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xlg-12">
                    <div class="form-group pull-left">
                        <h4><?php echo $advertiser_name?></h4>
                    </div>
                    <!-- <div class="form-group filter-form account-filter pull-right" style="margin-bottom:15px;padding-left: 0;text-align: center;">
                        
                        <div class=" form-control" style="width: 225px;">
                            <div id="reportrange" class="pull-right">
                                <i class="glyphicon glyphicon-calendar fa fa-calendar"></i>&nbsp;
                                <span></span> <b class="caret"></b>

                                <input type="hidden" value="" class="date_start" />
                                <input type="hidden" value="" class="date_end" />
                            </div>
                        </div>
                        
                    </div> -->
                </div>
                <?php foreach($ad_list as $key=>$item):?>
                <div class="col-xs-12 col-sm-6 col-md-4 col-lg-3 col-xlg-2 masonry-item">
                      <!-- Widget -->
                    <div class="widget widget-article widget-border">
                        <figure class="">
                            <div class="widget-header">
                                <div class="overlay overlay-hover review-cover-image overlay_click">
                                    <!-- <img class="cover-image img-responsive overlay-scale" src="<?php echo $item['image_url']?>" alt=""> -->
                                    <?php if($item['object_type']=='SHARE'):?>
                                        <img class="cover-image img-responsive overlay-scale" src="<?php echo $item['org_image_url']?>" alt="" onerror="javascript:this.src='<?php echo $item['image_url']?>'">
                                    <?php elseif($item['object_type']=='MORE_SHARE'):?>
                                        <div class="slider exampleVariableWidth"  style="width:auto;">
                                            <?php foreach($item['more_image'] as $image):?>
                                                <div class="">
                                                  <img class="cover-image img-responsive" src="<?php echo $image['url']?>" alt="" onerror="javascript:this.src='<?php echo base_url();?>assets/images/Artboard.png'">
                                                </div>
                                            <?php endforeach;?>
                                        </div>
                                    <?php elseif($item['object_type']=='VIDEO'):?>
                                        <video width="298" height="155" controls="controls" style="background-color: #000;" poster="<?php echo $item['image_url']?>" preload='none'> 
                                            <source src="<?php echo $item['video_url']?>" type="video/mp4"></source> 
                                        </video> 
                                    <?php else:?>
                                        <img class="cover-image img-responsive overlay-scale" src="<?php echo $item['org_image_url']?>" alt="" onerror="javascript:this.src='<?php echo $item['image_url']?>'">
                                    <?php endif;?>
                                </div>
                            </div>
                            

                            <div class="widget-body">
                                <h5 class="widget-title"><?php echo $item['title']?></h5>
                                
                                <p class="widget-message"><?php echo $item['message']?></p>
                                
                                <div class="widget-body-footer padding-top-10" style="border-top: 1px solid #ededed;">
                                    <p><?php echo $item['account_id']?></p>
                                    <p><?php echo $item['campaign_name']?></p>
                                    <p data-id="<?php echo $item['ad_id']?>"><?php echo $item['name']?></p>
                                </div>
                            </div>
                            
                        </figure>
                        
                    </div>
                      <!-- End Widget -->
                </div>

            <?php endforeach;?>
                <div class="col-md-12">
                    <div class="fixed-table-pagination" style="display: block;">
                       
                        <div class="pull-right pagination">

                            <?php echo $page_links?>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
</div>
<style type="text/css">
    .widget-body{
        padding: 30px 10px 10px 10px;
    }
    .widget-body-footer p{
        padding: 0;
        margin:0;
        font-size: 13px;
    }
    .widget-title{
        height: 40px;
        line-height: 20px;
        overflow: hidden;
    }
    .widget-message{
        height: 88px;
        line-height: 21px;
        overflow: hidden;
    }
    .widget-body-footer{
        height: 71px;
    }
</style>
<script src="<?php echo base_url();?>assets/web/global/vendor/bootstrap-datepicker/bootstrap-datepicker.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/components/bootstrap-datepicker.js"></script>


<script type="text/javascript" src="<?php echo base_url();?>assets/js/moment.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/daterangepicker.js"></script>

  <script src="<?php echo base_url();?>assets/web/global/vendor/owl-carousel/owl.carousel.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/slick-carousel/slick.js"></script>

  <script src="<?php echo base_url();?>assets/web/global/js/components/owl-carousel.js"></script>
  <script src="<?php echo base_url();?>assets/web/assets/examples/js/uikit/carousel.js"></script>

<script type="text/javascript">

$('.exampleAdaptiveHeight').slick({
        dots: true,
        infinite: true,
        speed: 300,
        slidesToShow: 1,
        adaptiveHeight: true
    });

    $('.exampleVariableWidth').slick({
        dots: true,
        infinite: true,
        speed: 300,
        slidesToShow: 1,
        adaptiveHeight: true
    });

    function cb(start, end) {
        $('#reportrange span').html(start.format('MM/DD/YYYY') + ' - ' + end.format('MM/DD/YYYY'));
        $(".date_start").val(start.format('MM/DD/YYYY'));
        $(".date_end").val(end.format('MM/DD/YYYY'));
    }

    cb(moment().subtract(3, 'days'), moment());

    <?php if($this->input->get('start')):?>
        $('#reportrange').daterangepicker({
            "startDate": "<?php echo urldecode($this->input->get('start'))?>",
            "endDate": "<?php echo urldecode($this->input->get('end'))?>",
            ranges: {
               'Today': [moment(), moment()],
               'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
               'Last 7 Days': [moment().subtract(6, 'days'), moment()],
               'Last 30 Days': [moment().subtract(29, 'days'), moment()],
               'This Month': [moment().startOf('month'), moment().endOf('month')],
               'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
            }
        }, cb); 
        $('#reportrange span').html("<?php echo urldecode($this->input->get('start'))?>" + ' - ' + "<?php echo urldecode($this->input->get('end'))?>");
        $(".date_start").val("<?php echo urldecode($this->input->get('start'))?>");
        $(".date_end").val("<?php echo urldecode($this->input->get('end'))?>");
    <?php else:?>
        $('#reportrange').daterangepicker({
            ranges: {
               'Today': [moment(), moment()],
               'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
               'Last 7 Days': [moment().subtract(6, 'days'), moment()],
               'Last 30 Days': [moment().subtract(29, 'days'), moment()],
               'This Month': [moment().startOf('month'), moment().endOf('month')],
               'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
            }
        }, cb); 
    <?php endif;?>

    var url = "<?php echo $base_url?>";
    $('#reportrange').on('apply.daterangepicker', function(ev, picker) {
        location.href=url + "&start=" + picker.startDate.format('MM/DD/YYYY') + "&end=" + picker.endDate.format('MM/DD/YYYY');
      //$(this).val(picker.startDate.format('MM/DD/YYYY') + ' - ' + picker.endDate.format('MM/DD/YYYY'));
  });
</script>

<script src="<?php echo base_url();?>assets/web/global/vendor/bootstrap-select/bootstrap-select.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/select2/select2.min.js"></script>
    
<script src="<?php echo base_url();?>assets/web/global/js/components/bootstrap-select.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/components/select2.js"></script>

<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/bootstrap-select/bootstrap-select.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/select2/select2.css">

<footer class="site-footer">
    <div class="site-footer-right">
        © 2015 - 2016, Palmax Limited, All rights reserved.
    </div>
</footer>

</body>
</html>