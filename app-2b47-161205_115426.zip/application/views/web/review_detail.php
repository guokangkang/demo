<style type="text/css">
    .span_block{ position:relative; }
    .span_block span{display: block; width: 100%; height: 100%;}
    .span_block input{display: none;}
    .span_block input.active{display: block; position: absolute; left: 0; top: 0;}
</style>
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/owl-carousel/owl.carousel.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/slick-carousel/slick.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/assets/examples/css/uikit/carousel.css">
<div class="page animsition">
    <div class="page-header ">
        <h1 class="page-title"><?php echo $ad_info['name']?></h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo site_url('review')?>">Creative</a></li>
            <li><a href="<?php echo site_url('review')?>">Review</a></li>
            <li class="active"><?php echo $ad_info['name']?></li>
        </ol>
    </div> 
    <div class="page-content"> 
        <div class="panel">
            <div class="panel-body">
                <div class="row">
                    <div class="col-md-12">
                        <!-- Example Fade -->
                        <div class="example-wrap" style="margin-bottom:0px;">
                            <div class="example">
                                <div class="slider" id="exampleAdaptiveHeight">
                                    <?php foreach($ad_list as $item):?>
                                        <div>
                                           <div class="col-md-3 col-sm-3">
                                                <a target="_black" href="<?php echo site_url('review/detail?ad='.$item['ad_id'])?>" style="width: 100%;position: relative;padding-bottom: 56.25%;height: 0;display: block;">
                                                    <!-- <img class="cover-image img-responsive overlay-scale" src="<?php echo $item['image_url']?>" alt=""> -->
                                                    <?php if($item['object_type']=='SHARE'):?>
                                                        <img class="cover-image img-responsive overlay-scale" src="<?php echo $item['image_url']?>" alt="">
                                                    <?php elseif($item['object_type']=='MORE_SHARE'):?>
                                                        <div class="slider review_image">
                                                            <?php foreach($item['more_image'] as $image):?>
                                                                <div class="">
                                                                  <img class="cover-image img-responsive overlay-scale" src="<?php echo $image['url']?>" alt="">
                                                                </div>
                                                            <?php endforeach;?>
                                                        </div>
                                                    <?php elseif($item['object_type']=='VIDEO'):?>
                                                        <video  controls="controls" style="position: absolute; top:0; left:0; width: 100%;height: 100%;background-color: #000;" poster="<?php echo $item['image_url']?>" preload='none'> 
                                                            <source src="<?php echo $item['video_url']?>" type="video/mp4"></source> 
                                                        </video> 
                                                    <?php else:?>
                                                        <img class="cover-image img-responsive overlay-scale" src="<?php echo $item['image_url']?>" alt="">
                                                    <?php endif;?>
                                                </a>
                                            </div>
                                            <div class="col-md-8">
                                                <h4 class="widget-title text-left" style="padding-top:8px;"><a href="#" style="text-decoration:none;"><?php echo $item['title']?></a> <span>(<?php echo date('Y-m-d', $item['updated_time'])?>)</span></h4>
                                                <p class="text-left"><?php echo $item['message']?></p>
                                                <div class="example example-buttons text-left">
                                                    <a type="button" target="_blank" class="btn btn-outline btn-primary" href="https://translate.google.co.jp/?hl=en&tab=wT#auto/zh-CN/<?php echo urlencode($item['message'])?>">See Translation</a>  
                                                    <a type="button" target="_blank" class="btn btn-outline btn-primary" href="https://business.facebook.com/ads/manager/ad/ads/?act=<?php echo $item['account_id']?>&ids=<?php echo $item['ad_id']?>">See Post</a>        
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach;?>
                                </div>
                            </div>
                        </div>
                        <!-- End Example Fade -->
                    </div>
                </div>
                <?php if($insight):?>
                <div class="col-md-8 col-md-offset-2">
                    <div class="row table-responsive" style="padding-left:6px;">
                        <table  class="table dataTable width-full text-center">
                            <thead>
                                <tr>
                                    <td>Impressions</td>
                                    <td>Results</td>
                                    <td>CTR</td>
                                    <td>Relevance</td>

                                    <td>Shares</td>
                                    <td>Likes</td>
                                    <td>Comments</td>
                                </tr>
                            </thead>
                            <tbody class="no_border">
                                <tr>
                                    <td><?php echo number_format($insight['results'])?></td>
                                    <td><?php echo number_format($insight['impressions'])?></td>
                                    <td><?php echo $insight['ctr']?>%</td>
                                    <td><?php echo $insight['relevance_score']?></td>

                                    <td><?php echo number_format($insight['shares'])?></td>
                                    <td><?php echo number_format($insight['likes'])?></td>
                                    <td><?php echo number_format($insight['comments'])?></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div> 
            <?php endif;?>
            </div>
        </div>   
        <!-- Panel Table Tools -->
        <div class="panel">
            <div class="panel-body table-responsive" id="">
              <table class="editable-table table-hover table table-striped" id="">
                <thead>
                    <tr>

                        
                        <?php if($this->userinfo['type']==0):?>
                            <th style="width:15%;">Created Time</th>
                            <th style="width:15%;">Facebook User</th>
                            <th style="width:50%;">Post Comments</th>
                            <th style="width:20%;">可能可以改进的建议(点击可以修改)</th>
                        <?php else:?>
                            <th style="width:25%;">Created Time</th>
                            <th style="width:25%;">Facebook User</th>
                            <th style="width:50%;">Post Comments</th>
                        <?php endif;?>
                    </tr>
                    </thead>
                    <tbody>
                        <?php foreach($comment_list as $item):?>
                            <tr>
                                <td class=""><?php echo date('m/d/Y H:i', $item['created_time'])?></td>
                                <td class=""><a href="https://www.facebook.com/app_scoped_user_id/<?php echo $item['user_id']?>" target="_blank"><?php echo $item['user_name']?></a></td>
                                <td class=""><?php echo $item['message']?></td>
                                
                                <?php if($this->userinfo['type']==0):?>
                                    <td class="span_block">
                                        <span><?php echo isset($comment_ids[$item['comment_id']])?$comment_ids[$item['comment_id']]:'评论建议'?></span>
                                        <input type="text" name="" value="" class="sss input_desc" data-id="<?php echo $item['comment_id']?>">
                                    </td>
                                <?php endif;?>

                            </tr>
                        <?php endforeach;?>
                    </tbody>
              </table>
            </div>   
        </div>
        <!-- End Panel Table Tools -->
    </div>
</div>

<script type="text/javascript">
    $('.span_block').click(function (){
        $('.span_block input').removeClass('active');
        $(this).children().eq(0).css('display','none');
        $(this).children().eq(1).css({'width':$(this).css('width'),'height':$(this).css('height')});
        $(this).children().eq(1).addClass('active');
        if ($(this).children().eq(0).text() != '评论建议') {
            $(this).children().eq(1).val($(this).children().eq(0).text());
        }
        //
        $(this).children().eq(1).focus();
    });
    $('.span_block input').blur(function (){
        $('.span_block span').css('display','block');
        $(this).removeClass('active');

        var input_val = $(this).val();
        if (input_val == '') {
            $(this).prev().text('评论建议');
        }else{
            $(this).prev().text($(this).val());
        }

        if (input_val != '') {
            $.ajax({
                url : site_url + "review/addcomment",
                type : 'post',
                dataType : 'json',
                data : {'comment_id':$(this).attr('data-id'), 'text':input_val},
                success:function(data){

                }
            });
        }

        
    });

    $(window).resize(function (){
        $('.span_block input').css({'width':$('.span_block').css('width'),'height':$('.span_block').css('height')});
    });
</script>

<script src="<?php echo base_url();?>assets/web/global/vendor/datatables/jquery.dataTables.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/datatables-fixedheader/dataTables.fixedHeader.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/datatables-bootstrap/dataTables.bootstrap.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/datatables-responsive/dataTables.responsive.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/datatables-tabletools/dataTables.tableTools.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/editable-table/mindmup-editabletable.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/editable-table/numeric-input-example.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/owl-carousel/owl.carousel.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/slick-carousel/slick.js"></script>


<script src="<?php echo base_url();?>assets/web/global/js/components/datatables.js"></script>
<script src="<?php echo base_url();?>assets/web/assets/examples/js/tables/datatable.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/select2/select2.min.js"></script>  
<script src="<?php echo base_url();?>assets/web/global/js/components/select2.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/components/editable-table.js"></script>
<script src="<?php echo base_url();?>assets/web/assets/examples/js/tables/editable.js"></script>

<script src="<?php echo base_url();?>assets/web/global/js/components/owl-carousel.js"></script>
<script src="<?php echo base_url();?>assets/web/assets/examples/js/uikit/carousel.js"></script>


<script>
  $('.no_input').removeAttr('tabindex');

  $(".featured_input").blur(function(){
    var comment_id = $(this).attr('data-id');
    console.log(comment_id);
  });
</script>
