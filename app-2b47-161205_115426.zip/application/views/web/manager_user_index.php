<!-- 新加css -->
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/assets/examples/css/advanced/masonry.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/bootstrap-select/bootstrap-select.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/select2/select2.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/webui-popover/webui-popover.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/toolbar/toolbar.css">
<!-- Page -->
<div class="page animsition">
    <div class="page-header">
        <ol class="breadcrumb">
            <li><a href="<?php echo site_url('manager/user/index');?>">Management</a></li>
            <li class="active">Advertisers</li>
        </ol>
        <div class="clearfix margin-top-30">
            <div class="pull-left">
              <!--  <select data-plugin="selectpicker">
                    <option>All</option>
                    <option>Active</option>
                    <option>Paused</option>
                </select>-->
            </div>
            <div class="pull-right">
                <button type="button" data-target="#add_manager" data-toggle="modal" class="btn btn-primary btn-round margin-right-15 pull-left" style="background:#12abc5;">
                    <i class="icon wb-plus" aria-hidden="true"></i>
                    Add User
                </button>
                <div class="form-group pull-right margin-bottom-0">
                    <div class="input-search margin-bottom-0">
                        <i class="input-search-icon wb-search" aria-hidden="true"></i>
                        <input type="text" class="form-control" value="<?php /*echo $this->input->get('q')?$this->input->get('q'):''; */?>" name="q" placeholder="Search...">
                        <button type="button" class="input-search-close icon wb-close" aria-label="Close"></button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="page-content padding-30 blue-grey-500 padding-top-0">
        <ul class="blocks blocks-100 blocks-xlg-3 blocks-lg-3 blocks-md-3 blocks-sm-2" data-plugin="masonry">
            <?php foreach($data as $item):?>
                <li class="masonry-item">
                <div class="widget-article widget-border bg-white">
                    <div class="widget-header padding-30 clearfix" style="position:relative;">
                        <a class="avatar avatar-lg pull-left margin-right-20 bg-white" href="javascript:void(0)" style="height: 50px;border: 1px solid #26788C;text-align: center;line-height: 50px;font-size:18px; color:#26788C;">
                            <?php echo $item['head'];?>
                        </a>
                        <div class="font-size-16" style="color:#444c52;"><?php echo $item['user_name']?></div>
                        <div class="font-size-14" style="color:#79848e;"><?php echo $item['email']?></div>
                        <p class="pull-right red-600" style="position: absolute;right: 30px;top: 35px;"><?php echo implode(' - ', $item['role'])?></p>
                        <div class="pull-right">
                            <a href="#" data-val="<?php echo $item['manager_id']?>" class="btn btn-sm btn-icon btn-pure btn-default add_manager edit_manager_button on-default edit-row padding-0 margin-right-10" data-target="#add_manager" data-toggle="modal">
                                <i class="icon md-edit" aria-hidden="true"></i>
                            </a>
                            <a data-val="<?php echo $item['manager_id']?>" class="btn btn-sm btn-icon btn-pure btn-default on-default remove-row remove_manager_button padding-0" data-toggle="popover">
                                <i class="icon wb-trash" aria-hidden="true"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </li>
            <?php endforeach;?>
        </ul>
    </div>
</div>
<!--add-->
<div class="modal fade" id="add_manager" aria-hidden="false" aria-labelledby="add_bucket_Label" role="dialog" tabindex="-1">
    <div class="modal-dialog">
        <form class="modal-content" autocomplete="off" method="post" id="add_advertiser" action="<?php echo site_url('manager/user/add_manager_action')?>">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
                <h4 class="modal-title" id="add_bucket_Label">Add User</h4>
            </div>
            <input type="hidden" name="manager" class="input_manager" value="">
            <div class="modal-body">
                <div class="row">

                    <div class="col-lg-12 form-group ">
                        <label class="control-label">
                            Role
                            <span class="required">*</span>
                        </label>
                        <div>
                            <?php foreach(config_item('MANAGER_ROLE') as $v):?>
                                <div class="checkbox-custom checkbox-default checkbox-inline">
                                    <input type="checkbox" id="input_checkbox_<?php echo $v?>" name="select_role[]" value="<?php echo $v?>" class="checkbox_role">
                                    <label for="input_checkbox_<?php echo $v?>"><?php echo $v?></label>
                                </div>
                            <?php endforeach;?>
                        </div>
                    </div>

                    <div class="col-lg-12 form-group ">
                        <label class="control-label" for="first_name">
                            Name
                            <span class="required">*</span>
                        </label>
                        <input type="text" class="form-control" id="first_name" name="input_first_name" placeholder="" autocomplete="off">
                    </div>

                    <div class="col-lg-12 form-group ">
                        <label class="control-label" for="email">
                            Email
                            <span class="required">*</span>
                        </label>
                        <input type="text" class="form-control" id="email" name="input_email" placeholder="" autocomplete="off">
                    </div>

                    <div class="col-lg-12 form-group">
                        <label class="control-label" for="inputBasicRemember">Default Password : <b>123456</b></label>
                    </div>

                    <div class="col-lg-12 form-group ">
                        <button type="submit" class="btn btn-primary" id="add_advertiser_button">Submit</button>
                    </div>

                </div>
            </div>
        </form>
    </div>
</div>

<!-- 新加js -->
<script src="<?php echo base_url();?>assets/web/global/vendor/masonry/masonry.pkgd.min.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/core.js"></script>
<script src="<?php echo base_url();?>assets/web/assets/js/site.js"></script>
<script src="<?php echo base_url();?>assets/web/assets/js/sections/menu.js"></script>
<script src="<?php echo base_url();?>assets/web/assets/js/sections/menubar.js"></script>
<script src="<?php echo base_url();?>assets/web/assets/js/sections/sidebar.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/configs/config-colors.js"></script>
<script src="<?php echo base_url();?>assets/web/assets/js/configs/config-tour.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/components/asscrollable.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/components/animsition.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/components/slidepanel.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/asrange/jquery-asRange.min.js"></script>
<script src="<?php echo base_url();?>assets/web/assets/examples/js/uikit/icon.js"></script>
<!-- 新加js -->
<script src="<?php echo base_url();?>assets/web/global/js/components/switchery.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/components/masonry.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/select2/select2.min.js"></script>  
<script src="<?php echo base_url();?>assets/web/global/js/components/select2.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/bootstrap-select/bootstrap-select.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/components/bootstrap-select.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/webui-popover/jquery.webui-popover.min.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/toolbar/jquery.toolbar.min.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/components/webui-popover.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/components/toolbar.js"></script>
<script src="<?php echo base_url();?>assets/web/assets/examples/js/uikit/tooltip-popover.js"></script>
<!-- 新加js结束 -->
<script>
 $('.input-search').keydown(function (e) {
     var curKey = e.which;
     if (curKey == 13) {
         var url = '<?php echo site_url('manager/user/index?q=');?>';
         var data = $('input[name=q]').val();
         url = url + data;
         location.href = url;
     }
 });
 $('.input-search-close').click(function () {
     location.href='<?php echo site_url('manager/user/index');?>';
 });
</script>