<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/global/vendor/chartist-js/chartist.css">

<link rel="stylesheet"
      href="<?php echo base_url(); ?>assets/css/chartist-plugin-tooltip.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/global/vendor/aspieprogress/asPieProgress.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/assets/examples/css/widgets/statistics.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/assets/examples/css/dashboard/team.css">
<style type="text/css">
    .ct-chart .ct-label.ct-horizontal.ct-end{
        text-align: left;
    }
    .teamCompletedWidget .list-inline1 li:last-child::before{
        background-color:white;
    }
    .teamCompletedWidget .list-inline-roi li:first-child::before{
        background-color:white;
    }
    .teamCompletedWidget .list-inline-roi li:last-child::before{
        background-color:#62a8ea;
    }
</style>
<!-- Page -->
<div class="page animsition">
    <div class="page-content padding-30 container-fluid">
        <div class="row" data-plugin="matchHeight" data-by-row="true">
            <!-- First Row -->
            <div class="col-md-4 col-sm-12">
              <div class="widget widget-shadow widget-completed-options">
                <div class="widget-content padding-30">
                  <div class="row">
                    <div class="col-xs-6">
                      <div class="counter text-left blue-grey-700">
                        <div class="counter-label margin-top-10">Conversions Of Yesterday
                        </div>
                        <div class="counter-number font-size-40 margin-top-10">
                          <?php echo number_format($yesterday['results'])?>
                        </div>
                      </div>
                    </div>
                    <div class="col-xs-6">
                      <div class="pie-progress pie-progress-sm" data-plugin="pieProgress" data-valuemax="100"
                      data-barcolor="#57c7d4" data-size="100" data-barsize="10"
                      data-goal="<?php echo $yesterday['ctr']?>" aria-valuenow="<?php echo $yesterday['ctr']?>" role="progressbar">
                        <span class="pie-progress-number blue-grey-700 font-size-20">
                          <?php echo $yesterday['ctr']?>%
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="col-md-4 col-sm-12">
              <div class="widget widget-shadow widget-completed-options">
                <div class="widget-content padding-30">
                  <div class="row">
                    <div class="col-xs-6">
                      <div class="counter text-left blue-grey-700">
                        <div class="counter-label margin-top-10">Conversions Of This Week
                        </div>
                        <div class="counter-number font-size-40 margin-top-10">
                          <?php echo number_format($last_week['results'])?>
                        </div>
                      </div>
                    </div>
                    <div class="col-xs-6">
                      <div class="pie-progress pie-progress-sm" data-plugin="pieProgress" data-valuemax="100"
                      data-barcolor="#62a8ea" data-size="100" data-barsize="10"
                      data-goal="<?php echo $last_week['ctr']?>" aria-valuenow="<?php echo $last_week['ctr']?>" role="progressbar">
                        <span class="pie-progress-number blue-grey-700 font-size-20">
                          <?php echo $last_week['ctr']?>%
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-4 col-sm-12">
              <div class="widget widget-shadow widget-completed-options">
                <div class="widget-content padding-30">
                  <div class="row">
                    <div class="col-xs-6">
                      <div class="counter text-left blue-grey-700">
                        <div class="counter-label margin-top-10">Conversions Of This Month
                        </div>
                        <div class="counter-number font-size-40 margin-top-10">
                          <?php echo number_format($last_month['results'])?>
                        </div>
                      </div>
                    </div>
                    <div class="col-xs-6">
                      <div class="pie-progress pie-progress-sm" data-plugin="pieProgress" data-valuemax="100"
                      data-barcolor="#926dde" data-size="100" data-barsize="10"
                      data-goal="<?php echo $last_month['ctr']?>" aria-valuenow="<?php echo $last_month['ctr']?>" role="progressbar">
                        <span class="pie-progress-number blue-grey-700 font-size-20">
                          <?php echo $last_month['ctr']?>%
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="col-lg-6 col-xlg-9">
                <div class="widget widget-shadow example-responsive ">
                    <div class="widget-content padding-20 padding-bottom-25">
                        <div class="row padding-bottom-40 teamCompletedWidget" data-plugin="matchHeight">
                            <div class="col-md-6 col-sm-12 ">
                                <div class="counter text-left padding-left-10">
                                    <div class="counter-label">Spent/Revenue</div>
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-12">
                                <div class="counter text-right padding-right-20">
                                    <div class="counter-label font-size-20">Last 7 Days</div>
                                </div>
                                <ul class="list-inline margin-right-50 margin-top-20">
                                    <li>
                                        Spent(USD)
                                    </li>
                                    <li>
                                        Revenue(USD)
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="ct-chart" id="spent_revenue_charts" data-date='<?php echo $spent_revenue['date']?>' data-spent='<?php echo $spent_revenue['spent']?>' data-revenue='<?php echo $spent_revenue['revenue']?>' style="height:300px;"></div>
                    </div>
                </div>
            </div>

            <div class="col-lg-6 col-xlg-9">
                <div class="widget widget-shadow example-responsive ">
                    <div class="widget-content padding-20 padding-bottom-25">
                        <div class="row padding-bottom-40 teamCompletedWidget" data-plugin="matchHeight">
                            <div class="col-md-6 col-sm-12 ">
                                <div class="counter text-left padding-left-10">
                                    <div class="counter-label">ROI</div>
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-12">
                                <div class="counter text-right padding-right-20">
                                    <div class="counter-label font-size-20">Last 7 Days</div>
                                </div>
                                <ul class="list-inline list-inline-roi margin-right-50 margin-top-20">
                                    <li style="background-color:white">
                                        
                                    </li>
                                    <li>
                                        ROI(%)
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="ct-chart" id="roi_chart" style="height:300px;" data-date='<?php echo $spent_revenue['date']?>' data-profit='<?php echo $spent_revenue['profit']?>'></div>
                    </div>
                </div>
            </div>


            <!-- Team Total Completed -->
            <div class="col-lg-12 col-xlg-9">
                <div id="teamCompletedWidget" class="widget widget-shadow example-responsive teamCompletedWidget">
                    <div class="widget-content padding-20 padding-bottom-25">
                        <div class="row padding-bottom-40" data-plugin="matchHeight">
                            <div class="col-md-6 col-sm-12">
                                <div class="counter text-left padding-left-10">
                                    <div class="counter-label">Conversions Statistics</div>
                                    <div class="counter-number-group text-truncate">
                                        <span><?php echo number_format($conversions_date['results_total'])?></span>
                                        <span><?php echo $conversions_date['clicks_total']>0?sprintf("%.2f", $conversions_date['results_total']/$conversions_date['clicks_total']*100):0?>%</span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-12">
                                <div class="counter text-right padding-right-20">
                                    <div class="counter-label font-size-20">Last 7 Days</div>
                                </div>
                                <ul class="list-inline margin-right-50 margin-top-20 conversions_ul">
                                    <li>
                                        Conversions
                                    </li>
                                    <li>
                                        Clicks
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="ct-chart" id="conversions_charts" data-date='<?php echo $conversions_date['date']?>' data-results='<?php echo $conversions_date['results']?>' data-clicks='<?php echo $conversions_date['clicks']?>'></div>
                    </div>
                </div>
            </div>

            <div class="col-lg-12 col-xlg-9">
                <div class="widget widget-shadow example-responsive ">
                    <div class="widget-content padding-20 padding-bottom-25">
                        <div class="row padding-bottom-40 teamCompletedWidget" data-plugin="matchHeight">
                            <div class="col-md-6 col-sm-12 ">
                                <div class="counter text-left padding-left-10">
                                    <div class="counter-label">Top 10 Products Spent/Revenue</div>
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-12">
                                <div class="counter text-right padding-right-20">
                                    <div class="counter-label font-size-20">Last 7 Days</div>
                                </div>
                                <ul class="list-inline margin-right-50 margin-top-20">
                                    <li>
                                        Spent(USD)
                                    </li>
                                    <li>
                                        Revenue(USD)
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="ct-chart" id="product_chart" style="height:300px;" data-name='<?php echo $product_data['name']?>' data-spent='<?php echo $product_data['spent']?>' data-revenue='<?php echo $product_data['revenue']?>'></div>
                    </div>
                </div>
            </div>


            <div class="col-lg-12 col-xlg-9">
                <div class="widget widget-shadow example-responsive ">
                    <div class="widget-content padding-20 padding-bottom-25">
                        <div class="row padding-bottom-40 teamCompletedWidget" data-plugin="matchHeight">
                            <div class="col-md-6 col-sm-12 ">
                                <div class="counter text-left padding-left-10">
                                    <div class="counter-label">Top 10 Offers Spent/Revenue</div>
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-12">
                                <div class="counter text-right padding-right-20">
                                    <div class="counter-label font-size-20">Last 7 Days</div>
                                </div>
                                <ul class="list-inline margin-right-50 margin-top-20">
                                    <li>
                                        Spent(USD)
                                    </li>
                                    <li>
                                        Revenue(USD)
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="ct-chart" id="offer_chart" style="height:300px;" data-name='<?php echo $country_data['name']?>' data-spent='<?php echo $country_data['spent']?>' data-revenue='<?php echo $country_data['revenue']?>'></div>
                    </div>
                </div>
            </div>
            <?php $spent = json_decode($publisher_data['spent'], true); if($spent):?>
            <div class="col-lg-12 col-xlg-9">
                <div class="widget widget-shadow example-responsive ">
                    <div class="widget-content padding-20 padding-bottom-25">
                        <div class="row padding-bottom-40 teamCompletedWidget" data-plugin="matchHeight">
                            <div class="col-md-6 col-sm-12 ">
                                <div class="counter text-left padding-left-10">
                                    <div class="counter-label">Publisher Spent/Revenue</div>
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-12">
                                <div class="counter text-right padding-right-20">
                                    <div class="counter-label font-size-20">Last 7 Days</div>
                                </div>
                                <ul class="list-inline margin-right-50 margin-top-20">
                                    <li>
                                        Spent(USD)
                                    </li>
                                    <li>
                                        Revenue(USD)
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="ct-chart" id="publisher_chart" style="height:300px;" data-name='<?php echo $publisher_data['name']?>' data-spent='<?php echo $publisher_data['spent']?>' data-revenue='<?php echo $publisher_data['revenue']?>'></div>
                    </div>
                </div>
            </div>
            <?php endif;?>
            
        </div>
    </div>
</div>
<!-- End Page -->


<script src="<?php echo base_url(); ?>assets/web/global/vendor/chartist-js/chartist.js"></script>
<script
<script src="<?php echo base_url(); ?>assets/web/global/vendor/aspieprogress/jquery-asPieProgress.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/vendor/matchheight/jquery.matchHeight-min.js"></script>
<script src="<?php echo base_url(); ?>assets/web/assets/examples/js/uikit/icon.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/js/components/matchheight.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/js/components/aspieprogress.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/chartist-plugin-tooltip.min.js"></script>


<script src="<?php echo base_url(); ?>assets/js/team.js"></script>
<script src="<?php echo base_url(); ?>assets/js/charts.js"></script>

