<!-- 新加css -->
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/assets/examples/css/advanced/masonry.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/select2/select2.css">
<style>
    .table>tbody>tr>td{vertical-align: middle;}
    .ad_circle{width:86px;height: 86px; border-radius: 50%;background: rgba(255,255,255,0.2); position: absolute;left: -9px; top:-29px; font-size:48px; font-weight: bold; line-height: 100px;text-align: center;}
    .select2-search>input {
        width: 220px!important;
    }
    .select2-container{z-index: 1800;}
    .counter-sm{cursor:pointer;}
    .counter-sm:hover .counter-label{color:#79848e;}
    .counter-sm:hover .counter-number{color:#79848e;}
    .setting:hover{color:#EBEBEB!important;}
    .select2-container--default.select2-container--open .select2-selection {
        border-color: #12abc5;
    }
</style>
<!-- Page -->
<div class="page animsition">
    <div class="page-header">
        <ol class="breadcrumb">
            <li><a href="<?php echo site_url('manager/user/index');?>">Management</a></li>
            <li class="active">Agenc</li>
        </ol>
        <div class="clearfix">
            <div class="pull-right">
                <button type="button" id="add_bucket_Label" data-target="#add_agency_div" data-toggle="modal" class="btn btn-primary btn-round margin-right-15 pull-left" style="background:#12abc5;">
                    <i class="icon wb-plus" aria-hidden="true"></i>
                    Add Agency
                </button>
                <div class="form-group pull-right margin-bottom-0">
                    <div class="input-search margin-bottom-0">
                        <i class="input-search-icon wb-search" aria-hidden="true"></i>
                        <input type="text" class="form-control" value="<?php echo $this->input->get('q')?$this->input->get('q'):''; ?>" name="q" placeholder="Search...">
                        <button type="button" class="input-search-close icon wb-close" aria-label="Close"></button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="page-content padding-30 blue-grey-500 padding-top-0">
        <ul class="blocks blocks-100 blocks-xlg-3 blocks-lg-3 blocks-md-3 blocks-sm-2" data-plugin="masonry">
            <?php $colors=['#998fff','#7ed321','#f7dd72','#22d3b7','#ff8c9a','#9b9b9b'];?>
            <?php foreach($data as $k=>$item):?>
                <?php $color=$colors[array_rand($colors)];?>
                <li class="masonry-item">
                    <div class="widget-article widget-shadow bg-white">
                        <div class="widget-header cover">
                            <div class="margin-bottom-15" style="height:92px; background:<?php echo $color;?>;position: relative;">
                                    <span class="ad_circle" style="color:<?php echo $color;?>;">AD</span>
                                    <p class="font-size-30 padding-top-20 padding-left-20 font-weight-500 margin-bottom-0" style="color: #fff;position: relative;line-height:30px;"><?php echo $item['user_name']?></p>
                                    <p class="font-size-16 padding-top-0" style="color:#fff; padding-left:20px;"><?php echo $item['email'];?></p>
                                    <div style="position: absolute;right: 20px;top: 20px;">
                                        <a  data-toggle="modal" data-target="#set_account" data-agency="<?php echo $item['user_id']?>" data-agency-name="<?php echo $item['user_name']?>" class="setting setting_agency_account" style="color: #fff;">
                                            <i class="icon wb-settings" aria-hidden="true"></i>
                                        </a>
                                    </div>
                            </div>
                            <div class="row padding-top-5 padding-bottom-20">
                                <div class="col-xs-4 agency_advertiser" data-toggle="modal" data-target="#agency_advertiser" data-agency="<?php echo $item['user_id'];?>">
                                    <div class="counter counter-sm">
                                        <div class="counter-label">Advertiser</div>
                                        <div class="counter-number font-weight-600"><?php echo count($item['advertiser'])?></div>
                                    </div>
                                </div>
                                <div class="col-xs-4">
                                    <div class="counter counter-sm">
                                        <div class="counter-label">Product</div>
                                        <div class="counter-number font-weight-600"><?php echo count($item['product'])?></div>
                                    </div>
                                </div>
                                <div class="col-xs-4 agency_account" data-toggle="modal" data-target="#account_details" data-agency="<?php echo $item['user_id']?>">
                                    <div class="counter counter-sm">
                                        <div class="counter-label">Account</div>
                                        <div class="counter-number font-weight-600"><?php echo count($item['account'])?></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </li>
            <?php endforeach;?>
        </ul>
    </div>
</div>

<!-- 弹框 -->
<div class="modal fade" id="set_account" aria-hidden="false" aria-labelledby="add_bucket_Label" role="dialog" tabindex="-1">
    <div class="modal-dialog">
    <form class="modal-content" autocomplete="off" method="post" id="add_agency_account" action="<?php echo site_url('manager/user/add_agency_account_action')?>">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
                <h4 class="modal-title" id="add_bucket_Label">Setting</h4>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-lg-12 form-group ">
                        <label class="control-label" for="advertiser">
                            Accounts
                            <span class="required">*</span>
                        </label>
                        <select class="form-control" name="select_account[]" multiple="" data-plugin="select2" data-placeholder="Select Accounts" data-allow-clear="true">
                            <?php foreach($account as $key=>$val):?>
                             <option value="<?php echo $val['account_id']?>"><?php echo $val['account_id'].' ( '.$val['name']." )"?></option>
                            <?php endforeach;?>
                        </select>
                    </div>
                    <input type="hidden" name="agency_id" class="agency_id" value="">
                    <input type="hidden" name="agency_name" class="agency_name" value="">
                    <div class="col-lg-12 form-group ">
                        <button type="submit" class="btn btn-primary" id="add_agency_account_button">Submit</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<!-- account -->
<div class="modal fade" id="account_details" aria-hidden="true" aria-labelledby="exampleModalTabs"
 role="dialog" tabindex="-1">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×</span>
              </button>
              <h4 class="modal-title" id="agency_model_title">Accounts</h4>
        </div>
        <div class="modal-body">
           <table class="editable-table table table-striped" id="editableTable">
                <thead class="agency_account_modal_thead">
                    <tr>
                        <td>Accounts</td>
                    </tr>
                </thead>
                <tbody class="agency_account_details">

                </tbody>
            </table>
        </div>
      </div>
    </div>
</div>
<!-- Advertiser -->
<div class="modal fade" id="agency_advertiser" aria-hidden="true" aria-labelledby="exampleModalTabs"
 role="dialog" tabindex="-1">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×</span>
              </button>
              <h4 class="modal-title" id="agency_model_title">Advertiser</h4>
        </div>
        <div class="modal-body">
           <table class="editable-table table table-striped" id="editableTable">
                <thead class="agency_account_modal_thead">
                    <tr>
                        <td>Advertiser</td>
                    </tr>
                </thead>
                <tbody class="agency_advertiser_details">

                </tbody>
            </table>
        </div>
      </div>
    </div>
</div>
<!--添加-->
<div class="modal fade" id="add_agency_div" aria-hidden="false" aria-labelledby="add_bucket_Label" role="dialog" tabindex="-1">
    <div class="modal-dialog">
        <form class="modal-content" autocomplete="off" method="post" id="add_agency" action="<?php echo site_url('manager/user/add_agency_action')?>">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
                <h4 class="modal-title" id="add_bucket_Label">Add Agency</h4>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-lg-12 form-group ">
                        <label class="control-label" for="name">
                            Name
                            <span class="required">*</span>
                        </label>
                        <input type="text" class="form-control" id="name" name="input_name" placeholder="" autocomplete="off">
                    </div>

                    <div class="col-lg-12 form-group ">
                        <label class="control-label" for="email">
                            Email
                            <span class="required">*</span>
                        </label>
                        <input type="text" class="form-control" id="email" name="input_email" placeholder="" autocomplete="off">
                    </div>

                    <div class="col-lg-12 form-group ">
                        <label class="control-label" for="email">
                            Country
                            <!-- <span class="required">*</span> -->
                        </label>
                        <select class="form-control" id="select" name="select_country">
                            <option></option>
                            <?php foreach($config_product['countries'] as $key=>$val):?>
                                <option value="<?php echo $key?>" <?php echo $key=='CN'?"selected='selected'":''?>><?php echo $val?></option>
                            <?php endforeach;?>
                        </select>
                    </div>


                    <div class="col-lg-12 form-group ">
                        <label class="control-label" for="Conversion_Rate">
                            Conversion Rate
                        </label>
                        <input type="text" class="form-control" id="Conversion_Rate" name="chart[input_conversion_rate]" placeholder="" autocomplete="off" maxlength="2">
                    </div>

                    <div class="col-lg-12 form-group ">
                        <label class="control-label" for="product_count">
                            Product Count
                        </label>
                        <input type="text" class="form-control" value="" id="product_count" name="chart[input_product_count]" placeholder="" autocomplete="off" maxlength="2">
                    </div>

                    <div class="col-lg-12 form-group ">
                        <label class="control-label" for="next_day">
                            Retention Of Next Day
                        </label>
                        <input type="text" class="form-control" id="next_day" name="chart[input_next_day]" placeholder="" autocomplete="off" maxlength="2">
                    </div>

                    <div class="col-lg-12 form-group ">
                        <label class="control-label" for="7days">
                            Retention Of 7 Days
                        </label>
                        <input type="text" class="form-control" id="7days" name="chart[input_7days]" placeholder="" autocomplete="off" maxlength="2">
                    </div>

                    <div class="col-lg-12 form-group ">
                        <label class="control-label" for="30days">
                            Retention Of 30 Days
                        </label>
                        <input type="text" class="form-control" id="30days" name="chart[input_30days]" placeholder="" autocomplete="off" maxlength="2">
                    </div>
                    <div class="col-lg-12 form-group ">
                        <label class="control-label" for="30days">
                            Score
                        </label>
                        <input type="text" class="form-control" name="score" placeholder="" autocomplete="off">
                    </div>
                    <div class="col-lg-12 form-group ">
                        <label class="control-label" for="30days">
                            Tags
                        </label>
                        <select class="form-control" id="tags" name="tags">
                            <option></option>
                            <?php foreach(config_item('tags') as $val):?>
                                <option value="<?php echo $val?>"><?php echo $val?></option>
                            <?php endforeach;?>
                        </select>
                    </div>
                    <div class="col-lg-12 form-group ">
                        <button type="submit" class="btn btn-primary" id="add_agency_button">Submit</button>
                    </div>

                </div>
            </div>
        </form>
    </div>
</div>
<!-- 新加js -->
<script src="<?php echo base_url();?>assets/web/global/vendor/masonry/masonry.pkgd.min.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/core.js"></script>
<script src="<?php echo base_url();?>assets/web/assets/js/site.js"></script>
<script src="<?php echo base_url();?>assets/web/assets/js/sections/menu.js"></script>
<script src="<?php echo base_url();?>assets/web/assets/js/sections/menubar.js"></script>
<script src="<?php echo base_url();?>assets/web/assets/js/sections/sidebar.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/configs/config-colors.js"></script>
<script src="<?php echo base_url();?>assets/web/assets/js/configs/config-tour.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/components/asscrollable.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/components/animsition.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/components/slidepanel.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/asrange/jquery-asRange.min.js"></script>
<script src="<?php echo base_url();?>assets/web/assets/examples/js/uikit/icon.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/components/switchery.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/components/masonry.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/select2/select2.min.js"></script>  
<script src="<?php echo base_url();?>assets/web/global/js/components/select2.js"></script>
<!-- 新加js结束 -->
<script>
    $('.input-search').keydown(function (e) {
        var curKey = e.which;
        if (curKey == 13) {
            var url = '<?php echo site_url('manager/user/agency?q=');?>';
            var data = $('input[name=q]').val();
            url = url + data;
            location.href = url;
        }
    });
    $('.input-search-close').click(function () {
        location.href='<?php echo site_url('manager/user/agency');?>';
    });
</script>