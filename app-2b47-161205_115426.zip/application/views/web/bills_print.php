<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta name="description" content="bootstrap admin template">
    <meta name="author" content="">
    <title>Bill Detail Print</title>
    <link rel="apple-touch-icon" href="<?php echo base_url(); ?>assets/web/assets/images/apple-touch-icon.png">
    <link rel="shortcut icon" href="<?php echo base_url(); ?>assets/web/assets/images/favicon.ico">
    <!-- Stylesheets -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/global/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/global/css/bootstrap-extend.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/assets/css/site.min.css">
    <!-- Plugins -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/global/vendor/animsition/animsition.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/global/vendor/asscrollable/asScrollable.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/global/vendor/switchery/switchery.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/global/vendor/intro-js/introjs.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/global/vendor/slidepanel/slidePanel.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/global/vendor/flag-icon-css/flag-icon.min.css">
    <!-- <link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/global/vendor/toastr/toastr.min.css"> -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/assets/examples/css/advanced/toastr.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/assets/examples/css/pages/profile.min.css">

    <!-- Fonts -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/global/fonts/web-icons/web-icons.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/global/fonts/font-awesome/font-awesome.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/global/fonts/brand-icons/brand-icons.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/global/fonts/brand-icons/brand-icons.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/global/fonts/google/fonts.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/location.default.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/global/fonts/material-design/material-design.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/assets/examples/css/uikit/icon.css">
    <!--[if lt IE 9]>
    <script src="<?php echo base_url();?>assets/web/global/vendor/html5shiv/html5shiv.min.js"></script>
    <![endif]-->
    <!--[if lt IE 10]>
    <script src="<?php echo base_url();?>assets/web/global/vendor/media-match/media.match.min.js"></script>
    <script src="<?php echo base_url();?>assets/web/global/vendor/respond/respond.min.js"></script>
    <![endif]-->
    <!-- Scripts -->
    <script src="<?php echo base_url(); ?>assets/web/global/vendor/modernizr/modernizr.js"></script>
    <script src="<?php echo base_url(); ?>assets/web/global/vendor/breakpoints/breakpoints.js"></script>
    <script>
        Breakpoints();
    </script>

    <style type="text/css">
        @media (min-width: 768px) {
            .site-navbar .navbar-header {
                width: 220px;
            }
        }
    </style>
    <!-- Core  -->
    <script src="<?php echo base_url(); ?>assets/web/global/vendor/jquery/jquery.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/web/global/vendor/bootstrap/bootstrap.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/web/global/vendor/animsition/animsition.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/web/global/vendor/asscroll/jquery-asScroll.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/web/global/vendor/mousewheel/jquery.mousewheel.min.js"></script>
    <script
        src="<?php echo base_url(); ?>assets/web/global/vendor/asscrollable/jquery.asScrollable.all.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/web/global/vendor/ashoverscroll/jquery-asHoverScroll.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/web/global/vendor/asrange/jquery-asRange.min.js"></script>
    <!-- Plugins -->
    <script src="<?php echo base_url(); ?>assets/web/global/vendor/switchery/switchery.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/web/global/vendor/intro-js/intro.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/web/global/vendor/screenfull/screenfull.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/web/global/vendor/slidepanel/jquery-slidePanel.min.js"></script>
    <!-- Scripts -->
    <script src="<?php echo base_url(); ?>assets/web/global/js/core.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/web/assets/js/site.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/web/assets/js/sections/menu.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/web/assets/js/sections/menubar.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/web/assets/js/sections/sidebar.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/web/global/js/configs/config-colors.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/web/assets/js/configs/config-tour.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/web/global/js/components/asscrollable.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/web/global/js/components/animsition.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/web/global/js/components/slidepanel.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/web/global/js/components/switchery.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/jQuery.print.js"></script>
    <script src="<?php echo base_url(); ?>assets/web/assets/examples/js/uikit/icon.js"></script>
    <style>
        .table > tbody > tr > td {
            vertical-align: middle;
        }

        .counter-lg .counter-number-group, .counter-lg > .counter-number {
            font-size: 24px;
        }
    </style>
</head>
<body class="site-navbar-small padding-top-0">
<!--[if lt IE 8]>
<p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade
    your browser</a> to improve your experience.</p>
<![endif]-->
<div class="page animsition">
    <div class="page-header clearfix">
        <div class="filter pull-right">
            <?php echo $date ?>
        </div>
    </div>
    <div class="page-content">
        <div class="row">
            <div class="col-lg-12 col-md-12">
                <div class="row">
                    <div class="col-xs-4">
                        <div class="widget widget-border" style="height:185px;overflow:hidden;">
                            <div class="widget-content padding-25 bg-white">
                                <div class="counter counter-lg ">
                                    <div class="counter-number-group margin-vertical-20">
                                        <span class="counter-number-related">$</span>
                                        <span class="counter-number"><?php echo number_format($paid, 2) ?></span>
                                    </div>
                                    <div class="counter-label text-uppercase">
                                        <img src="<?php echo base_url(); ?>assets/images/bill_details_green.png"
                                             style="vertical-align:top;padding-top:3px;">
                                        <span class="margin-left-5"
                                              style="height:21px;line-height: 21px;display: inline-block;">应付金额</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xs-4">
                        <div class="widget widget-border" style="height:185px; overflow:hidden;">
                            <div class="widget-content padding-25 bg-white">
                                <div class="counter counter-lg ">
                                    <div class="counter-number-group margin-vertical-20 red-600">
                                        <span class="counter-number-related">$</span>
                                        <span
                                            class="counter-number"><?php echo number_format($adjust_money, 2) ?></span>
                                    </div>
                                    <div class="counter-label text-uppercase">
                                        <img src="<?php echo base_url(); ?>assets/images/bill_details_red.png"
                                             style="vertical-align:top;padding-top:3px;">
                                        <span class="margin-left-5"
                                              style="height:21px;line-height: 21px;display: inline-block;">调整金额</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xs-4">
                        <div class="widget widget-border" style="height:185px;overflow:hidden;">
                            <div class="widget-content padding-25 bg-white">
                                <div class="counter counter-lg ">
                                    <div class="counter-number-group margin-vertical-20">
                                        <span class="counter-number-related">$</span>
                                        <span
                                            class="counter-number"><?php echo number_format($paid + $adjust_money, 2) ?></span>
                                    </div>
                                    <div class="counter-label text-uppercase">
                                        <img src="<?php echo base_url(); ?>assets/images/bill_details_green.png"
                                             style="vertical-align:top;padding-top:3px;">
                                        <span class="margin-left-5"
                                              style="height:21px;line-height: 21px;display: inline-block;">实际金额</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php if ($data): ?>
            <div class="panel widget-border">
                <header class="panel-heading clearfix">
                    <h3 class="panel-title pull-left">Bills Details</h3>
                </header>
                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="table dataTable table-striped width-full">
                            <thead>
                            <tr class="change_thead">
                                <?php if ($user_info['type'] == 1): ?>
                                    <th style="width:15%;">Advertiser</th>
                                    <th style="width:30%;">Product</th>
                                    <th style="width:20%;">Category</th>
                                    <th style="width:15%;">Conversion</th>
                                    <th style="width:20%;">Total Pay</th>
                                <?php else: ?>
                                    <th style="width:25%;">Publisher</th>
                                    <th style="width:50%;">Product</th>
                                    <th style="width:20%;">Category</th>
                                    <th style="width:15%;">Conversion</th>
                                    <th style="width:15%;">Total Pay</th>
                                <?php endif; ?>
                            </tr>
                            </thead>
                            <tbody>
                            <?php foreach ($data as $item): ?>
                                <tr>
                                    <td><?php echo $item['user_name'] ?></td>
                                    <td><?php echo $item['product_name'] ?></td>
                                    <td><?php echo $item['product_category'] == 'android'?'Android':'iOS' ?></td>
                                    <td><?php echo number_format($item['results']) ?></td>
                                    <td>$<?php echo number_format($item['amount'], 2) ?></td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        <?php if ($adjust): ?>
            <div class="panel widget-border">
                <header class="panel-heading clearfix">
                    <h3 class="panel-title pull-left">Bills Adjust</h3>
                </header>
                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="table dataTable table-striped width-full">
                            <thead>
                            <tr class="change_thead">
                                <th style="width:20%;">Date</th>
                                <th style="width:20%;">Adjust Type</th>
                                <th style="width:20%;">Money</th>
                                <th style="width:40%;">Reason</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php foreach ($adjust as $item): ?>
                                <tr>
                                    <td><?php echo date('m/d/Y', $item['extend_date']) ?></td>
                                    <td><?php echo $item['money_type'] == 1?'罚款':'奖励'; ?></td>
                                    <td>
                                        $<?php echo sprintf("%.2f", abs($item['money'])) ?>
                                    </td>
                                    <td>
                                        <?php echo $item['reason'] ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>
</body>
</html>