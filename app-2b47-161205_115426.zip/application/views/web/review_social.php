<!-- 新加css -->
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/global/vendor/select2/select2.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/global/vendor/bootstrap-select/bootstrap-select.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/global/fonts/material-design/material-design.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/assets/examples/css/uikit/icon.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/global/vendor/footable/footable.css">
<style>
    .table>thead>tr>th{border-bottom:0;}
    .table>tbody>tr>td{vertical-align: middle;border-top: 0; border-bottom: 1px solid #edefee;}
    .table>tbody>tr.active>td{background-color:#fff!important; color:#596065!important;}
</style>

<!-- Page -->
<div class="page animsition">
    <div class="page-header">
        <ol class="breadcrumb">
            <li><a href="<?php echo site_url('review');?>" style="text-decoration:none;">Creative</a></li>
            <li class="active">Risk</li>
        </ol>
    </div>
    <div class="page-content padding-30 padding-top-0 blue-grey-500">
        <!-- 数据 -->
        <div class="panel" style="box-shadow:none;border: 1px solid #e3eaec;">
            <header class="panel-heading clearfix">
                <h3 class="panel-title pull-left">Details</h3>
                <div class="pull-right col-md-6">
                    <div class="pull-right col-md-5 margin-top-15">
                        <button type="button" data-url="<?php echo site_url('review/get_export');?>" class="wz-comments-export pull-right btn btn-outline btn-default wz-comments-download hover_btn margin-left-10" data-comments=""><i class="icon md-download" aria-hidden="true"></i> Comments </button>
                        <button type="button" data-url="<?php echo site_url('review/get_export');?>" class="wz-user-export pull-right btn btn-outline btn-default wz-user-download hover_btn" data-uid="" ><i class="icon md-download" aria-hidden="true"></i>  Users </button>
                    </div>
                </div>
            </header>
            <div class="panel-body container-fluid table-responsive">
                <table class="table text-center width-full" id="" data-selectable="selectable" data-row-selectable="true" data-page-size="7">
                    <thead class="thead change_thead" id="thead">
                        <tr>
                            <th data-sort-ignore="true" class="min-width text-center" data-sort-initial="true" data-toggle="true" style="width:12%;">Ad Creative</th>
                            <th data-hide="phone, tablet" class="text-center">Impressions</th>
                            <th data-hide="phone, tablet" class="text-center">Results</th>
                            <th data-hide="phone, tablet" class="text-center">Relevance</th>
                            <th data-hide="phone, tablet" class="text-center">CTR</th>
                            <th data-hide="phone, tablet" class="text-center">Shares</th>
                            <th data-hide="phone, tablet" class="text-center">Likes</th>
                            <th data-hide="phone, tablet" class="text-center">Comments</th>
                            <th data-sort-ignore="true" class="text-center min-width">User</th>
                            <th data-sort-ignore="true" class="text-center min-width">Comments</th>
                            <th data-sort-ignore="true"  class="text-center min-width">
                                <div class="checkbox-custom checkbox-primary" style="width: 20px; margin: 0 auto;">
                                    <input type="checkbox" name="inputCheckboxes" id="media_all" class="selectable-all">
                                    <label for="media_all"></label>
                                </div>
                            </th>
                        </tr>
                    </thead>
                    <tbody class="tbody">
                    <?php if($ad_list):?>
                        <?php foreach($ad_list as $ad):?>
                            <tr>
                                <td style="vertical-align : middle;">
                                    <img onerror="this.src='<?php echo $ad['org_thumbnail_url'];?>';" src="<?php echo $ad['image_url']?$ad['image_url']:$ad['org_thumbnail_url'];?>" alt="" style="max-width:120px;">
                                </td>
                                <td><?php echo number_format($ad['impressions'])?></td>
                                <td><?php echo number_format($ad['results'])?></td>
                                <td><?php echo number_format($ad['relevance_score'])?></td>
                                <td><?php echo $ad['ctr']?>%</td>
                                <td><?php echo number_format($ad['shares'])?></td>
                                <td><?php echo number_format($ad['likes'])?></td>
                                <td><?php echo number_format($ad['comments'])?></td>
                                <td>
                                    <button type="button" data-uid="<?php echo $ad['ad_id'];?>" class="wz-user font-size-18 btn btn-pure btn-default icon md-download"></button>
                                </td>
                                <td>
                                    <button type="button" data-comments="<?php echo $ad['ad_id'];?>" class="wz-comments font-size-18 btn btn-pure btn-default icon md-download"></button>
                                </td>
                                <td>
                                    <div class="checkbox-custom checkbox-primary" style="width: 20px; margin: 0 auto;">
                                        <input type="checkbox" name="inputCheckboxes" data-uid="<?php echo $ad['ad_id'];?>" data-comments="<?php echo $ad['ad_id'];?>" value="<?php echo $ad['account_id'];?>" class="selectable-item">
                                        <label for=""></label>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach;?>
                    <?php endif;?>
                    </tbody>
                </table>
                <div class="fixed-table-pagination clearfix">
                    <div class="pull-right pagination">
                        <?php echo $page_links?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- 新加js -->
<script src="<?php echo base_url(); ?>assets/web/global/js/components/panel.js"></script>
<script src="<?php echo base_url(); ?>assets/web/assets/examples/js/uikit/panel-actions.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/vendor/bootstrap-select/bootstrap-select.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/js/components/bootstrap-select.js"></script>
<script src="<?php echo base_url(); ?>assets/web/assets/examples/js/uikit/icon.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/js/plugins/selectable.js"></script>
<script src="<?php echo base_url(); ?>assets/js/selectable.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/vendor/footable/footable.all.min.js"></script>
<script src="<?php echo base_url(); ?>assets/web/assets/examples/js/tables/footable.js"></script>
