<style type="text/css">
    .select2-container--open{
        z-index: 9999;
    }
    .ui-timepicker-wrapper{
        z-index: 1700;
    }
</style>
<div class="modal fade" id="add_bucket" aria-hidden="false" aria-labelledby="add_bucket_Label" role="dialog" tabindex="-1">
    <div class="modal-dialog">
    <form class="modal-content add_bucket_form" autocomplete="off" id="my_form2"  method="post" action="<?php echo site_url('manager/offer/add_offer_action')?>">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
                <h4 class="modal-title" id="add_bucket_Label">Add Offer</h4>
            </div>
            <input type="hidden" name="product_id" value="<?php echo $product_info['product_id']?>">
            <div class="modal-body">
                <div class="row"> 

                    <div class="col-lg-12 form-group ">
                        <label class="control-label" for="select_country">    Country
                            <span class="required">*</span>
                        </label>
                        <div class="input-group">
                            <div class="radio-custom radio-default radio-inline">
                                <input type="radio" id="bucket_include" name="choose_type" value="include" checked="">
                                <label for="bucket_include">Include</label>
                            </div>
                            <div class="radio-custom radio-default radio-inline">
                                <input type="radio" id="bucket_exclude" name="choose_type"  value="exclude">
                                <label for="bucket_exclude">Exclude</label>
                            </div>
                        </div>
                    </div>


                    <div class="col-lg-12 form-group" id="exclude_countries" >
                        <select  class="form-control bucket_country_select" multiple="" data-plugin="select2" name="select_country[]" data-placeholder="All Countries">
                            <?php foreach($config_product['countries'] as $key=>$val):?>
                                <?php if(!in_array($key,$include_countries)):?>
                                <option value="<?php echo $key?>" ><?php echo $val."(".$key.")"?></option>
                                <?php endif;?>
                            <?php endforeach;?>
                        </select>
                    </div>
                    <div class="col-lg-12 form-group" id="inclue_countries" style="display:none">
                        <select class="form-control" multiple="" data-plugin="select2" name="select_country[]" data-placeholder="All Countries">
                            <?php foreach($config_product['countries'] as $key=>$val):?>
                                <?php if(!in_array($key,$exclude_countries)):?>
                                <option value="<?php echo $key?>" ><?php echo $val?></option>
                                <?php endif;?>
                            <?php endforeach;?>
                        </select>
                    </div>


                    <div class="col-lg-12 form-group ">
                        <label class="control-label" for="select_country">    RPA
                            <span class="required">*</span>
                        </label>
                        <div class="input-group bootstrap-touchspin">
                            <span class="input-group-addon bootstrap-touchspin-prefix">$</span>
                            <input type="text" class="form-control" name="input_rpa" data-plugin="TouchSpin" data-min="0" data-max="1000000000" data-stepinterval="50" data-maxboostedstep="10000000" data-prefix="$" value="" style="display: block;">
                        </div>
                    </div>

                    
                    <div class="col-lg-12 form-group starttime_class">
                        <label class="control-label" for="description">
                            Effective Time
                            <span class="required">*</span>
                        </label>
                        <div class="input-daterange-wrap">
                            <div class="input-daterange">
                                <div class="input-group">
                                    <span class="input-group-addon">
                                        <i class="icon wb-calendar" aria-hidden="true"></i>
                                    </span>
                                        <input type="text" class="form-control datepair-date datepair-start" data-plugin="datepicker" name="input_date" id="inputdate" value="">
                                </div>
                                <div class="input-group ">
                                    <span class="input-group-addon">
                                        <i class="icon wb-time" aria-hidden="true"></i>
                                    </span>
                                    <input type="text" class="form-control datepair-time datepair-start" data-plugin="timepicker" name="input_time" id="inputtime"
                                        value="12:00am" />
                                </div>
                            </div>
                        </div>
                    </div>

                    
                    <div class="col-sm-12 pull-right">
                      <button class="btn btn-info" data-dismiss="" type="submit" id="my_val">Submit</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>