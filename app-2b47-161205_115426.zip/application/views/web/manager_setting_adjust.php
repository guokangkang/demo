<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/assets/examples/css/tables/datatable.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/global/vendor/select2/select2.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/global/vendor/owl-carousel/owl.carousel.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/global/vendor/slick-carousel/slick.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/assets/examples/css/uikit/carousel.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/daterangepicker.css"/>
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/global/vendor/bootstrap-datepicker/bootstrap-datepicker.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/global/fonts/material-design/material-design.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/assets/examples/css/uikit/icon.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/index_select.css">

<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/global/vendor/webui-popover/webui-popover.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/global/vendor/toolbar/toolbar.css">

<div class="page animsition">
    <div class="page-header">
        <ol class="breadcrumb">
            <li><a href="<?php echo site_url('manager/product/listview') ?>">Manager Management</a></li>
            <li><a href="<?php echo site_url('manager/setting/adjust') ?>">Bill Adjust</a></li>
            <li class="active">Index</li>
        </ol>
    </div>
    <div class="page-content padding-30 blue-grey-500 padding-top-0">
        <div class="nav-tabs-horizontal">
            <div class="tab-content widget-border">
                <div class="tab-pane active" id="exampleTabsOne" role="tabpanel">
                    <div class="panel margin-bottom-0">
                        <header class="panel-heading margin-bottom-0 clearfix">
                            <h3 class="panel-title pull-left">Details</h3>
                            <div class="pull-right margin-top-15 padding-right-30">
                                <div>
                                    <button data-target="#add_bills" data-toggle="modal"
                                            class="btn btn-primary btn-round margin-right-15"
                                            style="background:#12abc5;color:#fff!important;"><i class="icon wb-plus"
                                                                                                aria-hidden="true"></i>
                                        Add Adjust
                                    </button>
                                </div>
                            </div>
                        </header>
                        <div class="panel-body table-responsive">
                            <table class="table dataTable table-striped width-full" id="facebook_report"
                                   data-selectable="selectable" data-row-selectable="true">
                                <thead class="change_thead">
                                <tr>
                                    <th style="width: 15%">Date</th>
                                    <th style="width: 15%">User</th>
                                    <th style="width: 15%">Adjust Type</th>
                                    <th style="width: 15%">Money</th>
                                    <th style="width: 30%">Reason</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php if ($list): ?>
                                    <?php foreach ($list as $item): ?>
                                        <tr>
                                            <td><?php echo date('m/d/Y', $item['extend_date']); ?></td>
                                            <td>
                                                <?php echo $item['user_name'] ?>
                                            </td>
                                            <td>
                                                <?php echo $item['money_type'] == 1?'罚款':'奖励'; ?><br/>
                                            </td>
                                            <td>
                                                $<?php echo sprintf("%.2f", abs($item['money']))?>
                                            </td>
                                            <td>
                                                <?php echo $item['reason'] ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="10">
                                            <div class="text-center padding-top-80">
                                                <img src="<?php echo site_url(); ?>assets/images/no_data.png">
                                                <h4 class="margin-top-30">NO DATA HERE</h4>
                                                <p style="line-height: 18px;">I hate peeping Toms. For one thing they
                                                    usually step all over<br>the hedges and plants on the side of
                                                    someone's house killing</p>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="panel-footer">
                            <div class="fixed-table-pagination clearfix">
                                <div class="pull-right">
                                    <?php echo $page_links?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="tab-pane panel margin-bottom-0 height-200" id="exampleTabsTwo" role="tabpanel"></div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="add_bills" aria-hidden="false" aria-labelledby="add_bucket_Label" role="dialog"
         tabindex="-1" style="display: none;">
        <div class="modal-dialog">
            <form class="modal-content" autocomplete="off" method="post" id="add_advertiser"
                  action="<?php echo site_url('manager/setting/add_bills_extend'); ?>">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                    <h4 class="modal-title" id="add_bucket_Label">Add Adjust</h4>
                </div>
                <input type="hidden" name="data[user_id][]" class="input_manager" value="">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-lg-12 form-group ">
                            <label class="control-label" for="first_name">
                                Type
                                <span class="required">*</span>
                            </label>
                            <div class="radio-custom radio-primary">
                                <input type="radio" name="data[user_type]" id="advertiser" value="1" checked>
                                <label for="advertiser" style="margin-right: 40px;">Advertiser</label>
                                <input type="radio" name="data[user_type]" id="publisher" value="2">
                                <label for="publisher">Publisher</label>
                            </div>
                        </div>
                        <div class="col-lg-12 form-group ">
                            <label class="control-label">
                                User ID
                                <span class="required">*</span>
                            </label>
                            <div class="form-group filter-form bills-filter">
                                <div class="diy_select">
                                    <!--【存】当前选中的值-->
                                    <input type="hidden" name="data[user_id]" class="diy_select_input filter_publisher"
                                           value="">
                                    <!--【显示】当前选中的值-->
                                    <input type="text" class="diy_select_txt filter_input_1" placeholder="Nothing selected"
                                           value="">
                                    <!--下拉三角形-->
                                    <span class="caret"
                                          style="right: 14px;position: absolute;top: 50%;margin-top: -2px;"></span>
                                    <!--数据列表-->
                                    <ul class="diy_select_list" style="display:none;" id="radiao_box_1">
                                        <?php if ($users): ?>
                                            <?php foreach ($users as $user): ?>
                                                <li data-key="<?php echo $user['user_id']; ?>">
                                                    <span><?php echo $user['user_id']; ?>(<?php echo $user['user_name']; ?>)</span>
                                                    <b class="icon wb-check check-mark"></b>
                                                </li>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12 form-group ">
                            <label class="control-label" for="first_name">
                                Date
                                <span class="required">*</span>
                            </label>
                            <input type="text" class="form-control" id="date" name="data[extend_date]" placeholder="" autocomplete="off">
                        </div>

                        <div class="col-lg-12 form-group ">
                            <label class="control-label" for="email">
                                Adjust Type
                                <span class="required">*</span>
                            </label>
                            <div class="radio-custom radio-primary">
                                <input type="radio" name="data[money_type]" id="money_type_1" value="1" checked>
                                <label for="money_type_1" style="margin-right: 40px;">扣罚</label>
                                <input type="radio" name="data[money_type]" id="money_type_2" value="2">
                                <label for="money_type_2">奖励</label>
                            </div>
                        </div>
                        <div class="col-lg-12 form-group ">
                            <label class="control-label" for="first_name">
                                Money
                                <span class="required">*</span>
                            </label>
                            <input type="text" class="form-control" id="first_name" name="data[money]" placeholder=""
                                   autocomplete="off">
                        </div>

                        <div class="col-lg-12 form-group">
                            <label class="control-label" for="first_name">
                                Reason
                                <span class="required">*</span>
                            </label>
                            <textarea cols="5" class="form-control" name="data[reason]"></textarea>
                        </div>

                        <div class="col-lg-12 form-group ">
                            <button type="submit" class="btn btn-primary" id="add_advertiser_button">Submit</button>
                        </div>

                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="<?php echo base_url(); ?>assets/web/global/vendor/datatables/jquery.dataTables.js"></script>
<script
    src="<?php echo base_url(); ?>assets/web/global/vendor/datatables-fixedheader/dataTables.fixedHeader.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/vendor/datatables-bootstrap/dataTables.bootstrap.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/vendor/datatables-responsive/dataTables.responsive.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/vendor/datatables-tabletools/dataTables.tableTools.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/vendor/editable-table/mindmup-editabletable.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/vendor/editable-table/numeric-input-example.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/vendor/owl-carousel/owl.carousel.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/vendor/slick-carousel/slick.js"></script>

<script src="<?php echo base_url(); ?>assets/web/global/js/components/datatables.js"></script>
<script src="<?php echo base_url(); ?>assets/web/assets/examples/js/tables/datatable.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/vendor/select2/select2.min.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/js/components/select2.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/js/components/editable-table.js"></script>
<script src="<?php echo base_url(); ?>assets/web/assets/examples/js/tables/editable.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/js/components/owl-carousel.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/js/components/panel.js"></script>
<script src="<?php echo base_url(); ?>assets/web/assets/examples/js/uikit/panel-actions.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/vendor/slidepanel/jquery-slidePanel.js"></script>
<script src="<?php echo base_url(); ?>assets/web/assets/js/app.js"></script>
<script src="<?php echo base_url(); ?>assets/js/new_js.js"></script>

<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/moment.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/daterangepicker.js"></script>
<script src="<?php echo base_url(); ?>assets/web/assets/examples/js/uikit/icon.js"></script>

<script src="<?php echo base_url(); ?>assets/web/global/vendor/webui-popover/jquery.webui-popover.min.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/vendor/toolbar/jquery.toolbar.min.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/js/components/webui-popover.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/js/components/toolbar.js"></script>
<script src="<?php echo base_url(); ?>assets/web/assets/examples/js/uikit/tooltip-popover.js"></script>
<script src="<?php echo base_url(); ?>assets/js/index_select.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/vendor/bootstrap-datepicker/bootstrap-datepicker.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/js/components/bootstrap-datepicker.js"></script>
<script>
    $('#publisher').click(function () {
        var type = $(this).val();
        var html = '';
        var url = '<?php echo site_url('manager/setting/get_user_id_action?type=');?>' + type;
        $.ajax({
            url: url,
            type: 'get',
            success: function (data) {
                $('.filter_publisher').val('');
                $('.filterinput_1').val('');
                $.each(data.msg, function (k, v) {
                    html += '<li data-key="' + v + '"  class="" style="">';
                    html += '<span>' + v + '</span>('+k+')<b class="icon wb-check check-mark"></b></li>';
                });
                $('#radiao_box_1').html(html);
               selectPackage('diy_select');
            }
        });
    });
    $('.filter_input_1').focus(function () {
        $(this).val('');
    });
    $('#advertiser').click(function () {
        $('.filter_input_1').val('');
        var type = $(this).val();
        var html = '';
        var url = '<?php echo site_url('manager/setting/get_user_id_action?type=');?>' + type;
        $.ajax({
            url: url,
            type: 'get',
            success: function (data) {
                $('.filter_publisher').val('');
                $('.filter_input_1').val('');
                $.each(data.msg, function (k, v) {
                    html += '<li data-key="' + v + '"  class="" style="">';
                    html += '<span>' + v + '</span>('+k+')<b class="icon wb-check check-mark"></b></li>';
                });
                $('#radiao_box_1').html(html);
                selectPackage('diy_select');
            }
        });
    });
    $('#date').datepicker({
        endDate: "now"
    });
</script>