<!-- Page -->
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/assets/examples/css/advanced/masonry.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/assets/examples/css/tables/datatable.css">

<div class="page animsition">
    <div class="page-header">
        <ol class="breadcrumb">
            <li><a href="<?php echo site_url('dashboard/index');?>">Dashboard</a></li>
            <li class="active">Index</li>
        </ol>
    </div>
    <div class="page-content padding-top-30 blue-grey-500">
        <div class="row">
            <div class="col-lg-12 col-md-12">
                <div class="row">
                    <div class="col-md-4">
                        <div class="widget widget-border" style="height:185px;overflow:hidden;">
                            <div class="widget-content padding-25 bg-white">
                                <div class="counter counter-lg ">
                                    <div class="counter-number-group margin-vertical-20 <?php echo $yesterday_data>=0?'':'red-600'?>">
                                        <span class="counter-number-related">$</span>
                                        <span class="counter-number"><?php echo number_format($yesterday_data,2)?></span>
                                    </div>
                                    <div class="counter-label text-uppercase">
                                        <img src="<?php echo $yesterday_data>=0?site_url().'assets/images/blue_pic.png':site_url().'assets/images/red_pic.png';?>" style="vertical-align:0;display: inline-block;">
                                        <span class="margin-left-5" style="display: inline-block;">Profits Of Yesterday</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="widget widget-border" style="height:185px;overflow:hidden;">
                            <div class="widget-content padding-25 bg-white">
                                <div class="counter counter-lg ">
                                    <div class="counter-number-group margin-vertical-20">
                                        <span class="counter-number-related">$</span>
                                        <span class="counter-number"><?php echo number_format($this_month_total_data, 2)?></span>
                                    </div>
                                    <div class="counter-label text-uppercase">
                                        <img src="<?php echo site_url();?>assets/images/blue_pic.png" style="vertical-align:top;">
                                        <span class="margin-left-5" style="height:21px;line-height: 21px;display: inline-block;">TOTAL PROFITS OF THIS MONTH</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="widget widget-border" style="height:185px;overflow:hidden;">
                            <div class="widget-content padding-25 bg-white">
                                <div class="counter counter-md">
                                    <div class="clearfix">
                                        <div class="pull-left">
                                            <div class="counter-number-group text-left font-size-18" style="color:#79848e;">
                                                <span class="counter-number-related font-weight-600">$</span>
                                                <span class="counter-number font-weight-600"><?php echo number_format($last_month_data, 2)?></span>
                                                <span class="font-size-12" style="color:#9ba3aa;">/DAY</span>
                                                <p class="font-size-14" style="color:#9ba3aa;margin-top:-5px;">Last Month</p>
                                            </div>
                                            <div class="counter-number-group text-left font-size-18" style="color:#79848e; margin-top:-5px;">
                                                <span class="counter-number-related font-weight-600">$</span>
                                                <span class="counter-number font-weight-600"><?php echo number_format($this_month_data, 2)?></span>
                                                <span class="font-size-12">/DAY</span>
                                                <p class="font-size-14" style="margin-top:-5px;">This Month</p>
                                            </div>
                                        </div>
                                        <div class="pull-right" style="margin-top:-5px;">
                                            <img src="<?php echo $profit_today>=0?site_url().'assets/images/green_pic.png':site_url().'assets/images/fu_pic.png';?>" style="margin-top:-5px;">
                                            <span class="font-weight-600 <?php echo $profit_today>=0?'green-600':'red-600';?>" style="color:#3b434a;font-size:30px;">
                                                <?php echo $profit_today;?>
                                                %
                                            </span>
                                        </div>
                                    </div>
                                    <div class="counter-label text-uppercase">
                                        Avg. daily profits
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- 利润 -->
            <div class="col-md-12">
                <div class="widget widget-border example-responsive padding-vertical-20">
                    <div id="profit" style="height:360px;" data-date='<?php echo $profit_chart['date']?>' data-profit='<?php echo $profit_chart['data']?>'></div>
                </div>
            </div>

            <!-- Top 10 利润 -->
            <div class="col-md-12">
                <div class="widget widget-border example-responsive padding-vertical-20">
                    <div id="top_ten_profit" style="height:360px;" data-name='<?php echo $product_data['name']?>' data-profit='<?php echo $product_data['profit']?>'></div>
                </div>
            </div>

            <!-- Top 10 profits fluctuate -->
            <div class="col-md-12">
                <div class="widget widget-border example-responsive padding-vertical-20">
                    <div id="top_ten_profit_fluctuate" style="height:360px;"  data-name='<?php echo $product_profit['name']?>' data-data='<?php echo $product_profit['data']?>'></div>
                </div>
            </div>

            <!-- Top 10 Results -->
            <div class="col-md-12">
                <div class="widget widget-border example-responsive padding-vertical-20">
                    <div id="top_ten_results" style="height:360px;" data-name='<?php echo $product_results['name']?>' data-data='<?php echo $product_results['data']?>'></div>
                </div>
            </div>

        </div>
        <?php if($this->userinfo['type']==0):?>
                        <ul class="blocks blocks-100 blocks-xlg-4 blocks-lg-3 blocks-md-3 blocks-sm-2" data-plugin="masonry">
                <?php foreach($publisher_data as $data):?>
                    <li class="masonry-item">
                        <div class="widget widget-article widget-shadow widget-border padding-30" style="height:169px;">
                            <div class="clearfix" style="height:58px;">
                                <blockquote class="font-size-16 pull-left" style="padding:0 22px; border-left:2px solid #79848e; color:#79848e;">
                                    <p>
                                        <span class="block" style="line-height:18px;"><?php echo $data['publisher_name'];?></span>
                                    </p>
                                </blockquote>
                                <div class="pull-right" style="height:36px;line-height:36px;">
                                    <img src="<?php echo site_url().'assets/images/'.(($data['revenue']-$data['spend'])>0?'manage_dash_green.png':'manager_dash.png');?>" style="vertical-align:bottom;" />
                                </div>
                            </div>

                            <div class="row padding-top-5" style="margin-left:-40px;margin-right:-40px;">
                                <div class="col-xs-4">
                                    <div class="counter counter-sm">
                                        <div class="counter-number font-weight-600">$<?php echo number_format($data['revenue'], 2)?></div>
                                        <div class="counter-label">REVENUE</div>
                                    </div>
                                </div>
                                <div class="col-xs-4">
                                    <div class="counter counter-sm">
                                        <div class="counter-number font-weight-600">$<?php echo number_format($data['spend'], 2)?></div>
                                        <div class="counter-label">SPEND</div>
                                    </div>
                                </div>
                                <div class="col-xs-4">
                                    <div class="counter counter-sm">
                                        <div class="counter-number font-weight-600 red-600">$<?php echo number_format(($data['revenue']-$data['spend']),2);?></div>
                                        <div class="counter-label">PROFITS</div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </li>
                <?php endforeach;?>
            </ul>

        <?php endif;?>

        

        <?php if($this->userinfo['type']==2):?>
            <div class="panel" style="box-shadow:none;border: 1px solid #e3eaec;">
                
                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="table dataTable table-striped width-full">
                            <thead class="thead">
                                <tr>
                                    <th>Product</th>
                                    <th>Results</th>
                                    <th>Spend</th>
                                    <th>Earning</th>
                                    <th>Profit</th>
                                    <th>ROI</th>
                                    <th>Real Earning</th>
                                    <th>Real Profit</th>
                                    <th>Real ROI</th>
                                </tr>
                            </thead>
                            <tbody class="tbody">
                                <?php foreach($publisher_product_data as $item):?>
                                    <tr>
                                        <td><?php echo $item['product_name']?></td>
                                        <td><?php echo number_format($item['results'])?></td>
                                        <td><?php echo "$".sprintf("%.2f", $item['spend'])?></td>
                                        <td><?php echo "$".sprintf("%.2f", $item['revenue'])?></td>
                                        <td class="<?php echo $item['profit']>0?'green-600':'red-600'?>"><?php echo "$".sprintf("%.2f", $item['profit'])?></td>
                                        <td class="<?php echo $item['roi']>0?'green-600':'red-600'?>"><?php echo $item['roi']?>%</td>
                                        <td><?php echo "$".sprintf("%.2f", $item['real_earning'])?></td>
                                        <td class="<?php echo $item['real_profit']>0?'green-600':'red-600'?>"><?php echo "$".sprintf("%.2f", $item['real_profit'])?></td>
                                        <td class="<?php echo $item['real_roi']>0?'green-600':'red-600'?>"><?php echo $item['real_roi']?>%</td>
                                        
                                    </tr>
                                <?php endforeach;?>
                            </tbody>
                        </table>
                    </div>
                </div>  
            </div>
        <?php endif;?>
    </div>
</div>
<!-- 新加js -->
<script type="text/javascript" src="http://echarts.baidu.com/gallery/vendors/echarts/echarts-all-3.js"></script>
<script type="text/javascript" src="http://echarts.baidu.com/gallery/vendors/echarts/extension/dataTool.min.js"></script>
<script type="text/javascript" src="http://echarts.baidu.com/gallery/vendors/echarts/map/js/china.js"></script>
<script type="text/javascript" src="http://echarts.baidu.com/gallery/vendors/echarts/map/js/world.js"></script>
<script type="text/javascript" src="http://api.map.baidu.com/api?v=2.0&ak=ZUONbpqGBsYGXNIYHicvbAbM"></script>
<script type="text/javascript" src="http://echarts.baidu.com/gallery/vendors/echarts/extension/bmap.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/dashboard.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/js/components/masonry.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/vendor/datatables/jquery.dataTables.js"></script>

<script src="<?php echo base_url(); ?>assets/web/global/js/components/datatables.js"></script>
<script src="<?php echo base_url(); ?>assets/web/assets/examples/js/tables/datatable.js"></script>





