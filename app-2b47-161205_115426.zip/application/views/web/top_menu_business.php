<div class="site-menubar site-menubar-light">
    <div class="site-menubar-body">
        <div>
            <div>
                <ul class="site-menu">
                    <li class="site-menu-category">General</li>
                    <li class="site-menu-item <?php echo ($this->router->class=='business'&&$this->router->method=='users')?'active':''?>">
                        <a href="<?php echo site_url('business/users')?>">
                            <i class="site-menu-icon wb-mobile" aria-hidden="true"></i>
                            <span class="site-menu-title">Business Users</span>
                        </a>
                    </li>
                    <!-- <li class="site-menu-item <?php echo ($this->router->class=='business'&&$this->router->method=='accounts')?'active':''?>">
                        <a href="<?php echo site_url('business/accounts')?>">
                            <i class="site-menu-icon wb-mobile" aria-hidden="true"></i>
                            <span class="site-menu-title">Business Accounts</span>
                        </a>
                    </li>
                    <li class="site-menu-item <?php echo ($this->router->class=='business'&&$this->router->method=='offers')?'active':''?>">
                        <a href="<?php echo site_url('business/offers')?>">
                            <i class="site-menu-icon wb-mobile" aria-hidden="true"></i>
                            <span class="site-menu-title">Business Offers</span>
                        </a>
                    </li> -->
                </ul>
            </div>
        </div>
    </div>
</div>