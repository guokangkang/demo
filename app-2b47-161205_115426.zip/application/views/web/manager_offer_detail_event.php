<div class="panel margin-bottom-0">
    <div class="row padding-top-30">
        <div class="col-sm-6">
            <form class="form-horizontal" autocomplete="off" action="<?php echo site_url('manager/offer/add_offer_effective_action')?>" method="post" id="offer_event_form">
                <input type="hidden" name="offer_id" value="<?php echo $offer_info['offer_id']?>">

                <div class="form-group">
                    <label class="col-sm-3 control-label" for="contact">Status</label>
                    <div class="col-sm-9">
                        <div class="margin-right-20">
                           <div class="radio-custom radio-default radio-inline">
                                <input type="radio" value="0" id="input_pause" name="status">
                                <label for="input_pause">Pause</label>
                            </div>
                            <div class="radio-custom radio-default radio-inline">
                                <input type="radio" value="1" id="input_active" name="status">
                                <label for="input_active">Start</label>
                            </div>

                            <div class="radio-custom radio-default radio-inline">
                                <input type="radio" value="-1" id="input_delete" name="status">
                                <label for="input_delete">Delete</label>
                            </div>
                        </div>
                        <small class="help-block" data-fv-validator="notEmpty" data-fv-for="status" data-fv-result="NOT_VALIDATED" style="display: none;">The status is required</small>
                    </div>
                </div>

                <div class="form-group">
                    <label class="col-sm-3 control-label" for="contact">Effective Time</label>
                    <div class="col-sm-9">
                        <div class="input-daterange">
                            <div class="input-group">
                                <span class="input-group-addon">
                                    <i class="icon wb-calendar" aria-hidden="true"></i>
                                </span>
                                    <input type="text" class="form-control datepair-date datepair-start" data-plugin="datepicker" name="input_date" id="inputdate" value="<?php echo date('m/d/Y')?>">
                            </div>
                            <div class="input-group ">
                                <span class="input-group-addon">
                                    <i class="icon wb-time" aria-hidden="true"></i>
                                </span>
                                <input type="text" class="form-control datepair-time datepair-start" data-plugin="timepicker" name="input_time" id="inputtime"
                                    value="<?php echo date('H:i a')?>" />
                            </div>
                        </div>
                    </div>
                </div>


                <div class="form-group">
                    <label class="col-sm-3 control-label" for="contact"></label>
                    <div class="col-sm-9">
                    <button type="submit" class="btn btn-info hover_btn" id="offer_event_button">Submit</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <header class="panel-heading margin-bottom-0 clearfix">
        <h3 class="panel-title pull-left">Details</h3>
    </header>
    <div class="panel-body table-responsive">
        <table class="table dataTable table-striped width-full" id="facebook_report">
            <thead class="change_thead">
                <tr>
                    <th>Effective Time</th>
                    <th>Status</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($effective_list as $item):?>
                    <tr>
                        <td><?php echo date('m/d/Y H:i', $item['effective_time'])?></td>
                        <td>
                            <?php
                                if ($item['status']==0) {
                                    echo "Paused";
                                }elseif ($item['status']==1) {
                                    echo "Started";
                                }else{
                                    echo "Deleted";
                                }
                            ?>
                        </td>
                        
                        <?php if($item['is_current']):?>
                            <td><span class="label label-table label-success">Current</span></td>
                        <?php else:?>
                            <td></td>
                        <?php endif;?>
                    </tr>
                <?php endforeach;?>
            </tbody>
        </table>
    </div>
</div>