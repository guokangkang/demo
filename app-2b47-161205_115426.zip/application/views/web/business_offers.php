<style type="text/css">
    .business_item{
        display: block;
        line-height: 30px;
        height: 30px;
        width: 30px;
        border-radius: 1000px;
        background-color: #eee;
        font-size: 12px;
        font-weight: bold;
        text-align: center;
    }
</style>
<div class="page animsition">
    <div class="page-header ">
        <h1 class="page-title">Business Offers</h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo site_url('business/users')?>">Business Manager</a></li>
            <li class="active">Business Offers</li>
        </ol>
    </div>
    <div class="page-content">
        <div class="panel panel-bordered panel-default table-responsive">
            <div class="panel-body">
                
                <table class="table table-hover dataTable table-striped width-full verticaltop" id="productlist" data-selectable="selectable" data-row-selectable="true">
                    <thead>
                      <tr>
                        <th style="width: 5%"></th>
                        <th style="width: 15%">Business ID</th>
                        <th style="width: 15%">Business Name</th>
                        <th style="width: 10%">Publisher Name</th>
                        <th style="width: 25%">Account</th>
                        <th style="width: 20%">Product Name</th>
                        <th style="width: 10%">Offer Details</th>
                      </tr>
                    </thead>
                    <tbody>
                        <?php foreach($apply_applicaion as $item):?>
                            <tr>
                                <td>
                                    <span class="business_item">
                                        <?php echo $item['letters']?>
                                    </span>
                                </td>
                                <td>
                                    <?php echo $item['business_id']?>
                                </td>
                                <td>
                                    <?php echo $item['business_name']?>
                                </td>
                                <td>
                                    <?php echo $item['publisher_name']?>
                                </td>
                                <td>
                                    <?php foreach($item['account'] as $account_id):?>
                                        <?php echo $account_id?><br/>
                                    <?php endforeach;?>
                                </td>
                                <td><?php echo $item['product_name']?></td>
                                <td>
                                    <a class="business_offer_details" data-toggle="modal" data-target="#offer_details" data-account="<?php echo implode(',', $item['account_id'])?>">
                                        Details
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="offer_details" aria-hidden="true" aria-labelledby="exampleModalTabs"
                              role="dialog" tabindex="-1">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×</span>
              </button>
              <h4 class="modal-title" id="exampleModalTabs">Offers</h4>
        </div>
        <div class="modal-body">
            <table class="editable-table table table-striped" id="editableTable">
                <thead>
                  <tr>
                    <th>Offer ID</th>
                    <th>Product</th>
                    <th>Countries</th>
                    <th>CPA</th>
                  </tr>
                </thead>
                <tbody class="offer_detail_modal">
                    
                </tbody>
            </table>
        </div>
      </div>
    </div>
  </div>