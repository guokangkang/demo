  <link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/blueimp-file-upload/jquery.fileupload.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/dropify/dropify.css">
<div class="page animsition" style="animation-duration: 800ms; opacity: 1;">
    <div class="page-header ">
        <h1 class="page-title">Import Retention</h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo site_url('setup')?>">Retetion Management</a></li>
            <li class="active">Import Retention</li>
        </ol>
    </div>

    
    <div class="page-content">
        <div class="panel row" style="background:transparent;box-shadow:none;">
            <div class="col-lg-4 col-sm-6">
                <div class="col-lg-12 " style="line-height: 200px;">
                    <div class="dropify-wrapper fetching">
                        <div class="dropify-message">
                            <span class="file-icon"></span> 
                            <p class="filename">Kika 留存模板</p>
                            <p class="dropify-error">Ooops, something wrong appended.</p>
                        </div>
                        <div class="dropify-loader"></div>
                        <input id="fileupload" class="btn fileinput-button" type="file"  style="opacity: 0; position: absolute; left: 0; top: 0;">

                        <div class="col-md-12 example-loading example-well height-200 vertical-align text-center loading hide" style=" position: absolute; left: 0; top: 0;">
                            <div class="loader vertical-align-middle loader-round-circle" data-type="round-circle"></div>
                        </div>
                    </div>
                    
                </div>
            </div>

            <div class="col-lg-4 col-sm-6">
                <div class="col-lg-12 " style="line-height: 200px;">
                    <div class="dropify-wrapper fetching">
                        <div class="dropify-message">
                            <span class="file-icon"></span> 
                            <p class="filename-appsflyer">Appsflyer 留存模板</p>
                            <p class="dropify-error">Ooops, something wrong appended.</p>
                        </div>
                        <div class="dropify-loader"></div>
                        <input id="appsflyer" class="btn fileinput-button" type="file"  style="opacity: 0; position: absolute; left: 0; top: 0;">

                        <div class="col-md-12 example-loading-appsflyer example-well height-200 vertical-align text-center loading hide" style=" position: absolute; left: 0; top: 0;">
                            <div class="loader vertical-align-middle loader-round-circle" data-type="round-circle"></div>
                        </div>
                    </div>
                    
                </div>
            </div>

            <div class="col-lg-4 col-sm-6">
                <div class="col-lg-12 " style="line-height: 200px;">
                    <div class="dropify-wrapper fetching">
                        <div class="dropify-message">
                            <span class="file-icon"></span> 
                            <p class="filename-go">Go 留存模板</p>
                            <p class="dropify-error">Ooops, something wrong appended.</p>
                        </div>
                        <div class="dropify-loader"></div>
                        <input id="go" class="btn fileinput-button" type="file"  style="opacity: 0; position: absolute; left: 0; top: 0;">

                        <div class="col-md-12 example-loading-go example-well height-200 vertical-align text-center loading hide" style=" position: absolute; left: 0; top: 0;">
                            <div class="loader vertical-align-middle loader-round-circle" data-type="round-circle"></div>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript"
        src="<?php echo base_url(); ?>assets/js/jQueryFileUpload/js/vendor/jquery.ui.widget.js"></script>
<script type="text/javascript"
        src="<?php echo base_url(); ?>assets/js/jQueryFileUpload/js/jquery.iframe-transport.js"></script>

<script type="text/javascript"
    src="<?php echo base_url(); ?>assets/js/jQueryFileUpload/js/jquery.fileupload.js"></script>
<script type="text/javascript"
        src="<?php echo base_url(); ?>assets/js/jQueryFileUpload/js/jquery.fileupload-validate.js"></script>
<script type="text/javascript"
        src="<?php echo base_url(); ?>assets/js/jQueryFileUpload/js/jquery.fileupload-validate.js"></script>
<script type="text/javascript"
        src="<?php echo base_url(); ?>assets/js/upload_excel.js"></script>

<script src="<?php echo base_url();?>assets/web/assets/examples/js/advanced/animation.js"></script>
