<!-- 新加css -->
<?php $bg_color=['#5C6BC0','#EF5350','#EC407A','#AB47BC','#7E57C2','#42A5F5','#29B6F6','#26C6DA','#26A69A','#66BB6A','#9CCC65','#D4E157','#FFEE58','#FFCA28','#FFA726','#FF7043','#8D6E63','#BDBDBD','#78909C'];
$bg=$bg_color[array_rand($bg_color)];
?>
<link rel="stylesheet" href="<?php echo base_url();?>assets/examples/css/advanced/masonry.css">
<style>
   .table>tbody>tr>td{vertical-align: middle;}
   .ad_circle{width: 100px;height: 100px; border-radius: 50%;background: rgba(255,255,255,0.2); position: absolute;left: -16px; top:-20px; font-size: 50px; font-weight: bold; line-height: 100px;text-align: center;}
</style>

<div class="site-menubar site-menubar-light">
    <div class="site-menubar-body">
        <div>
            <div>
                <ul class="site-menu">
                    <li class="site-menu-category">General</li>
                    <li class="site-menu-item active">
                        <a href="javascript:void(0)">
                            <i class="site-menu-icon wb-dashboard" aria-hidden="true"></i>
                            <span class="site-menu-title">AdCreative</span>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- Page -->
<div class="page animsition">
    <div class="page-header">
        <h1 class="page-title">Review</h1>
        <ol class="breadcrumb">
            <li><a href="/">Creative</a></li>
            <li class="active">Agency</li>
        </ol>
    </div>
    <div class="page-content padding-30 blue-grey-500 padding-top-0">
        <ul class="blocks blocks-100 blocks-xlg-2 blocks-lg-2 blocks-md-2 blocks-sm-2" data-plugin="masonry">
            <?php if($list):?>
                <?php foreach ($list as $k=>$item):?>
                    <li class="masonry-item">
                <div class="widget widget-article widget-shadow widget-border" style="padding-top:20px;">
                    <div class="widget-header cover">
                        <div class="row">
                            <div class="col-md-10 col-md-offset-1 col-sm-10 col-sm-offset-1 col-xs-10 col-xs-offset-1 padding-horizontal-0 margin-bottom-10" style="position: relative;">
                                <div class="font-size-30 widget-title font-weight-500"><?php $item['advertiser_name'];?></div>
                                <div class="text-right" style="position: absolute;right:0;bottom: 6px;">
                                    <a href="#" style="text-decoration: none;">Details &gt;&gt;</a>
                                </div>
                            </div>

                            <div class="col-md-10 col-md-offset-1 col-sm-10 col-sm-offset-1 col-xs-10 col-xs-offset-1 widget margin-bottom-30" style="height:140px; background:<?php echo $bg;?>;box-shadow:0 3px 6px #b8d4fe;position: relative;opacity:0.9;filter:alpha(opacity=90);">
                                    <span class="ad_circle" style="color:<?php echo $bg;?>;">AD</span>
                                    <p class="font-size-16 padding-top-30 padding-left-20 margin-bottom-0" style="color: #fff;position: relative;">Total ads</p>
                                    <p class="font-size-30 widget-title padding-top-0 font-weight-500 col-md-5 col-sm-5 col-xs-5" style="color:#fff;"><?php echo $item['ads'];?></p>
                                    <div class="col-md-7 col-sm-7 col-xs-7 text-center font-size-16" style="color:#fff;">
                                        <table>                                               
                                            <tbody>
                                                <tr>
                                                    <td style="width:20%;">Image</td>
                                                    <td style="width:20%;">Carousel</td>
                                                    <td style="width:20%;">Video</td>
                                                </tr>
                                                <tr>
                                                    <td class="font-weight-500"><?php echo $item['images'];?></td>
                                                    <td class="font-weight-500"><?php echo $item['carousels'];?></td>
                                                    <td class="font-weight-500"><?php echo $item['videos'];?></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                            </div>

                            <div class="col-md-10 col-md-offset-1 col-sm-10 col-sm-offset-1 col-xs-10 col-xs-offset-1 widget margin-bottom-30" style="height:85px; background:<?php echo $bg;?>">
                                <table class="text-center margin-top-15" style="color:#fff; width:100%;">               
                                    <tbody>
                                        <tr class="font-size-16">
                                            <td style="width:30%;">Campaign</td>
                                            <td style="width:20%;">Ad Set</td>
                                            <td style="width:18%;">Ads</td>
                                            <td style="width:32%;">Illegal Rate</td>
                                        </tr>
                                        <tr class="font-size-18">
                                            <td class="font-weight-500"><?php echo $item['campaigns'];?></td>
                                            <td class="font-weight-500"><?php echo $item['adsets'];?></td>
                                            <td class="font-weight-500"><?php echo $item['ads'];?></td>
                                            <td class="font-weight-500"><?php echo $item['ads']?round(($item['ads']/$item['ads'])*100).'%':0;?></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>

                            <div class="col-md-10 col-md-offset-1 col-sm-10 col-sm-offset-1 col-xs-10 col-xs-offset-1 widget padding-0">
                                <div class="widget pull-left margin-bottom-30" style="height:78px; border:1px solid #f1f1f1; width:45%;">
                                    <div class="col-md-6 col-sm-6 col-xs-6 text-center margin-top-10">
                                        <p class="widget-title font-size-20 font-weight-500 margin-bottom-0" style="color:#f8ba53;"><?php echo $item['pendings'];?></p>
                                        <p>Pending</p>
                                    </div>
                                    <div class="col-md-6 col-sm-6 col-xs-6 icondemo vertical-align-middle text-center">
                                        <i class="wb-time" aria-hidden="true" style="font-size:46px; color:#f3f3f3;"></i>
                                    </div>
                                </div>
                                <div class="widget pull-right margin-bottom-30" style="height:78px; border:1px solid #f1f1f1; width:45%;">
                                    <div class="col-md-6 col-sm-6 col-xs-6 text-center margin-top-10">
                                        <p class="widget-title font-size-20 font-weight-500 margin-bottom-0" style="color:#7ed321;"><?php echo $item['approveds'];?></p>
                                        <p>Approved</p>
                                    </div>
                                    <div class="col-md-6 col-sm-6 col-xs-6 icondemo vertical-align-middle text-center">
                                        <i class="md-check" aria-hidden="true" style="font-size:46px; color:#f3f3f3;"></i>
                                    </div>
                                </div>
                                <div class="widget pull-left margin-bottom-30" style="height:78px; border:1px solid #f1f1f1; width:45%;">
                                    <div class="col-md-6 col-sm-6 col-xs-6 text-center margin-top-10">
                                        <p class="widget-title font-size-20 font-weight-500 margin-bottom-0" style="color:#d496fe;"><?php echo $item['suspecteds'];?></p>
                                        <p>Suspected</p>
                                    </div>
                                    <div class="col-md-6 col-sm-6 col-xs-6 icondemo vertical-align-middle text-center">
                                        <i class="wb-help" aria-hidden="true" style="font-size:46px; color:#f3f3f3;"></i>
                                    </div>
                                </div>
                                <div class="widget pull-right margin-bottom-30" style="height:78px; border:1px solid #f1f1f1; width:45%;">
                                    <div class="col-md-6 col-sm-6 col-xs-6 text-center margin-top-10">
                                        <p class="widget-title font-size-20 font-weight-500 margin-bottom-0" style="color:#ff8594;"><?php echo $item['illegals'];?></p>
                                        <p>Illegal</p>
                                    </div>
                                    <div class="col-md-6 col-sm-6 col-xs-6 icondemo vertical-align-middle text-center">
                                        <i class="md-close-circle" aria-hidden="true" style="font-size:46px; color:#f3f3f3;"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </li>
                <?php endforeach;?>
            <?php endif;?>
        </ul>
    </div>
</div>

<!-- 新加js -->
<script src="<?php echo base_url();?>assets/web/global/vendor/masonry/masonry.pkgd.min.js"></script>
<!-- 新加js结束 -->
<!-- 新加js -->
<script src="<?php echo base_url();?>assets/web/global/js/components/switchery.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/components/masonry.js"></script>
<!-- 新加js结束 -->
<script>
(function(document, window, $) {
    'use strict';
    var Site = window.Site;
    $(document).ready(function() {
        Site.run();
    });
})(document, window, jQuery);
</script>