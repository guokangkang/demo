<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/bootstrap-select/bootstrap-select.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/select2/select2.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/webui-popover/webui-popover.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/toolbar/toolbar.css">
<style type="text/css">
    .table>tbody>tr>td{vertical-align:middle;}
</style>
<div class="page animsition">
    <div class="page-header">
        <ol class="breadcrumb">
            <li><a href="<?php echo site_url('manager/product/listview')?>">Manager Management</a></li>
            <li><a href="<?php echo site_url('manager/offer/applications')?>">Offer Assignment</a></li>
            <li class="active">Applications</li>
        </ol>
    </div>
    <div class="page-content padding-30 blue-grey-500 padding-top-0">
        <div class="nav-tabs-horizontal">
            <!-- <div class="clearfix">
                <ul class="nav nav-tabs pull-left" style="border-bottom:none;">
                    <li class="active" role="presentation"><a data-toggle="tab" href="#exampleTabsOne" aria-controls="exampleTabsOne" role="tab">Applications</a></li>
                    <li role="presentation"><a data-toggle="tab" href="#exampleTabsTwo" aria-controls="exampleTabsOne" role="tab">Kika Keyboard - INTL</a></li>
                </ul>
            </div> -->
            <div class="tab-content widget-border">
                <div class="tab-pane active" id="exampleTabsOne" role="tabpanel">
                    <div class="panel margin-bottom-0">
                        <header class="panel-heading margin-bottom-0 clearfix">
                            <h3 class="panel-title pull-left">Details</h3>
                            <div class="pull-right margin-top-15 padding-right-30">
                                <div>
                                    <button type="button" class="btn btn_self btn-round btn-primary  btn-pill-left apply_offer_approve_all" style="padding:3px 9px;"><i class="icon md-check" aria-hidden="true"></i></button>
                                    <button type="button" class="btn btn_self btn-round btn-primary  btn-pill-right apply_offer_disapprove_all" style="padding:3px 9px;"><i class="icon md-close" aria-hidden="true"></i></button>
                                </div>
                            </div>
                        </header>
                        <div class="panel-body table-responsive">
                            <table class="table dataTable table-striped width-full" id="facebook_report" data-selectable="selectable" data-row-selectable="true">
                                <thead class="change_thead">
                                    <tr>
                                        <th style="width: 10%">Advertiser</th>
                                        <th style="width: 10%">Publisher</th>
                                        <th style="width: 10%">Account ID</th>
                                        <th style="width: 20%">Offer</th>
                                        <th style="width: 5%">RPA</th>
                                        <th style="width: 10%">CPA</th>
                                        <th style="width: 10%">Note</th>
                                        <th style="width: 5%">Status</th>
                                        <th style="width: 7%">Actions</th>
                                        <th>
                                            <span class="checkbox-custom checkbox-primary" style="width:20px; margin:0 auto;">
                                                <input class="selectable-all" type="checkbox">
                                                <label></label>
                                            </span>
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if($apply_applicaion):?>
                                     <?php foreach($apply_applicaion as $item):?>
                                        <tr>
                                            <td>
                                                <?php echo $item['advertiser_name']?>
                                            </td>
                                            <td>
                                                <?php echo $item['publisher_name']?>
                                            </td>
                                            <td>
                                                <?php foreach($item['account_id'] as $account_id):?>
                                                    <?php echo $account_id?><br/>
                                                <?php endforeach;?>
                                            </td>
                                            <td><?php echo $item['product_name'].'-'.$item['countries'].'-$'.$item['cpa']?></td>
                                            
                                            <td>
                                                <?php echo $item['rpa']?'$'.$item['rpa']:"-"?>
                                            </td>
                                            <td>
                                                <?php if($item['specific_payout']):?>
                                                    $<?php echo $item['specific_payout']['payout']."(Specific)"?>
                                                <?php else:?>
                                                    $<?php echo sprintf("%.2f", $item['current_cpa']['cpa']); ?>
                                                    (<?php echo $config_product['offer_category'][$item['current_cpa']['category']];?>)
                                                <?php endif;?>
                                            </td>
                                            <td>
                                                <?php echo $item['note']?$item['note']:'-'?>
                                            </td>
                                            <td>
                                                <?php if($item['status']==1):?>
                                                    <span class="label label-table label-success">Approved</span>
                                                <?php elseif($item['status']==0):?>
                                                    <span class="label label-table label-danger">Applied</span>
                                                <?php else:?>
                                                    <span class="label label-warning">Disapproved</span>
                                                <?php endif;?>
                                            </td>
                                            <td class="actions">
                                                <?php if($item['status']==0):?>
                                                <span class="popover-success popover-rotate apply_offer_approve margin-right-10 green-600" data-val="<?php echo $item['offer_id']?>" data-toggle="popover" data-status="1" data-user="<?php echo $item['publisher_id']?>" data-original-title="" title="" style="font-size:20px;cursor:pointer;"><i class="icon md-check" aria-hidden="true"></i></span>

                                                <span class="popover-warning popover-rotate apply_offer_disapprove red-600" data-val="<?php echo $item['offer_id']?>" data-toggle="popover" data-status="-1" data-user="<?php echo $item['publisher_id']?>" data-original-title="" title="" style="font-size:20px;cursor:pointer;"><i class="icon md-close" aria-hidden="true"></i></span>
                                                <?php endif;?>
                                            </td>
                                            <td>
                                                <span class="checkbox-custom checkbox-primary" style="width: 20px; margin: 0 auto;">
                                                    <input class="selectable-item checkbox_offer" type="checkbox" id="offer-<?php echo $item['offer_id']?>" value="<?php echo $item['offer_id']?>">
                                                    <label for="offer-<?php echo $item['offer_id']?>"></label>
                                                </span>
                                            </td>
                                        </tr>
                                    <?php endforeach;?>
                                    <?php else:?>
                                        <tr>
                                            <td colspan="10">
                                                <div class="text-center padding-top-80">
                                                    <img src="<?php echo site_url();?>assets/images/no_data.png">
                                                    <h4 class="margin-top-30">NO DATA HERE</h4>
                                                    <p style="line-height: 18px;">I hate peeping Toms. For one thing they usually step all over<br>the hedges and plants on the side of someone's house killing</p>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endif;?>
                                </tbody>
                            </table>
                            <div class="pull-right margin-top-15">
                                <div>
                                    <button type="button" class="btn btn-round btn-default btn-pill-left apply_offer_approve_all" style="padding:3px 9px;"><i class="icon md-check" aria-hidden="true"></i></button>
                                    <button type="button" class="btn btn-round btn-default btn-pill-right apply_offer_disapprove_all" style="padding:3px 9px;"><i class="icon md-close" aria-hidden="true"></i></button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="tab-pane panel margin-bottom-0 height-200" id="exampleTabsTwo" role="tabpanel"></div>
            </div>
        </div>   
    </div>
</div>

<script src="<?php echo base_url();?>assets/web/global/vendor/datatables/jquery.dataTables.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/components/datatables.js"></script>
<script src="<?php echo base_url();?>assets/web/assets/examples/js/tables/datatable.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/plugins/selectable.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/components/selectable.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/webui-popover/jquery.webui-popover.min.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/toolbar/jquery.toolbar.min.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/components/webui-popover.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/components/toolbar.js"></script>
<script src="<?php echo base_url();?>assets/web/assets/examples/js/uikit/tooltip-popover.js"></script>
<script>
   /* $('.checkbox_offer').change(function () {
        if($(this).prop('checked')){
            $('.apply_offer_approve_all').removeClass('disabled');
            $('.apply_offer_disapprove_all').removeClass('disabled');
        }else{
            $('.apply_offer_approve_all').addClass('disabled');
            $('.apply_offer_disapprove_all').addClass('disabled');
        }
    });*/
</script>