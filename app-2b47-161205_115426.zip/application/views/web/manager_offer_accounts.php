<style>
    .table>tbody>tr>td{border-top:0; vertical-align: middle;}
</style>
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/select2/select2.css">
<!-- Page -->
<div class="page animsition">
    <div class="page-header">        
        <ol class="breadcrumb">
            <li><a href="<?php echo site_url('manager/product/listview')?>">Manager Management</a></li>
            <li><a href="<?php echo site_url('manager/offer/applications')?>">Offer Assignment</a></li>
            <li class="active">Account Assigned</li>
        </ol>
    </div>
    <div class="page-content">
        <div class="panel">
            <div class="panel-body container-fluid" style=" padding-bottom: 0;">
                <div class="row row-lg">
                    <div class="clearfix visible-md-block visible-lg-block"></div>
                    <div class="col-md-12">

                        <div class="example-wrap" style="margin-bottom:0;">
                            <h4>Conditions</h4>
                            <!-- <div class="nav-tabs"></div> -->
                            <div class="example" style="margin-bottom: 0; margin-top: 0;">

                                <div class="col-md-12 table-responsive" style="border:none;">
                                    <!-- Example Multi Balue -->
                                    <div class="example-wrap">
                                        <div class="example">
                                            <form style="padding-bottom:20px;">
                                                <div class="form-group col-lg-1 col-md-1 filter-form advertiser-filter" style="height:36px;line-height:36px; margin-bottom:15px;">
                                                    <label class="control-label"></label>
                                                </div>

                                                <div class="form-group col-lg-3 col-md-3 filter-form product-filter" style="margin-bottom:15px;">
                                                    <select class="form-control select2-hidden-accessible filter_product" data-plugin="select2" tabindex="-1" aria-hidden="true" data-placeholder="Product Filter">
                                                        <option></option>
                                                        <?php foreach($product_ids as $product):?>
                                                            <option value="<?php echo $product['product_id']?>" <?php echo (in_array($product['product_id'], $product_params))?"selected='selected'":''?>><?php echo "(".$product['product_id'].")".$product['product_name']?></option>
                                                        <?php endforeach;?>
                                                    </select>
                                                </div>

                                                <div class="form-group col-lg-3 col-md-3 filter-form publisher-filter" style="margin-bottom:15px;">
                                                    <select class="form-control select2-hidden-accessible filter_publisher" data-plugin="select2" tabindex="-1" aria-hidden="true" data-placeholder="Publisher Filter">
                                                        <option></option>
                                                        <?php foreach($publisher_ids as $product):?>
                                                            <option value="<?php echo $product['publisher_id']?>" <?php echo (in_array($product['publisher_id'], $publisher_params))?"selected='selected'":''?>><?php echo "(".$product['publisher_id'].")".$product['publisher_name']?></option>
                                                        <?php endforeach;?>
                                                    </select>
                                                </div>

                                                <div class="form-group col-lg-3 col-md-3 filter-form account-filter" style="margin-bottom:15px;">
                                                    <select class="form-control select2-hidden-accessible filter_account" data-plugin="select2" tabindex="-1" aria-hidden="true" data-placeholder="Account Filter">
                                                        <option></option>
                                                        <?php foreach($account_ids as $product):?>
                                                            <option value="<?php echo $product['account_id']?>" <?php echo (in_array($product['account_id'], $account_params))?"selected='selected'":''?>><?php echo "(".$product['account_id'].")".$product['account_name']?></option>
                                                        <?php endforeach;?>
                                                    </select>
                                                </div>


                                                <div class="form-group filter-form" style="margin-left:15px;">
                                                    <button type="button" class="btn btn-outline btn-primary manager_accounts_search">Search</button>
                                                    <button type="button" class="btn btn-outline btn-info manager_accounts_rest">Reset</button>
                                                </div>

                                            </form>

                                        </div>
                                    </div>
                                    <!-- End Example Multi Balue -->
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="panel">
            <header class="panel-heading clearfix">
                <h3 class="panel-title">Details</h3>
            </header>
            <div class="panel-body container-fluid">
                <?php if($apply_applicaion):?>
                    <table class="table dataTable table-striped width-full" id="facebook_report">
                        <tbody>
                          <?php foreach($apply_applicaion as $item):?>
                            <tr>
                                <td style="width:50%;"><i class="icon md-account margin-right-10" aria-hidden="true"></i><?php echo $item['publisher_name']?></td>
                                <td style="width:50%;"><i class="icon md-apps margin-right-10" aria-hidden="true"></i><?php echo $item['product_name']?></td>
                            </tr>
                            <tr style="background-color:#f4f4f4;">
                                <td colspan='3'>
                                    <ul class="blocks blocks-50 blocks-xlg-6 blocks-md-6 blocks-sm-2 margin-horizontal-0">
                                        <?php foreach($item['account_id'] as $account_id):?>
                                            <li class="text-center margin-bottom-0"><?php echo $account_id?></li>
                                        <?php endforeach;?>
                                    </ul>
                                </td>
                            </tr>
                          <?php endforeach?>
                        </tbody>
                    </table>
                   <?php echo $page_links?>
                <?php else:?>
                    <div class="panel margin-bottom-0 height-500">
                        <div class="text-center padding-top-80">
                            <img src="<?php echo base_url();?>assets/images/no_data.png">
                            <h4 class="margin-top-30">NO DATA HERE</h4>
                            <p style="line-height: 18px;">I hate peeping Toms. For one thing they usually step all over<br>the hedges and plants on the side of someone's house killing</p>
                        </div>
                    </div>
                <?php endif;?>
            </div>
        </div>        
    </div>
</div>
<!-- 新加js -->
<script src="<?php echo base_url();?>assets/web/global/vendor/datatables/jquery.dataTables.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/components/datatables.js"></script>
<script src="<?php echo base_url();?>assets/web/assets/examples/js/tables/datatable.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/select2/select2.min.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/components/formatter-js.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/components/select2.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/components/multi-select.js"></script>