<div class="panel margin-bottom-0">
    <div class="row padding-top-30">
        <div class="col-sm-6"> 
            <form class="form-horizontal" autocomplete="off" id="offer_specific_cap_form"  method="post" action="<?php echo site_url('manager/offer/add_specific_cap_action')?>">
                <input type="hidden" name="offer_id" value="<?php echo $offer_info['offer_id']?>">
    
                <div class="form-group">
                    <label class="col-sm-3 control-label" for="contact"></label>
                    <div class="col-sm-9">
                        <div class="margin-right-20">
                            <div class="radio-custom radio-default radio-inline">
                                <input type="radio" value="1" id="add_cap" name="specific_cap_category" checked="">
                                <label for="add_cap">Add Specific CAP</label>
                            </div>
                            <div class="radio-custom radio-default radio-inline">
                                <input type="radio" value="2" id="cancel_cap" name="specific_cap_category">
                                <label for="cancel_cap">Cancel Specific CAP</label>
                            </div>

                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label class="col-sm-3 control-label" for="contact">Publishers / Agency</label>
                    <div class="col-sm-9">
                        <div class="cap_publisher1">
                            <select id="select_publisher" class="form-control bucket_country_select" multiple="" data-plugin="select2" name="select_publisher[]" data-placeholder="Publishers">
                                <?php foreach($publisher as $val):?>
                                    <option value="<?php echo $val['user_id']?>" ><?php echo $val['publisher_type']==2?$val['user_name']."-Agency":$val['user_name']?></option>
                                <?php endforeach;?>
                            </select>
                        </div>
                        <div class="cap_publisher2 hide">
                            <select id="select_publisher" class="form-control bucket_country_select " multiple="" data-plugin="select2" name="select_publisher[]" data-placeholder="Publishers">
                                <?php foreach($specific_cap_publisher as $val):?>
                                    <option value="<?php echo $val['user_id']?>" ><?php echo $val['user_name']?></option>
                                <?php endforeach;?>
                            </select>
                        </div>
                    </div>
                </div>

                <div class="form-group cap_value">
                    <label class="col-sm-3 control-label" for="contact">CAP</label>
                    <div class="col-sm-9">
                        <div class="input-group">
                            <span class="input-group-addon bootstrap-touchspin-prefix">$</span>
                            <input type="text" id="input_payout" class="form-control" name="input_payout" data-plugin="TouchSpin" data-min="0" data-max="1000000000" data-stepinterval="50" data-maxboostedstep="10000000" data-prefix="$" value="" style="display: block;">
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label class="col-sm-3 control-label" for="contact">Note</label>
                    <div class="col-sm-9">
                        <textarea class="form-control" id='input_note' name="input_note" placeholder="Briefly Describe Yourself"></textarea>
                    </div>
                </div>

                <div class="form-group">
                    <label class="col-sm-3 control-label" for="contact">Effective Time</label>
                    <div class="col-sm-9">
                        <div class="input-daterange">
                            <div class="input-group">
                                <span class="input-group-addon">
                                    <i class="icon wb-calendar" aria-hidden="true"></i>
                                </span>
                                    <input type="text" class="form-control datepair-date datepair-start" data-plugin="datepicker" name="input_date" id="inputdate" value="<?php echo date('m/d/Y')?>">
                            </div>
                            <div class="input-group ">
                                <span class="input-group-addon">
                                    <i class="icon wb-time" aria-hidden="true"></i>
                                </span>
                                <input type="text" class="form-control datepair-time datepair-start" data-plugin="timepicker" name="input_time" id="inputtime"
                                    value="<?php echo date('H:i a')?>" />
                            </div>
                        </div>
                    </div>
                </div>

                
                <div class="form-group">
                    <label class="col-sm-3 control-label" for="contact"></label>
                    <div class="col-sm-9">
                        <button class="btn btn-info product_bucket_payout_save" data-dismiss="" type="submit" id="offer_specific_cap_button">Submit</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <header class="panel-heading margin-bottom-0 clearfix">
        <h3 class="panel-title pull-left">Details</h3>
    </header>
    <div class="panel-body table-responsive">
        <table class="table dataTable table-striped width-full" id="facebook_report">
            <thead class="change_thead">
                <tr>
                    <th style="width: 25%">Publisher / Agency</th>
                    <th style="width: 25%">Effective time</th>
                    <th style="width: 20%">Payout</th>
                    <th style="width: 20%">Status</th>
                    <th style="width: 20%">Note</th>
                    <th style="width: 10%"></th>
                </tr>
            </thead>
            <tbody>
                <?php if($specific_cap):foreach($specific_cap as $item_id=>$value):?>
                    <?php foreach($value as $item):?>
                    <tr>
                        
                        <td><?php echo $item['user_name']?></td>
                        <td><?php echo date('m/d/Y H:i', $item['start_time'])?></td>
                        <td>$<?php echo sprintf("%.2f", $item['cap'])?></td>
                        <td><?php echo $item['type']==1?'ADD':'CANCEL'?></td>
                        <td><?php echo $item['note']?></td>

                        <?php if($item['is_current']):?>
                            <td><span class="label label-table label-success">Current</span></td>
                        <?php else:?>
                            <td></td>
                        <?php endif;?>
                        <!-- <td>
                            <a data-toggle="popover" href="javascript:void(0)" class="btn btn-sm btn-icon btn-pure btn-default on-default del_specific_payout_tr"  data-user="<?php echo $item_id?>" data-val="<?php echo $offer_info['offer_id']?>">
                                <i class="icon fa-remove" aria-hidden="true"></i>
                            </a>
                        </td> -->
                    </tr>
                    <?php endforeach;?>
                <?php endforeach;else:?>
                    <tr>
                        <td colspan="4" class="text-center"><?php echo config_item('LIST_EMPTY_DATA')?></td>
                    </tr>
                <?php endif;?>
            </tbody>
        </table>
    </div>
</div>

<script type="text/javascript">
    var publisher = '<?php echo json_encode($publisher)?>';
    publisher = eval("("+publisher+")");
</script>
