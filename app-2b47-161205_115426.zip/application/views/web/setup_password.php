
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/formvalidation/formValidation.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/assets/examples/css/forms/validation.css">
<div class="page animsition" >
    <div class="page-header ">
        <ol class="breadcrumb">
            <li><a href="<?php echo site_url('setup/password')?>">Setting</a></li>
            <li class="active">Edit Password</li>
        </ol>
    </div> 


    <div class="page-content">
        <div class="panel">
            <div class="panel-body container-fluid">
                <div class="row row-lg">
                    <div class="col-sm-offset-3 col-sm-6">
                        <!-- Example Basic Form -->
                        <div class="example-wrap">
                            <h4 class="example-title"></h4>

                            <div class="example">
                                <form autocomplete="off" id="edit_password_form" action="<?php echo site_url('setup/edit_password_action')?>" method="post">
                                    

                                    <div class="form-group">
                                        <label class="control-label" for="current_password">
                                            Current Password
                                            <span class="required">*</span>
                                        </label>
                                        <input type="password" class="form-control" id="current_password" name="current_password" placeholder="" autocomplete="off">
                                    </div>

                                    <div class="form-group">
                                        <label class="control-label" for="new_password">
                                            New Password
                                            <span class="required">*</span>
                                        </label>
                                        <input type="password" class="form-control" name="new_password" data-fv-notempty="true"
                                          data-fv-notempty-message="The password is required and cannot be empty"
                                          data-fv-identical="true" data-fv-identical-field="re_new_password"
                                          data-fv-identical-message="The password and re-enter password are not the same" data-fv-stringlength="true"
                                      data-fv-stringlength-min="6" 
                                      data-fv-stringlength-message="Please enter more than 6 length"/>
                                    </div>

                                    <div class="form-group">
                                        <label class="control-label" for="re_new_password">
                                            Re-type New Password
                                            <span class="required">*</span>
                                        </label>
                                        <input type="password" class="form-control" name="re_new_password" id="new_password" data-fv-notempty="true"
                                            data-fv-notempty-message="The confirm password is required and cannot be empty"
                                            data-fv-identical="true" data-fv-identical-field="new_password"
                                            data-fv-identical-message="The password and re-enter password are not the same" data-fv-stringlength="true"
                                        data-fv-stringlength-min="6" 
                                        data-fv-stringlength-message="Please enter more than 6 length"/>
                                    </div>


                                    <div class="form-group">
                                        <button type="submit" class="btn btn-info" id="edit_password_button">Submit</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <!-- End Example Basic Form -->
                    </div>
                    <div class="clearfix hidden-xs"></div>
                </div>
            </div>
        </div>
    </div>
</div>
  <script src="<?php echo base_url();?>assets/web/global/vendor/formvalidation/formValidation.min.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/formvalidation/framework/bootstrap.min.js"></script>
<script src="<?php echo base_url();?>assets/js/my_valiation.js"></script>

