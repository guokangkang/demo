<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/bootstrap-datepicker/bootstrap-datepicker.css">

<style>
    .table>tbody>tr>td{vertical-align: middle;}
    .counter-lg .counter-number-group, .counter-lg>.counter-number{font-size:30px;}
    .nav-tabs>li.active>a{
        color: #fff;
        background-color:#12abc5!important;
        border-color:transparent;
        border-bottom-color:#12abc5!important;
    }   
    .nav-tabs>li.active>a:hover{
        color: #fff;
        background-color:#0890a7;
        border-color:transparent;
        border-bottom-color:#0890a7;
    }
    .nav-tabs>li>a{
        color: #707070;
        background-color:#fff;
        border-color:#ededed;
        border-bottom-color:#fff;
    }
    .nav-tabs>li>a:hover{
        color: #fff;
        background-color:#0890a7;
        border-color:transparent;
        border-bottom-color:#0890a7;
    }
</style>
<div class="page animsition">
    <div class="page-header clearfix">
        <ol class="breadcrumb pull-left">
            <li><a href="<?php echo site_url('bills/listview')?>">Bills</a></li>
            <li class="active">Listview</li>
        </ol>
        <div class="filter pull-right">
            <div class="dropdown pull-right">
                <button type="button" id="input_date" class="btn btn-pure">
                    <?php echo $this->input->get('date')?$this->input->get('date'):date('M Y')?>
                    <span class="icon wb-chevron-down-mini" aria-hidden="true"></span>
                </button>
            </div>
        </div>
    </div>
    <div class="page-content"> 
        <div class="row">
            <div class="col-lg-12 col-md-12">
                <div class="row">
                    <div class="col-md-3 col-sm-6">
                        <div class="widget widget-border" style="height:185px; overflow:hidden;">
                            <div class="widget-content padding-25 bg-white">
                                <div class="counter counter-lg ">
                                    <div class="counter-number-group margin-vertical-20">
                                        <span class="counter-number-related">$</span>
                                        <span class="counter-number"><?php echo number_format($data1['earning']-$data1['spend'], 2)?></span>
                                    </div>
                                    <div class="counter-label text-uppercase">
                                        <!-- <img src="<?php echo base_url();?>/assets/images/blue_pic.png" style="vertical-align:top;"> -->
                                         <i class="icon fa-bar-chart" aria-hidden="true" style="font-size:20px;color:#12abc5;vertical-align:top;"></i>
                                        <span class="margin-left-5" style="height:21px;line-height: 21px;display: inline-block;">Profits</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <div class="widget widget-border" style="height:185px;overflow:hidden;">
                            <div class="widget-content padding-25 bg-white">
                                <div class="counter counter-lg ">
                                    <div class="counter-number-group margin-vertical-20">
                                        <span class="counter-number-related">$</span>
                                        <span class="counter-number"><?php echo number_format($data1['earning'], 2)?></span>
                                    </div>
                                    <div class="counter-label text-uppercase">
                                        <!-- <img src="<?php echo base_url();?>/assets/images/blue_pic.png" style="vertical-align:top;"> -->
                                        <i class="icon fa-line-chart" aria-hidden="true" style="font-size:20px;color:#12abc5;vertical-align:top;"></i>
                                        <span class="margin-left-5" style="height:21px;line-height: 21px;display: inline-block;">Earning</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <div class="widget widget-border" style="height:185px;overflow:hidden;">
                            <div class="widget-content padding-25 bg-white">
                                <div class="counter counter-lg ">
                                    <div class="counter-number-group margin-vertical-20">
                                        <span class="counter-number-related">$</span>
                                        <span class="counter-number"><?php echo number_format($data1['spend'], 2)?></span>
                                    </div>
                                    <div class="counter-label text-uppercase">
                                        <!-- <img src="<?php echo base_url();?>/assets/images/blue_pic.png" style="vertical-align:top;"> -->
                                        <i class="icon fa-money" aria-hidden="true" style="vertical-align:top;font-size:20px;color:#12abc5;"></i>
                                        <span class="margin-left-5" style="height:21px;line-height: 21px;display: inline-block;">Spend</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <div class="widget widget-border" style="height:185px;overflow:hidden;">
                            <div class="widget-content padding-25 bg-white">
                                <div class="counter counter-lg ">
                                    <div class="counter-number-group margin-vertical-20">
                                        <span class="counter-number-related"></span>
                                        <span class="counter-number"><?php echo $data1['spend']>0?number_format(($data1['earning']-$data1['spend'])/$data1['spend']*100, 2):0.00?>%</span>
                                    </div>
                                    <div class="counter-label text-uppercase">
                                        <!-- <img src="<?php echo base_url();?>/assets/images/roi.png" style="vertical-align:top;"> -->
                                        <i class="icon fa-pie-chart" aria-hidden="true" style="font-size:20px;color:#12abc5;vertical-align:top;"></i>
                                        <span class="margin-left-5" style="height:21px;line-height: 21px;display: inline-block;"">ROI</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="nav-tabs-horizontal">
            <div class="clearfix">
                <ul class="nav nav-tabs pull-left" data-plugin="nav-tabs" role="tablist" style="border-bottom:none;">
                    <li class="active" role="presentation"><a data-toggle="tab" href="#bills_advertiser" aria-controls="bills_advertiser" role="tab">Advertiser</a></li>
                    <li role="presentation"><a data-toggle="tab" href="#bills_publisher" aria-controls="bills_publisher" role="tab">Publisher</a></li>
                    
                </ul>
            </div>
            <div class="tab-content widget-border">
                <div class="tab-pane active" id="bills_advertiser" role="tabpanel">
                    <div class="panel-body bg-white">
                        <div class="table-responsive">
                            <table class="table dataTable table-striped width-full">
                                <thead>
                                    <tr class="change_thead">
                                        <th style="width:22%;">Advertiser</th>
                                        <th style="width:22%;">Amount</th>
                                        <th style="width:18%;">Details</th>
                                        <th style="width:18%;">Invoice</th>
                                        <th>Pay Status</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach($advertiser_bill as $item):?>
                                        <tr>
                                            <td><?php echo $item['user_name']?></td>
                                            <td>$<?php echo number_format($item['amount'], 2)?></td>
                                            <td>
                                                <a target="_blank" href="<?php echo site_url('bills/detail?user='.$item['user_id'].'&date='.$date)?>">Details</a>
                                            </td>
                                            <td>
                                                <a target="_blank" href="<?php echo site_url('bills/invoice?user='.$item['user_id']."&date=".$date)?>">Invoice</a>
                                            </td>
                                            <?php if($item['paid']):?>
                                                <td style="color:#1dccb0;">Paid</td>
                                                <td></td>
                                            <?php else:?>
                                                <td style="color:#fe6477;">Unpaid</td>
                                                <td>
                                                    <a href="###" data-toggle="Popover" data-val="<?php echo $item['bill_id']?>" class="btn btn-outline hover_btn confrim_paid" style="color:#12abc5; border:1px solid #12abc5;"><i class="font-weight-600 md-check" aria-hidden="true"></i> Confrim</a>
                                                </td>
                                            <?php endif;?>
                                            
                                        </tr>
                                    <?php endforeach;?>
                                    
                                </tbody>
                            </table>
                        </div>
                    </div>  
                </div>
                <div class="tab-pane" id="bills_publisher" role="tabpanel">
                    <div class="panel-body bg-white">
                        <div class="table-responsive">
                            <table class="table dataTable table-striped width-full">
                                <thead>
                                    <tr class="change_thead">
                                        <th style="width:22%;">Publisher</th>
                                        <th style="width:22%;">Amount</th>
                                        <th style="width:18%;">Details</th>
                                        <th>Pay Status</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach($publisher_bill as $item):?>
                                        <tr>
                                            <td><?php echo $item['user_name']?></td>
                                            <td>$<?php echo number_format($item['amount'], 2)?></td>
                                            <td>
                                                <a target="_blank" href="<?php echo site_url('bills/detail?user='.$item['user_id'].'&date='.$date)?>">Details</a>
                                            </td>
                                            <?php if($item['paid']):?>
                                                <td style="color:#1dccb0;">Paid</td>
                                                <td></td>
                                            <?php else:?>
                                                <td style="color:#fe6477;">Unpaid</td>
                                                <td>
                                                    <a href="###" data-toggle="Popover" data-val="<?php echo $item['bill_id']?>" class="btn btn-outline hover_btn confrim_paid" style="color:#12abc5; border:1px solid #12abc5;"><i class="font-weight-600 md-check" aria-hidden="true"></i> Confrim</a>
                                                </td>
                                            <?php endif;?>
                                            
                                        </tr>
                                    <?php endforeach;?>
                                </tbody>
                            </table>
                        </div>
                    </div>  
                </div>
            </div>
        </div>

        
    </div>
</div>
<script src="<?php echo base_url();?>assets/web/global/vendor/bootstrap-datepicker/bootstrap-datepicker.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/js/components/bootstrap-datepicker.js"></script>
  <script>
    $(function() {
        $('#input_date').datepicker({
            format: "MM yyyy",
            viewMode: "months", 
            minViewMode: "months"
        }).datepicker("setDate", "<?php echo $this->input->get('date')?$this->input->get('date'):date('M Y')?>")
        .on('changeDate', function (ev) {
            var month = $(".datepicker-months span.active").html();
            var year = $(".datepicker-years span.active").html();
            location.href = site_url + "bills/listview?date="+month+' '+year;
        }).val();

        $(".table tr").click(function(){
            //location.href = site_url + "report/detail?product_id="+$(this).attr('data-val')+"&time="+$(this).attr('data-date');
        });

     }); 
</script>


