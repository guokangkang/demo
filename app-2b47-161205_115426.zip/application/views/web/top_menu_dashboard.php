
<div class="site-menubar site-menubar-light">
    <div class="site-menubar-body">
        <div>
            <div>
                <ul class="site-menu">
                    <li class="site-menu-category">General</li>
                    <li class="site-menu-item <?php echo ($this->router->method == 'index') ? "active" : ''; ?>">
                        <a href="<?php echo site_url('dashboard')?>">
                            <i class="site-menu-icon wb-dashboard" aria-hidden="true"></i>
                            <span class="site-menu-title">My Dashboard</span>
                        </a>
                    </li>

                </ul>
            </div>
        </div>
    </div>
</div>
