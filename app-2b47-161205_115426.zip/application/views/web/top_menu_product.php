<div class="site-menubar site-menubar-light">
    <div class="site-menubar-body">
        <div>
            <div>
                <ul class="site-menu">
                    <li class="site-menu-category">General</li>
                    <li class="site-menu-item <?php echo in_array($this->router->method, ['listview', 'detail']) && $this->router->class=='product'?'active':''?>">
                        <a href="<?php echo site_url('product/listview')?>">
                            <i class="site-menu-icon md-apps" aria-hidden="true"></i>
                            <span class="site-menu-title">Products</span>
                        </a>
                    </li>
                    <?php if($this->userinfo['type']==2):?>
                        <li class="site-menu-item <?php echo $this->router->method=='my'&&$this->router->class=='offer'?'active':''?>">
                            <a href="<?php echo site_url('offer/my')?>">
                                <i class="site-menu-icon wb-mobile" aria-hidden="true"></i>
                                <span class="site-menu-title">My Offers</span>
                            </a>
                        </li>
                    <?php endif;?>
                </ul>
            </div>
        </div>
    </div>
</div>