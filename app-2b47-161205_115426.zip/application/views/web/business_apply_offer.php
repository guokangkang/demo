<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/icheck/icheck.css">
<div class="page animsition">
    <div class="page-header ">
        <h1 class="page-title">Apply For Team</h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo site_url('product/listview')?>">Marketplace</a></li>
            <li><a href="<?php echo site_url('product/listview')?>">Product</a></li>
            <li class="active">Apply For Team</li>
        </ol>
    </div>
    <div class="page-content">
        <div class="panel panel-bordered panel-default table-responsive">
            <div class="panel-body">
                <table class="table table-hover dataTable table-striped width-full verticaltop" id="productlist" data-selectable="selectable" data-row-selectable="true">
                    <thead>
                      <tr>
                        <th style="width: 20%">Business ID</th>
                        <th style="width: 20%">Business Name</th>
                        <th style="width: 20%">Publisher Name</th>
                        <th style="width: 40%">Account</th>
                        <th style="width: 5%">
                            <span class="checkbox-custom checkbox-primary">
                                <input class="selectable-all" type="checkbox">
                                <label></label>
                            </span>
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                        <?php $is_data = false;?>
                        <?php foreach($account_list as $item):?>
                            <?php if(!in_array($item['account_id'], $accounts)):?>
                                <?php $is_data = true;?>
                                <tr>
                                    <td>
                                        <?php echo $item['business_id']?>
                                    </td>
                                    <td>
                                        <?php echo $item['business_name']?>
                                    </td>
                                    <td>
                                        <?php echo $item['publisher_name']?>
                                    </td>
                                    <td>
                                        <?php echo $item['account_id']."-".$item['account_name']?><br/>
                                    </td>
                                    <td>
                                        <span class="checkbox-custom checkbox-primary">
                                            <input class="selectable-item checkbox_account" type="checkbox" id="offer-<?php echo $item['market_account_id']?>" value="<?php echo $item['publisher_id'].'-'.$item['market_account_id']?>" >
                                            <label for="offer-<?php echo $item['market_account_id']?>"></label>
                                        </span>
                                    </td>
                                </tr>
                            <?php endif;?>
                        <?php endforeach?>
                        <?php if(!$is_data):?>
                            <tr><td colspan="5" class="text-center">No Data</td></tr>
                        <?php endif;?>
                    </tbody>
                </table>
                <?php if($is_data):?>
                    <div class="form-inline padding-bottom-15">
                        <div class="row">
                            <div class="pull-right" style="padding-right:15px">
                              <div class="form-group">

                                <button class="btn btn-outline btn-primary btn-sm apply_offer_for_team_confirm" style="margin-right:6px;" data-offer="<?php echo $this->input->get('offer_ids')?>"><i class="icon wb-plus" aria-hidden="true"></i>Apply For Team
                                </button>   


                              </div>
                            </div>
                        </div>
                    </div>
                <?php endif;?>
            </div>
        </div>
    </div>
</div>
<script src="<?php echo base_url();?>assets/web/global/js/plugins/selectable.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/components/selectable.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/icheck/icheck.min.js"></script>

<script src="<?php echo base_url();?>assets/web/global/js/components/icheck.js"></script>



