<style>
    .table > tbody > tr > td {
        vertical-align: middle;
    }
</style>
<script src="<?php echo base_url(); ?>assets/js/jquery.printPage.js"></script>
<div class="page animsition">
    <div class="page-header clearfix">
        <ol class="breadcrumb pull-left">
            <li><a href="<?php echo site_url('bills/listview');?>">Bills</a></li>
            <li class="active">Details</li>
        </ol>
        <div class="filter pull-right">
            <?php echo $date ?>
        </div>
    </div>
    <div class="page-content">
        <div class="row">
            <div class="col-lg-12 col-md-12">
                <div class="row">
                    <div class="col-md-4">
                        <div class="widget widget-border" style="height:185px;overflow:hidden;">
                            <div class="widget-content padding-25 bg-white">
                                <div class="counter counter-lg ">
                                    <div class="counter-number-group margin-vertical-20">
                                        <span class="counter-number-related">$</span>
                                        <span class="counter-number"><?php echo number_format($paid, 2) ?></span>
                                    </div>
                                    <div class="counter-label text-uppercase">
                                        <img src="<?php echo base_url(); ?>assets/images/bill_details_green.png"
                                             style="vertical-align:top;padding-top:3px;">
                                        <span class="margin-left-5"
                                              style="height:21px;line-height: 21px;display: inline-block;">Payment</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="widget widget-border" style="height:185px; overflow:hidden;">
                            <div class="widget-content padding-25 bg-white">
                                <div class="counter counter-lg ">
                                    <div class="counter-number-group margin-vertical-20 red-600">
                                        <span class="counter-number-related">$</span>
                                        <span
                                            class="counter-number"><?php echo number_format($adjust_money, 2) ?></span>
                                    </div>
                                    <div class="counter-label text-uppercase">
                                        <img src="<?php echo base_url(); ?>assets/images/bill_details_red.png"
                                             style="vertical-align:top;padding-top:3px;">
                                        <span class="margin-left-5"
                                              style="height:21px;line-height: 21px;display: inline-block;">Adjustments</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="widget widget-border" style="height:185px;overflow:hidden;">
                            <div class="widget-content padding-25 bg-white">
                                <div class="counter counter-lg ">
                                    <div class="counter-number-group margin-vertical-20">
                                        <span class="counter-number-related">$</span>
                                        <span
                                            class="counter-number"><?php echo number_format($paid + $adjust_money, 2) ?></span>
                                    </div>
                                    <div class="counter-label text-uppercase">
                                        <img src="<?php echo base_url(); ?>assets/images/bill_details_green.png"
                                             style="vertical-align:top;padding-top:3px;">
                                        <span class="margin-left-5"
                                              style="height:21px;line-height: 21px;display: inline-block;">Net Payment</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="panel widget-border">
            <header class="panel-heading clearfix">
                <h3 class="panel-title pull-left">Bills Details</h3>
                <div class="pull-right margin-top-15 padding-right-30">
                    <button  class="pull-right wz-print no-print btn hover_btn print"
                       style="border:1px solid #edefee; background:#fff;color: #37474f;" target="_blank"><i
                            class="icon md-print" aria-hidden="true"></i> Print
                    </button>
                </div>
            </header>
            <div class="panel-body">
                <div class="table-responsive">
                    <table class="table dataTable table-striped width-full">
                        <thead>
                        <tr class="change_thead">
                            <?php if ($user_info['type'] == 1): ?>
                                <th style="width:20%;">Advertiser</th>
                                <th style="width:20%;">Product</th>
                                <th style="width:20%;">Category</th>
                                <th style="width:20%;">Conversion</th>
                                <th style="width:20%;">Total Pay</th>
                            <?php else: ?>
                                <th style="width:25%;">Publisher</th>
                                <th style="width:20%;">Product</th>
                                <th style="width:20%;">Category</th>
                                <th style="width:50%;">Conversion</th>
                                <th style="width:25%;">Total Pay</th>
                            <?php endif; ?>
                        </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($data as $item): ?>
                            <tr>
                                <td><?php echo $item['user_name'] ?></td>
                                <td><?php echo $item['product_name'] ?></td>
                                <td><?php echo $item['product_category'] == 'android'?'Android':'iOS' ?></td>
                                <td><?php echo number_format($item['results']) ?></td>
                                <td>$<?php echo number_format($item['amount'], 2) ?></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        
        <?php if($adjust):?>
        <div class="panel widget-border">
            <header class="panel-heading clearfix">
                <h3 class="panel-title pull-left">Bills Adjust</h3>

            </header>
            <div class="panel-body">
                <div class="table-responsive">
                    <table class="table dataTable table-striped width-full">
                        <thead>
                        <tr class="change_thead">
                            <th style="width:20%;">Date</th>
                            <th style="width:20%;">Adjust Type</th>
                            <th style="width:20%;">Money</th>
                            <th style="width:40%;">Reason</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($adjust as $item): ?>
                            <tr>
                                <td><?php echo date('m/d/Y', $item['extend_date']) ?></td>
                                <td><?php echo $item['money_type'] == 1?'罚款':'奖励'; ?></td>
                                <td>
                                    $<?php echo sprintf("%.2f", abs($item['money'])) ?>
                                </td>
                                <td>
                                    <?php echo $item['reason'] ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <?php endif;?>
    </div>
</div>
<script>
    var url='<?php echo $print_url;?>';
    url=encodeURI(url);
    $(".wz-print").printPage({
        url:url,
        attr: "href"
    })
</script>