<div class="site-menubar site-menubar-light">
    <div class="site-menubar-body">
        <div>
            <div>
                <ul class="site-menu">
                    <li class="site-menu-category">General</li>
                    <li class="site-menu-item <?php echo ($this->router->class=='report'&&$this->router->method=='index')?'active':''?>">
                        <a href="<?php echo site_url('report/index')?>">
                            <i class="site-menu-icon md-refresh-alt" aria-hidden="true"></i>
                            <span class="site-menu-title">Conversion Report</span>
                        </a>
                    </li>
                    
                    <?php if($this->userinfo['type']==1):?>
                    <li class="site-menu-item <?php echo ($this->router->class=='report'&&$this->router->method=='agency')?'active':''?>">
                        <a href="<?php echo site_url('report/agency')?>">
                            <i class="site-menu-icon md-account" aria-hidden="true"></i>
                            <span class="site-menu-title">Agency Retention Report</span>
                        </a>
                    </li>
                    <?php endif;?>
                    
                    <li class="site-menu-item <?php echo ($this->router->class=='report'&&$this->router->method=='product')?'active':''?>">
                        <a href="<?php echo site_url('report/product')?>">
                            <i class="site-menu-icon md-receipt" aria-hidden="true"></i>
                            <span class="site-menu-title">Product Retention Report</span>
                        </a>
                    </li>
                    
                    <?php if($this->userinfo['type']==0):?>
                        <li class="site-menu-item <?php echo ($this->router->class=='report'&&$this->router->method=='publisher')?'active':''?>">
                            <a href="<?php echo site_url('report/publisher')?>">
                                <i class="site-menu-icon md-receipt" aria-hidden="true"></i>
                                <span class="site-menu-title">Publisher Report</span>
                            </a>
                        </li>
                    <?php endif;?>

                    <?php if($this->userinfo['type']==1):?>
                    <li class="site-menu-item <?php echo ($this->router->class=='report'&&$this->router->method=='user')?'active':''?>">
                        <a href="<?php echo site_url('report/user')?>">
                            <i class="site-menu-icon md-accounts-alt" aria-hidden="true"></i>
                            <span class="site-menu-title">User Graphs</span>
                        </a>
                    </li>
                    <?php endif;?>

                    <!-- <li class="site-menu-item <?php echo ($this->router->class=='report'&&$this->router->method=='product_map')?'active':''?>">
                        <a href="<?php echo site_url('report/product_map')?>">
                            <i class="site-menu-icon wb-dashboard" aria-hidden="true"></i>
                            <span class="site-menu-title">Product Map</span>
                        </a>
                    </li> -->
                </ul>
            </div>
        </div>
    </div>
</div>