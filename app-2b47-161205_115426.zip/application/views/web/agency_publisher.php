<div class="page animsition">
    <div class="page-header">
      <ol class="breadcrumb">
        <li><a href="<?php echo site_url('agency/listview')?>">Agency</a></li>
        <li class="active">Publisher List</li>
      </ol>
    </div>
    <div class="page-content blue-grey-500">
        <ul class="blocks blocks-100 blocks-xlg-5 blocks-lg-4 blocks-md-3 blocks-sm-2" data-plugin="masonry">
            <?php foreach($publisher_list as $item):?>
                <li class="masonry-item">
                    <div class="widget widget-article widget-shadow widget-border" style="padding-top:20px;">
                        
                        <div class="widget-header cover" style="height:88px;">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="col-md-12">
                                        <p class="widget-title" style="padding-top:12px;font-size: 18px;font-weight: bold;"><?php echo $item['publisher_name']?></p>
                                        <p class="widget-title">ID : <?php echo $item['publisher_id']?></p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="widget-body-footer">
                            <div class="col-md-12">
                                <div class="time pull-right">Results : <?php echo number_format($item['results'])?></div>
                                <div class="text-truncate">Products : <?php echo $item['product']?></div>                           

                                <div class="time pull-right">Shares : <?php echo number_format($item['shares'])?></div>
                                <div class="text-truncate">AdAccounts : <?php echo $item['account_id']?></div>

                                <div class="time pull-right">Illegal Rate : <?php echo $item['illegal_rate']?></div>
                                <div class="text-truncate">Illegals : <?php echo $item['illegal']?></div>
                            </div>
                            <div class="col-sm-12">
                                <div class="example-wrap" style="margin-top:18px; margin-bottom:44px;">
                                    <div>
                                        <h5 style="margin-bottom:2px;">Conversion</h5>
                                        <div class="progress progress-xs">
                                            <div class="progress-bar progress-bar-default progress-bar-indicating active" style="width:85%;" role="progressbar">
                                                <span class="sr-only">85% Complete</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div>
                                        <h5 style="margin-bottom:2px;">The Next Day</h5>
                                        <div class="progress progress-xs">
                                            <div class="progress-bar progress-bar-success progress-bar-indicating active" style="width:80%;" role="progressbar">
                                                <span class="sr-only">80% Complete</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div>
                                        <h5 style="margin-bottom:2px;">7 Days</h5>
                                        <div class="progress progress-xs">
                                            <div class="progress-bar progress-bar-warning progress-bar-indicating active" style="width: 25%;" role="progressbar">
                                                <span class="sr-only">25% Complete</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div>
                                        <h5 style="margin-bottom:2px;">30 Days</h5>
                                        <div class="progress progress-xs">
                                            <div class="progress-bar progress-bar-danger progress-bar-indicating active" style="width: 8%;" role="progressbar">
                                                <span class="sr-only">8% Complete</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div> 
                    </div>
                </li>
            <?php endforeach;?>
        </ul>
    </div>
</div>
  