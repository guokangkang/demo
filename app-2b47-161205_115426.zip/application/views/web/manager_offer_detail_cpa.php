<div class="panel margin-bottom-0">
    <div class="row padding-top-30">
        <div class="col-sm-6">
            <form class="form-horizontal" autocomplete="off" id="manager_offer_detail_cpa"  method="post" action="<?php echo site_url('manager/offer/set_offer_cpa_action')?>">
                <input type="hidden" name="product_id" value="<?php echo $product_info['product_id']?>">
                <input type="hidden" name="offer_id" value="<?php echo $offer_info['offer_id']?>">

                <div class="form-group">
                    <label class="col-sm-3 control-label" for="contact">Payout Type </label>
                    <div class="col-sm-9">
                        <div class="margin-right-20">
                            <div class="radio-custom radio-default radio-inline">
                              <input type="radio" value="1" id="inputFix" name="category" checked="">
                              <label for="inputFix"><?php echo $config_product['offer_category'][1]?></label>
                            </div>
                            <div class="radio-custom radio-default radio-inline">
                              <input type="radio" value="2" id="inputTypeA" name="category" >
                              <label for="inputTypeA"><?php echo $config_product['offer_category'][2]?></label>
                            </div>
                            <div class="radio-custom radio-default radio-inline">
                              <input type="radio" value="3" id="inputTypeB" name="category" >
                              <label for="inputTypeB"><?php echo $config_product['offer_category'][3]?></label>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label class="col-sm-3 control-label" for="contact">CPA</label>
                    <div class="col-sm-9">
                        <div class="input-group">
                            <span class="input-group-addon">$</span>
                            <input type="text" class="form-control" id="input_cpa" name="myprice" data-fv-notempty="true" onkeyup="value=value.replace(/[^\d|.]/g,'')" value="" />
                        </div>
                    </div>
                </div>


                <div class="form-group wz hide bucket_payout_typea">
                    <label class="col-sm-3 control-label" for="contact">Tiers</label>
                    <div class="col-sm-9">
                        <div class="input-group">
                            <div class="col-lg-6 padding-0">
                                <div class="input-group">
                                    <input type="text" class="form-control" id="inputRetention" name="input_percent[]"  data-fv-lessthan-message="percent is not right" data-fv-field="input_percent[]" data-fv-notempty="true"  placeholder="Retention Rate" autocomplete="off">
                                    <span class="input-group-addon">%</span>
                                </div>
                            </div>
                            <div class="col-lg-6 padding-right-0">
                                <div class="input-group bootstrap-touchspin">

                                    <input type="text" class="form-control" id="inputPayout" name="input_price[]"  data-fv-lessthan-message="percent is not right" data-fv-field="input_price[]" data-fv-notempty="true"  placeholder="Payout Rate" autocomplete="off">
                                    <span class="input-group-addon">%</span>

                                    <span class="input-group-btn">
                                        <button class="btn btn-outline btn-default bootstrap-touchspin-up  wb_plus addButton" type="button">+</button>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="form-group  hide bucket_payout_typeb">
                    <label class="col-sm-3 control-label" for="contact">Tiers</label>
                    <div class="col-sm-9">
                        <div class="input-group">
                            <div class="col-lg-12 padding-0">
                                <div class="input-group">
                                    <input type="text" class="form-control" id="inputRetention" name="input_typeb"  data-fv-lessthan-message="percent is not right" data-fv-field="input_percent[]" data-fv-notempty="true"  placeholder="Retention Rate" autocomplete="off">
                                    <span class="input-group-addon">%</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
               

                <div class="form-group hide" id="retained_template">
                    <label class="col-sm-3 control-label" for="contact"></label>
                    <div class="col-sm-9">
                        <div class="input-group">
                            <div class="col-lg-6 padding-0">
                                <div class="input-group">
                                    <input type="text"  data-fv-lessthan-message="percent is not right"  class="form-control" name="input_percent[]" placeholder="Retention Rate" autocomplete="off">
                                    <span class="input-group-addon">%</span>
                                </div>
                            </div>
                            <div class="col-lg-6 padding-right-0">
                                <div class="input-group bootstrap-touchspin">
                                   <input type="text"  data-fv-lessthan-message="percent is not right"  class="form-control" name="input_price[]" placeholder="Payout Rate" autocomplete="off">

                                    <span class="input-group-addon">%</span>

                                    <span class="input-group-btn">
                                        <button class="btn btn-outline btn-default removeButton" type="button">-</button>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label class="col-sm-3 control-label" for="contact">Effective Time</label>
                    <div class="col-sm-9">
                        <div class="input-daterange">
                            <div class="input-group">
                                <span class="input-group-addon">
                                    <i class="icon wb-calendar" aria-hidden="true"></i>
                                </span>
                                    <input type="text" class="form-control datepair-date datepair-start" data-plugin="datepicker" name="input_date" id="inputdate" value="<?php echo date('m/d/Y')?>">
                            </div>
                            <div class="input-group ">
                                <span class="input-group-addon">
                                    <i class="icon wb-time" aria-hidden="true"></i>
                                </span>
                                <input type="text" class="form-control datepair-time datepair-start" data-plugin="timepicker" name="input_time" id="inputtime"
                                    value="<?php echo date('H:i a')?>" />
                            </div>
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label class="col-sm-3 control-label" for="contact"></label>
                    <div class="col-sm-9">
                        <button class="btn btn-info product_bucket_payout_save" data-dismiss="" type="submit" id="manager_offer_detail_cpa_button">Submit</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <header class="panel-heading margin-bottom-0 clearfix">
        <h3 class="panel-title pull-left">Details</h3>
    </header>
    <div class="panel-body table-responsive">
        <table class="table dataTable table-striped width-full" id="facebook_report">
            <thead class="change_thead">
                <tr>
                    <th style="width: 30%">Effective time</th>
                    <th style="width: 20%">Payout</th>
                    <th style="width: 25%">Retention</th>
                    <th style="width: 5%"></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($offer_cpa as $key=>$value):?>
                    <?php if($key=='schedule' || $key=='history'):?>
                        <?php foreach($value as $item):?>
                            <tr>
                                <td><?php echo date('m/d/Y H:i', $item['start_time'])?></td>
                                <td>$<?php echo sprintf("%.2f", $item['cpa'])?></td>
                                <td>
                                    <?php echo $config_product['offer_category'][$item['category']]?>
                                    <?php if($item['category']==2):?>
                                        <?php foreach($item['value'] as $val):?>  
                                            <p><?php echo "If RT > <strong>".$val['retention_rate']."%</strong>, ";?>
                                            <?php echo "Payout will be <strong>".$val['payout_rate']."%</strong> = ";?>
                                            <strong><?php echo "$".$val['payout'];?></strong></p>
                                        <?php endforeach;?>
                                    <?php elseif($item['category']==1):?>
                                        <strong><?php echo "$".$item['cpa']?></strong>
                                    <?php else:?>
                                        <p>Payout will be proportional to the retention rate.</p>
                                        <p>If RR > <strong><?php echo $item['value']?>%</strong>, Full Payout.</p>
                                        <p>If RR = x, payout = x/<strong><?php echo $item['value']?>%</strong>*Full Payout.</p>
                                    <?php endif;?>
                                </td>
                                <td></td>
                            </tr>
                        <?php endforeach;?>
                    <?php elseif($key =='current' && $offer_cpa['current']):?>
                        <tr>
                            <td><?php echo date('m/d/Y H:i', $value['start_time'])?></td>
                            <td>$<?php echo sprintf("%.2f", $value['cpa'])?></td>
                            <td>
                                <?php echo $config_product['offer_category'][$value['category']]?>
                                <?php if($value['category']==2):?>
                                    <?php foreach($value['value'] as $val):?>  
                                        <p><?php echo "If RT > <strong>".$val['retention_rate']."%</strong>, ";?>
                                        <?php echo "Payout will be <strong>".$val['payout_rate']."%</strong> = ";?>
                                        <strong><?php echo "$".$val['payout'];?></strong></p>
                                    <?php endforeach;?>
                                <?php elseif($value['category']==1):?>
                                    <strong><?php echo "$".$value['cpa']?></strong>
                                <?php else:?>
                                    <p>Payout will be proportional to the retention rate.</p>
                                    <p>If RR > <strong><?php echo $value['value']?>%</strong>, Full Payout.</p>
                                    <p>If RR = x, payout = x/<strong><?php echo $value['value']?>%</strong>*Full Payout.</p>
                                <?php endif;?>
                            </td>
                            <td><span class="label label-table label-success">Current</span></td>
                        </tr>
                    <?php endif;?>
                <?php endforeach;?>
            </tbody>
        </table>
    </div>
</div>