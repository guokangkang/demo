<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/datatables-bootstrap/dataTables.bootstrap.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/datatables-fixedheader/dataTables.fixedHeader.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/datatables-responsive/dataTables.responsive.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/assets/examples/css/tables/datatable.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/fonts/material-design/material-design.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/assets/examples/css/uikit/icon.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/multi-select/multi-select.css">

<link rel="stylesheet" href="<?php echo base_url();?>assets/web/assets/examples/css/advanced/masonry.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/assets/examples/css/uikit/dropdowns.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/asscrollable/asScrollable.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/assets/examples/css/advanced/scrollable.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/index_select.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/daterangepicker.css" />
        <a id="reports_detail"></a>

<style>
   @media (min-width: 768px){
    .form-inline .form-control{width: 100%;}
   }
   .table>tbody>tr>td{vertical-align: middle;}
   .bootstrap-select:not([class*="col-"]):not([class*="form-control"]):not(.input-group-btn) {
        width: 220px;
    }
    .table>thead>tr>th{border-bottom:0;}
    .table>tbody>tr>td{vertical-align: middle;border-top: 0; border-bottom: 1px solid #edefee;} 


    .btn-group.open .dropdown-toggle,.btn-group.open .dropdown-toggle{box-shadow:none;}
    .input-search .form-control{border-radius:0;}
    .save_name_input:focus{border:1px solid #12abc5!important;}
    #report_double canvas{margin-top:-45px;}
    #child_chart canvas{margin-top:-45px;}
    .checkbox-primary input[type=radio]:checked+label::before, .checkbox-primary input[type=checkbox]:checked+label::before{background-color: #12abc5;border-color: #12abc5;}
    .scrollable-container{width: 100%!important;}
    .panel-heading .dropdown-menu>li>a:hover{
        background-color:#fff!important;
    }
    .panel-heading .dropdown-menu>li.active>a:hover{
        background-color:#f3f7f9!important;
    }
    .loader.loader-default{
        background-color:inherit;
    }
    .active-check i{
        opacity: 1;
    }
    .md-check-i{
        opacity: 0;
    }
</style>

<div class="page animsition">
    <div class="page-header clearfix">
        <ol class="breadcrumb pull-left">
            <li><a href="<?php echo site_url('report')?>">Report</a></li>
            <li class="active">Conversion</li>
        </ol>
        <div class="pull-right">
            <form>  
                <div class="form-group col-lg-3 col-xlg-3 filter-form account-filter margin-bottom-0" style="padding-left: 0;text-align: center;">
                    <div class="form-control" style="width: 227px;">
                        <div id="report_date_time" class="pull-right">
                            <i class="glyphicon glyphicon-calendar fa fa-calendar"></i>&nbsp;
                            <span></span> <b class="caret"></b>

                            <input type="hidden" value="" class="report_date_start" />
                            <input type="hidden" value="" class="report_date_end" />
                        </div>
                    </div>
                </div> 
            </form>
        </div>
    </div>
    <div class="page-content"> 
        <div class="row">
            <div class="col-md-12">
                <div class="panel padding-horizontal-30" style="box-shadow:none;border: 1px solid #e3eaec;">
                    <div class="panel-heading clearfix">
                        <h3 class="panel-title pull-left padding-horizontal-0 padding-top-30">Filter</h3>

                        <!-- search -->
                        <div class="form-group margin-vertical-0 pull-right margin-top-20" style="margin-top:-5px;">
                            <div class="input-search margin-0">
                                <button type="submit" class="input-search-btn"><i class="icon wb-search" aria-hidden="true" style="color: #cfd7d7;"></i></button>
                                <input type="text" class="form-control reports_keywords" name="" placeholder="Search..." style="border: none;border-bottom: 1px solid #ebebeb;">
                            </div>
                        </div>

                        <!-- columns -->
                        <div class="btn-group pull-right margin-top-20 margin-right-10">
                            <div class="btn dropdown-toggle" id="exampleSizingDropdown2"
                             data-toggle="dropdown" aria-expanded="false">
                                Columns
                                <span class="caret"></span>
                            </div>
                            <ul class="dropdown-menu" aria-labelledby="exampleSizingDropdown2" role="menu" id="column_ul">
                                <li role="presentation" class="column_block"><a href="javascript:void(0)" role="menuitem">Modify Columns</a></li>
                                <?php if($custom_columns):?>
                                    <li role="presentation"><a role="menuitem"><b>Saved column sets</b></a></li>
                                    <?php foreach($custom_columns as $custom):?>
                                        <li role="presentation" class="select_custom_set" data-val="<?php echo $custom['custom_id']?>"><a href="javascript:void(0)" role="menuitem" ><?php echo $custom['title']?><i class="md-close-circle-o pull-right font-size-20" aria-hidden="true" style="margin-top:-4px;"  onclick="remove_filter_column_reports(this, event)" data-val="<?php echo $custom['custom_id']?>"></i></a></li>
                                    <?php endforeach;?>
                                <?php endif;?>
                            </ul>
                        </div> 

                        <!-- filter -->
                        <div class="btn-group pull-right margin-top-20">
                            <div class="btn dropdown-toggle" id="exampleSizingDropdown2"
                             data-toggle="dropdown" aria-expanded="false">
                                Filters
                                <span class="caret"></span>
                            </div>
                            <ul class="dropdown-menu" aria-labelledby="exampleSizingDropdown2" role="menu" id="filter_ul">
                                <li role="presentation" class="filter_block"><a href="javascript:void(0)" role="menuitem">Create Filters</a></li>
                                <?php if($custom_filters):?>
                                    <li role="presentation"><a role="menuitem"><b>Saved column sets</b></a></li>
                                    <?php foreach($custom_filters as $custom):?>
                                        <li role="presentation" class="select_custom_set" data-val="<?php echo $custom['custom_id']?>"><a href="javascript:void(0)" role="menuitem" ><?php echo $custom['title']?><i class="md-close-circle-o pull-right font-size-20" aria-hidden="true" style="margin-top:-4px;" onclick="remove_filter_column_reports(this, event)" data-val="<?php echo $custom['custom_id']?>"></i></a></li>
                                    <?php endforeach;?>
                                <?php endif;?>
                            </ul>
                        </div>
                    </div>
                    <div class="panel-body padding-horizontal-0">
                        <!-- filter_div -->
                        <div class="filter_div  padding-top-30" style="display:none;">
                            <div class="row">
                                <div class="col-md-4">
                                    <?php if($this->userinfo['type']==2 || $this->userinfo['type']==0):?>
                                        <div class="diy_select filter-form advertiser-filter form-group">
                                            <!--【存】当前选中的值-->
                                            <input type="hidden" name="" class="diy_select_input filter_advertiser" value="">
                                            <!--【显示】当前选中的值-->
                                            <input type="text" class="diy_select_txt filterinput_1" placeholder="Advertiser">
                                            <!--下拉三角形-->
                                            <span class="caret" style="right: 14px;position: absolute;top: 50%;margin-top: -2px;"></span>
                                            <!--数据列表-->
                                            <ul class="diy_select_list" style="display:none;" id="radiaobox_1">
                                                <?php if(isset($advertiserlist)):?>
                                                    <?php foreach($advertiserlist as $advertiser):?>
                                                        <li data-key="<?php echo $advertiser['advertiser_id']?>">
                                                            <span><?php echo $advertiser['advertiser_id']."(".$advertiser['advertiser_name'].')'?></span>
                                                            <b class="icon wb-check check-mark"></b>
                                                        </li>
                                                    <?php endforeach;?>
                                                <?php endif;?>
                                            </ul>
                                        </div>
                                            <!--<select class="form-control select2-hidden-accessible filter_advertiser" multiple="" data-plugin="select2" tabindex="-1" aria-hidden="true" data-placeholder="Advertiser">
                                                    <option value="<?php /*echo $advertiser['advertiser_id']*/?>"><?php /*echo $advertiser['advertiser_id']."(".$advertiser['advertiser_name'].')'*/?></option>

                                            </select>-->
                                    <?php endif;?>
                                    <?php if($this->userinfo['type']==1 || $this->userinfo['type']==0):?>
                                        <div class="diy_select form-group filter-form publisher-filter">
                                            <!--【存】当前选中的值-->
                                            <input type="hidden" name="" class="diy_select_input filter_publisher" value="">
                                            <!--【显示】当前选中的值-->
                                            <input type="text" class="diy_select_txt filter_input_1" placeholder="Publisher">
                                            <!--下拉三角形-->
                                            <span class="caret" style="right: 14px;position: absolute;top: 50%;margin-top: -2px;"></span>
                                            <!--数据列表-->
                                            <ul class="diy_select_list" style="display:none;" id="radiao_box_1">
                                                <?php if(isset($publisherlist)):?>
                                                <?php foreach($publisherlist as $publisher):?>
                                                    <li data-key="<?php echo $publisher['publisher_id']?>" <?php echo ($this->input->get('publisher')==$publisher['publisher_id']?"class='show_list'":'')?>>
                                                        <span><?php echo $publisher['publisher_id']."(".$publisher['publisher_name'].')';?></span>
                                                        <b class="icon wb-check check-mark"></b>
                                                    </li>
                                                <?php endforeach;?>
                                                <?php endif;?>
                                            </ul>
                                        </div>
                                    <?php endif;?>
                                    <div class="diy_select form-group filter-form agency-filter">
                                        <!--【存】当前选中的值-->
                                        <input type="hidden" name="" class="diy_select_input filter_agency" value="">
                                        <!--【显示】当前选中的值-->
                                        <input type="text" class="diy_select_txt filter_input_2" placeholder="Agency">
                                        <!--下拉三角形-->
                                        <span class="caret" style="right: 14px;position: absolute;top: 50%;margin-top: -2px;"></span>
                                        <!--数据列表-->
                                        <ul class="diy_select_list" style="display:none;" id="radiao_box_2">
                                            <?php if(isset($agency_list)):?>
                                                <?php foreach($agency_list as $agency):?>
                                                    <li data-key="<?php echo $agency['publisher_id']?>" <?php echo ($this->input->get('agency')==$agency['publisher_id']?"class='show_list'":'')?>>
                                                        <span><?php echo $agency['publisher_name']?></span>
                                                        <b class="icon wb-check check-mark"></b>
                                                    </li>
                                                <?php endforeach;?>
                                            <?php endif;?>
                                        </ul>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="diy_select form-group filter-form product-filter">
                                        <!--【存】当前选中的值-->
                                        <input type="hidden" name="" class="diy_select_input filter_product" value="">
                                        <!--【显示】当前选中的值-->
                                        <input type="text" class="diy_select_txt filterinput_2" placeholder="Product">
                                        <!--下拉三角形-->
                                        <span class="caret" style="right: 14px;position: absolute;top: 50%;margin-top: -2px;"></span>
                                        <!--数据列表-->
                                        <ul class="diy_select_list" style="display:none;" id="radiaobox_2">
                                            <?php if(isset($productlist)):?>
                                                <?php foreach($productlist as $product):?>
                                                    <li data-key="<?php echo $product['product_id']?>">
                                                        <span><?php echo "(".$product['product_id'].")".$product['product_name']?></span>
                                                        <b class="icon wb-check check-mark"></b>
                                                    </li>
                                                <?php endforeach;?>
                                            <?php endif;?>
                                        </ul>
                                    </div>
                                    <div class="diy_select form-group filter-form offer-filter">
                                        <!--【存】当前选中的值-->
                                        <input type="hidden" name="" class="diy_select_input filter_offer" value="">
                                        <!--【显示】当前选中的值-->
                                        <input type="text" class="diy_select_txt filter_input_3" placeholder="Offer">
                                        <!--下拉三角形-->
                                        <span class="caret" style="right: 14px;position: absolute;top: 50%;margin-top: -2px;"></span>
                                        <!--数据列表-->
                                        <ul class="diy_select_list" style="display:none;" id="radiao_box_3">
                                            <?php if(isset($offerlist)):?>
                                                <?php foreach($offerlist as $offer):?>
                                                    <li data-key="<?php echo $offer['offer_id']?>">
                                                        <span><?php echo $offer['offer_id'].'-'.$offer['product_name']?></span>
                                                        <b class="icon wb-check check-mark"></b>
                                                    </li>
                                                <?php endforeach;?>
                                            <?php endif;?>
                                        </ul>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="diy_select form-group filter-form account-filter">
                                        <!--【存】当前选中的值-->
                                        <input type="hidden" name="" class="diy_select_input filter_account" value="">
                                        <!--【显示】当前选中的值-->
                                        <input type="text" class="diy_select_txt filterinput_3" placeholder="Account">
                                        <!--下拉三角形-->
                                        <span class="caret" style="right: 14px;position: absolute;top: 50%;margin-top: -2px;"></span>
                                        <!--数据列表-->
                                        <ul class="diy_select_list" style="display:none;" id="radiaobox_3">
                                            <?php if(isset($accountlist)):?>
                                            <?php foreach($accountlist as $account):?>
                                                <li data-key="<?php echo $account['account_id']?>">
                                                    <span><?php echo $account['account_id']."(".$account['account_name'].')'?></span>
                                                    <b class="icon wb-check check-mark"></b>
                                                </li>
                                            <?php endforeach;?>
                                            <?php endif;?>
                                        </ul>
                                    </div>
                                    <div class="diy_select form-group filter-form country-filter">
                                        <!--【存】当前选中的值-->
                                        <input type="hidden" name="" class="diy_select_input filter_country" value="">
                                        <!--【显示】当前选中的值-->
                                        <input type="text" class="diy_select_txt filter_input_4" placeholder="Country">
                                        <!--下拉三角形-->
                                        <span class="caret" style="right: 14px;position: absolute;top: 50%;margin-top: -2px;"></span>
                                        <!--数据列表-->
                                        <ul class="diy_select_list" style="display:none;" id="radiao_box_4">
                                            <?php if(isset($config_country)):?>
                                                <?php foreach($config_country['country'] as $key=> $country):?>
                                                    <li data-key="<?php echo $key?>">
                                                        <span><?php echo $key.'-'.$country?></span>
                                                        <b class="icon wb-check check-mark"></b>
                                                    </li>
                                                <?php endforeach;?>
                                            <?php endif;?>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="example-buttons margin-vertical-0 margin-top-15 clearfix">
                                <button type="button" class="btn btn-outline hover_btn btn-primary filter_save pull-left" style="border:1px solid #12abc5; color:#12abc5;">Apply</button>
                                <button type="button" class="btn btn-outline btn-info pull-left filter_cannel">Cannel</button>
                                <div class="checkbox-custom checkbox-primary pull-left margin-left-10 margin-right-15">
                                    <input type="checkbox" id="input_save_filter" class="toggle_input">
                                    <label for="input_save_filter">Save this set of filters</label>
                                </div>
                                <input type="text" class="form-control pull-left width-200 save_name_input filter_save_name_input" id="inputHelpText" style="display:none;">
                            </div>
                        </div>
                        <!-- columns div -->
                        <div class="column_div margin-top-10" style="max-height:0; overflow-x:hidden;overflow-y:auto;">
                            <ul class="blocks blocks-100 blocks-xlg-5 blocks-lg-5 blocks-md-4 blocks-sm-2" data-plugin="masonry">
                                <li class="masonry-item">
                                    <h5 class="padding-bottom-15 padding-left-15" style="border-bottom:1px solid #f6f6f6;">Interval</h5>
                                    <div class="height-250" data-plugin="scrollable">
                                        <div data-role="container">
                                            <div data-role="content" class="padding-left-15">
                                                <div class="checkbox-custom checkbox-primary margin-bottom-20">
                                                    <input type="checkbox" id="input_year" value="year" class="select_fields">
                                                    <label for="input_year">Year</label>
                                                </div>
                                                <div class="checkbox-custom checkbox-primary margin-bottom-20">
                                                    <input type="checkbox" id="input_month" value="month" class="select_fields">
                                                    <label for="input_month">Month</label>
                                                </div>
                                                <div class="checkbox-custom checkbox-primary margin-bottom-20">
                                                    <input type="checkbox" id="input_date" value="date" checked="" class="select_fields">
                                                    <label for="input_date">Date</label>
                                                </div>
                                                
                                            </div>
                                        </div>
                                    </div>
                                </li>
                                <li class="masonry-item">
                                    <h5 class="padding-bottom-15 padding-left-15" style="border-bottom:1px solid #f6f6f6;">Breakdown</h5>
                                    <div class="height-250" data-plugin="scrollable">
                                        <div data-role="container">
                                            <div data-role="content" class="padding-left-15">
                                                <div class="checkbox-custom checkbox-primary margin-bottom-20">
                                                    <input type="checkbox" id="input_product" value="product_name" class="select_fields">
                                                    <label for="input_product">Product</label>
                                                </div>
                                                <?php if($this->userinfo['type']=='2' || $this->userinfo['type']=='0'):?>
                                                    <div class="checkbox-custom checkbox-primary margin-bottom-20">
                                                        <input type="checkbox" id="input_advertiser" value="advertiser_id" class="select_fields">
                                                        <label for="input_advertiser">Advertiser</label>
                                                    </div>
                                                <?php endif; if($this->userinfo['type']=='1' || $this->userinfo['type']=='0'):?>
                                                    <div class="checkbox-custom checkbox-primary margin-bottom-20">
                                                        <input type="checkbox" id="input_publisher" value="publisher_id" class="select_fields">
                                                        <label for="input_publisher">Publisher</label>
                                                    </div>
                                                    <div class="checkbox-custom checkbox-primary margin-bottom-20">
                                                        <input type="checkbox" id="input_agency" value="agency_id" class="select_fields">
                                                        <label for="input_agency">Agency</label>
                                                    </div>
                                                <?php endif;?>
                                                <div class="checkbox-custom checkbox-primary margin-bottom-20">
                                                    <input type="checkbox" id="input_country" value="country" class="select_fields">
                                                    <label for="input_country">Country</label>
                                                </div>
                                                <div class="checkbox-custom checkbox-primary margin-bottom-20">
                                                    <input type="checkbox" id="input_account" value="account_id" class="select_fields">
                                                    <label for="input_account">Account</label>
                                                </div>
                                                <?php if($this->userinfo['type']=='2' || $this->userinfo['type']=='0'):?>
                                                    <div class="checkbox-custom checkbox-primary margin-bottom-20">
                                                        <input type="checkbox" id="input_campaign" value="campaign_id" class="select_fields">
                                                        <label for="input_campaign">Campaign</label>
                                                    </div>
                                                    <div class="checkbox-custom checkbox-primary margin-bottom-20">
                                                        <input type="checkbox" id="input_adset" value="adset_id" class="select_fields">
                                                        <label for="input_adset">Adset</label>
                                                    </div>
                                                <?php endif;?>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                                <li class="masonry-item">
                                    <h5 class="padding-bottom-15 padding-left-15" style="border-bottom:1px solid #f6f6f6;">Statistics</h5>
                                    <div class="height-250" data-plugin="scrollable">
                                        <div data-role="container">
                                            <div data-role="content" class="padding-left-15">
                                                <?php if($this->userinfo['type']=='2' || $this->userinfo['type']=='0'):?>
                                                    <div class="checkbox-custom checkbox-primary margin-bottom-20">
                                                        <input type="checkbox" id="input_impressions" value="impressions" class="select_fields">
                                                        <label for="input_impressions">Impressions</label>
                                                    </div>
                                                    <div class="checkbox-custom checkbox-primary margin-bottom-20">
                                                        <input type="checkbox" id="input_clicks" class="select_fields" value="clicks" <?php echo $this->userinfo['type']==0?"checked=''":''?>>
                                                        <label for="input_clicks">Clicks(All)</label>
                                                    </div>
                                                    <div class="checkbox-custom checkbox-primary margin-bottom-20">
                                                        <input type="checkbox" id="input_clicks_link" value="clicks_link" class="select_fields">
                                                        <label for="input_clicks_link">Clicks(Link)</label>
                                                    </div>
                                                    <div class="checkbox-custom checkbox-primary margin-bottom-20">
                                                        <input type="checkbox" id="input_facebook_cpi" value="facebook_cpi" class="select_fields">
                                                        <label for="input_facebook_cpi">Facebook CPI</label>
                                                    </div>
                                                    <div class="checkbox-custom checkbox-primary margin-bottom-20">
                                                        <input type="checkbox" id="input_spend" value="spend" class="select_fields">
                                                        <label for="input_spend">Amount Spent</label>
                                                    </div>
                                                    <div class="checkbox-custom checkbox-primary margin-bottom-20">
                                                        <input type="checkbox" id="input_anticipated_income" class="select_fields" value="anticipated_income" <?php echo $this->userinfo['type']==0?"checked=''":''?>>
                                                        <label for="input_anticipated_income"><?php echo $this->userinfo['type']==2?'Earning':'Media Buy Earning'?></label>
                                                    </div>
                                                    <div class="checkbox-custom checkbox-primary margin-bottom-20">
                                                        <input type="checkbox" id="input_revenue" class="select_fields" value="revenue" <?php echo $this->userinfo['type']==0?"checked=''":''?>>
                                                        <label for="input_revenue"><?php echo $this->userinfo['type']==2?'Real Earning':'Real MB Earning'?></label>
                                                    </div>
                                                    <div class="checkbox-custom checkbox-primary margin-bottom-20">
                                                        <input type="checkbox" id="input_profit" class="select_fields" value="profit" <?php echo $this->userinfo['type']==0?"checked=''":''?>>
                                                        <label for="input_profit"><?php echo $this->userinfo['type']==2?'Profit':'Media Buy Profit'?></label>
                                                    </div>
                                                    <div class="checkbox-custom checkbox-primary margin-bottom-20">
                                                        <input type="checkbox" id="input_real_profit" class="select_fields" value="real_profit" <?php //echo $this->userinfo['type']==0?"checked=''":''?>>
                                                        <label for="input_real_profit">Real Profit</label>
                                                    </div>
                                                <?php endif;?>
                                                <div class="checkbox-custom checkbox-primary margin-bottom-20">
                                                    <input type="checkbox" id="input_results" value="results"  checked="" class="select_fields">
                                                    <label for="input_results">Results</label>
                                                </div>
                                                <div class="checkbox-custom checkbox-primary margin-bottom-20">
                                                    <input type="checkbox" id="input_epa" value="epa" class="select_fields">
                                                    <label for="input_epa">EPA(Earning Per Action)</label>
                                                </div>
                                                <?php if($this->userinfo['type']=='1'):?>
                                                    <div class="checkbox-custom checkbox-primary margin-bottom-20">
                                                        <input type="checkbox" id="input_amount_cost" value="amount_cost" checked="" class="select_fields">
                                                        <label for="input_amount_cost">Amount Cost</label>
                                                    </div>
                                                <?php endif;?>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                                <?php if($this->userinfo['type']=='2' || $this->userinfo['type']=='0'):?>
                                    <li class="masonry-item">
                                        <h5 class="padding-bottom-15 padding-left-15" style="border-bottom:1px solid #f6f6f6;">Calculations</h5>
                                        <div class="height-250" data-plugin="scrollable">
                                            <div data-role="container">
                                                <div data-role="content" class="padding-left-15">
                                                    <div class="checkbox-custom checkbox-primary margin-bottom-20">
                                                        <input type="checkbox" id="input_ctr_all" value="ctr_all" class="select_fields">
                                                        <label for="input_ctr_all">CTR(All)</label>
                                                    </div>
                                                    <div class="checkbox-custom checkbox-primary margin-bottom-20">
                                                        <input type="checkbox" id="input_ctr_link" value="ctr_link" class="select_fields">
                                                        <label for="input_ctr_link">CTR(Link)</label>
                                                    </div>
                                                    <div class="checkbox-custom checkbox-primary margin-bottom-20">
                                                        <input type="checkbox" id="input_cvr_all" value="cvr_all" class="select_fields">
                                                        <label for="input_cvr_all">CVR(All)</label>
                                                    </div>
                                                    <div class="checkbox-custom checkbox-primary margin-bottom-20">
                                                        <input type="checkbox" id="input_cvr_link" value="cvr_link" class="select_fields">
                                                        <label for="input_cvr_link">CVR(Link)</label>
                                                    </div>
                                                    <div class="checkbox-custom checkbox-primary margin-bottom-20">
                                                        <input type="checkbox" id="input_cpc_all" value="cpc_all" class="select_fields">
                                                        <label for="input_cpc_all">CPC(All)</label>
                                                    </div>
                                                    <div class="checkbox-custom checkbox-primary margin-bottom-20">
                                                        <input type="checkbox" id="input_cpc_link" value="cpc_link" class="select_fields">
                                                        <label for="input_cpc_link">CPC(Link)</label>
                                                    </div>
                                                    <div class="checkbox-custom checkbox-primary margin-bottom-20">
                                                        <input type="checkbox" id="input_cpm" value="cpm" class="select_fields">
                                                        <label for="input_cpm">CPM</label>
                                                    </div>
                                                    <div class="checkbox-custom checkbox-primary margin-bottom-20">
                                                        <input type="checkbox" id="input_roi" value="roi" class="select_fields">
                                                        <label for="input_roi">ROI</label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                
                                    <li class="masonry-item">
                                        <h5 class="padding-bottom-15 padding-left-15" style="border-bottom:1px solid #f6f6f6;">Retention</h5>
                                        <div class="height-250" data-plugin="scrollable">
                                            <div data-role="container">
                                                <div data-role="content" class="padding-left-15">
                                                    <div class="checkbox-custom checkbox-primary margin-bottom-20">
                                                        <input type="checkbox" id="input_day0" value="day0" class="select_fields">
                                                        <label for="input_day0">Day 0 Installs</label>
                                                    </div>
                                                    <div class="checkbox-custom checkbox-primary margin-bottom-20">
                                                        <input type="checkbox" id="input_day1" value="day1" class="select_fields">
                                                        <label for="input_day1">Day X Installs</label>
                                                    </div>
                                                    <div class="checkbox-custom checkbox-primary margin-bottom-20">
                                                        <input type="checkbox" id="input_retention" value="retention" class="select_fields">
                                                        <label for="input_retention">Retention Rate</label>
                                                    </div>
                                                    <div class="checkbox-custom checkbox-primary margin-bottom-20">
                                                        <input type="checkbox" id="input_appsflyer_facebook" value="appsflyer_facebook" class="select_fields">
                                                        <label for="input_appsflyer_facebook">A / F</label>
                                                        <i data-toggle="tooltip" data-placement="top" data-trigger="hover" data-original-title="A/F = Appsflyer Day 0 Installs / Facebook Results * 100%" class="icon md-info-outline" aria-hidden="true"></i>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                <?php endif;?>
                            </ul>
                            <div class="example-buttons margin-vertical-0 margin-top-15 clearfix">
                                <button type="button" class="btn btn-outline hover_btn btn-primary column_save pull-left" style="border:1px solid #12abc5; color:#12abc5;">Apply</button>
                                <button type="button" class="btn btn-outline btn-info pull-left column_cannel">Cannel</button>
                                <div class="checkbox-custom checkbox-primary pull-left margin-left-10 margin-right-15">
                                    <input type="checkbox" id="input_save_column" class="column_toggle_input">
                                    <label for="input_save_column">Save this set of columns</label>
                                </div>
                                <input type="text" class="form-control pull-left width-200 column_save_name_input" id="inputHelpText" style="display:none;">
                            </div>
                        </div>
                        <div class="margin-top-5" style="width:100%; border-top:1px solid #ebebeb; height:256px;">
                            <div class="select_html">
                            
                                <div class="btn-group pull-right margin-top-20" style="position:relative; z-index:10;">
                                    <div class="btn dropdown-toggle" id="exampleSizingDropdown2"
                                     data-toggle="dropdown" aria-expanded="false">
                                        <span class="chart_right_label">Day 0 Installs</span>
                                        <span class="caret"></span>
                                    </div>
                                    <ul class="dropdown-menu chart_ul_right" aria-labelledby="exampleSizingDropdown2" role="menu">
                                        <li role="presentation" data-val="none" data-color="#4CAF50">
                                            <a href="javascript:void(0)" role="menuitem">
                                                <span class="status status-lg bg-grey-600 pull-left" style="margin-top: 4px;margin-right: 4px;"></span>
                                                None
                                                <i class="pull-right icon md-check md-check-i" aria-hidden="true" style="line-height:22px;"></i>
                                            </a>
                                        </li>
                                        <li role="presentation" data-val="results" data-color="#4CAF50" style="display:none">
                                            <a href="javascript:void(0)" role="menuitem">
                                                <span class="status status-lg bg-green-600 pull-left" style="margin-top: 4px;margin-right: 4px;"></span>
                                                Results
                                                <i class="pull-right icon md-check md-check-i" aria-hidden="true" style="line-height:22px;"></i>
                                            </a>
                                        </li>
                                        <li role="presentation" data-val="day0" class="active-check" data-color="#F44336">
                                            <a href="javascript:void(0)" role="menuitem">
                                                <span class="status status-lg bg-red-600 pull-left" style="margin-top: 4px;margin-right: 4px;"></span>
                                                Day 0 Installs
                                                <i class="pull-right icon md-check md-check-i" aria-hidden="true" style="line-height:22px;"></i>
                                            </a>
                                        </li>
                                        <?php if($this->userinfo['type']==0):?>
                                            <li role="presentation" data-val="earning" data-color="#2196F3">
                                                <a href="javascript:void(0)" role="menuitem">
                                                    <span class="status status-lg bg-blue-600 pull-left" style="margin-top: 4px;margin-right: 4px;"></span>
                                                    Earning
                                                    <i class="pull-right icon md-check md-check-i" aria-hidden="true" style="line-height:22px;"></i>
                                                </a>
                                            </li>
                                            <li role="presentation" data-val="real-earning" data-color="#9C27B0">
                                                <a href="javascript:void(0)" role="menuitem">
                                                    <span class="status status-lg bg-purple-600 pull-left" style="margin-top: 4px;margin-right: 4px;"></span>
                                                    Real Earning
                                                    <i class="pull-right icon md-check md-check-i" aria-hidden="true" style="line-height:22px;"></i>
                                                </a>
                                            </li>
                                        <?php endif;?>
                                        <li role="presentation" data-val="a-f" data-color="#FF9800">
                                            <a href="javascript:void(0)" role="menuitem">
                                                <span class="status status-lg bg-orange-600 pull-left" style="margin-top: 4px;margin-right: 4px;"></span>
                                                A / F
                                                <i class="pull-right icon md-check md-check-i" aria-hidden="true" style="line-height:22px;"></i>
                                            </a>
                                        </li>
                                        <?php if($this->userinfo['type']==0):?>
                                            <li role="presentation" data-val="roi" data-color="#795548">
                                                <a href="javascript:void(0)" role="menuitem">
                                                    <span class="status status-lg bg-brown-600 pull-left" style="margin-top: 4px;margin-right: 4px;"></span>
                                                    ROI
                                                    <i class="pull-right icon md-check md-check-i" aria-hidden="true" style="line-height:22px;"></i>
                                                </a>
                                            </li>
                                        <?php endif;?>
                                        <li role="presentation" data-val="cpi" data-color="#009688">
                                            <a href="javascript:void(0)" role="menuitem">
                                                <span class="status status-lg bg-teal-600 pull-left" style="margin-top: 4px;margin-right: 4px;"></span>
                                                CPI
                                                <i class="pull-right icon md-check md-check-i" aria-hidden="true" style="line-height:22px;"></i>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="btn-group pull-right margin-top-20" style="position:relative; z-index:10;">
                                    <div class="btn dropdown-toggle" id="exampleSizingDropdown2"
                                     data-toggle="dropdown" aria-expanded="false">
                                        <span class="chart_left_label">Results</span>
                                        <span class="caret"></span>
                                    </div>
                                    <ul class="dropdown-menu chart_ul_left" aria-labelledby="exampleSizingDropdown2" role="menu">
                                        <li role="presentation" data-val="none" data-color="#4CAF50">
                                            <a href="javascript:void(0)" role="menuitem">
                                                <span class="status status-lg bg-grey-600 pull-left" style="margin-top: 4px;margin-right: 4px;"></span>
                                                None
                                                <i class="pull-right icon md-check md-check-i" aria-hidden="true" style="line-height:22px;"></i>
                                            </a>
                                        </li>
                                        <li role="presentation" data-val="results" class="active-check"  data-color="#4CAF50">
                                            <a href="javascript:void(0)" role="menuitem">
                                                <span class="status status-lg bg-green-600 pull-left" style="margin-top: 4px;margin-right: 4px;"></span>
                                                Results
                                                <i class="pull-right icon md-check md-check-i" aria-hidden="true" style="line-height:22px;"></i>
                                            </a>
                                        </li>
                                        <li role="presentation" data-val="day0" data-color="#F44336" style="display:none">
                                            <a href="javascript:void(0)" role="menuitem">
                                                <span class="status status-lg bg-red-600 pull-left" style="margin-top: 4px;margin-right: 4px;"></span>
                                                Day 0 Installs
                                                <i class="pull-right icon md-check md-check-i" aria-hidden="true" style="line-height:22px;"></i>
                                            </a>
                                        </li>
                                        <?php if($this->userinfo['type']==0):?>
                                            <li role="presentation" data-val="earning" data-color="#2196F3">
                                                <a href="javascript:void(0)" role="menuitem">
                                                    <span class="status status-lg bg-blue-600 pull-left" style="margin-top: 4px;margin-right: 4px;"></span>
                                                    Earning
                                                    <i class="pull-right icon md-check md-check-i" aria-hidden="true" style="line-height:22px;"></i>
                                                </a>
                                            </li>
                                            <li role="presentation" data-val="real-earning" data-color="#9C27B0">
                                                <a href="javascript:void(0)" role="menuitem">
                                                    <span class="status status-lg bg-purple-600 pull-left" style="margin-top: 4px;margin-right: 4px;"></span>
                                                    Real Earning
                                                    <i class="pull-right icon md-check md-check-i" aria-hidden="true" style="line-height:22px;"></i>
                                                </a>
                                            </li>
                                        <?php endif;?>
                                        <li role="presentation" data-val="a-f" data-color="#FF9800">
                                            <a href="javascript:void(0)" role="menuitem">
                                                <span class="status status-lg bg-orange-600 pull-left" style="margin-top: 4px;margin-right: 4px;"></span>
                                                A / F
                                                <i class="pull-right icon md-check md-check-i" aria-hidden="true" style="line-height:22px;"></i>
                                            </a>
                                        </li>
                                        <?php if($this->userinfo['type']==0):?>
                                            <li role="presentation" data-val="roi" data-color="#795548">
                                                <a href="javascript:void(0)" role="menuitem">
                                                    <span class="status status-lg bg-brown-600 pull-left" style="margin-top: 4px;margin-right: 4px;"></span>
                                                    ROI
                                                    <i class="pull-right icon md-check md-check-i" aria-hidden="true" style="line-height:22px;"></i>
                                                </a>
                                            </li>
                                        <?php endif;?>
                                        <li role="presentation" data-val="cpi" data-color="#009688">
                                            <a href="javascript:void(0)" role="menuitem">
                                                <span class="status status-lg bg-teal-600 pull-left" style="margin-top: 4px;margin-right: 4px;"></span>
                                                CPI
                                                <i class="pull-right icon md-check md-check-i" aria-hidden="true" style="line-height:22px;"></i>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <!-- <div class='text-center report_loading' style="display:none;position: absolute;top: 50px;left: 50%;margin-left: -11px;"><div class='loader vertical-align-middle loader-ellipsis' data-type='ellipsis'></div></div> -->

                            <div id="report_double" style="height:230px;" data-date='<?php echo $chart_date?>' data-results='<?php echo $chart_results?>' data-real-earning='<?php echo $chart_real_earning?>' data-earning='<?php echo $chart_earning?>'  data-roi='<?php echo $chart_roi?>' data-cpi='<?php echo $chart_cpi?>' data-day0='<?php echo $chart_day0?>' data-a-f='<?php echo $chart_a_f?>'></div>
                        </div>
                    </div>
                </div>
            </div> 
        </div>  
        <!-- Panel Table Tools -->
        <div class="panel" style="box-shadow:none;border: 1px solid #e3eaec;">
            <header class="panel-heading clearfix">
                <h3 class="panel-title pull-left">Details</h3>
                <div class="pull-right col-md-6 margin-top-15 padding-right-30">
                    <button type="button" class="pull-right btn hover_btn btn-outline btn-default excel_report"><i class="icon md-download" aria-hidden="true"></i> Export</button>
                </div>
            </header>
            <div class="panel-body">
                <div class="table-responsive">
                    <div class='text-center report_loading' style="display:none;position: fixed;top: 50%;left: 50%;margin-left: -11px;"><div class='loader vertical-align-middle loader-ellipsis' data-type='ellipsis'></div></div>

                    <table class="table dataTable table-striped width-full" id="facebook_report">
                        <thead class="thead" id="thead">
                            <?php if($data):?>
                            <tr class="change_thead">
                                
                                <th>Date</th>
                                <?php 
                                    if ($this->input->get('publisher')) {
                                        echo "<th>Publisher</th>";
                                    }elseif ($this->input->get('agency')) {
                                        echo "<th>Agency</th>";
                                    }
                                ?>

                                <?php if($this->userinfo['type']=='0'):?>
                                    <th>Media Buy Earning</th>
                                    <th>Real MB Earning</th>
                                    <th>Media Buy Profit</th>
                                    <!-- <th>Real Profit</th> -->
                                <?php endif;?>

                                <?php if($this->userinfo['type']=='2'):?>
                                    <th>Clicks(All)</th>
                                <?php endif;?>
                                <th>Results</th>
                                <?php if($this->userinfo['type']=='1'):?>
                                    <th>Amount Cost</th>
                                <?php endif;?>
                            </tr>
                            <?php else:?>
                                <tr>
                                    <td class="text-center"> No Data</td>
                                </tr>
                            <?php endif;?>

                        </thead>
                        <tbody class="tbody">
                            <?php for($i=1; $i<=$days; $i++):?>
                                <tr>
                                    <td><?php echo date('Y-m-d', strtotime("-".$i." day"))?></td>
                                    <td>-</td>
                                    <td>-</td>
                                    <?php if($this->userinfo['type']=='0'):?>
                                        <td>-</td>
                                        <td>-</td>
                                        <td>-</td>
                                    <?php endif;?>
                                    
                                </tr>
                            <?php endfor;?>
                            
                            <?php foreach($data as $item):?>

                                <tr class="gradeA">
                                    <td><?php echo $item['date']?></td>
                                    <?php 
                                        if ($this->input->get('publisher')) {
                                            echo "<td>".$item['publisher_name']."</td>";
                                        }elseif ($this->input->get('agency')) {
                                            echo "<td>".$item['publisher_name']."</td>";
                                        }
                                    ?>
                                    <?php if($this->userinfo['type']=='0'):?>
                                        
                                        <td><?php echo "$".number_format(sprintf("%.2f", $item['expect_revenue']), 2)?></td>
                                        <td><?php echo $item['real_earning']>0?"$".number_format(sprintf("%.2f", $item['real_earning']),2):"-"?></td>
                                        <!-- <?php if(isset($retentions[$item['date']])):?>
                                            <td><?php echo "$".sprintf("%.2f", $item['real_earning'])?></td>
                                        <?php else:?>
                                            <td>-</td>
                                        <?php endif;?> -->

                                        <td><?php echo "$".number_format(sprintf("%.2f", ($item['expect_revenue']-$item['spend'])),2)?></td>
                                        <!-- <td><?php echo $item['real_earning']>0?"$".sprintf("%.2f", ($item['real_earning']-$item['spend'])):'-'?></td> -->
                                        <!-- <?php if(isset($retentions[$item['date']])):?>
                                            <td><?php echo "$".sprintf("%.2f", ($item['real_earning']-$item['spend']))?></td>
                                        <?php else:?>
                                            <td>-</td>
                                        <?php endif;?> -->
                                    <?php endif;?>

                                    <?php if($this->userinfo['type']=='2'):?>
                                        <td><?php echo number_format($item['clicks'])?></td>
                                    <?php endif;?>
                                    <td><?php echo number_format($item['results'])?></td>
                                    <?php if($this->userinfo['type']=='1'):?>
                                        <td><?php echo "$".number_format(sprintf("%.2f", $item['amount_cost']),2)?></td>
                                    <?php endif;?>
                                </tr>
                            <?php endforeach;?>
                            
                        </tbody>
                    </table>
                </div>
                <div class="fixed-table-pagination clearfix">
                    <div class="pull-right pagination reports_page_links">
                    </div>
                </div> 
            </div> 
        </div>
        
        <!-- End Panel Table Tools -->
    </div>
</div>
<div id="child_chart" data-results="{}" data-day0="{}"></div>
<script src="<?php echo base_url();?>assets/web/global/vendor/datatables/jquery.dataTables.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/datatables-fixedheader/dataTables.fixedHeader.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/datatables-bootstrap/dataTables.bootstrap.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/datatables-responsive/dataTables.responsive.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/datatables-tabletools/dataTables.tableTools.js"></script>

  <script src="<?php echo base_url();?>assets/web/global/js/components/datatables.js"></script>
  <script src="<?php echo base_url();?>assets/web/assets/examples/js/tables/datatable.js"></script>
  <script src="<?php echo base_url();?>assets/web/assets/examples/js/uikit/icon.js"></script>
  <script src="<?php echo base_url();?>assets/js/index_select.js"></script>

<script src="<?php echo base_url();?>assets/web/global/js/components/masonry.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/bootstrap-hover-dropdown/bootstrap-hover-dropdown.min.js"></script>

<script src="<?php echo base_url();?>assets/web/global/js/components/asscrollable.js"></script>
<script src="<?php echo base_url();?>assets/web/assets/examples/js/advanced/scrollable.js"></script> 
<script type="text/javascript" src="<?php echo base_url();?>assets/js/echart/echarts-all-3.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/echart/dataTool.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/echart/china.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/echart/world.js"></script>
<!-- <script type="text/javascript" src="http://api.map.baidu.com/api?v=2.0&ak=ZUONbpqGBsYGXNIYHicvbAbM"></script> -->
<script type="text/javascript" src="<?php echo base_url();?>assets/js/echart/bmap.min.js"></script>
<script src="<?php echo base_url();?>assets/js/report_double.js"></script>

<script src="<?php echo base_url();?>assets/js/jquery.tabletoCSV.js" type="text/javascript" charset="utf-8"></script>
<script src="<?php echo base_url();?>assets/js/jquery.tablesorter.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/moment.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/daterangepicker.js"></script>
<script src="<?php echo base_url();?>assets/js/jquery.daterange.js"></script>
<script src="<?php echo base_url();?>assets/js/reports.js"></script>
<script>

    //filter js
    $('.toggle_input').change(function(){
        $('.save_name_input').toggle();
    });
   
    

    $('.filter_block').click(function(){
        $('.filter_div').css('display','block');
    });

    $('.filter_cannel').click(function(){
        $('.filter_div').css('display','none');
    });

    //column js
    $('.column_toggle_input').click(function(){
        $('.column_save_name_input').toggle();
    });

    $('.column_block').click(function(){
        $('.column_div').css('max-height','424px');
    });

    $('.column_cannel').click(function(){
        $('.column_div').css('max-height','0px');
    });

    //显示隐藏
    $(".toggle_btn").click(function(){
        $(this).parents("tr").next("tr").toggle();
         var oFalse = $(this).attr("data-term");
        $(this).attr("data-term",oFalse);
        $(this).attr("data-term") == "false" ? $(this).attr("data-term","true"): $(this).attr("data-term","false");
        $(this).attr('src',$(this).attr('data-click'));
        
        if($(this).attr("data-term") == "true"){
           $(this).attr('src',$(this).attr('data-click'));
           $(this).parents("tr").next("tr").css('height','150px');
        }else{
            $(this).attr('src',$(this).attr('data-base'));
            $(this).parents("tr").next("tr").css('height',0);
        } 
    });
    

</script>



