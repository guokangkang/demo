<!DOCTYPE html>
<html class="no-js css-menubar" lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
<meta name="description" content="bootstrap admin template">
<meta name="author" content="">
<title><?php echo $publisher_info['user_name']." Daily Reports"?></title>
<link rel="apple-touch-icon" href="<?php echo base_url();?>assets/web/assets/images/apple-touch-icon.png">
<link rel="shortcut icon" href="<?php echo base_url();?>assets/web/assets/images/favicon.ico">
<!-- Stylesheets -->
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/css/bootstrap-extend.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/assets/css/site.min.css">
<!-- Plugins -->
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/animsition/animsition.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/asscrollable/asScrollable.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/switchery/switchery.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/intro-js/introjs.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/slidepanel/slidePanel.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/flag-icon-css/flag-icon.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/advertiser_daily.css">
<!-- 新加css -->
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/datatables-bootstrap/dataTables.bootstrap.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/datatables-fixedheader/dataTables.fixedHeader.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/datatables-responsive/dataTables.responsive.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/assets/examples/css/tables/datatable.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/fonts/font-awesome/font-awesome.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/select2/select2.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/bootstrap-datepicker/bootstrap-datepicker.css">
<link href="http://vjs.zencdn.net/5.11.6/video-js.css" rel="stylesheet"> 
<!-- Fonts -->
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/fonts/web-icons/web-icons.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/fonts/brand-icons/brand-icons.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/fonts/web-icons/web-icons.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/fonts/font-awesome/font-awesome.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/fonts/brand-icons/brand-icons.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/fonts/brand-icons/brand-icons.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/fonts/google/fonts.css">
<style>
    .table-bordered>thead:first-child>tr:first-child>th{border: 0;}
    .table>tbody>tr>td{vertical-align: middle; border-top: 0;}
    .table-striped>tbody>tr:nth-of-type(odd){
        background-color: rgba(247,252,255,1);
    }
    .special_table>tbody>tr>td{
        padding: 0;
    }
    .video-js .vjs-big-play-button{
            font-size: 40px;
            line-height: 50px;
            height: 50px;
            width: 50px;
            margin-left: -25px;
            margin-top: -25px;
            border-radius: 50%;
            position: absolute;
            left: 50%;
            top: 50%;
            background: #c73434;
            border: none;
    }
    .video-js:hover .vjs-big-play-button{background-color: #b90606;}
    .btn-group.open .dropdown-toggle,.btn-group.open .dropdown-toggle{box-shadow:none;}

</style>
<!--[if lt IE 9]>
  <script src="<?php echo base_url();?>assets/web/global/vendor/html5shiv/html5shiv.min.js"></script>
  <![endif]-->
<!--[if lt IE 10]>
  <script src="<?php echo base_url();?>assets/web/global/vendor/media-match/media.match.min.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/respond/respond.min.js"></script>
  <![endif]-->
<!-- Scripts -->
<script src="<?php echo base_url();?>assets/web/global/vendor/modernizr/modernizr.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/breakpoints/breakpoints.js"></script>
<script>
Breakpoints();
</script>
</head>
<body class="site-navbar-small padding-top-0">
<!--[if lt IE 8]>
    <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
<![endif]-->
<div style="height:200px; background:#26bfd6; width:100%; overflow:hidden;">
    <div style="width:74%; height:110px; margin:52px auto 0;position: relative;">
        <h3 class="margin-top-0" style="font-size:40px;color:#fff;"><?php echo $publisher_info['user_name']?></h3>
        <p style="color: #fff;font-size: 92px;font-weight: bold; opacity: 0.1;position: absolute;left: 42px;top: -15px;letter-spacing: 6px;">DAILY</p>
        <p class="text-center" style="position: absolute;right:0;bottom:0;">
            <span class="block" style="color:#fff;">海外推广管理日报</span>
            <a href="#" class="block" style="color:#fff;text-decoration:none;">&copy; PALMAX LIMITED</a>
        </p>
    </div>
</div>
<div style="height:84px; background:#004753; width:100%; overflow:hidden;">
    <div style="width:74%; margin:0 auto;">
        <!-- <p class="pull-right margin-0 padding-right-10" style="color:#fff; line-height:84px;">2016/09/16</p> -->
        <div class="filter">
            <div class="dropdown pull-right" style="line-height: 84px;">
                <button type="button" id="input_date" class="btn btn-pure" style="color:#fff;">
                    <?php echo date('d M Y', $current_date)?>
                    <span class="icon wb-chevron-down-mini" aria-hidden="true"></span>
                </button>
            </div>
        </div>
    </div>
</div>
<!-- Page -->
<div class="page animsition">
    <div class="page-content padding-top-0"> 
        <div class="panel">
            <div class="panel-body container-fluid" style=" padding-bottom: 0; padding-top:66px;">
                <div class="row">
                    
                    <!-- 第三个表格 -->
                    <div class="col-md-12">
                        <h4 class="example-title margin-bottom-0" style="padding-left:66px; font-size:24px;">1.基础数据</h4>

                        <div class="col-md-10 col-md-offset-1 margin-bottom-10">
                            <h4 class="margin-bottom-10 margin-top-15">①七日产品数据波形图</h4>
                            <p class="text-center font-size-12" style="width:200px;height:46px;background:#005f6b;padding-top:4px;color:#fff;margin-bottom: -61px;margin-left: 59px;"><?php echo date('d/m', $current_7date)?> - <?php echo date('d/m',$current_date)?><br/>转化总量走势图</p>
                            <div style="position:absolute;right:25px;z-index:10;">
                                <!-- 第一个过滤 -->
                                <div class="btn-group pull-right margin-top-20 margin-right-10">
                                    <div class="btn dropdown-toggle" id="exampleSizingDropdown2" data-toggle="dropdown" aria-expanded="false">
                                        <span class="chart_right_label">Results</span>
                                        <span class="caret"></span>
                                    </div>
                                    <ul class="dropdown-menu chart_ul_right" aria-labelledby="exampleSizingDropdown2" role="menu">
                                        
                                        <li role="presentation" data-val="results" data-color="#4CAF50">
                                            <a href="javascript:void(0)" role="menuitem">
                                                <span class="status status-lg bg-green-600 pull-left" style="margin-top: 4px;margin-right: 4px;"></span>
                                                Results
                                                <i class="pull-right icon md-check md-check-i" aria-hidden="true" style="line-height:22px;"></i>
                                            </a>
                                        </li>
                                        <li role="presentation" data-val="day0" class="active-check" data-color="#F44336">
                                            <a href="javascript:void(0)" role="menuitem">
                                                <span class="status status-lg bg-red-600 pull-left" style="margin-top: 4px;margin-right: 4px;"></span>
                                                Day 0 Installs
                                                <i class="pull-right icon md-check md-check-i" aria-hidden="true" style="line-height:22px;"></i>
                                            </a>
                                        </li>
                                        <li role="presentation" data-val="spend" data-color="#E91E63">
                                            <a href="javascript:void(0)" role="menuitem">
                                                <span class="status status-lg bg-pink-600 pull-left" style="margin-top: 4px;margin-right: 4px;"></span>
                                                Spend
                                                <i class="pull-right icon md-check md-check-i" aria-hidden="true" style="line-height:22px;"></i>
                                            </a>
                                        </li>
                                        <li role="presentation" data-val="earning" data-color="#2196F3">
                                            <a href="javascript:void(0)" role="menuitem">
                                                <span class="status status-lg bg-blue-600 pull-left" style="margin-top: 4px;margin-right: 4px;"></span>
                                                Earning
                                                <i class="pull-right icon md-check md-check-i" aria-hidden="true" style="line-height:22px;"></i>
                                            </a>
                                        </li>
                                        <li role="presentation" data-val="real_earning" data-color="#9C27B0">
                                            <a href="javascript:void(0)" role="menuitem">
                                                <span class="status status-lg bg-purple-600 pull-left" style="margin-top: 4px;margin-right: 4px;"></span>
                                                Real Earning
                                                <i class="pull-right icon md-check md-check-i" aria-hidden="true" style="line-height:22px;"></i>
                                            </a>
                                        </li>
                                        <li role="presentation" data-val="a_f" data-color="#FF9800">
                                            <a href="javascript:void(0)" role="menuitem">
                                                <span class="status status-lg bg-orange-600 pull-left" style="margin-top: 4px;margin-right: 4px;"></span>
                                                A / F
                                                <i class="pull-right icon md-check md-check-i" aria-hidden="true" style="line-height:22px;"></i>
                                            </a>
                                        </li>
                                        <li role="presentation" data-val="roi" data-color="#795548">
                                            <a href="javascript:void(0)" role="menuitem">
                                                <span class="status status-lg bg-brown-600 pull-left" style="margin-top: 4px;margin-right: 4px;"></span>
                                                ROI
                                                <i class="pull-right icon md-check md-check-i" aria-hidden="true" style="line-height:22px;"></i>
                                            </a>
                                        </li>
                                        <li role="presentation" data-val="cpi" data-color="#009688">
                                            <a href="javascript:void(0)" role="menuitem">
                                                <span class="status status-lg bg-teal-600 pull-left" style="margin-top: 4px;margin-right: 4px;"></span>
                                                CPI
                                                <i class="pull-right icon md-check md-check-i" aria-hidden="true" style="line-height:22px;"></i>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div id="data1" style="height:300px;" data-product='<?php echo $data1['product']?>' data-day0='<?php echo $data1['day0']?>' data-day1='<?php echo $data1['day1']?>' data-spend='<?php echo $data1['spend']?>' data-date='<?php echo $data1['date']?>' data-results='<?php echo $data1['results']?>' data-real_earning='<?php echo $data1['real_earning']?>' data-earning='<?php echo $data1['earning']?>'  data-roi='<?php echo $data1['roi']?>' data-cpi='<?php echo $data1['cpi']?>' data-a_f='<?php echo $data1['a_f']?>'></div>
                        </div>
                        

                        <div class="col-md-10 col-md-offset-1">
                            <div class="example-wrap" style="margin-bottom:50px;"> 
                                <h4 class="example-title font-size-12" style="padding-left:40px;">当日产品数据详情</h4>
                                <div class="example table-responsive margin-bottom-10" style="box-shadow:0 3px 8px 0 #f1f6f7;">
                                    <table class="table text-center dataTable table-striped width-full ">
                                        <thead class="thead" id="thead">
                                            <tr style="background:#00b1c9;">
                                                <th class="text-center" style="color:#fff;">Product</th>
                                                <th class="text-center" style="color:#fff;">Results</th>
                                                <th class="text-center" style="color:#fff;">Day0 Installs</th>
                                                <th class="text-center" style="color:#fff;">Spend</th>
                                                <th class="text-center" style="color:#fff;">Earning</th>
                                                <th class="text-center" style="color:#fff;">Real Earning</th>
                                                <th class="text-center" style="color:#fff;">CPI</th>
                                                <th class="text-center" style="color:#fff;">ROI</th>
                                            </tr>
                                        </thead>
                                        <tbody class="tbody">
                                            <?php foreach($data1_list as $item):?>
                                            <tr>
                                                
                                                    <td><?php echo $item['product_name']?></td>
                                                    <td><?php echo number_format($item['results'])?></td>
                                                    <td><?php echo number_format($item['day0'])?></td>
                                                    <td>$<?php echo number_format($item['spend'], 2)?></td>
                                                    <td>$<?php echo number_format($item['earning'], 2)?></td>
                                                    <td style="color:<?php echo $item['real_earning']>0?'#4CAF50':'#F44336'?>">$<?php echo number_format($item['real_earning'], 2)?></td>
                                                    <td>$<?php echo number_format($item['cpi'], 2)?></td>
                                                    <td style="color:<?php echo $item['roi']>0?'#4CAF50':'#F44336'?>"><?php echo $item['roi']?>%</td>
                                                
                                            </tr>
                                            <?php endforeach;?>
                                        </tbody>
                                    </table>                                   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>   
    </div>
</div>
  
<!-- Footer -->
<footer class="site-footer">
    <div class="site-footer-legal"><a href="http://marketmax.palmax.com">Palmax AdDigger Build 2016</a></div>
    <div class="site-footer-right">
        © 2015 - 2016, Palmax Limited, All rights reserved.
    </div>
</footer>
 <script type="text/javascript">
 var base_url = "<?php echo base_url()?>";
 var site_url = "<?php echo site_url()?>";
</script>
<!-- Core  -->
<script src="<?php echo base_url();?>assets/web/global/vendor/jquery/jquery.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/bootstrap/bootstrap.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/animsition/animsition.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/asscroll/jquery-asScroll.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/mousewheel/jquery.mousewheel.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/asscrollable/jquery.asScrollable.all.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/ashoverscroll/jquery-asHoverScroll.js"></script>
<!-- Plugins -->
<script src="<?php echo base_url();?>assets/web/global/vendor/switchery/switchery.min.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/intro-js/intro.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/screenfull/screenfull.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/slidepanel/jquery-slidePanel.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/asrange/jquery-asRange.min.js"></script>
<!-- 新加js -->
<script src="<?php echo base_url();?>assets/web/global/vendor/datatables/jquery.dataTables.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/datatables-bootstrap/dataTables.bootstrap.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/datatables-responsive/dataTables.responsive.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/datatables-tabletools/dataTables.tableTools.js"></script>
<!-- Scripts -->
<script src="<?php echo base_url();?>assets/web/global/js/core.js"></script>
<script src="<?php echo base_url();?>assets/web/assets/js/site.js"></script>
<script src="<?php echo base_url();?>assets/web/assets/js/sections/menu.js"></script>
<script src="<?php echo base_url();?>assets/web/assets/js/sections/menubar.js"></script>
<script src="<?php echo base_url();?>assets/web/assets/js/sections/sidebar.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/configs/config-colors.js"></script>
<script src="<?php echo base_url();?>assets/web/assets/js/configs/config-tour.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/components/asscrollable.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/components/animsition.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/components/slidepanel.js"></script>
<script type="text/javascript" src="http://echarts.baidu.com/gallery/vendors/echarts/echarts-all-3.js"></script>
<script type="text/javascript" src="http://echarts.baidu.com/gallery/vendors/echarts/extension/dataTool.min.js"></script>
<script type="text/javascript" src="http://echarts.baidu.com/gallery/vendors/echarts/map/js/china.js"></script>
<script type="text/javascript" src="http://echarts.baidu.com/gallery/vendors/echarts/map/js/world.js"></script>
<script type="text/javascript" src="http://api.map.baidu.com/api?v=2.0&ak=ZUONbpqGBsYGXNIYHicvbAbM"></script>
<script type="text/javascript" src="http://echarts.baidu.com/gallery/vendors/echarts/extension/bmap.min.js"></script>
<!-- 新加js -->
<script src="<?php echo base_url();?>assets/web/global/js/components/datatables.js"></script>
<script src="<?php echo base_url();?>assets/web/assets/examples/js/tables/datatable.js"></script>
<script src="<?php echo base_url();?>assets/js/publisher_daily.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/select2/select2.min.js"></script>  
<script src="<?php echo base_url();?>assets/web/global/js/components/select2.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/bootstrap-datepicker/bootstrap-datepicker.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/components/bootstrap-datepicker.js"></script>
<!-- If you'd like to support IE8 -->
<script src="http://vjs.zencdn.net/ie8/1.1.2/videojs-ie8.min.js"></script>
<script src="http://vjs.zencdn.net/5.11.6/video.js"></script>
<script>
    $(function() {
        function getLocalTime(nS) {     
            return new Date(parseInt(nS)).toLocaleString().substr(0,17);
        } 

        $('#input_date').datepicker({
            format: "dd MM yyyy",
            viewMode: "months", 
            minViewMode: 0
        }).datepicker("setDate", "<?php echo date('d M Y', $current_date)?>")
        .on('changeDate', function (ev) {
            var date = ev.date.valueOf();

            var newDate = new Date();
            newDate.setTime(date);

            date = newDate.toLocaleDateString()
            date = date.replace(/\//gm,'-');;

            location.href = site_url + "publisher/daily?publisher=<?php echo $publisher_info['user_id']?>&date="+date;
        }).val();

     }); 
</script>
</body>
</html>