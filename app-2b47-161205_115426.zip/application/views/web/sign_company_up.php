<!DOCTYPE html>
<html class="no-js css-menubar" lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
  <meta name="description" content="bootstrap admin template">
  <meta name="author" content="">
  <title><?php echo $title?></title>
  <link rel="apple-touch-icon" href="<?php echo base_url();?>assets/web/assets/images/apple-touch-icon.png">
  <link rel="shortcut icon" href="<?php echo base_url();?>assets/web/assets/images/favicon.ico">
  <!-- Stylesheets -->
  <link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/css/bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/css/bootstrap-extend.min.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/web/assets/css/site.min.css">
  <!-- Plugins -->
  <link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/animsition/animsition.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/asscrollable/asScrollable.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/switchery/switchery.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/intro-js/introjs.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/slidepanel/slidePanel.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/flag-icon-css/flag-icon.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/web/assets/examples/css/pages/register-v2.css">
  <!-- Fonts -->
  <link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/fonts/web-icons/web-icons.min.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/fonts/brand-icons/brand-icons.min.css">
  <link rel='stylesheet' href='http://fonts.googleapis.com/css?family=Roboto:300,400,500,300italic'>
  <!--[if lt IE 9]>
    <script src="<?php echo base_url();?>assets/web/global/vendor/html5shiv/html5shiv.min.js"></script>
    <![endif]-->
  <!--[if lt IE 10]>
    <script src="<?php echo base_url();?>assets/web/global/vendor/media-match/media.match.min.js"></script>
    <script src="<?php echo base_url();?>assets/web/global/vendor/respond/respond.min.js"></script>
    <![endif]-->
  <!-- Scripts -->
  <script src="<?php echo base_url();?>assets/web/global/vendor/modernizr/modernizr.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/breakpoints/breakpoints.js"></script>
  <script>
  Breakpoints();
  </script>
</head>
<body class="page-register-v2 layout-full page-dark">
  <!--[if lt IE 8]>
        <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
    <![endif]-->
  <!-- Page -->
  <div class="page animsition" data-animsition-in="fade-in" data-animsition-out="fade-out">
    <div class="page-content">
      <div class="page-brand-info">
        <div class="brand">
          <img class="brand-img" src="<?php echo base_url();?>assets/images/marketmax-white.png" alt="...">
          <h2 class="brand-text font-size-40">MarketMax</h2>
        </div>
        <p class="font-size-20">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
          tempor incididunt ut labore et dolore magna aliqua.</p>
      </div>
      <div class="page-register-main">
        <div class="brand visible-xs">
          <img class="brand-img" src="<?php echo base_url();?>assets/images/marketmax-black.png" alt="...">
          <h3 class="brand-text font-size-40">MarketMax</h3>
        </div>
        <h3 class="font-size-24">Company Sign Up</h3>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
        <form method="post" action="<?php echo site_url('sign/form_company_up_action')?>" id="signUpForm">
            <div class="form-group form-material floating">
              <input type="text" class="form-control" name="input_account" value="<?php echo $this->uri->segment(3)?>" />
              <label class="floating-label">Account</label>
            </div>

            <div class="form-group form-material floating">
              <input type="text" class="form-control" name="input_first" />
              <label class="floating-label">First Name</label>
            </div>
            <div class="form-group form-material floating">
              <input type="text" class="form-control" name="input_last" />
              <label class="floating-label">Last Name</label>
            </div>
            
            <div class="form-group form-material floating">
              <input type="text" class="form-control" name="input_email" />
              <label class="floating-label">Email</label>
            </div>
            
            <div class="form-group form-material floating">
              <input type="password" class="form-control" name="input_password" data-fv-notempty="true"
                            data-fv-notempty-message="The password is required and cannot be empty"
                            data-fv-identical="true" data-fv-identical-field="input_PasswordCheck"
                            data-fv-identical-message="The password and re-enter password are not the same" data-fv-stringlength="true"
                        data-fv-stringlength-min="6" 
                        data-fv-stringlength-message="Please enter more than 6 length"/>
              <label class="floating-label">Password</label>
            </div>
            <div class="form-group form-material floating">
              <input type="password" class="form-control" name="input_PasswordCheck" id="input_password" data-fv-notempty="true"
                            data-fv-notempty-message="The confirm password is required and cannot be empty"
                            data-fv-identical="true" data-fv-identical-field="input_password"
                            data-fv-identical-message="The password and re-enter password are not the same" data-fv-stringlength="true"
                        data-fv-stringlength-min="6" 
                        data-fv-stringlength-message="Please enter more than 6 length"/>
              <label class="floating-label">Re-enter Password</label>
            </div>
            <small class="help-block sign_error" style="color: #f96868"><?php echo get_cookie('sign_up_error')?></small>
            <button id="signUpButton" type="submit" class="btn btn-primary btn-block btn-lg margin-top-40">Sign up</button>
          </form>
        <p>Have account already? Please go to <a href="<?php echo site_url('sign/company_in/'.$this->uri->segment(3))?>">Sign In</a></p>
        <footer class="page-copyright">
          <p>WEBSITE BY amazingSurge</p>
          <p>© 2016. All RIGHT RESERVED.</p>
        </footer>
      </div>
    </div>
  </div>
  <!-- End Page -->
  <!-- Core  -->
  <script src="<?php echo base_url();?>assets/web/global/vendor/jquery/jquery.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/bootstrap/bootstrap.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/animsition/animsition.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/asscroll/jquery-asScroll.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/mousewheel/jquery.mousewheel.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/asscrollable/jquery.asScrollable.all.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/ashoverscroll/jquery-asHoverScroll.js"></script>
  <!-- Plugins -->
  <script src="<?php echo base_url();?>assets/web/global/vendor/switchery/switchery.min.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/intro-js/intro.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/screenfull/screenfull.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/slidepanel/jquery-slidePanel.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/jquery-placeholder/jquery.placeholder.js"></script>
  <!-- Scripts -->
  <script src="<?php echo base_url();?>assets/web/global/js/core.js"></script>
  <script src="<?php echo base_url();?>assets/web/assets/js/site.js"></script>
  <script src="<?php echo base_url();?>assets/web/assets/js/sections/menu.js"></script>
  <script src="<?php echo base_url();?>assets/web/assets/js/sections/menubar.js"></script>
  <script src="<?php echo base_url();?>assets/web/assets/js/sections/sidebar.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/js/configs/config-colors.js"></script>
  <script src="<?php echo base_url();?>assets/web/assets/js/configs/config-tour.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/js/components/asscrollable.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/js/components/animsition.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/js/components/slidepanel.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/js/components/switchery.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/js/components/jquery-placeholder.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/js/components/animate-list.js"></script>

  <script src="<?php echo base_url();?>assets/web/global/vendor/formvalidation/formValidation.min.js"></script>
     <script src="<?php echo base_url();?>assets/web/global/vendor/formvalidation/framework/bootstrap.min.js"></script>
   <script src="<?php echo base_url();?>assets/web/assets/examples/js/forms/validation.js"></script>

  <script>
  (function(document, window, $) {
    'use strict';
    var Site = window.Site;
    $(document).ready(function() {
      Site.run();
    });
  })(document, window, jQuery);
  </script>
</body>
</html>