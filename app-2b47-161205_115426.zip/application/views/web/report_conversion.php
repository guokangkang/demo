<!-- 新加css -->
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/datatables-bootstrap/dataTables.bootstrap.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/ web/global/vendor/bootstrap-datepicker/bootstrap-datepicker.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/datatables-fixedheader/dataTables.fixedHeader.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/datatables-responsive/dataTables.responsive.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/assets/examples/css/tables/datatable.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/select2/select2.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/bootstrap-select/bootstrap-select.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/fonts/material-design/material-design.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/assets/examples/css/uikit/icon.css">

<style>
   @media (min-width: 768px){
    .form-inline .form-control{width: 100%;}
   }
   .table>tbody>tr>td{vertical-align: middle;}
   .bootstrap-select:not([class*="col-"]):not([class*="form-control"]):not(.input-group-btn) {
        width: 110px;
    }
    .table>thead>tr>th{border-bottom:0;}
    .table>tbody>tr>td{vertical-align: middle;border-top: 0; border-bottom: 1px solid #edefee;} 
</style>


<div class="page animsition">
    <div class="page-header">
        <ol class="breadcrumb">
            <li><a href="<?php echo site_url('report/index');?>">Report</a></li>
            <li class="active">Conversion</li>
        </ol>
    </div>
    <div class="page-content"> 
        <div class="row">
            <div class="clearfix visible-md-block visible-lg-block"></div>
            <div class="col-md-12">
                <div class="panel is-collapse" style="box-shadow:none;border: 1px solid #e3eaec;">
                    <div class="panel-heading">
                        <h3 class="panel-title">Filter</h3>
                        <div class="panel-actions">
                            <a class="panel-action icon wb-plus" data-toggle="panel-collapse" aria-hidden="true"></a>
                        </div>
                    </div>
                    <div class="panel-body">
                        <div class="example table-responsive" style="margin-bottom: 0; margin-top: 0;">
                            <form>
                            <div class="col-md-4">
                                <div class="example-wrap margin-bottom-30">
                                    <div class="example">
                                            <div class="form-group filter-form advertiser-filter" style="margin-bottom:15px;padding-left: 0;">
                                                <select class="form-control select2-hidden-accessible" multiple="" data-plugin="select2" tabindex="-1" aria-hidden="true" data-placeholder="Data">
                                                    <option value="product_name">Product Name</option>
                                                    <option value="product_id">Product Id</option>
                                                    <option value="offer_id">Offer</option>
                                                    <option value="country">Country</option>
                                                    <option value="account_id">Account</option>
                                                    <option value="campaign_id">Campaign ID(Name)</option>
                                                    <option value="advertiser_id">Advertiser Name</option>
                                                    <option value="advertiser_name">Ad Set ID(Name)</option>
                                                </select>
                                            </div>

                                            <div class="form-group filter-form advertiser-filter" style="margin-bottom:15px;padding-left: 0;">
                                                <select class="form-control select2-hidden-accessible filter_publisher" multiple="" data-plugin="select2" tabindex="-1" aria-hidden="true" data-placeholder="Calculations">
                                                    <option value="ctr_all">CTR(All)</option>
                                                    <option value="ctr_link">CTR(Link)</option>
                                                    <option value="cvr_all">CVR(All)</option>
                                                    <option value="cvr_link">CVR(Link)</option>
                                                    <option value="cpc_all)">CPC(All)</option>
                                                    <option value="cpc_link">CPC(Link)</option>
                                                    <option value="cpm">CPM</option>
                                                </select>
                                            </div>
                                            
                                            <div class="form-group filter-form advertiser-filter" style="margin-bottom:15px;padding-left: 0;">
                                                <select class="form-control select2-hidden-accessible filter_publisher" multiple="" data-plugin="select2" tabindex="-1" aria-hidden="true" data-placeholder="Interval">
                                                    <option value="offer">Offer</option>
                                                    <option value="NV">Account ID(NAME)</option>
                                                    <option value="OR">Advertiser</option>
                                                    <option value="WA">Product</option>
                                                    <option value="WA">Countries </option>
                                                </select>
                                            </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-4">
                                <div class="example-wrap margin-bottom-30">
                                    <div class="example">
                                        <div class="form-group filter-form advertiser-filter" style="margin-bottom:15px;padding-left: 0;">
                                            <select class="form-control select2-hidden-accessible filter_publisher" multiple="" data-plugin="select2" tabindex="-1" aria-hidden="true" data-placeholder="Statistics">
                                                <option value="impressions">Impressions</option>
                                                <option value="clicks">Clicks(All)</option>
                                                <option value="clicks_link">Clicks(Link)</option>
                                                <option value="results">Results</option>
                                                <option value="epa">EPA(earning per action)</option>
                                                <option value="facebook_cpi">Facebook CPI</option>
                                                <option value="spend">Amount Spent</option>
                                                <option value="anticipated_income">Earning</option>
                                                <option value="revenue">Real Earning</option>
                                                <option value="profit">Profit</option>
                                                <option value="real_profit">Real Profit</option>
                                            </select>
                                        </div>
                                            <div class="form-group filter-form advertiser-filter" style="margin-bottom:15px;padding-left: 0;">
                                                <select class="form-control select2-hidden-accessible filter_publisher" multiple="" data-plugin="select2" tabindex="-1" aria-hidden="true" data-placeholder="Interval">
                                                    <option value="year">Year</option>
                                                    <option value="month">Month</option>
                                                    <option value="date">Date</option>
                                                </select>
                                            </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-1 text-center">
                                <span class="inline-block margin-top-20" style="width:1px; height:180px; border-right:1px dashed #d1d1d1;"></span>
                            </div>
                            <div class="col-md-3">
                                <div class="example-wrap margin-bottom-30">
                                    <div class="example">
                                        <form>  
                                            <div class="form-group col-lg-3 col-xlg-3 filter-form account-filter" style="margin-bottom:15px;padding-left: 0;text-align: center;">
                                                <div class="form-control" style="width: 225px;">
                                                    <div id="reportrange" class="pull-right">
                                                        <i class="glyphicon glyphicon-calendar fa fa-calendar"></i>&nbsp;
                                                        <span>08/07/2016 - 08/10/2016</span> <b class="caret"></b>

                                                        <input type="hidden" value="" class="date_start" />
                                                        <input type="hidden" value="" class="date_end" />
                                                    </div>
                                                </div>
                                            </div> 
                                        </form>
                                    </div>
                                </div>
                            </div>
                            </form>
                        </div>   
                        <a  id="ad_list" name="ad_list"></a>                         
                        <div class="example example-buttons text-center margin-vertical-0">
                            <button type="button" class="btn btn-outline btn-primary review_search">Search</button>
                            <button type="button" class="btn btn-outline btn-info review_rest">Reset</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>  
        <!-- Panel Table Tools -->
        <div class="panel" style="box-shadow:none;border: 1px solid #e3eaec;">
            <header class="panel-heading clearfix">
                <h3 class="panel-title pull-left">Details</h3>
                <div class="pull-right col-md-6 margin-top-15 padding-right-30">
                    <button type="button" class="pull-right btn btn-outline btn-default"><i class="icon md-download" aria-hidden="true"></i> Export</button>
                    <div class="pull-right padding-right-15">
                        <form>                                    
                            <div class="form-group filter-form advertiser-filter" style="margin-bottom:15px;padding-left: 0;">
                                <select data-plugin="selectpicker">
                                    <option>Mustard</option>
                                    <option>Ketchup</option>
                                    <option>Relish</option>
                                </select>
                            </div>
                        </form>
                    </div>
                    <div class="pull-right padding-right-15">
                        <form>                                    
                            <div class="form-group filter-form advertiser-filter" style="margin-bottom:15px;padding-left: 0;">
                                <select data-plugin="selectpicker">
                                    <option>Mustard</option>
                                    <option>Ketchup</option>
                                    <option>Relish</option>
                                </select>
                            </div>
                        </form>
                    </div>
                </div>
            </header>
            <div class="panel-body">
                <div class="table-responsive">
                    <table class="table dataTable table-striped width-full" id="facebook_report">
                        <thead>
                           <?php if($data):?>
                            <tr class="change_thead">
                                <th style="width:20%;">Date</th>
                                <?php if($this->userinfo['type']=='2'):?>
                                    <th>Clicks(All)</th>
                                <?php endif;?>
                                <th>Results</th>
                                <?php if($this->userinfo['type']=='1'):?>
                                    <th>Amount Cost</th>
                                <?php endif;?>

                                <?php if($this->userinfo['type']=='0'):?>
                                    <th>Media Buy Earning</th>
                                    <th>Real MB Earning</th>
                                    <th>Media Buy Profit</th>
                                    <th>Real Profit</th>
                                <?php endif;?>
                            </tr>
                            <?php else:?>
                                <tr class="change_thead">
                                    <td class="text-center"> No Data</td>
                                </tr>
                            <?php endif;?>
                        </thead>
                        <tbody>
                        <?php for($i=1; $i<=$days; $i++):?>
                            <tr class="gradeA">
                                <td><?php echo date('Y-m-d', strtotime("-".$i." day"))?></td>
                                <td>-</td>
                                <td>-</td>
                                <?php if($this->userinfo['type']=='0'):?>
                                    <td>-</td>
                                    <td>-</td>
                                    <td>-</td>
                                <?php endif;?>
                            </tr>
                        <?php endfor;?>
                        <?php foreach($data as $item):?>
                            <tr class="gradeA">
                                <td><?php echo $item['date']?></td>
                                <?php if($this->userinfo['type']=='2'):?>
                                    <td><?php echo $item['clicks']?></td>
                                <?php endif;?>
                                <td><?php echo $item['results']?></td>
                                <?php if($this->userinfo['type']=='1'):?>
                                    <td><?php echo "$".sprintf("%.2f", $item['amount_cost'])?></td>
                                <?php endif;?>

                                <?php if($this->userinfo['type']=='0'):?>
                                    <td><?php echo "$".sprintf("%.2f", $item['expect_revenue'])?></td>
                                    <?php if(isset($retentions[$item['date']])):?>
                                        <td><?php echo "$".sprintf("%.2f", $item['real_earning'])?></td>
                                    <?php else:?>
                                        <td>-</td>
                                    <?php endif;?>
                                    <td><?php echo "$".sprintf("%.2f", ($item['expect_revenue']-$item['spend']))?></td>
                                    <?php if(isset($retentions[$item['date']])):?>
                                        <td><?php echo "$".sprintf("%.2f", ($item['real_earning']-$item['spend']))?></td>
                                    <?php else:?>
                                        <td>-</td>
                                    <?php endif;?>
                                <?php endif;?>
                            </tr>
                        <?php endforeach;?>
                        </tbody>
                    </table>
                </div>
            </div>  
        </div>
        <!-- End Panel Table Tools -->
    </div>
</div>
<!-- End Page -->
<!-- 新加js -->
<script src="<?php echo base_url();?>assets/web/global/vendor/datatables/jquery.dataTables.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/datatables-fixedheader/dataTables.fixedHeader.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/datatables-bootstrap/dataTables.bootstrap.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/datatables-responsive/dataTables.responsive.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/datatables-tabletools/dataTables.tableTools.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/moment.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/daterangepicker.js"></script>
<!-- 新加js -->
<script src="<?php echo base_url();?>assets/web/global/js/components/datatables.js"></script>
<script src="<?php echo base_url();?>assets/web/assets/examples/js/tables/datatable.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/select2/select2.min.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/components/select2.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/components/panel.js"></script>
<script src="<?php echo base_url();?>assets/web/assets/examples/js/uikit/panel-actions.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/bootstrap-select/bootstrap-select.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/components/bootstrap-select.js"></script>
<script src="<?php echo base_url();?>assets/web/assets/examples/js/uikit/icon.js"></script>

<script>
    function cb(start, end) {
        $('#reportrange span').html(start.format('MM/DD/YYYY') + ' - ' + end.format('MM/DD/YYYY'));
        $(".date_start").val(start.format('MM/DD/YYYY'));
        $(".date_end").val(end.format('MM/DD/YYYY'));
    }

    cb(moment().subtract(3, 'days'), moment());

    $('#reportrange').daterangepicker({
        "startDate": "09/01/2016",
        "endDate": "09/30/2016",
        ranges: {
            'Today': [moment(), moment()],
            'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
            'Last 7 Days': [moment().subtract(6, 'days'), moment()],
            'Last 30 Days': [moment().subtract(29, 'days'), moment()],
            'This Month': [moment().startOf('month'), moment().endOf('month')],
            'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
        }
    }, cb);
    $('#reportrange span').html("09/01/2016" + ' - ' + "09/30/2016");
    $(".date_start").val("09/01/2016");
    $(".date_end").val("09/30/2016");
    $(function() {
        $('#input_date').datepicker({
            format: "MM yyyy",
            viewMode: "months",
            minViewMode: "months"
        }).on('changeDate', function (ev) {
            var month = $(".datepicker-months span.active").html();
            var year = $(".datepicker-years span.active").html();
            //$(this).val(month+' '+year);
            $(this).datepicker('hide');
        }).val();
    });
</script>