<!-- 新加css -->
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/global/vendor/select2/select2.css">
<link rel="stylesheet"
      href="<?php echo base_url(); ?>assets/web/global/vendor/bootstrap-datepicker/bootstrap-datepicker.css">

<style>
    .table > tbody > tr > td {
        vertical-align: middle;
    }

    .left_div {
        background: #f8fdff;
        cursor: pointer;
    }

    .left_div:hover {
        background: #eaf8ff;
    }

    .left_div.active {
        background: #eaf8ff;
    }
</style>

<div class="page animsition">
    <div class="page-content padding-top-0">
        <div class="panel">
            <div class="panel-body container-fluid" style=" padding-bottom:0; padding-top:0;">
                <div class="row row-lg">
                    <div class="col-md-3 padding-left-15">
                        <div class="example-wrap margin-bottom-0">
                            <div class="example">
                                <div
                                    class="form-group col-md-12 filter-form advertiser-filter margin-bottom-25 padding-horizontal-0 margin-top-15">
                                    <select class="wz-select form-control select2-hidden-accessible filter_publisher"
                                            data-plugin="select2" tabindex="-1" aria-hidden="true"
                                            data-placeholder="Publisher Filter"
                                            data-url="<?php echo site_url($this->input->get('q', true)?"report/product_map?q={$this->input->get('q',true)}&channel=":'report/product_map?channel='); ?>">
                                        <option
                                            value="all" <?php echo $this->input->get('channel')?'':'selected="selected"'; ?>>
                                            All
                                        </option>
                                        <?php if ($channels): ?>
                                            <?php foreach ($channels as $channel): ?>
                                                <option
                                                    value="<?php echo $channel['publisher_id']; ?>" <?php echo $channel['publisher_id'] == $this->input->get('channel')?'selected="selected"':''; ?>><?php echo $channel['publisher_name']; ?></option>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    </select>
                                </div>

                                <div class="form-group col-md-12 padding-horizontal-0">
                                    <div class="padding-top-25" style="border-top:1px solid #eee;">
                                        <button type="submit" class="input-search-btn" style="top:13px;"
                                                data-url="<?php echo $this->input->get('channel', true)?site_url("report/product_map?channel={$this->input->get('channel',true)}&q="):site_url("report/product_map?q="); ?>">
                                            <i
                                                class="icon wb-search" aria-hidden="true"></i>
                                        </button>
                                        <input type="text" class="form-control" name="q"
                                               placeholder="Search..."
                                               value="<?php echo $this->input->get('q')?$this->input->get('q'):''; ?>">
                                    </div>
                                </div>
                                <div class="col-md-12 padding-horizontal-0" style="height:415px; overflow-y:auto;">
                                    <?php if ($product_list): ?>
                                        <?php foreach ($product_list as $k=>$item): ?>
                                            <div
                                                class="col-md-12 padding-15 left_div margin-bottom-10 <?php echo $k == 0?'active wz':''; ?>"
                                                style="overflow:hidden;position:relative;"
                                                data-json='<?php echo json_encode($item['countries']); ?>'
                                                data-url="<?php echo $k == 0?site_url('report/product?key=country'):''; ?>"
                                                data-report-url="<?php echo site_url('report/retention/?product_id=' . $item['product_id']) . "&time=" . $this->input->get('date') . "&start=" . $date_start . "&end=" . $date_end; ?>"
                                            >
                                                <div class="col-md-4 col-xs-3 padding-horizontal-0">
                                                    <img class="cover-image img-responsive overlay-scale"
                                                         src="<?php echo $item['logo']; ?>" alt="">
                                                </div>
                                                <div class="col-md-8 col-xs-9">
                                                    <h4 class="widget-title text-left font-size-14 margin-bottom-5">
                                                        <a href="<?php echo site_url('manager/offer/listview?product=' . $item['product_id']); ?>"
                                                           style="text-decoration:none;"><?php echo $item['name']; ?></a>
                                                    </h4>
                                                    <span
                                                        class="label label-sm <?php echo $item['category'] == 'ios'?'label-warning':'label-success'; ?>"><?php echo strtoupper($item['category']); ?></span>
                                                </div>
                                                <p class="text-center pull-right font-size-10"
                                                   style="position: absolute;right: 15px;bottom:0;">
                                                <span
                                                    class="block font-size-14 font-weight-600"><?php echo count($item['countries']); ?></span>
                                                    <span class="block">COUNTRIES</span>
                                                </p>
                                            </div>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-9 padding-horizontal-0" style="border-left:1px solid #eee;">
                        <div class="panel-body table-responsive" style="height:500px; overflow-y:auto;">
                            <div class="filter" style="position: absolute;top:20px;right:20px; z-index:12;">
                                <span style="line-height:36px;">Filter :</span>
                                <div class="dropdown pull-right">
                                    <button type="button" id="input_date2" class="btn btn-pure">
                                        <?php echo $this->input->get('date')?$this->input->get('date'):date('M Y') ?>
                                        <span class="icon wb-chevron-down-mini" aria-hidden="true"></span>
                                    </button>
                                </div>
                            </div>
                            <div id="container" style="height:100%;"></div>
                        </div>
                        <ul class="wz-table blocks blocks-100 blocks-xlg-6 blocks-md-4 blocks-lg-5 blocks-sm-2 margin-horizontal-0 padding-top-20"
                            style="box-shadow:inset 0 1px 0 #f8f8f8;background:#f6feff; margin-right:-5px!important;">

                        </ul>
                        <div class="text-center padding-bottom-20 padding-top-5"
                             style="margin-right:-5px;background: -webkit-linear-gradient(top,rgba(240, 253, 255, 0.63),rgb(255, 255, 255));">
                            <a href="" type="button" class="btn btn-round btn_self btn-primary wz-check-result">Show Retention
                                Reports</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End Page -->
<!-- End Page -->
<!-- 新加js -->
<script src="<?php echo base_url(); ?>assets/web/global/vendor/datatables/jquery.dataTables.js"></script>
<script
    src="<?php echo base_url(); ?>assets/web/global/vendor/datatables-fixedheader/dataTables.fixedHeader.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/vendor/datatables-bootstrap/dataTables.bootstrap.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/vendor/datatables-responsive/dataTables.responsive.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/vendor/datatables-tabletools/dataTables.tableTools.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/vendor/editable-table/mindmup-editabletable.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/vendor/editable-table/numeric-input-example.js"></script>
<!-- 新加结束 -->
<!-- Scripts -->
<script src="<?php echo base_url(); ?>assets/web/global/js/core.js"></script>
<script src="<?php echo base_url(); ?>assets/web/assets/js/site.js"></script>
<script src="<?php echo base_url(); ?>assets/web/assets/js/sections/menu.js"></script>
<script src="<?php echo base_url(); ?>assets/web/assets/js/sections/menubar.js"></script>
<script src="<?php echo base_url(); ?>assets/web/assets/js/sections/sidebar.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/js/configs/config-colors.js"></script>
<script src="<?php echo base_url(); ?>assets/web/assets/js/configs/config-tour.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/js/components/asscrollable.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/js/components/animsition.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/js/components/slidepanel.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/js/components/switchery.js"></script>

<!-- 新加js -->
<script src="<?php echo base_url(); ?>assets/web/global/js/components/datatables.js"></script>
<script src="<?php echo base_url(); ?>assets/web/assets/examples/js/tables/datatable.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/vendor/select2/select2.min.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/js/components/select2.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/js/components/editable-table.js"></script>
<script src="<?php echo base_url(); ?>assets/web/assets/examples/js/tables/editable.js"></script>
<script src="//cdn.bootcss.com/echarts/3.2.3/echarts.min.js"></script>
<script src="//cdn.bootcss.com/echarts/3.2.3/extension/bmap.min.js"></script>
<!--<script type="text/javascript" src="--><?php //echo base_url(); ?><!--assets/js/echarts.min.js?ver=--><?php //echo time();?><!--"></script>-->
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/world.js"></script>
<script src="<?php echo base_url(); ?>assets/js/country.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/vendor/bootstrap-datepicker/bootstrap-datepicker.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/js/components/bootstrap-datepicker.js"></script>
<script>
    $('.left_div').click(function () {
        $('.left_div').removeClass('active');
        $('.left_div').removeClass('wz');
        $(this).addClass('active');
        $(this).addClass('wz');
        Wz.init();
    });
    $(function () {
        var q = '<?php echo $this->input->get('q');?>';
        var channel = '<?php echo $this->input->get('channel');?>';
        var url = '<?php echo site_url('report/product_map?date=');?>';
        var wz_date = "<?php echo $this->input->get('date', true)?$this->input->get('date', true):date('M Y', time());?>";
        $('#input_date2').datepicker({
            format: "MM yyyy",
            viewMode: "months",
            minViewMode: "months"
        }).datepicker("setDate", wz_date)
            .on('changeDate', function (ev) {
                var month = $(".datepicker-months span.month.focused.active").text();
                var year = $('.datepicker-months .datepicker-switch').text();
                var time = month + ' ' + year;
                location.href = url + encodeURIComponent(time) + '&channel=' + channel + '&q=' + q;
            }).val();

        $(".table tr").click(function () {
            //console.log(2);
            //location.href = site_url + "report/detail?product_id="+$(this).attr('data-val')+"&time="+$(this).attr('data-date');
        });


    });

    /**
     * 获取选中项
     */
    $('.wz-select').change(function () {
        var url = $(this).attr('data-url');
        var data = $(this).val();
        url = url + data;
        location.href = url;
    });
    /**
     * 搜索
     */
    $('.input-search-btn').click(function () {
        var url = $(this).attr('data-url');
        var data = $('.input-search-btn').siblings().val();
        var date = '<?php echo $this->input->get('date', true);?>';
        var channel = '<?php echo $this->input->get('channel', true);?>';
        url = url + data;
        if (date) {
            url = url + '&date=' + date;
        }
        if (channel) {
            url = url + '&channel=' + channel;
        }
        location.href = url;
    });
</script>
<!-- 新加js结束 -->
