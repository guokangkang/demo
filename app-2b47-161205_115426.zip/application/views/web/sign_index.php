<!DOCTYPE html>
<html class="no-js css-menubar" lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
<meta name="description" content="bootstrap admin template">
<meta name="author" content="">
<title></title>
<link rel="apple-touch-icon" href="<?php echo base_url();?>assets/web/assets/images/apple-touch-icon.png">
<link rel="shortcut icon" href="<?php echo base_url();?>assets/web/assets/images/favicon.ico">
<!-- Stylesheets -->
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/css/bootstrap-extend.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/assets/css/site.min.css">
<!-- Plugins -->
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/animsition/animsition.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/asscrollable/asScrollable.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/switchery/switchery.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/intro-js/introjs.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/slidepanel/slidePanel.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/flag-icon-css/flag-icon.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/assets/examples/css/pages/login-v3.css">
<!-- Fonts -->
 <link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/fonts/web-icons/web-icons.min.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/fonts/font-awesome/font-awesome.min.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/fonts/brand-icons/brand-icons.min.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/fonts/brand-icons/brand-icons.min.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/fonts/google/fonts.css">
<!--[if lt IE 9]>
  <script src="<?php echo base_url();?>assets/web/global/vendor/html5shiv/html5shiv.min.js"></script>
  <![endif]-->
<!--[if lt IE 10]>
  <script src="<?php echo base_url();?>assets/web/global/vendor/media-match/media.match.min.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/respond/respond.min.js"></script>
  <![endif]-->
<!-- Scripts -->
<script src="<?php echo base_url();?>assets/web/global/vendor/modernizr/modernizr.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/breakpoints/breakpoints.js"></script>
<script>
Breakpoints();
</script>
</head>
<body class="page-login-v3 layout-full" style="padding-top:0;">
  <!--[if lt IE 8]>
        <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
    <![endif]-->
  <!-- Page -->
  <div class="page vertical-align text-center" data-animsition-in="fade-in"
  data-animsition-out="fade-out">
    <div class="page-content vertical-align-middle" style="padding:0;">
      <div class="relative" style="position:relative;height:180px;overflow:hidden; top:-100px;">
        <div class="brand" style="position: absolute;left:50%;margin-left:-72px;top:0px;">
          <img class="brand-img" src="<?php echo base_url();?>assets/images/malogo.png" alt="..." style="width:56px;height:40px;">
          <h2 class="brand-text font-size-14" style="color:#fff;">PALMAX MARKETMAX</h2>
        </div>
      </div>

      <div class="sign_box col-md-12 col-xs-12 col-sm-12" style="margin-top:-100px;">
            <div class="col-md-1 col-sm-1"></div>
            <div class="sign_box_ch col-md-4 col-sm-4">
              <div class="panel col-md-10 col-xs-12" style="width:auto;margin-top:20px;    background-color: transparent;-webkit-box-shadow: none;box-shadow: none;">
                <div class="panel-body">
                  <div class="brand" style="position: absolute;left:50%;margin-left:-45px;top:0;">
                    <img class="brand-img" src="<?php echo base_url();?>assets/images/person.png" alt="..." style="width:90px;height:90px;">
                  </div>
                    <div>
                        <p style="font-size:16px; margin-top:50px; color:#fff;">Publisher</p>
                    </div>
                    <a href="<?php echo site_url('sign/in')?>" class="btn btn-primary btn-block btn-lg margin-top-20" style="    width: 200px;height: 40px; background-color: transparent;border: 1px solid #fff;line-height: 1.1;">Login</a>
                </div>
              </div>
            </div>
            <div class="col-md-2 col-sm-1"></div>
            <div class="sign_box_ch col-md-4 col-sm-4">
              <div class="panel col-md-10 col-xs-12" style="width:auto;margin-top:20px;    background-color: transparent;-webkit-box-shadow: none;box-shadow: none;">
                <div class="panel-body">
                  <div class="brand" style="position: absolute;left:50%;margin-left:-45px;top:0;">
                    <img class="brand-img" src="<?php echo base_url();?>assets/images/bussiness.png" alt="..." style="width:90px;height:90px;">
                  </div>
                    <div>
                        <p style="font-size:16px; margin-top:50px;color:#fff;">Advertiser</p>
                    </div>
                    <a href="<?php echo site_url('sign/advertiser_in')?>" class="btn btn-primary btn-block btn-lg margin-top-20" style="    width: 200px;height: 40px; background-color: transparent;border: 1px solid #fff;line-height: 1.1;">Login</a>
                </div>
              </div>
            </div>
          </div>
      </div>

      <footer class="page-copyright page-copyright-inverse" style="margin-top:-80px;">
        <p style="margin-bottom:0;">POWERED BY PALMAX</p>
        <p style="margin-bottom:0;">© 2016. All RIGHT RESERVED.</p>
      </footer>
    </div>
  </div>
  <style type="text/css">
    @media (min-width: 1200px) {
        .sign_box{width:1086px;}
        .sign_box .sign_box_ch{width:350px; float: left;} 
    }
     @media (max-width:768px) {
        .relative{top:0!important;}
        .page-copyright{margin-top:-30px!important;}
    }
    .page-login-v3:before{background: -webkit-radial-gradient(circle,#00A7D0,#26788c)!important;}
    .layout-full .page .btn-primary:hover{background:rgba(255,255,255,0.5)!important;}
  </style>

  <!-- End Page -->
  <!-- Core  -->
  <script src="<?php echo base_url();?>assets/web/global/vendor/jquery/jquery.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/bootstrap/bootstrap.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/animsition/animsition.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/asscroll/jquery-asScroll.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/mousewheel/jquery.mousewheel.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/asscrollable/jquery.asScrollable.all.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/ashoverscroll/jquery-asHoverScroll.js"></script>
  <!-- Plugins -->
  <script src="<?php echo base_url();?>assets/web/global/vendor/switchery/switchery.min.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/intro-js/intro.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/screenfull/screenfull.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/slidepanel/jquery-slidePanel.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/jquery-placeholder/jquery.placeholder.js"></script>
  <!-- Scripts -->
  <script src="<?php echo base_url();?>assets/web/glob<?php echo base_url();?>assets/web/core.js"></script>
  <script src="<?php echo base_url();?>assets/web/asse<?php echo base_url();?>assets/web/site.js"></script>
  <script src="<?php echo base_url();?>assets/web/asse<?php echo base_url();?>assets/web/sections/menu.js"></script>
  <script src="<?php echo base_url();?>assets/web/asse<?php echo base_url();?>assets/web/sections/menubar.js"></script>
  <script src="<?php echo base_url();?>assets/web/asse<?php echo base_url();?>assets/web/sections/sidebar.js"></script>
  <script src="<?php echo base_url();?>assets/web/glob<?php echo base_url();?>assets/web/configs/config-colors.js"></script>
  <script src="<?php echo base_url();?>assets/web/asse<?php echo base_url();?>assets/web/configs/config-tour.js"></script>
  <script src="<?php echo base_url();?>assets/web/glob<?php echo base_url();?>assets/web/components/asscrollable.js"></script>
  <script src="<?php echo base_url();?>assets/web/glob<?php echo base_url();?>assets/web/components/animsition.js"></script>
  <script src="<?php echo base_url();?>assets/web/glob<?php echo base_url();?>assets/web/components/slidepanel.js"></script>
  <script src="<?php echo base_url();?>assets/web/glob<?php echo base_url();?>assets/web/components/switchery.js"></script>
  <script src="<?php echo base_url();?>assets/web/glob<?php echo base_url();?>assets/web/components/jquery-placeholder.js"></script>
  <script src="<?php echo base_url();?>assets/web/glob<?php echo base_url();?>assets/web/components/material.js"></script>
  <script>
  (function(document, window, $) {
    'use strict';
    var Site = window.Site;
    $(document).ready(function() {
      Site.run();
    });
  })(document, window, jQuery);
  </script>
</body>
</html>