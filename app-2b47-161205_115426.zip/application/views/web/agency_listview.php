<style type="text/css">
   .widget-body-footer .time{width: 50%;} 
</style>
<div class="page animsition">
    <div class="page-header">
      <ol class="breadcrumb">
        <li><a href="<?php echo site_url('agency/listview')?>">Agency</a></li>
        <li class="active">Agency List</li>
      </ol>
    </div>
    <div class="page-content blue-grey-500">
        <ul class="blocks blocks-100 blocks-xlg-5 blocks-lg-4 blocks-md-3 blocks-sm-2" data-plugin="masonry">
            <?php foreach($agency_list as $item):?>
                <li class="masonry-item">
                    <div class="widget widget-article widget-shadow widget-border" style="padding-top:10px;">
                        <div class="widget-header cover">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="col-md-6 col-xs-8">
                                        <p class="widget-title" style="padding-top:12px;font-size: 18px;font-weight: bold;"><?php echo $item['publisher_name']?></p>
                                        <p class="widget-title"><?php echo date('Y-m-d', $item['addtime'])?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="widget-body-footer">
                            <div class="col-md-12">
                                <div class="time pull-right text-left">Results : <?php echo number_format($item['results'])?></div>
                                <div class="text-truncate">Products : <?php echo $item['product']?></div>                           

                                <div class="time pull-right text-left">Shares : <?php echo number_format($item['shares'])?></div>
                                <div class="text-truncate">AdAccounts : <?php echo $item['account_id']?></div>

                                <div class="time pull-right text-left">Illegal Rate : <?php echo $item['illegal_rate']?></div>
                                <div class="text-truncate">Illegals : <?php echo $item['illegal']?></div>
                            </div>
                            <div class="col-sm-12">
                                <div class="example-wrap" style="margin-top:18px; margin-bottom:44px;">
                                    <div class="contextual-progress">
                                        <div class="clearfix">
                                            <div class="progress-title">Conversion</div>
                                            <div class="progress-label"><?php echo $item['chart']['input_conversion_rate']?>%</div>
                                        </div>
                                        <div class="progress progress-xs">
                                            <div class="progress-bar progress-bar-default progress-bar-indicating active" style="width:<?php echo $item['chart']['input_conversion_rate']?>%;" role="progressbar">
                                                <span class="sr-only"><?php echo $item['chart']['input_conversion_rate']?>% Complete</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="contextual-progress">
                                        <div class="clearfix">
                                            <div class="progress-title">The Next Day</div>
                                            <div class="progress-label"><?php echo $item['chart']['input_next_day']?>%</div>
                                        </div>
                                        <div class="progress progress-xs">
                                            <div class="progress-bar progress-bar-success progress-bar-indicating active" style="width:<?php echo $item['chart']['input_next_day']?>%;" role="progressbar">
                                                <span class="sr-only"><?php echo $item['chart']['input_next_day']?>% Complete</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="contextual-progress">
                                        <div class="clearfix">
                                            <div class="progress-title">7 Days</div>
                                            <div class="progress-label"><?php echo $item['chart']['input_7days']?>%</div>
                                        </div>
                                        <div class="progress progress-xs">
                                            <div class="progress-bar progress-bar-warning progress-bar-indicating active" style="width: <?php echo $item['chart']['input_7days']?>%;" role="progressbar">
                                                <span class="sr-only"><?php echo $item['chart']['input_7days']?>% Complete</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="contextual-progress">
                                        <div class="clearfix">
                                            <div class="progress-title">30 Days</div>
                                            <div class="progress-label"><?php echo $item['chart']['input_30days']?>%</div>
                                        </div>
                                        <div class="progress progress-xs">
                                            <div class="progress-bar progress-bar-danger progress-bar-indicating active" style="width: <?php echo $item['chart']['input_30days']?>%;" role="progressbar">
                                                <span class="sr-only"><?php echo $item['chart']['input_30days']?>% Complete</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div> 
                    </div>
                </li>
            <?php endforeach;?>
        </ul>
    </div>
</div>
  