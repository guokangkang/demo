<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/fonts/material-design/material-design.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/assets/examples/css/uikit/icon.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/select2/select2.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/index_select.css">
<style>
    .nav-tabs>li.active>a{
        color: #fff;
        background-color:#12abc5!important;
        border-color:transparent;
        border-bottom-color:#12abc5!important;
    }   
    .nav-tabs>li.active>a:hover{
        color: #fff;
        background-color:#0890a7;
        border-color:transparent;
        border-bottom-color:#0890a7;
    }
    .nav-tabs>li>a{
        color: #707070;
        background-color:#fff;
        border-color:transparent;
        border-bottom-color:#fff;
    }
    .nav-tabs>li>a:hover{
        color: #fff;
        background-color:#0890a7;
        border-color:transparent;
        border-bottom-color:#0890a7;
    }
    .nav-tabs>li>a{margin-right: 1px;}  
    .table-striped>tbody>tr:nth-of-type(odd){
        background-color: rgba(247,252,255,1);
    }
</style>
<div class="page animsition">
    <div class="page-header">        
        <ol class="breadcrumb">
            <li><a href="<?php echo site_url('agency/listview')?>">Agency</a></li>
            <li class="active">Agency Task</li>
        </ol>
    </div>
    <div class="page-content"> 
        <div class="panel">
            <div class="panel-body container-fluid" style=" padding-bottom: 0;">
                <div class="row row-lg">
                    <div class="clearfix visible-md-block visible-lg-block"></div>
                    <div class="col-md-12">
                        <div class="example-wrap" style="margin-bottom:0;">
                            <h4>Filter</h4>
                            <div class="example" style="margin-bottom: 0; margin-top: 0;">
                                <div class="col-md-12 padding-left-0">
                                    <div class="example-wrap">
                                        <div class="example margin-top-3">
                                            <form>                                   
                                                <div class="form-group col-md-5 filter-form advertiser-filter" style="margin-bottom:15px;padding-left: 0;">
                                                    <div class="diy_select">
                                                        <!--【存】当前选中的值-->
                                                        <input type="hidden" name="" class="diy_select_input filter_country" value="<?php echo $country_params?implode(',',$country_params).',':'';?>">
                                                        <!--【显示】当前选中的值-->
                                                        <input type="text" class="diy_select_txt filter_input_4" placeholder="<?php echo count($country_params)?count($country_params).' items selected':'Country';?>">
                                                        <!--下拉三角形-->
                                                        <span class="caret" style="right: 14px;position: absolute;top: 50%;margin-top: -2px;"></span>
                                                        <!--数据列表-->
                                                        <ul class="diy_select_list" style="display:none;" id="radiao_box_4">
                                                            <?php if(isset($config_country)):?>
                                                                <?php foreach($config_country['country'] as $key=>$name):?>
                                                                    <?php if(in_array($key, $country_list)):?>
                                                                        <li data-key="<?php echo $key?>" <?php echo (in_array($key, $country_params))?"class='show_list'":''?>>
                                                                            <span><?php echo $key.'-'.$name?></span>
                                                                            <b class="icon wb-check check-mark"></b>
                                                                        </li>
                                                                    <?php endif;?>
                                                                <?php endforeach;?>
                                                            <?php endif;?>
                                                        </ul>
                                                    </div>
                                                    <!--<select class="form-control select2-hidden-accessible filter_country" multiple="" data-plugin="select2" tabindex="-1" aria-hidden="true" data-placeholder="Country">
                                                        <?php /*foreach($config_country['country'] as $key=>$name):*/?>
                                                            <?php /*if(in_array($key, $country_list)):*/?>
                                                            <option value="<?php /*echo $key*/?>" <?php /*echo (in_array("'".$key."'", $country_params))?"selected='selected'":''*/?>><?php /*echo $key.'-'.$name*/?></option>
                                                            <?php /*endif;*/?>
                                                        <?php /*endforeach;*/?>
                                                    </select>-->
                                                </div>

                                               <div class="form-group col-md-4 filter-form advertiser-filter" style="margin-bottom:15px;padding-left: 0;">
                                                   <div class="diy_select">
                                                       <!--【存】当前选中的值-->
                                                       <input type="hidden" name="" class="diy_select_input filter_agency" value="<?php echo $agency_params?implode(',',$agency_params).',':'';?>">
                                                       <!--【显示】当前选中的值-->
                                                       <input type="text" class="diy_select_txt filter_input_4" placeholder="<?php echo count($agency_params)?count($agency_params).' items selected':'Agency';?>">
                                                       <!--下拉三角形-->
                                                       <span class="caret" style="right: 14px;position: absolute;top: 50%;margin-top: -2px;"></span>
                                                       <!--数据列表-->
                                                       <ul class="diy_select_list" style="display:none;" id="radiao_box_4">
                                                           <?php if(isset($agency_list)):?>
                                                               <?php foreach($agency_list as $p):?>
                                                                       <li data-key="<?php echo $p['publisher_id']?>" <?php echo (in_array($p['publisher_id'], $agency_params))?"class='show_list'":''?>>
                                                                           <span><?php echo $p['publisher_name']?></span>
                                                                           <b class="icon wb-check check-mark"></b>
                                                                       </li>
                                                               <?php endforeach;?>
                                                           <?php endif;?>
                                                       </ul>
                                                   </div>
                                          <!--          <select class="form-control select2-hidden-accessible filter_agency" multiple="" data-plugin="select2" tabindex="-1" aria-hidden="true" data-placeholder="Agency">
                                                        <?php /*foreach($agency_list as $p):*/?>
                                                            <option value="<?php /*echo $p['publisher_id']*/?>" <?php /*echo (in_array($p['publisher_id'], $agency_params))?"selected='selected'":''*/?>><?php /*echo $p['publisher_name']*/?></option>
                                                        <?php /*endforeach;*/?>
                                                    </select>-->
                                                </div>
                                                <div class="form-group col-md-3 filter-form" style="margin-bottom:15px;padding-left: 0;">
                                                    
                                                    <button type="button" class="btn btn-outline btn-primary agency_search margin-right-10">Search</button>

                                                    <button type="button" class="btn btn-outline btn-info agency_rest">Reset</button>
                                                </div>        
                                            </form>
                                        </div>
                                    </div>
                                    <!-- End Example Multi Balue -->
                                </div>                               
                            </div>  
                        </div>
                    </div>
                </div>
            </div>
        </div> 

        <div class="nav-tabs-horizontal">
            <div class="clearfix">
                <ul class="nav nav-tabs pull-left" style="border-bottom:none;">
                    <?php foreach($product_list as $k=>$p):?>
                        <li class="<?php echo $k==0?'active':''?>" role="presentation"><a data-toggle="tab" href="#product-<?php echo $p['product_id']?>" aria-controls="product-<?php echo $p['product_id']?>" role="tab" aria-expanded="false"><?php echo $p['name']?></a></li>
                    <?php endforeach;?>
                </ul>
            </div>
            <div class="tab-content">
                    <?php foreach($product_list as $k=>$p):?>
                        <div class="tab-pane <?php echo $k==0?'active':''?>" id="product-<?php echo $p['product_id']?>" role="tabpanel">
                            <div class="panel padding-30">
                                <table class="table dataTable table-striped width-full" id="facebook_report">
                                    <thead>
                                        <tr>
                                            <th style="width:30%;">Country / Agency</th>
                                            <?php foreach($agency_list as $k=>$agency):?>
                                                <?php if(!$this->input->get('agency') || ($this->input->get('agency') && $this->input->get('agency')==$agency['publisher_id'])):?>
                                                    <th><?php echo $agency['publisher_name']?></th>
                                                <?php endif;?>
                                            <?php endforeach;?>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php if($results):?>
                                        <?php if(isset($results[$p['product_id']])):?>
                                            <?php foreach($results[$p['product_id']] as $key=>$item):?>
                                            <tr class="gradeA">
                                                <td><?php echo $key?><?php echo isset($config_country['country'][$key])?" - ".$config_country['country'][$key]:''?></td>
                                                <?php foreach($agency_list as $a):?>
                                                    <?php if(isset($item[$a['publisher_name']])):?>
                                                        <td><?php echo "$".$item[$a['publisher_name']]['rpa'].' / '.$item[$a['publisher_name']]['rate']?>
                                                            <?php
                                                                if (isset($item[$a['publisher_name']]['category'])) {
                                                                    echo " (".$config_product['offer_category'][$item[$a['publisher_name']]['category']].")";
                                                                }
                                                            ?>
                                                        </td>
                                                    <?php else:?>
                                                        <?php if(!$this->input->get('agency') || ($this->input->get('agency') && $this->input->get('agency')==$a['publisher_id'])):?>
                                                        <td>-</td>
                                                        <?php endif;?>
                                                    <?php endif;?>
                                                <?php endforeach;?>
                                            </tr>
                                            <?php endforeach;?>
                                        <?php endif;?>
                                    <?php else:?>
                                        <tr>
                                            <td colspan="3" style="text-align: center;background-color: #ffffff">
                                                <img src="<?php echo base_url();?>assets/images/no_data.png">
                                                <h4 class="margin-top-30">NO DATA HERE</h4>
                                                <p style="line-height: 18px;">I hate peeping Toms. For one thing they usually step all over<br>the hedges and plants on the side of someone's house killing</p>
                                            </td>
                                        </tr>
                                    <?php endif;?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    <?php endforeach;?>
            </div>
        </div>        
    </div>
</div>

<script src="<?php echo base_url();?>assets/web/global/vendor/datatables/jquery.dataTables.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/components/datatables.js"></script>
<script src="<?php echo base_url();?>assets/web/assets/examples/js/tables/datatable.js"></script>
<script src="<?php echo base_url();?>assets/web/assets/examples/js/uikit/icon.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/select2/select2.min.js"></script>  
<script src="<?php echo base_url();?>assets/web/global/js/components/select2.js"></script>
<script src="<?php echo base_url();?>assets/js/index_select.js"></script>


