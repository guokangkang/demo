<div class="site-menubar site-menubar-light">
    <div class="site-menubar-body">
        <div>
            <div>
                <ul class="site-menu">
                    <li class="site-menu-category">General</li>
                    <li class="site-menu-item <?php echo $this->router->class=='review'&&$this->router->method=='index'?'active':''?>">
                        <a href="<?php echo site_url('review')?>">
                            <i class="site-menu-icon md-eye" aria-hidden="true"></i>
                            <span class="site-menu-title">Review</span>
                        </a>
                    </li>

                    <li class="site-menu-item <?php echo $this->router->class=='review'&&$this->router->method=='risk'?'active':''?>">
                        <a href="<?php echo site_url('review/risk')?>">
                            <i class="site-menu-icon md-alert-triangle" aria-hidden="true"></i>
                            <span class="site-menu-title">Risk</span>
                        </a>
                    </li>

                    <li class="site-menu-item <?php echo $this->router->class=='review'&&$this->router->method=='social'?'active':''?>">
                        <a href="<?php echo site_url('review/social')?>">
                            <i class="site-menu-icon md-globe-alt" aria-hidden="true"></i>
                            <span class="site-menu-title">Social Data</span>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>