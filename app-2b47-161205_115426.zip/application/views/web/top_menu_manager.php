<div class="site-menubar site-menubar-light">
    <div class="site-menubar-body">
        <div>
            <div>
                <ul class="site-menu">
                    <li class="site-menu-category">General</li>
                    <li class="dropdown site-menu-item has-sub <?php echo $this->router->class=='product'?'active':''?>">
                        <a class="dropdown-toggle" href="javascript:void(0)" data-dropdown-toggle="false">
                            <i class="site-menu-icon md-apps" aria-hidden="true"></i>
                            <span class="site-menu-title">Products Management</span>
                            <span class="site-menu-arrow"></span>
                        </a>
                        <div class="dropdown-menu">
                            <div class="site-menu-scroll-wrap is-list">
                                <div>
                                    <div>
                                        <ul class="site-menu-sub site-menu-normal-list">
                                            <li class="site-menu-item <?php echo ($this->router->class == 'product'&&$this->router->method=='listview')?'active':''?>">
                                                <a class="animsition-link" href="<?php echo site_url('manager/product/listview')?>">
                                                    <span class="site-menu-title">Listview</span>
                                                </a>
                                            </li>
                                            <li class="site-menu-item <?php echo ($this->router->class == 'product'&&in_array($this->router->method, ['find', 'confirm']))?'active':''?>">
                                                <a class="animsition-link" href="<?php echo site_url('manager/product/find')?>">
                                                    <span class="site-menu-title">Add Product</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </li>
                    <li class="dropdown site-menu-item has-sub <?php echo ($this->router->class=='offer')?'active':''?>">
                        <a class="dropdown-toggle" href="javascript:void(0)" data-dropdown-toggle="false">
                            <i class="site-menu-icon wb-mobile" aria-hidden="true"></i>
                            <span class="site-menu-title">Offer Assignment</span>
                            <span class="site-menu-arrow"></span>
                        </a>
                        <div class="dropdown-menu">
                            <div class="site-menu-scroll-wrap is-list">
                                <div>
                                    <div>
                                        <ul class="site-menu-sub site-menu-normal-list">
                                            <li class="site-menu-item <?php echo ($this->router->class=='offer'&&$this->router->method=='applications')?'active':''?>">
                                                <a class="animsition-link" href="<?php echo site_url('manager/offer/applications')?>">
                                                    <span class="site-menu-title">Offer Applications</span>
                                                </a>
                                            </li>
                                            <li class="site-menu-item <?php echo ($this->router->class=='offer'&&$this->router->method=='assign')?'active':''?>">
                                                <a class="animsition-link" href="<?php echo site_url('manager/offer/assign')?>">
                                                    <span class="site-menu-title">Offer Bulk Assign</span>
                                                </a>
                                            </li>
                                            <li class="site-menu-item <?php echo $this->router->method=='accounts' && $this->router->class=='offer'?'active':''?>">
                                                <a class="animsition-link" href="<?php echo site_url('manager/offer/accounts')?>">
                                                    <span class="site-menu-title">Account Assigned</span>
                                                </a>
                                            </li>
                                            <!-- <li class="site-menu-item <?php echo $this->router->method=='assigned' && $this->router->class=='manage'?'active':''?>">
                                                <a class="animsition-link" href="<?php echo site_url('manager/offer/assigned')?>">
                                                    <span class="site-menu-title">Offer Assigned</span>
                                                </a>
                                            </li> -->
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </li>


                    <li class="dropdown site-menu-item has-sub <?php echo ($this->router->class=='retention')?'active':''?>">
                        <a class="dropdown-toggle" href="javascript:void(0)" data-dropdown-toggle="false">
                            <i class="site-menu-icon md-receipt" aria-hidden="true"></i>
                            <span class="site-menu-title">Retention Management</span>
                            <span class="site-menu-arrow"></span>
                        </a>
                        <div class="dropdown-menu">
                            <div class="site-menu-scroll-wrap is-list">
                                <div>
                                    <div>
                                        <ul class="site-menu-sub site-menu-normal-list">
                                            <li class="site-menu-item <?php echo ($this->router->class=='retention'&&$this->router->method=='import')?'active':''?>">
                                                <a class="animsition-link" href="<?php echo site_url('manager/retention/import')?>">
                                                    <span class="site-menu-title">Import Retention</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </li>


                    <li class="dropdown site-menu-item has-sub <?php echo ($this->router->class=='user')?'active':''?>">
                        <a class="dropdown-toggle" href="javascript:void(0)" data-dropdown-toggle="false">
                            <i class="site-menu-icon md-accounts-alt" aria-hidden="true"></i>
                            <span class="site-menu-title">User Management</span>
                            <span class="site-menu-arrow"></span>
                        </a>
                        <div class="dropdown-menu">
                            <div class="site-menu-scroll-wrap is-list">
                                <div>
                                    <div>
                                        <ul class="site-menu-sub site-menu-normal-list">
                                            <li class="site-menu-item <?php echo ($this->router->class=='user'&&$this->router->method=='index')?'active':''?>">
                                                <a class="animsition-link" href="<?php echo site_url('manager/user/index')?>">
                                                    <span class="site-menu-title">Users</span>
                                                </a>
                                            </li>
                                            <li class="site-menu-item <?php echo ($this->router->class=='user'&&$this->router->method=='publisher')?'active':''?>">
                                                <a class="animsition-link" href="<?php echo site_url('manager/user/publisher')?>">
                                                    <span class="site-menu-title">Publishers</span>
                                                </a>
                                            </li>
                                            <li class="site-menu-item <?php echo ($this->router->class=='user'&&$this->router->method=='advertiser')?'active':''?>">
                                                <a class="animsition-link" href="<?php echo site_url('manager/user/advertiser')?>">
                                                    <span class="site-menu-title">Advertisers</span>
                                                </a>
                                            </li>
                                            <li class="site-menu-item <?php echo ($this->router->class=='user'&&$this->router->method=='agency')?'active':''?>">
                                                <a class="animsition-link" href="<?php echo site_url('manager/user/agency')?>">
                                                    <span class="site-menu-title">Agencies</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </li>


                    <li class="dropdown site-menu-item has-sub <?php echo ($this->router->class=='setting')?'active':''?>">

                        <a class="dropdown-toggle" href="javascript:void(0)" data-dropdown-toggle="false">
                            <i class="icon fa-gear" aria-hidden="true"></i>
                            <span class="site-menu-title">Setting Management</span>
                            <span class="site-menu-arrow"></span>
                        </a>
                        <div class="dropdown-menu">
                            <div class="site-menu-scroll-wrap is-list">
                                <div>
                                    <div>
                                        <ul class="site-menu-sub site-menu-normal-list">
                                            <li class="site-menu-item <?php echo ($this->router->class=='setting'&&$this->router->method=='adjust')?'active':''?>">
                                                <a class="animsition-link" href="<?php echo site_url('manager/setting/adjust')?>">
                                                    <span class="site-menu-title">Bills Adjust</span>
                                                </a>
                                            </li>
                                            <li class="site-menu-item <?php echo ($this->router->class=='setting'&&$this->router->method=='risk')?'active':''?>">
                                                <a class="animsition-link" href="<?php echo site_url('manager/setting/risk')?>">
                                                    <span class="site-menu-title">Review</span>
                                                </a>
                                            </li>
                                            <li class="site-menu-item <?php echo ($this->router->class=='setting'&&$this->router->method=='daily')?'active':''?>">
                                                <a class="animsition-link" href="<?php echo site_url('manager/setting/daily')?>">
                                                    <span class="site-menu-title">Daily</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </li> 
                </ul>
            </div>
        </div>
    </div>
</div>