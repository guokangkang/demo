<!-- 新加css -->
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/global/fonts/material-design/material-design.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/assets/examples/css/uikit/icon.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/assets/examples/css/advanced/masonry.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/global/vendor/webui-popover/webui-popover.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/global/vendor/toolbar/toolbar.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/assets/examples/css/uikit/modals.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/global/vendor/select2/select2.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/global/vendor/bootstrap-sweetalert/sweet-alert.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/global/vendor/toastr/toastr.css">

<style>
    .nav-tabs > li.active > a {
        color: #fff;
        background-color: #12abc5 !important;
        border-color: transparent;
        border-bottom-color: #12abc5 !important;
    }

    .select2-container {
        z-index: 1800;
    }

    .nav-tabs > li.active > a:hover {
        color: #fff;
        background-color: #0890a7;
        border-color: transparent;
        border-bottom-color: #0890a7;
    }

    .nav-tabs > li > a {
        color: #707070;
        background-color: #fff;
        border-color: transparent;
        border-bottom-color: #fff;
    }

    .nav-tabs > li > a:hover {
        color: #fff;
        background-color: #0890a7;
        border-color: transparent;
        border-bottom-color: #0890a7;
    }

    .special_a > li.active > a {
        color: #22d3b7 !important;
        background-color: transparent !important;
        border-color: transparent;
        border-bottom-color: transparent !important;
    }

    .special_a > li.active > a:hover {
        color: #707070;
        background-color: transparent !important;
        border-color: transparent;
        border-bottom-color: transparent !important;
    }

    .special_a > li > a {
        color: #707070;
        background-color: transparent !important;
        border-color: transparent;
        background-color: transparent !important;
        padding-left: 4px;
        padding-right: 4px;
    }

    .nav-special_a > li > a:hover {
        color: #707070;
        background-color: transparent !important;
        border-color: transparent;
        background-color: transparent !important;
    }

    .nav-tabs > li > a {
        margin-right: 1px;
    }

    .table > thead > tr > th, .table > tbody > tr > td {
        padding: 0;
        border: none;
    }

    @media (max-width: 767px) {
        .padding_right {
            padding-right: 40px !important
        }
    }

    @media (max-width: 476px) {
        .xs_row {
            margin-left: -6px;
            margin-right: -35px !important;
        }
    }

    @media (min-width: 992px) {
        .bg_color {
            background: -webkit-linear-gradient(left, #fff 83%, #fbfbfb 80%);
        }
    }
</style>

<!-- Page -->
<div class="page animsition">
    <div class="page-header">
        <ol class="breadcrumb">
            <li><a href="<?php echo site_url('product/listview'); ?>">Marketing</a></li>
            <li><a href="<?php echo site_url('product/listview'); ?>">Products</a></li>
            <li class="active">Details</li>
        </ol>
    </div>
    <div class="page-content">
        <div class="panel" style="border:1px solid #f2f2f2;">
            <div class="panel-body padding-vertical-0 container-fluid">
                <div class="row xs_row" style="margin-right:-45px;">
                    <div class="col-md-2 col-xs-12 text-center padding-top-30 padding_right">
                        <img style="border:0" class="img img-thumbnail" src="<?php echo $product_info['logo']; ?>">
                    </div>
                    <div class="col-md-8 col-xs-12 padding-top-30 padding-bottom-30 padding_right">
                        <div>
                            <h3 class="panel-title padding-0 inline-block vertical-align-middle font-size-18"
                                style="color:#3b434a;"><?php echo strtoupper($product_info['name']); ?></h3>
                            <span
                                class="label label-sm <?php echo $product_info['category'] == 'ios'?'label-warning':'label-success'; ?> inline-block"><?php echo strtoupper($product_info['category']); ?></span>
                            <?php if ($this->userinfo['type'] == 2): ?>
                                <?php if (count($apply_publisher_offer) < count($list)): ?>
                                    <button type="button"
                                            style="background:#12abc5; outline:none; border:0;margin-right: 30px;"
                                            class="btn btn-wz btn_self btn-success pull-right" data-product-name=""
                                            data-target="#product_apply_offer" data-toggle="modal" data-id=""
                                            data-country="" data-include="">Apply
                                    </button>
                                <?php else: ?>
                                    <button type="button"
                                            style="background:#dedede; outline:none; border:0;margin-right: 30px;"
                                            class="btn btn-success pull-right" disabled>Apply
                                    </button>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                        <p class="margin-bottom-0">ID : <?php echo $product_info['product_id']; ?></p>
                        <p class="margin-bottom-0" style="color:#79848e;"><strong
                                style="color:#454d54; ">Package</strong> : <?php echo $product_info['app_id']; ?></p>
                        <p class="margin-bottom-10 padding-right-10"
                           style="color:#79848e; height:110px;overflow:hidden;"><strong style="color:#454d54; ">Description</strong>
                            :
                            <?php echo $product_info['description']; ?>
                        </p>
                        <p class="margin-bottom-0 btn btn-round btn-outline btn-default" style="white-space: initial;">
                            <a href="<?php echo $product_info['object_store_url']; ?>" target="_blank" class="icondemo"
                               style="color:#76838f!important;text-decoration: none;word-break: break-all;">
                                <i class="md-link" aria-hidden="true"></i>
                                <?php echo $product_info['object_store_url']; ?>
                            </a>
                        </p>
                    </div>
                    <div class="col-md-2 col-xs-12 padding-top-30"
                         style="border-left:1px solid #f2f2f2; background:#fbfbfb; padding-bottom:37px; margin-left:-15px;">
                        <div class="text-center padding-top-10 margin-bottom-5" style="height:40px;">
                            <div class="inline-block" style="height: 40px;vertical-align: middle;">
                                <img class="img vertical-align-middle"
                                     src="<?php echo site_url() . ($product_info['category'] == 'android'?'assets/images/right_pic.png':'assets/images/apple_pic.png'); ?>">
                            </div>
                            <div class="inline-block">
                                <span class="block" style="color:#a9b9b9;">Total Rate</span>
                                <span class="block"
                                      style="margin-top:-5px;color:#a9b9b9;">
                                    <?php
                                    if ($product_info['score_info']) {
                                        if ($product_info['category'] == 'ios') {
                                            echo $product_info['score_info'];
                                        } else {
                                            echo $product_info['score_info']['total_count'];
                                        }
                                    } else {
                                        echo 0;
                                    } ?></span>
                            </div>
                        </div>
                        <p class="<?php echo $product_info['category'] == 'ios'?'':'font-size-40'; ?> text-center margin-bottom-0" <?php echo $product_info['category'] == 'ios'?'style="font-size:64px;margin-top:20px;margin-bottom:14px;"':''; ?>><?php echo $product_info['score']; ?></p>
                        <p class="text-center"
                           style="margin-top:-8px;<?php echo $product_info['category'] == 'ios'?'margin-bottom:42px;':''; ?>">
                            <?php
                            for ($i=1; $i <= 5; $i++) {
                                if ($product_info['score'] > $i) {
                                    echo '<span class="icondemo margin-right-5"><i class="md-star" aria-hidden="true"></i> </span>';
                                } else {
                                    echo '<span class="icondemo margin-right-5" style="color:#d8d8d8;"><i class="md-star" aria-hidden="true"></i> </span>';
                                }
                            }; ?>
                        </p>

                        <?php if ($product_info['category'] == 'android'): ?>
                            <div>
                                <div class="contextual-progress" style="position: relative; margin:14px auto;">
                                    <span class="font-size-12" style="position:absolute;left: 0;top: -8px;">5</span>
                                    <div class="progress margin-left-15" data-goal="60" data-plugin="progress"
                                         style="background:#d8d8d8;">
                                        <div class="progress-bar progress-bar-indicating active" aria-valuemin="15"
                                             aria-valuemax="115" aria-valuenow="25" role="progressbar"
                                             style="width:<?php echo array_key_exists('total_count', $product_info['score_info']) && $product_info['score_info']['total_count']?round((int)str_replace(',', '', $product_info['score_info']['5']) / (int)str_replace(',', '', $product_info['score_info']['total_count']), 2) * 100:0; ?>%;background:#707070;">
                                            <span
                                                class="progress-label"><?php echo $product_info['score_info']?$product_info['score_info'][5]:0; ?></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="contextual-progress" style="position: relative; margin:14px auto;">
                                    <span class="font-size-12" style="position:absolute;left: 0;top: -8px;">4</span>
                                    <div class="progress margin-left-15" data-goal="60" data-plugin="progress"
                                         style="background:#d8d8d8;">
                                        <div class="progress-bar progress-bar-indicating active" aria-valuemin="15"
                                             aria-valuemax="115" aria-valuenow="25" role="progressbar"
                                             style="width:<?php echo array_key_exists('total_count', $product_info['score_info']) && $product_info['score_info']['total_count']?round((int)str_replace(',', '', $product_info['score_info']['4']) / (int)str_replace(',', '', $product_info['score_info']['total_count']), 2) * 100:0; ?>%;background:#707070;">
                                            <span
                                                class="progress-label"><?php echo $product_info['score_info']?$product_info['score_info'][4]:0; ?></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="contextual-progress" style="position: relative; margin:14px auto;">
                                    <span class="font-size-12" style="position:absolute;left: 0;top: -8px;">3</span>
                                    <div class="progress margin-left-15" data-goal="60" data-plugin="progress"
                                         style="background:#d8d8d8;">
                                        <div class="progress-bar progress-bar-indicating active" aria-valuemin="15"
                                             aria-valuemax="115" aria-valuenow="25" role="progressbar"
                                             style="width:<?php echo array_key_exists('total_count', $product_info['score_info']) && $product_info['score_info']['total_count']?round((int)str_replace(',', '', $product_info['score_info']['3']) / (int)str_replace(',', '', $product_info['score_info']['total_count']), 2) * 100:0; ?>%;background:#707070;">
                                            <span
                                                class="progress-label"><?php echo $product_info['score_info']?$product_info['score_info'][3]:0; ?></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="contextual-progress" style="position: relative; margin:14px auto;">
                                    <span class="font-size-12" style="position:absolute;left: 0;top: -8px;">2</span>
                                    <div class="progress margin-left-15" data-goal="60" data-plugin="progress"
                                         style="background:#d8d8d8;">
                                        <div class="progress-bar progress-bar-indicating active" aria-valuemin="15"
                                             aria-valuemax="115" aria-valuenow="25" role="progressbar"
                                             style="width:<?php echo array_key_exists('total_count', $product_info['score_info']) && $product_info['score_info']['total_count']?round((int)str_replace(',', '', $product_info['score_info']['2']) / (int)str_replace(',', '', $product_info['score_info']['total_count']), 2) * 100:0; ?>%;background:#707070;">
                                            <span
                                                class="progress-label"><?php echo $product_info['score_info']?$product_info['score_info'][2]:0; ?></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="contextual-progress" style="position: relative; margin:14px auto;">
                                    <span class="font-size-12" style="position:absolute;left: 0;top: -8px;">1</span>
                                    <div class="progress margin-left-15" data-goal="60" data-plugin="progress"
                                         style="background:#d8d8d8;">
                                        <div class="progress-bar progress-bar-indicating active" aria-valuemin="15"
                                             aria-valuemax="115" aria-valuenow="25" role="progressbar"
                                             style="width:<?php echo array_key_exists('total_count', $product_info['score_info']) && $product_info['score_info']['total_count']?round((int)str_replace(',', '', $product_info['score_info']['1']) / (int)str_replace(',', '', $product_info['score_info']['total_count']), 2) * 100:0; ?>%;background:#707070;">
                                            <span
                                                class="progress-label"><?php echo $product_info['score_info']?$product_info['score_info'][1]:0; ?></span>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <div class="nav-tabs-horizontal">
            <div class="clearfix margin-bottom-20">
                <!--<ul class="nav nav-tabs pull-left" style="border-bottom:none;">
                    <li class="active" role="presentation"><a data-toggle="tab" href="#exampleTabsOne"
                                                              aria-controls="exampleTabsOne" role="tab">Offers</a></li>
                    <li role="presentation"><a data-toggle="tab" href="#exampleTabsTwo" aria-controls="exampleTabsOne"
                                               role="tab">Item1</a></li>
                   <!-- <li><a data-toggle="tab" href="javascript:void(0)">Item2</a></li>
                    <li><a data-toggle="tab" href="javascript:void(0)">Item3</a></li>-->
                <!--                </ul>-->
                <!--<div class="pull-right" style="overflow:hidden;">
                    <div class="pull-left margin-top-10">
                        <span class="icondemo margin-right-10 font-size-18" style="cursor: pointer;">
                            <i class="wb-grid-4" aria-hidden="true"></i>
                        </span>
                        <span class="icondemo margin-right-10 font-size-18" style="cursor: pointer;">
                            <i class="wb-list" aria-hidden="true"></i>
                        </span>
                    </div>
                    <div class="pull-left margin-top-3">
                        <div class="input-search margin-0">
                            <i class="input-search-icon wb-search" aria-hidden="true"></i>
                            <input type="text" class="form-control" name="" placeholder="Search...">
                            <button type="button" class="input-search-close icon wb-close" aria-label="Close"></button>
                        </div>
                    </div>
                </div>-->
            </div>
            <div class="tab-content padding-top-20">
                <div class="tab-pane active" id="exampleTabsOne" role="tabpanel">
                    <!-- 卡片列表 每行一个-->
                    <div>
                        <?php if ($list): ?>
                            <?php foreach ($list as $item): ?>
                                <div class="panel panel_box">
                                    <div class="panel-body container-fluid padding-0 bg_color"
                                         style="position: relative;padding-bottom:54px!important;">
                                        <div class="col-md-12 padding-horizontal-0">
                                            <div class="col-md-10 height_standard">
                                                <div class="ribbon ribbon-badge ribbon-danger">
                                                    <!--                                                <span class="ribbon-inner">Hot</span>-->
                                                </div>
                                                <div
                                                    style="border-bottom:1px solid #eee; width:92%; margin:0 auto 20px;">
                                                    <h3 class="panel-title padding-bottom-15 inline-block padding-right-10 font-weight-600 padding-left-0"
                                                        style="color:#3b434a; font-size:32px;"><?php if ($item['specific_payout']): ?>
                                                            $<?php echo $item['specific_payout']['payout']; ?>
                                                        <?php else: ?>
                                                            $<?php echo sprintf("%.2f", $item['current']['cpa']); ?>
                                                        <?php endif; ?>
                                                        <span
                                                            class="font-weight-300">-<?php if ($item['country_size'] <= 5 && $item['country_size'] > 0): ?>
                                                                <?php echo implode(',', $item['countries']) ?>
                                                            <?php elseif ($item['country_size'] == 0): ?>
                                                                All Countries
                                                            <?php else: ?>
                                                                <?php echo count($item['countries']) . ' Countries'; ?>
                                                            <?php endif; ?></span></h3>
                                                    <p class="pull-right margin-top-20">
                                                    <span class="margin-right-15" style="color:#f96868;">
                                                        <?php if ($item['next_status']) {
                                                            if ($item['next_status']['status'] == 0) {
                                                                echo "Will pause at:" . date('m/d/Y H:i a', $item['next_status']['effective_time']);
                                                            } elseif ($item['next_status']['status'] == -1) {
                                                                echo "Will delete at:" . date('m/d/Y H:i a', $item['next_status']['effective_time']);
                                                            } elseif ($item['next_status']['status'] == 1) {
                                                                echo "Will start at:" . date('m/d/Y H:i a', $item['next_status']['effective_time']);
                                                            }
                                                        }; ?></span>
                                                        <span class="inline-block font-size-16"
                                                              style="margin-bottom: -5px;">#<?php echo $item['offer_id']; ?></span>
                                                    </p>
                                                </div>
                                                <div class="padding-left-40 table-responsive clearfix">
                                                    <div class="col-sm-8 padding-left-0">
                                                        <div class="table_box" style="height:70px;overflow:hidden;">
                                                            <div class="font-weight-600" style="color:#454d54;">
                                                                Schedule
                                                            </div>
                                                            <?php if ($item['schedules']): ?>
                                                                <table class="table">
                                                                    <thead>
                                                                    <tr>
                                                                        <th style="width:20%;">Effective time</th>
                                                                        <th style="width:15%;">Payout</th>
                                                                        <th style="width:35%;">Retention</th>
                                                                    </tr>
                                                                    </thead>
                                                                    <tbody>
                                                                    <?php foreach ($item['schedules'] as $schedule): ?>
                                                                        <tr>
                                                                            <td><?php echo date('m/d/Y g:i a', $schedule['start_time']) ?></td>
                                                                            <td>$<?php echo $schedule['cpa'] ?></td>
                                                                            <?php if ($schedule['category'] == 1): ?>
                                                                                <td>
                                                                                    <?php if ($item['specific_payout']): ?>
                                                                                        <?php echo "Specific"; ?>
                                                                                    <?php else: ?>
                                                                                        <?php echo $config_product['offer_category'][$item['current']['category']]; ?>
                                                                                    <?php endif; ?>
                                                                                    <strong>$<?php echo $schedule['cpa'] ?></strong>
                                                                                </td>
                                                                            <?php elseif ($schedule['category'] == 2): ?>
                                                                                <td>
                                                                                    <?php if ($item['specific_payout']): ?>
                                                                                        <?php echo "Specific"; ?>
                                                                                    <?php else: ?>
                                                                                        <?php echo $config_product['offer_category'][$item['current']['category']]; ?>
                                                                                    <?php endif; ?>
                                                                                    <?php foreach ($schedule['value'] as $val): ?>
                                                                                        <?php echo "If RT > <strong>" . $val['retention_rate'] . "%</strong>, "; ?>
                                                                                        <?php echo "Payout will be <strong>" . $val['payout_rate'] . "%</strong> = "; ?>
                                                                                        <?php echo "<strong>$" . $val['payout'] . "</strong><br>"; ?>
                                                                                    <?php endforeach; ?>
                                                                                </td>
                                                                            <?php else: ?>
                                                                                <td>
                                                                                    <?php if ($item['specific_payout']): ?>
                                                                                        <?php echo "Specific"; ?>, 
                                                                                    <?php else: ?>
                                                                                        <?php echo $config_product['offer_category'][$item['current']['category']]; ?>, 
                                                                                    <?php endif; ?>
                                                                                        Payout will be proportional to the
                                                                                        retention rate.<br/>
                                                                                        If RR >= <strong><?php echo $schedule['value'] ?>%</strong>, Full Payout.<br/>

                                                                                        If RR < <strong><?php echo $schedule['value'] ?>%</strong>, Payout = RR / <strong><?php echo $schedule['value'] ?>%</strong> * Full Payout.
                                                                                            
                                                                                        <!-- Payout will be proportional to the
                                                                                        retention rate.<br/>
                                                                                        If RR >
                                                                                    <strong><?php echo $schedule['value'] ?>
                                                                                        %</strong>, Full Payout.<br/>
                                                                                    If RR = x, payout =
                                                                                    x/<strong><?php echo $schedule['value'] ?>
                                                                                        %</strong>*Full Payout. -->
                                                                                </td>
                                                                            <?php endif; ?>
                                                                        </tr>
                                                                    <?php endforeach; ?>
                                                                    </tbody>
                                                                </table>
                                                            <?php else: ?>
                                                                <div class="font-size-16">None</div>
                                                            <?php endif; ?>
                                                        </div>
                                                        <div class="font-weight-600" style="color:#454d54;">Countries
                                                        </div>
                                                        <p class="p_height" style="height: 24px;overflow: hidden;"
                                                           data-content="<?php echo $item['countries']?implode(', ', $item['countries']):'All Countries'; ?>">
                                                            <strong><?php if ($item['choose_type'] == 'include'): ?>
                                                                    <span class="label label-table label-success">Include</span>
                                                                <?php else: ?>
                                                                    <span
                                                                        class="label label-table label-danger">Exclude</span>
                                                                <?php endif; ?>: </strong>
                                                            <?php $all_countries='';
                                                            foreach ($item['countries_info'] as $k=>$val): ?>
                                                                <?php $all_countries.=implode(' - ', $val) . '　'; ?>
                                                            <?php endforeach; ?>
                                                            <?php echo trim($all_countries, ','); ?>
                                                        </p>
                                                    </div>
                                                    <div class="col-sm-4 padding-left-0">
                                                        <div class="font-weight-600" style="color:#454d54;">Quality
                                                            Control
                                                        </div>
                                                        <?php if ($item['current']): ?>
                                                            <div class="clearfix margin-top-5">
                                                                <strong
                                                                    class="pull-left margin-right-20 font-weight-300">
                                                                    <?php
                                                                    if ($item['specific_payout']) {
                                                                        echo "Specific";
                                                                    } else {
                                                                        echo $config_product['offer_category'][$item['current']['category']];
                                                                    }
                                                                    ?></strong>
                                                                <p class="pull-left">

                                                                    <?php if ($item['current']['category'] == 2): ?>
                                                                    <?php foreach ($item['current']['value'] as $val): ?>
                                                                    <span
                                                                        class="block"><?php echo "If RT > <strong>" . $val['retention_rate'] . "%</strong>, "; ?>
                                                                        <?php echo "Payout will be <strong>" . $val['payout_rate'] . "%</strong> = "; ?>
                                                                        <strong><?php echo "$" . $val['payout']; ?></strong>
                                                                        <?php endforeach; ?>
                                                                        <?php elseif ($item['current']['category'] == 1): ?>
                                                                            <strong>$<?php echo $item['current']['cpa'] ?></strong>
                                                                        <?php else: ?>
                                                                            <span class="block">Payout will be proportional to the retention rate.</span>
                                                                            <span
                                                                                class="block">If RR >= <strong><?php echo $item['current']['value'] ?>%</strong>, Full Payout.</span>
                                                                            <span
                                                                                class="block">If RR < <strong><?php echo $item['current']['value'] ?>%</strong>, Payout = RR / <strong><?php echo $item['current']['value'] ?>%</strong> * Full Payout.</span>
                                                                        <?php endif; ?>

                                                        </span>
                                                            </div>
                                                        <?php else: ?>
                                                            <div class="font-size-16">None</div>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-2 text-center right_box padding-bottom-20"
                                                 style="height:284px;overflow:hidden;background:#fbfbfb;position:relative;margin-bottom: -54px;">

                                                <p class="col-md-10 col-md-offset-1 padding-vertical-5 margin-bottom-0"
                                                   style="border-bottom:1px solid #e7e7e7;margin-top:20px;padding-bottom: 12px!important;">
                                                    <span class="font-size-12 block"
                                                          style="color:#3B434A;">Status</span>

                                                    <?php if($item['status']==-2):?>
                                                        <span class="font-size-12 block" style="color:#5EA1FE;">Pending</span>
                                                    <?php elseif($item['status']==1):?>
                                                        <span class="font-size-12 block" style="color:#9adc51;">Started</span>
                                                    <?php elseif($item['status']==0):?>
                                                        <span class="font-size-12 block" style="color:#79848E;">Paused</span>
                                                    <?php elseif($item['status']==-1):?>
                                                        <span class="font-size-12 block" style="color:#9adc51;">Deleted</span>
                                                    <?php endif;?>

                                                </p>
                                                <p class="col-md-10 col-md-offset-1 padding-bottom-5 padding-top-10"
                                                   style="border-bottom:1px solid #e7e7e7;">
                                                    <span class="font-size-12 block"
                                                          style="color:#3B434A;"> Caps </span>
                                                    <?php if ($item['cap']): ?>
                                                        <span class="font-size-12 block"
                                                              style="color:#3B434A;"><?php echo $item['cap']; ?></span>
                                                    <?php else: ?>
                                                        <span class="font-size-12 block"
                                                              style="color:#79848e;">No caps</span>
                                                    <?php endif; ?>
                                                </p>
                                                <?php if ($this->userinfo['type'] == 2): ?>
                                                    <?php if (isset($publisher_offer_account[$item['offer_id']]) && in_array($item['offer_id'], $apply_publisher_offer)): ?>
                                                        <?php if ($publisher_offer_account[$item['offer_id']]['status'] == 0): ?>
                                                            <button type="button"
                                                                    style="background:#FF6477; outline:none; border:0;"
                                                                    class="btn btn-success margin-top-20">Applied
                                                            </button> <!--Applied  - 已申请-->
                                                        <?php elseif ($publisher_offer_account[$item['offer_id']]['status'] == 1): ?>
                                                            <button type="button"
                                                                    style="background:#B0BDC6; outline:none; border:0;"
                                                                    class="btn  btn-success margin-top-20">Approved
                                                            </button><!--Approved  - 已批准-->
                                                        <?php else: ?>
                                                            <button type="button"
                                                                    style="background:#dedede; outline:none; border:0;"
                                                                    class="btn disabled btn-success margin-top-20">
                                                                Disapproved
                                                            </button>   <!-- 拒绝-->
                                                        <?php endif; ?>
                                                    <?php else: ?>
                                                        <button type="button"
                                                                style="background:#12abc5; outline:none; border:0;"
                                                                class="btn btn_self btn-success apply_offer_modal margin-top-20"
                                                                data-product-name="<?php echo $item['product_name']; ?>"
                                                                data-target="#product_apply_offer" data-toggle="modal"
                                                                data-id="<?php echo $item['offer_id'] ?>"
                                                                data-country="<?php echo $item['countries']?implode(', ', $item['countries']):'All Countries'; ?>"
                                                                data-include="<?php echo $item['choose_type'] ?>"
                                                                data-product-id="<?php echo $item['product_id']; ?>">
                                                            Apply
                                                        </button>  <!--Need Approval   - 需要审批-->
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <p class="text-center p_list_show margin-top-20" data-term="false"
                                           style="cursor: pointer;position: absolute; left: 50%;margin-left: -18px;bottom: 20px;"
                                           data-topsrc="<?php echo base_url(); ?>assets/images/top_pic.png"
                                           data-bottomsrc="<?php echo base_url(); ?>assets/images/bottom_pic.png">
                                            <img src="<?php echo base_url(); ?>assets/images/bottom_pic.png">
                                        </p>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else:?>
                            <div class="panel margin-bottom-0 height-500">
                                <div class="text-center padding-top-80">
                                    <img src="<?php echo base_url(); ?>assets/images/no_data.png">
                                    <h4 class="margin-top-30">NO DATA HERE</h4>
                                    <p style="line-height: 18px;">I hate peeping Toms. For one thing they usually step all over<br>the hedges and plants on the side of someone's house killing</p>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="tab-content padding-top-20"></div>
                </div>
                <div class="tab-pane height-300" id="exampleTabsTwo" role="tabpanel" style="background:#fff;"></div>
            </div>
        </div>
    </div>
</div>
<?php echo $product_detail_apply_offer; ?>
<!-- 新加js -->
<script src="<?php echo base_url(); ?>assets/web/global/vendor/datatables/jquery.dataTables.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/vendor/webui-popover/jquery.webui-popover.min.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/vendor/toolbar/jquery.toolbar.min.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/vendor/editable-table/mindmup-editabletable.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/vendor/editable-table/numeric-input-example.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/js/components/bootstrap-sweetalert.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/js/components/toastr.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/js/components/select2.min.js"></script>
<script src="<?php echo base_url(); ?>assets/web/assets/examples/js/advanced/bootbox-sweetalert.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/vendor/select2/select2.min.js"></script>
<!-- 新加js -->
<script src="<?php echo base_url(); ?>assets/web/global/js/components/datatables.js"></script>
<script src="<?php echo base_url(); ?>assets/web/assets/examples/js/tables/datatable.js"></script>
<script src="<?php echo base_url(); ?>assets/web/assets/examples/js/uikit/icon.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/js/components/masonry.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/js/components/webui-popover.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/js/components/toolbar.js"></script>
<script src="<?php echo base_url(); ?>assets/web/assets/examples/js/uikit/tooltip-popover.js"></script>
<script src="<?php echo base_url(); ?>assets/js/new_js.js"></script>
