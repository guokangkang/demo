<div class="modal fade" id="product_apply_offer" aria-hidden="false" aria-labelledby="add_bucket_Label" role="dialog" tabindex="-1">
    <div class="modal-dialog">
    <form class="modal-content add_bucket_form" autocomplete="off" id="my_form3"  method="post" action="<?php echo site_url('product/apply_offer_action')?>">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
                <h4 class="modal-title" id="add_bucket_Label">Apply Offer</h4>
            </div>
            <input type="hidden" name="offer_id" value="">
            <input type="hidden" name="product_id" value="<?php echo $product_info['product_id']?>">
            <div class="modal-body">
                <div class="row">
                    <div class="col-lg-6 form-group apply_offer_id_model">
                        <label class="control-label" for="select_country">    Product Name(ID)
                            
                        </label>
<!--                        <div class="input-group bootstrap-touchspin">-->
<!--                            <p>--><?php //echo $product_info['name']?><!--</p>-->
<!--                        </div>-->
                        <div class="inline-block input-group bootstrap-touchspin apply_offer_id">

                        </div>
                    </div>

                    <div class="col-lg-12 form-group apply_country_model">
                        <label class="control-label" for="select_country">   Countries (Include)
                        </label>
                        <div class="input-group bootstrap-touchspin apply_offer_country">
                            
                        </div>
                    </div>

                    <div class="col-lg-12 form-group">
                        <label class="control-label" for="select_country">    Account
                        <span class="required">*</span>
                        </label>
                        <select  class="form-control offer_account_select" multiple="" data-plugin="select2" name="apply_account[]" data-placeholder="All Accounts">
                            <?php foreach($accountlist as $key=>$val):?>
                                <option value="<?php echo $val['market_account_id']?>" ><?php echo '('.$val['account_id'].') '.$val['account_name']?></option>
                            <?php endforeach;?>
                        </select>
                    </div>

                    <div class="col-lg-12 form-group">
                        <label class="control-label" for="select_country">    Note
                            <!-- <span class="required">*</span> -->
                        </label>
                        <textarea class="form-control apply_offer_note" name="note" placeholder=""></textarea>
                    </div>

                    <div class="col-sm-12 pull-right">
                        <button type="submit" id="my_val3" class="btn btn_self btn-success pull-right" style="background:#12abc5; outline:none; border:0;">APPLY </button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>