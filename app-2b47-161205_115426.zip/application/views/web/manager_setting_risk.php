<!-- 新加css -->
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/location.default.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/select2/select2.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/owl-carousel/owl.carousel.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/slick-carousel/slick.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/assets/examples/css/uikit/carousel.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/webui-popover/webui-popover.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/formvalidation/formValidation.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/assets/examples/css/forms/validation.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/toolbar/toolbar.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/assets/examples/css/uikit/buttons.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/icheck/icheck.css">
<style>
    .red_color{color:red!important;}
    .red_orange{color:orange!important;}
    .table>tbody>tr>td{vertical-align: middle;}
    .table>.no_border>tr>td{ border-top: none; font-size: 18px;}
    @media screen and (max-width: 767px){
        .table-responsive{
            border: none;
        }
        .slide_right{top:60px!important;}
    }
    .span_block{ position:relative; }
    .span_block span{display: block; width: 100%; height: 100%;}
    .span_block input{display: none;}
    .span_block input.active{display: block; position: absolute; left: 0; top: 0;}
    .change_btn{padding:2px;font-size:12px;margin-top:-6px;margin-left:5px;}
    .overlay figcaption .btn{ margin-left:4px;}
    .tools_btn .btn{margin-right: 2px!important; padding: 7px!important; font-size: 12!important;}
    .panel-actions{z-index: 0!important;}
    .exampleVariableWidth img{border-top:none;border-bottom:none;}
    .exampleVariableWidth{margin:0;}
    .exampleVariableWidth .slick-prev {left: 4px;z-index: 12;}
    .exampleVariableWidth .slick-next {right: 4px;}
    .exampleVariableWidth .slick-list,.exampleVariableWidth .slick-track,.exampleVariableWidth .slick-slide,.exampleVariableWidth .slick-slide img{height: 100%;}
    .select2-search__field{width: 200px!important;}

    input[type="text"]:focus{border:1px solid #12abc5;}
</style>
<div class="page animsition">
    <div class="page-header">
        <h1 class="page-title">Risk</h1>
        <ol class="breadcrumb">
            <li><a href="../index.html">Setting</a></li>
            <li class="active">Review</li>
        </ol>
    </div>
    <div class="page-content"> 
        <div class="row">
            <div class="clearfix visible-md-block visible-lg-block"></div>
            <div class="col-md-12">
                <div class="panel">
                    <div class="panel-heading" style="position:relative;">
                        <h3 class="panel-title">预警配置</h3>
                    </div>
                    <div class="panel-body">
                        <form class="form-horizontal" action="<?php echo site_url('/manager/setting/risk_save');?>" method="post" id="val_form">
                            <div class="example table-responsive" style="margin-bottom:0;margin-top:0;">
                                <div class="col-md-10 col-md-offset-2">
                                    <div class="col-md-2">
                                        <div class="example-wrap margin-bottom-20">
                                            <div class="example">
                                                <div class="form-group filter-form advertiser-filter" style="margin-bottom:10px;">
                                                    <label class="control-label">监控波动值</label>
                                                </div>

                                                <div class="form-group">
                                                    <span class="control-label" style="line-height:36px;">CTR</span>
                                                </div>
                                                 <div class="form-group">
                                                    <span class="control-label" style="line-height:36px;">CVR</span>
                                                </div>
                                               
                                                 <div class="form-group">
                                                    <span class="control-label" style="line-height:36px;">Clicks</span>
                                                </div>
                                                <div class="form-group">
                                                    <span class="control-label" style="line-height:36px;">Spend</span>
                                                </div>
                                                <div class="form-group">
                                                    <span class="control-label" style="line-height:36px;">Results</span>
                                                </div>
                                                <div class="form-group">
                                                    <span class="control-label" style="line-height:36px;">Likes</span>
                                                </div>
                                                <div class="form-group">
                                                    <span class="control-label" style="line-height:36px;">Shares</span>
                                                </div>
                                                <div class="form-group">
                                                    <span class="control-label" style="line-height:36px;">Comments</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-md-3">
                                        <div class="example-wrap margin-bottom-20">
                                            <div class="example">
                                                   
                                                    <div class="form-group filter-form advertiser-filter" style="margin-bottom:12px;">
                                                        <label class="control-label">绝对值</label>
                                                    </div>
                                                    <div class="form-group">
                                                        <label class="col-sm-1 control-label"> &ge; </label>
                                                        <div class="col-sm-9">
                                                            <input type="text" name="ctr[value]" class="form-control"  placeholder="placeholder" id="inputPercent"  value="0">
                                                        </div>
                                                        <label class="control-label"> % </label>
                                                    </div>
                                                     <div class="form-group">
                                                        <label class="col-sm-1 control-label"> &ge; </label>
                                                        <div class="col-sm-9">
                                                            <input type="text" name="cvr[value]" class="form-control inline-block"  style="width:100%;" placeholder="placeholder" id="inputPercent" value="0">
                                                        </div>
                                                        <label class="control-label"> % </label>
                                                    </div>
                                                    
                                                    <div class="form-group">
                                                        <label class="col-sm-1 control-label"> &ge; </label>
                                                        <div class="col-sm-9">
                                                            <input type="text" name="clicks[value]" class="form-control inline-block"  style="width:100%;" placeholder="placeholder" id="inputPercent"  value="0">
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label class="col-sm-1 control-label"> &ge; </label>
                                                        <div class="col-sm-9">
                                                            <input type="text" name="spend[value]" class="form-control inline-block"  style="width:100%;" placeholder="placeholder" id="inputPercent"  value="0">
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label class="col-sm-1 control-label"> &ge; </label>
                                                        <div class="col-sm-9">
                                                            <input type="text" name="results[value]" class="form-control inline-block"  style="width:100%;" placeholder="placeholder" id="inputPercent"  value="0">
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label class="col-sm-1 control-label"> &ge; </label>
                                                        <div class="col-sm-9">
                                                            <input type="text" name="likes[value]" class="form-control inline-block"  style="width:100%;" placeholder="placeholder" id="inputPercent"  value="0">
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label class="col-sm-1 control-label"> &ge; </label>
                                                        <div class="col-sm-9">
                                                            <input type="text" name="shares[value]" class="form-control inline-block"  style="width:100%;" placeholder="0" id="inputPercent"  value="0">
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label class="col-sm-1 control-label"> &ge; </label>
                                                        <div class="col-sm-9">
                                                            <input type="text" name="comments[value]" class="form-control inline-block" id="inputPercent" data-plugin="formatter"  value="0" data-pattern="{{9999999999}}" style="width:100%;" placeholder="0">
                                                        </div>
                                                    </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                            <div class="col-md-8 col-md-offset-2">
                                <div class="col-md-2"></div>
                                <div class="col-md-4">
                                    <input type="submit" class="btn btn-outline btn-primary" id="val_btn" value="Submit" />
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="panel">
                    <div class="panel-body">
                        <div class="row row-lg">
                            <?php foreach($result as $item):?>
                            <div class="col-md-3">
                                <table class="table">
                                    <thead>
                                      <tr>
                                        <th>监控波动值
                                        </th>
                                        <th>
                                            绝对值
                                            <a style="padding-bottom: 0;padding-top: 0" href="###" data-val="<?php echo $item['setting_id']?>" class="btn btn-sm btn-icon btn-pure btn-default on-default remove-row remove-review-risk-setting" data-toggle="tooltip" data-original-title="Remove"><i class="icon wb-trash" aria-hidden="true"></i></a>
                                        </th>
                                      </tr>
                                    </thead>
                                    <tbody>
                                        
                                        <?php foreach($item['content'] as $k=>$v):?>
                                            <tr>
                                                <td><?php echo $fields[$k]?></td>
                                                <td>
                                                    &ge;
                                                    <?php 
                                                        if ($k=='ctr' || $k=='cvr') {
                                                            echo $v."%";
                                                        }else{
                                                            echo $v;
                                                        }
                                                    ?>
                                                </td>
                                            </tr>
                                        <?php endforeach;?>
                                        
                                    </tbody>
                                  </table>
                            </div>
                            <?php endforeach;?>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="<?php echo base_url();?>assets/web/global/vendor/icheck/icheck.min.js"></script>
<!-- 新加的js -->
<script src="<?php echo base_url();?>assets/web/global/js/components/owl-carousel.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/components/panel.js"></script>
<script src="<?php echo base_url();?>assets/web/assets/examples/js/uikit/panel-actions.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/slidepanel/jquery-slidePanel.js"></script>
<script src="<?php echo base_url();?>assets/js/new_js.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/formvalidation/formValidation.min.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/formvalidation/framework/bootstrap.min.js"></script>
<script src="<?php echo base_url();?>assets/js/val.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/webui-popover/jquery.webui-popover.min.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/toolbar/jquery.toolbar.min.js"></script> 
<script src="<?php echo base_url();?>assets/web/global/js/components/webui-popover.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/components/buttons.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/components/icheck.js"></script>