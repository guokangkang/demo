
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/formvalidation/formValidation.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/assets/examples/css/forms/validation.css">

<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/bootstrap-datepicker/bootstrap-datepicker.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/jt-timepicker/jquery-timepicker.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/select2/select2.css">

<style>
    .nav-tabs>li.active>a{
        color: #fff;
        background-color:#12abc5!important;
        border-color:transparent;
        border-bottom-color:#12abc5!important;
    }   
    .nav-tabs>li.active>a:hover{ 
        color: #fff;
        background-color:#0890a7;
        border-color:transparent;
        border-bottom-color:#0890a7;
    }
    .nav-tabs>li>a{
        color: #707070;
        background-color:#fff;
        border:1px solid #ebebeb;
    }
    .nav-tabs>li>a:hover{
        color: #fff;
        background-color:#0890a7;
        border-color:transparent;
        border-bottom-color:#0890a7;
    }
    .dropdown-toggle:hover{
        color: #fff;
        background-color:#0890a7;
        border-color:transparent;
        border-bottom-color:#0890a7;
    }
    .nav .open>a{
        color: #fff;
        background-color:#12abc5!important;
        border-color:transparent;
        border-bottom-color:#12abc5!important;
    }
    .nav-tabs>li>a{margin-right: -1px;}  
    @media (max-width: 767px) {
        .padding_right{padding-right: 40px!important}
    }
    @media (max-width:476px) {
        .xs_row{margin-left: -6px;margin-right: -35px!important;}
    }
    @media (min-width:992px) {
        .bg_color{background: -webkit-linear-gradient(left,#fff 83%, #fbfbfb 80%);}
    }
    .review_search{border: 1px solid #12abc5; color:#12abc5!important; background-color: #fff;}
    .red_btn{border: 1px solid #ff6477; color: #ff6477!important;}
    .red_btn:hover{background:#ff6477; color: #fff!important;}
</style>
<div class="page animsition">
    <div class="page-header clearfix">        
        <ol class="breadcrumb">
            <li><a href="<?php echo site_url('manager/product/listview')?>">Manager Management</a></li>
            <li><a href="<?php echo site_url('manager/product/listview')?>"><?php echo $product_info['name']?></a></li>
            <li><a href="<?php echo site_url('manager/offer/listview?product='.$product_info['product_id'])?>">Offers</a></li>
            <li class="active">Detail</li>
        </ol>    
    </div>
    <div class="page-content"> 
        <div class="panel widget-border">
            <div class="panel-body padding-vertical-0 container-fluid bg_color">
                <div class="row xs_row" style="margin-right:-45px;">
                    <div class="col-md-2 col-xs-12 text-center padding-top-30 padding_right">
                        <img style="border:0" class="img img-thumbnail" src="<?php echo $product_info['logo']?>" >
                    </div>
                    <div class="col-md-8 col-xs-12 padding-top-30 padding-bottom-30 padding_right">
                        <div class="clearfix">
                            <div class="pull-left">
                                <h3 class="panel-title padding-0 inline-block vertical-align-middle font-size-18" style="color:#3b434a;"><?php echo $product_info['name']?></h3>
                                <span class="label label-sm label-success inline-block"><?php echo strtoupper($product_info['category'])?></span>
                            </div>
                            <p class="pull-right margin-vertical-0 padding-right-30">
                                <span class="inline-block font-size-16" style="margin-bottom: -5px;">#<?php echo $product_info['product_id']?></span>
                            </p>
                        </div>
                        <p class="margin-bottom-0">CPA : <?php echo $offer_cpa['current']?"$".$offer_cpa['current']['cpa']:'-'?></p>
                        <p class="margin-bottom-10 padding-right-20" style="color:#79848e; height:110px;overflow:hidden;"><strong style="color:#454d54; ">Description</strong> : <?php echo $product_info['description']?></p>
                        <p class="margin-bottom-10 padding-right-20" style="color:#79848e;"><strong style="color:#454d54; ">
                            Countries <?php echo ucfirst($offer_info['choose_type'])?></strong> : 
                            <?php if($offer_info['countries']):foreach($offer_info['countries'] as $c):?>
                                <?php echo $c.' - '.$config_product['countries'][$c];?>
                            <?php endforeach;else:?>
                                All Countries
                            <?php endif;?>
                        </p>
                    </div>
                    <div class="col-md-2 col-xs-12 text-center padding-top-30" style="background:#fbfbfb; margin-left:-15px;">
                        <p class="col-md-10 col-md-offset-1 padding-vertical-5 margin-bottom-0" style="border-bottom:1px solid #e7e7e7;margin-top:20px;padding-bottom: 12px!important;">
                            <span class="font-size-12 block" style="color:#3B434A;">Status</span>
                            <?php if(!$offer_cpa['current'] || $offer_info['status']==-2):?>
                                <span class="font-size-12 block" style="color:#5EA1FE;">Pending</span>
                            <?php elseif($offer_info['status']==1):?>
                                <span class="font-size-12 block" style="color:#9adc51;">Started</span>
                            <?php elseif($offer_info['status']==0):?>
                                <span class="font-size-12 block" style="color:#79848E;">Paused</span>
                            <?php elseif($offer_info['status']==-1):?>
                                <span class="font-size-12 block" style="color:#9adc51;">Deleted</span>
                            <?php endif;?>
                        </p>
                        <p class="col-md-10 col-md-offset-1 padding-bottom-5 padding-top-20 margin-bottom-0" style="border-bottom:1px solid #e7e7e7;padding-bottom: 20px!important;">
                            <span class="font-size-12 block" style="color:#3B434A;">Caps</span>
                            <span class="font-size-12 block" style="color:#79848e;">No caps</span>
                        </p>
                        <p class="col-md-10 col-md-offset-1 padding-bottom-5 padding-top-20" style="padding-bottom: 20px!important;">
                            <span class="font-size-12 block" style="color:#3B434A;">RPA</span>
                            <span class="font-size-12 block" style="color:#79848e;">$ <?php echo $offer_info['rpa']?></span>
                        </p>
                    </div>
                </div>
            </div>
        </div>

        <div class="nav-tabs-horizontal">
            <div class="clearfix">
                <ul class="nav nav-tabs pull-left" data-plugin="nav-tabs" role="tablist" style="border-bottom:none;">
                    <li class="active" role="presentation"><a data-toggle="tab" href="#exampleTabsOne" aria-controls="exampleTabsOne" role="tab">Event</a></li>
                    <li role="presentation"><a data-toggle="tab" href="#exampleTabsTwo" aria-controls="exampleTabsOne" role="tab">Countries</a></li>
                    <li role="presentation"><a data-toggle="tab" href="#exampleTabsThree" aria-controls="exampleTabsThree" role="tab">CPA</a></li>
                    <li role="presentation"><a data-toggle="tab" href="#exampleTabsFour" aria-controls="exampleTabsFour" role="tab">RPA</a></li>
                    <li role="presentation"><a data-toggle="tab" href="#exampleTabsFive" aria-controls="exampleTabsFive" role="tab">CAP</a></li>
                    <li role="presentation"><a data-toggle="tab" href="#exampleTabsSix" aria-controls="exampleTabsSix" role="tab">Specific Payout</a></li>
                    <li role="presentation"><a data-toggle="tab" href="#exampleTabsSeven" aria-controls="exampleTabsSeven" role="tab">Specific CAP</a></li>
                    <li class="dropdown" role="presentation">
                        <a class="dropdown-toggle" data-toggle="dropdown" href="#" aria-expanded="false">
                        <span class="caret"></span>Menu </a>
                        <ul class="dropdown-menu" role="menu">
                            <li class="active" role="presentation"><a data-toggle="tab" href="#exampleTabsOne" aria-controls="exampleTabsOne" role="tab">Event</a></li>
                            <li role="presentation"><a data-toggle="tab" href="#exampleTabsTwo" aria-controls="exampleTabsOne" role="tab">Countries</a></li>
                            <li role="presentation"><a data-toggle="tab" href="#exampleTabsThree" aria-controls="exampleTabsThree" role="tab">CPA</a></li>
                            <li role="presentation"><a data-toggle="tab" href="#exampleTabsFour" aria-controls="exampleTabsFour" role="tab">RPA</a></li>
                            <li role="presentation"><a data-toggle="tab" href="#exampleTabsFive" aria-controls="exampleTabsFive" role="tab">CAP</a></li>
                            <li role="presentation"><a data-toggle="tab" href="#exampleTabsSix" aria-controls="exampleTabsSix" role="tab">Specific Payout</a></li>
                            <li role="presentation"><a data-toggle="tab" href="#exampleTabsSeven" aria-controls="exampleTabsSeven" role="tab">Specific CAP</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
            <div class="tab-content widget-border">
                <div class="tab-pane active" id="exampleTabsOne" role="tabpanel">
                    <?php echo $offer_detail_event?>
                </div>
                <div class="tab-pane" id="exampleTabsTwo" role="tabpanel">
                    <?php echo $offer_detail_country?>
                </div>
                <div class="tab-pane" id="exampleTabsThree" role="tabpanel">
                    <?php echo $offer_detail_cpa?>
                </div>
                <div class="tab-pane" id="exampleTabsFour" role="tabpanel">
                    <?php echo $offer_detail_rpa?>
                </div>
                <div class="tab-pane" id="exampleTabsFive" role="tabpanel">
                    <?php echo $offer_detail_cap?>
                </div>
                <div class="tab-pane" id="exampleTabsSix" role="tabpanel">
                    <?php echo $offer_detail_specific_payout?>
                </div>
                <div class="tab-pane" id="exampleTabsSeven" role="tabpanel">
                    <?php echo $offer_detail_specific_cap?>
                </div>
            </div>
        </div>   
    </div>
</div>




<script src="<?php echo base_url();?>assets/web/global/vendor/formvalidation/formValidation.min.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/formvalidation/framework/bootstrap.min.js"></script>

<script src="<?php echo base_url();?>assets/js/my_valiation.js"></script>

<script src="<?php echo base_url();?>assets/web/global/vendor/datatables/jquery.dataTables.js"></script>

<script src="<?php echo base_url();?>assets/web/global/js/components/datatables.js"></script>
<script src="<?php echo base_url();?>assets/web/assets/examples/js/tables/datatable.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/components/bootstrap-datepicker.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/bootstrap-datepicker/bootstrap-datepicker.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/jt-timepicker/jquery.timepicker.min.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/components/jt-timepicker.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/plugins/responsive-tabs.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/plugins/closeable-tabs.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/components/tabs.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/select2/select2.min.js"></script>  
<script src="<?php echo base_url();?>assets/web/global/js/components/select2.js"></script>






