<link rel="stylesheet" href="<?php echo base_url();?>assets/web/assets/examples/css/advanced/masonry.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/select2/select2.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/bootstrap-select/bootstrap-select.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/bootstrap-datepicker/bootstrap-datepicker.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/fonts/material-design/material-design.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/assets/examples/css/uikit/icon.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/footable/footable.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/daterangepicker.css" />
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/index_select.css">
<div class="page animsition">
    <div class="page-header">
        <ol class="breadcrumb">
            <li><a href="<?php echo site_url('report/index');?>" style="text-decoration:none;">Reports</a></li>
            <li class="active">Retention</li>
        </ol>
    </div>
    <div class="page-content blue-grey-500">
        <!-- 过滤条件 -->
        <div class="row" >
            <div class="clearfix visible-md-block visible-lg-block"></div>
            <div class="col-md-12">
                <div class="panel" style="border:1px solid #ebebeb;box-shadow:none;">
                    <div class="panel-heading">
                        <h3 class="panel-title">Filter</h3>
                        <div class="panel-actions">
                            <a class="panel-action icon wb-minus" data-toggle="panel-collapse" aria-hidden="true"></a>
                        </div>
                    </div>
                    <div class="panel-body">
                        <div class="example" style="margin-bottom: 0; margin-top: 0;">
                            <div class="col-md-4">
                                <div class="example-wrap margin-bottom-30">
                                    <div class="example">
                                        <form>
                                            <div class="diy_select filter-form advertiser-filter form-group">
                                                <!--【存】当前选中的值-->
                                                <input type="hidden" name="" class="diy_select_input filter_country" value="<?php echo $country_params?implode(',',$country_params).',':'';?>">
                                                <!--【显示】当前选中的值-->
                                                <input type="text" class="diy_select_txt filter_input_1" placeholder="<?php echo count($country_params)?count($country_params).' items selected':'Country';?>">
                                                <!--下拉三角形-->
                                                <span class="caret" style="right: 14px;position: absolute;top: 50%;margin-top: -2px;"></span>
                                                <!--数据列表-->
                                                <ul class="diy_select_list" style="display:none;" id="radiao_box_1">
                                                    <?php if(isset($config_country)):?>
                                                        <?php foreach($config_country['country'] as $key=>$name):?>
                                                            <li data-key="<?php echo $key?>" <?php echo (in_array($key, $country_params))?"class='show_list'":''?>>
                                                                <span><?php echo $key.'-'.$name?></span>
                                                                <b class="icon wb-check check-mark"></b>
                                                            </li>
                                                        <?php endforeach;?>
                                                    <?php endif;?>
                                                </ul>
                                            </div>
                                            <!--<div class="form-group filter-form advertiser-filter" style="margin-bottom:15px;padding-left: 0;">
                                               <select class="form-control select2-hidden-accessible filter_country" multiple="" data-plugin="select2" tabindex="-1" aria-hidden="true" data-placeholder="Country">
                                                    <?php /*foreach($config_country['country'] as $key=>$name):*/?>
                                                        <option value="<?php /*echo $key*/?>" <?php /*echo (in_array("'".$key."'", $country_params))?"selected='selected'":''*/?>><?php /*echo $key.'-'.$name*/?></option>
                                                    <?php /*endforeach;*/?>
                                                </select>
                                            </div>-->


                                            <div class="diy_select filter-form advertiser-filter form-group">
                                                <!--【存】当前选中的值-->
                                                <input type="hidden" name="" class="diy_select_input filter_agency" value="<?php echo $agency_params?implode(',',$agency_params).',':''?>">
                                                <!--【显示】当前选中的值-->
                                                <input type="text" class="diy_select_txt filter_input_2" placeholder="<?php echo count($agency_params)?count($agency_params).' items selected':'Agency';?>">
                                                <!--下拉三角形-->
                                                <span class="caret" style="right: 14px;position: absolute;top: 50%;margin-top: -2px;"></span>
                                                <!--数据列表-->
                                                <ul class="diy_select_list" style="display:none;" id="radiao_box_2">
                                                    <?php if(isset($agency_list)):?>
                                                        <?php foreach($agency_list as $p):?>
                                                            <li data-key="<?php echo $p['publisher_id']?>"  <?php echo (in_array($p['publisher_id'], $agency_params))?"class='show_list'":''?>>
                                                                <span><?php echo $p['publisher_name']?></span>
                                                                <b class="icon wb-check check-mark"></b>
                                                            </li>
                                                        <?php endforeach;?>
                                                    <?php endif;?>
                                                </ul>
                                            </div>
                                            <!--<div class="form-group filter-form advertiser-filter" style="margin-bottom:15px;padding-left: 0;">
                                                <select class="form-control select2-hidden-accessible filter_agency" multiple="" data-plugin="select2" tabindex="-1" aria-hidden="true" data-placeholder="Agency">
                                                    <?php /*foreach($agency_list as $p):*/?>
                                                        <option value="<?php /*echo $p['publisher_id']*/?>" <?php /*echo (in_array($p['publisher_id'], $agency_params))?"selected='selected'":''*/?>><?php /*echo $p['publisher_name']*/?></option>
                                                    <?php /*endforeach;*/?>
                                                </select>
                                            </div>-->
                                        </form>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-4">
                                <div class="example-wrap margin-bottom-30">
                                    <div class="example">
                                        <form>
                                            <div class="diy_select filter-form advertiser-filter form-group">
                                                <!--【存】当前选中的值-->
                                                <input type="hidden" name="" class="diy_select_input filter_product" value="<?php echo $product_params?implode(',',$product_params).',':'';?>">
                                                <!--【显示】当前选中的值-->
                                                <input type="text" class="diy_select_txt filter_input_3" placeholder="<?php echo count($product_params)?count($product_params).' items selected':'Product';?>">
                                                <!--下拉三角形-->
                                                <span class="caret" style="right: 14px;position: absolute;top: 50%;margin-top: -2px;"></span>
                                                <!--数据列表-->
                                                <ul class="diy_select_list" style="display:none;" id="radiao_box_3">
                                                    <?php if(isset($product_list)):?>
                                                        <?php foreach($product_list as $p):?>
                                                            <li data-key="<?php echo $p['product_id']?>"  <?php echo (in_array($p['product_id'], $product_params))?"class='show_list'":''?>>
                                                                <span><?php echo $p['name']?></span>
                                                                <b class="icon wb-check check-mark"></b>
                                                            </li>
                                                        <?php endforeach;?>
                                                    <?php endif;?>
                                                </ul>
                                            </div>
                                            <!--<div class="form-group filter-form advertiser-filter" style="margin-bottom:15px;padding-left: 0;">
                                                <select class="form-control select2-hidden-accessible filter_product" multiple="" data-plugin="select2" tabindex="-1" aria-hidden="true" data-placeholder="Product">
                                                    <?php /*foreach($product_list as $p):*/?>
                                                        <option value="<?php /*echo $p['product_id']*/?>"><?php /*echo $p['name']*/?></option>
                                                    <?php /*endforeach;*/?>
                                                </select>
                                            </div>-->
                                        </form>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-1 text-center">
                                <span class="inline-block margin-top-20" style="width:1px; height:88px; border-right:1px dashed #d1d1d1;"></span>
                            </div>
                            <div class="col-md-3">
                                <div class="example-wrap">
                                    <div class="example">
                                        <form>  
                                            <div class="form-group col-lg-3 col-xlg-3 filter-form account-filter" style="margin-bottom:15px;padding-left: 0;text-align: center;">
                                                <div class="form-control" style="width: 225px;">
                                        
                                                    <div id="reportrange" class="pull-left">
                                                        <i class="glyphicon glyphicon-calendar fa fa-calendar"></i>&nbsp;
                                                        <span></span> <b class="caret"></b>

                                                        <input type="hidden" value="" class="date_start" />
                                                        <input type="hidden" value="" class="date_end" />
                                                    </div>
                                                </div>
                                            </div> 
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>   
                        <a  id="ad_list" name="ad_list"></a>                         
                        <div class="example example-buttons text-center margin-vertical-0">
                            <button type="button" class="btn btn-outline btn-primary report_agency_search">Search</button>

                            <button type="button" class="btn btn-outline btn-info report_agency_rest">Reset</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>  
        <!-- 列表 -->
        <div class="panel" style="border:1px solid #ebebeb;box-shadow:none;">
             <header class="panel-heading clearfix">
                <h3 class="panel-title pull-left">Details</h3>
                <!-- <div class="pull-right col-md-6 margin-top-15 padding-right-30">
                    <button type="button" class="pull-right btn hover_btn btn-outline btn-default"><i class="icon md-download" aria-hidden="true"></i> Export</button>
                </div> -->
            </header>
            <div class="panel-body table-responsive">
                <table id="exampleFooAddRemove" class="table toggle-circle" data-page-size="100">
                    <thead class="thead change_thead" id="thead"> 
                        <tr>
                           <!--  <th class="text-center">Agency</th>
                            <th class="text-center">Country</th>
                            <th class="text-center">Country RR</th>
                            <th class="text-center">Installs</th> -->
                            <th class="text-center">Agency</th>
                            <th class="text-center">Country</th>
                            <th class="text-center">Country RR</th>
                            <th class="text-center">Account</th>
                            <th class="text-center">Account RR</th>
                        </tr>
                    </thead>
                    <tbody class="tbody text-center">
                        <?php if($result):?>
                        <?php foreach($result as $item):?>
                            <?php foreach($item['item'] as $v):?>
                            <tr>
                                <td><?php echo $v['publisher_name']?></td>
                                <td><?php echo $v['country']." - ".$config_country['country'][$v['country']]?></td>
                                <td><?php echo sprintf("%.2f", $item['rate']*100)?>%</td>
                                <td><?php echo "(".$v['account_id'].")".$v['account_name']?></td>
                                <td><?php echo sprintf("%.2f", $v['rate']*100)?>%</td>
                                
                            </tr>
                            <?php endforeach;?>
                        <?php endforeach;?>
                        <?php else:?>
                            <tr>
                                <td colspan="5">
                                    <div class="panel margin-bottom-0 height-500">
                                        <div class="text-center padding-top-80">
                                            <img src="<?php echo base_url(); ?>assets/images/no_data.png">
                                            <h4 class="margin-top-30">NO DATA HERE</h4>
                                            <p style="line-height: 18px;">I hate peeping Toms. For one thing they usually step all over<br>the hedges and plants on the side of someone's house killing</p>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endif;?>
                    </tbody>
                    <tfoot>
                      <tr>
                        <td colspan="5">
                          <div class="text-right">
                            <ul class="pagination"></ul>
                          </div>
                        </td>
                      </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>
</div>


<script src="<?php echo base_url();?>assets/web/global/js/components/panel.js"></script>
<script src="<?php echo base_url();?>assets/web/assets/examples/js/uikit/panel-actions.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/bootstrap-select/bootstrap-select.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/components/bootstrap-select.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/web/assets/examples/js/tables/moment.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/web/assets/examples/js/tables/daterangepicker.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/footable/footable.all.min.js"></script>
<script src="<?php echo base_url();?>assets/web/assets/examples/js/tables/footable.js"></script>


<script src="<?php echo base_url();?>assets/web/global/vendor/datatables/jquery.dataTables.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/datatables-fixedheader/dataTables.fixedHeader.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/datatables-bootstrap/dataTables.bootstrap.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/datatables-responsive/dataTables.responsive.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/datatables-tabletools/dataTables.tableTools.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/components/datatables.js"></script>
<script src="<?php echo base_url();?>assets/web/assets/examples/js/tables/datatable.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/select2/select2.min.js"></script>  
<script src="<?php echo base_url();?>assets/web/global/js/components/select2.js"></script>

<script type="text/javascript" src="<?php echo base_url();?>assets/js/moment.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/daterangepicker.js"></script>
<script src="<?php echo base_url();?>assets/js/jquery.daterange.js"></script>

<script src="<?php echo base_url();?>assets/web/assets/examples/js/uikit/icon.js"></script>
<script src="<?php echo base_url();?>assets/js/index_select.js"></script>


<script type="text/javascript">
    function cb(start, end) {
        $('#reportrange span').html(start.format('MM/DD/YYYY') + ' - ' + end.format('MM/DD/YYYY'));
        $(".date_start").val(start.format('MM/DD/YYYY'));
        $(".date_end").val(end.format('MM/DD/YYYY'));
    }

    cb(moment().subtract(3, 'days'), moment());

    <?php if($this->input->get('start')):?>
        $('#reportrange').daterangepicker({
            "startDate": "<?php echo urldecode($this->input->get('start'))?>",
            "endDate": "<?php echo urldecode($this->input->get('end'))?>",
            ranges: {
               'Today': [moment(), moment()],
               'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
               'Last 7 Days': [moment().subtract(6, 'days'), moment()],
               'Last 30 Days': [moment().subtract(29, 'days'), moment()],
               'This Month': [moment().startOf('month'), moment().endOf('month')],
               'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
            }
        }, cb); 
        $('#reportrange span').html("<?php echo urldecode($this->input->get('start'))?>" + ' - ' + "<?php echo urldecode($this->input->get('end'))?>");
        $(".date_start").val("<?php echo urldecode($this->input->get('start'))?>");
        $(".date_end").val("<?php echo urldecode($this->input->get('end'))?>");
    <?php else:?>
        $('#reportrange').daterangepicker({
            ranges: {
               'Today': [moment(), moment()],
               'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
               'Last 7 Days': [moment().subtract(6, 'days'), moment()],
               'Last 30 Days': [moment().subtract(29, 'days'), moment()],
               'This Month': [moment().startOf('month'), moment().endOf('month')],
               'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
            }
        }, cb); 
    <?php endif;?>

</script>

