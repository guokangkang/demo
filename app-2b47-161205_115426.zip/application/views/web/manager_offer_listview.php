<link rel="stylesheet" href="<?php echo base_url();?>assets/web/assets/examples/css/advanced/masonry.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/webui-popover/webui-popover.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/toolbar/toolbar.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/assets/examples/css/uikit/modals.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/select2/select2.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/bootstrap-select/bootstrap-select.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/bootstrap-datepicker/bootstrap-datepicker.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/jt-timepicker/jquery-timepicker.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/index_select.css">

<style>
    .bootstrap-select:not([class*="col-"]):not([class*="form-control"]):not(.input-group-btn) {
        width: 100px;
    }
    .table>thead>tr>th,.table>tbody>tr>td{padding:0;border:none;}
    @media (max-width: 767px) {
        .padding_right{padding-right: 40px!important}
    }
    @media (min-width:992px) {
        .bg_color{background: -webkit-linear-gradient(left,#fff 83%, #fbfbfb 80%);}
    }
    @media (max-width:476px) {
        .xs_row{margin-left: -6px;margin-right: -35px!important;}
    }
    .btn-group.open .btn-select, .btn-select:focus{border-color: #12abc5 !important;}
    .dropdown-menu a {color:#76838f!important;}
    .dropdown-menu .selected a{color:#12abc5!important;}
    .checkbox-primary input[type=radio]:checked+label::before, .checkbox-primary input[type=checkbox]:checked+label::before{background-color: #12abc5;border-color: #12abc5;}
</style>

<div class="page animsition">
    <div class="page-header clearfix">
        <ol class="breadcrumb pull-left" style="line-height:36px;">
            <li><a href="<?php echo site_url('manager/product/listview')?>">Manager Management</a></li>
            <li><a href="<?php echo site_url('manager/product/listview')?>"><?php echo $product_info['name']?></a></li>
            <li class="active">Offers</li>
        </ol>
        <div class="pull-right">
            <button type="button" class="btn btn-primary btn-round margin-right-15 add_bucket" data-target="#add_bucket" data-toggle="modal" style="background:#12abc5;">
                <i class="icon wb-plus" aria-hidden="true"></i>
                Add offer
            </button>
            <!-- <div class="form-group pull-right margin-bottom-0">
                <div class="input-search margin-bottom-0">
                    <i class="input-search-icon wb-search" aria-hidden="true"></i>
                    <input type="text" class="form-control" name="" placeholder="Search...">
                    <button type="button" class="input-search-close icon wb-close" aria-label="Close"></button>
                </div>
            </div> -->
        </div>
    </div>
    <div class="page-content" data-selectable="selectable" data-row-selectable="true"> 
        <div class="panel widget-border">
            <div class="panel-body container-fluid" style=" padding-bottom: 0;">
                <div class="row row-lg">
                    <div class="clearfix visible-md-block visible-lg-block"></div>
                    <div class="col-md-12">
                        <div class="example-wrap" style="margin-bottom:0;">
                            <h4>Conditions</h4>
                            <div class="example" style="margin-bottom: 0; margin-top: 0;">
                                <div class="col-md-12 padding-left-0">
                                    <div class="example-wrap">
                                        <div class="example margin-top-3">
                                            <form>
                                                <div class="form-group col-md-5 filter-form advertiser-filter" style="margin-bottom:15px;padding-left: 0;">

                                                    <select class="form-control select2-hidden-accessible filter_product" data-plugin="select2" tabindex="-1" aria-hidden="true" data-placeholder="Product">
                                                        <option></option>
                                                        <?php foreach($product_list as $product):?>
                                                            <option value="<?php echo $product['product_id']?>" <?php echo ($product['product_id']==$this->input->get('product'))?"selected='selected'":''?>><?php echo "(".$product['product_id'].")".$product['name']?></option>
                                                        <?php endforeach;?>
                                                    </select>
                                                </div>

                                               <!--<div class="form-group col-md-4 filter-form advertiser-filter" style="margin-bottom:15px;padding-left: 0;">
                                                    <select class="form-control select2-hidden-accessible filter_country" multiple="" data-plugin="select2" tabindex="-1" aria-hidden="true" data-placeholder="Country">
                                                        <?php /*foreach($config_product['countries'] as $key=> $country):*/?>
                                                            <option value="<?php /*echo $key*/?>" <?php /*echo (in_array($key, $country_params))?"selected='selected'":''*/?>><?php /*echo $key.'-'.$country*/?></option>
                                                        <?php /*endforeach;*/?>
                                                    </select>
                                                </div>-->
                                                <div class="col-md-4 filter-form advertiser-filter">
                                                    <div class="diy_select form-group">
                                                        <!--【存】当前选中的值-->
                                                        <input type="hidden" data-item-num="2" name="" class="diy_select_input filter_country" value="<?php echo $this->input->get('country')?$this->input->get('country').',':'';?>">
                                                        <!--【显示】当前选中的值-->
                                                        <input type="text" class="diy_select_txt filter_input_1" placeholder="Country" value="<?php echo $this->input->get('country')?count(explode(',',$this->input->get('country'))) .' items selected':'';?>">
                                                        <!--下拉三角形-->
                                                        <span class="caret" style="right: 14px;position: absolute;top: 50%;margin-top: -2px;"></span>
                                                        <!--数据列表-->
                                                        <ul class="diy_select_list" style="display:none;" id="radiao_box_1">
                                                            <?php foreach($config_product['countries'] as $key=> $country):?>
                                                                <li data-key="<?php echo $key;?>" <?php echo (in_array($key, $country_params))?'class="show_list"':'';?>>
                                                                    <span><?php echo $key.'-'.$country;?></span>
                                                                    <b class="icon wb-check check-mark"></b>
                                                                </li>
                                                            <?php endforeach;?>
                                                        </ul>
                                                    </div>
                                                </div>

                                                <div class="form-group col-md-3 filter-form" style="margin-bottom:15px;padding-left: 0;">
                                                    <button type="button" class="btn btn-outline btn-primary margin-right-10 offer_search"  data-type="manage_offer">Search</button>

                                                    <button type="button" class="btn btn-outline btn-info offer_search_rest">Reset</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                    <!-- End Example Multi Balue -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php if($listview):?>
        <div class="clearfix margin-bottom-20 padding-top-10">
            <h4 class="pull-left padding-left-30">Details</h4>
            <div class="pull-right">
                <button type="button" class="btn btn-outline btn-primary batch_add_offer_event" data-target="#add_event" data-toggle="modal" style="border:1px solid #12abc5; color:#12abc5;">
                    <i class="icon wb-plus" aria-hidden="true"></i>
                    Event
                </button>
            </div>
            <div class="checkbox-custom checkbox-primary pull-right margin-right-15">
                <input type="checkbox" name="inputCheckboxes" id="media_all" class="selectable-all">
                <label for="media_all"></label>
            </div>  
        </div>
        <div>
            <?php foreach($listview as $item):?>
                <div class="panel panel_box">
                    <div class="panel-body container-fluid padding-0 bg_color" style="position: relative;padding-bottom:54px!important;">
                        <div class="col-md-12 padding-horizontal-0">
                            <div class="col-md-10 height_standard">
                                <div style="border-bottom:1px solid #eee; width:92%; margin:0 auto 20px;">
                                    <h3 class="panel-title padding-bottom-15 inline-block padding-right-10 font-weight-600 padding-left-0" style="color:#3b434a; font-size:32px;">
                                        <?php if($item['current']):?>
                                            $<?php echo $item['current']?$item['current']['cpa']:'-'?> -
                                        <?php endif;?>
                                        <span class="font-weight-300"><?php echo count($item['countries'])<5?implode(' ', $item['countries']):count($item['countries'])." Counties"?></span>
                                    </h3>
                                    <p class="pull-right margin-top-20">
                                        <span class="margin-right-15" style="color:#f96868;">
                                            <?php if ($item['next_status']) {
                                                if ($item['next_status']['status'] == 0) {
                                                    echo "Will pause at:" . date('m/d/Y H:i a', $item['next_status']['effective_time']);
                                                } elseif ($item['next_status']['status'] == -1) {
                                                    echo "Will delete at:" . date('m/d/Y H:i a', $item['next_status']['effective_time']);
                                                } elseif ($item['next_status']['status'] == 1) {
                                                    echo "Will start at:" . date('m/d/Y H:i a', $item['next_status']['effective_time']);
                                                }
                                            }; ?></span>
                                            <span class="inline-block font-size-16"
                                                  style="margin-bottom: -5px;">#<?php echo $item['offer_id']; ?></span>
                                    </p>
                                </div>
                                <div class="padding-left-40 table-responsive clearfix">
                                    <div class="col-sm-8  padding-left-0" >
                                        <div class="table_box" style="height:70px;overflow:hidden;">
                                        <div class="font-weight-600" style="color:#454d54;">Schedule</div>
                                        <table class="table margin-bottom-15">
                                            <thead>
                                                <tr>
                                                    <th style="width:40%;">Effective time </th>
                                                    <th style="width:30%;">Payout</th>
                                                    <th style="width:30%;">Retention</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach($item['payout'] as $payout):?>
                                                    <tr>
                                                        <td><?php echo date('m/d/Y H:i:s a', $payout['start_time'])?></td>
                                                        <td>$<?php echo $payout['cpa']?></td>
                                                        <?php if ($payout['category'] == 1): ?>
                                                            <td>
                                                                <?php echo $config_product['offer_category'][$payout['category']]; ?>,
                                                                <strong>$<?php echo $payout['cpa'];?></strong>
                                                            </td>
                                                        <?php elseif ($payout['category'] == 2): ?>
                                                            <td>
                                                                <?php echo $config_product['offer_category'][$payout['category']]; ?>,

                                                                <?php foreach ($payout['value'] as $val): ?>
                                                                    <?php echo "If RT > <strong>" . $val['retention_rate'] . "%</strong>, "; ?>
                                                                    <?php echo "Payout will be <strong>" . $val['payout_rate'] . "%</strong> = "; ?>
                                                                    <?php echo "<strong>$" . $val['payout'] . "</strong><br>"; ?>
                                                                <?php endforeach; ?>
                                                            </td>
                                                        <?php else: ?>
                                                            <td>
                                                                <?php echo $config_product['offer_category'][$payout['category']]; ?>,
                                                                Payout will be proportional to the
                                                                retention rate.<br/>
                                                                If RR >
                                                                <strong><?php echo $payout['value'] ?>
                                                                    %</strong>, Full Payout.<br/>
                                                                If RR <= <?php echo $payout['value'] ?>, Payout =
                                                                RR/<strong><?php echo $payout['value'] ?>
                                                                    %</strong>*Full Payout.
                                                            </td>
                                                        <?php endif; ?>
                                                    </tr>
                                                <?php endforeach;?>
                                            </tbody>
                                        </table>

                                        </div>
                                        <div class="font-weight-600" style="color:#454d54;">Country</div>
                                        <p class="p_height" style="height: 24px;overflow: hidden;">
                                            <strong><?php echo ucfirst($item['choose_type'])?> : </strong>
                                            <?php foreach($item['countries'] as $country):?>
                                                <?php echo $country.' - '.$config_product['countries'][$country]?>　
                                            <?php endforeach;?>
                                        </p>
                                    </div>
                                    <div class="col-sm-4 padding-left-0">
                                        <div class="font-weight-600" style="color:#454d54;">Quality Control</div>
                                        <div class="clearfix margin-top-5">
                                            <?php if($item['current']):?>
                                            <strong class="pull-left margin-right-20 font-weight-300"><?php echo $config_product['offer_category'][$item['current']['category']]?></strong>

                                            <?php endif;?>


                                            <p class="pull-left">
                                                <?php if($item['current']):?>
                                                    <?php if ($item['current']['category'] == 1): ?>
                                                        <strong>$<?php echo $item['current']['cpa'];?></strong>
                                                    <?php elseif ($item['current']['category'] == 2): ?>

                                                        <?php foreach ($item['current']['value'] as $val): ?>
                                                            <?php echo "If RT > <strong>" . $val['retention_rate'] . "%</strong>, "; ?>
                                                            <?php echo "Payout will be <strong>" . $val['payout_rate'] . "%</strong> = "; ?>
                                                            <?php echo "<strong>$" . $val['payout'] . "</strong><br>"; ?>
                                                        <?php endforeach; ?>
                                                    <?php else: ?>
                                                            Payout will be proportional to the
                                                            retention rate.<br/>
                                                            If RR >
                                                            <strong><?php echo $item['current']['value'] ?>
                                                                %</strong>, Full Payout.<br/>
                                                            If RR <= <?php echo $item['current']['value'] ?>, Payout =
                                                            RR/<strong><?php echo $item['current']['value'] ?>
                                                                %</strong>*Full Payout.
                                                    <?php endif; ?>
                                                <?php endif;?>
                                            </p>

                                        </div>
                                    </div>

                                </div>
                            </div>
                            <div class="col-md-2 text-center right_box padding-bottom-20" style="height:284px;overflow:hidden;position:relative;margin-bottom: -54px;background:#fbfbfb;">

                                <p class="col-md-10 col-md-offset-1 padding-vertical-5 margin-bottom-0" style="border-bottom:1px solid #e7e7e7;margin-top:20px;padding-bottom: 12px!important;">
                                    <span class="font-size-12 block" style="color:#3B434A;">Status</span>


                                    <?php if(!$item['current'] || $item['status']==-2):?>
                                        <span class="font-size-12 block" style="color:#5EA1FE;">Pending</span>
                                    <?php elseif($item['status']==1):?>
                                        <span class="font-size-12 block" style="color:#9adc51;">Started</span>
                                    <?php elseif($item['status']==0):?>
                                        <span class="font-size-12 block" style="color:#79848E;">Paused</span>
                                    <?php elseif($item['status']==-1):?>
                                        <span class="font-size-12 block" style="color:#9adc51;">Deleted</span>
                                    <?php endif;?>


                                </p>
                                <p class="col-md-10 col-md-offset-1 padding-bottom-5 padding-top-20 margin-bottom-0" style="border-bottom:1px solid #e7e7e7;padding-bottom: 20px!important;">
                                    <span class="font-size-12 block" style="color:#3B434A;">Caps</span>
                                    <span class="font-size-12 block" style="color:#79848e;">No caps</span>
                                </p>
                                <p class="col-md-10 col-md-offset-1 padding-bottom-5 padding-top-20">
                                    <span class="font-size-12 block" style="color:#3B434A;">RPA</span>
                                    <span class="font-size-12 block" style="color:#79848e;">$ <?php echo $item['rpa']?></span>
                                </p>
                                <a href="<?php echo site_url('manager/offer/detail?offer='.$item['offer_id'])?>" style="background:#12abc5; outline:none; border:0;" class="btn btn_self btn-success apply_offer_modal">
                                    Detail
                                </a>
                                <div class="checkbox-custom checkbox-primary" style="position: absolute;right: 10px;top: 10px;margin-top:1px;">
                                    <input type="checkbox" id="inputUnchecked" class="selectable-item event_checkbox" data-val="<?php echo $item['offer_id']?>" name="offer_item_checkbox">
                                    <label for="inputUnchecked"></label>
                                </div>
                            </div>
                        </div>
                        <p class="text-center p_list_show margin-top-20" data-term="false" style="cursor: pointer;position: absolute; left: 50%;margin-left: -18px;bottom:20px;" data-topsrc="../../assets/images/top_pic.png" data-bottomsrc="../../assets/images/bottom_pic.png">
                            <img src="<?php echo site_url();?>assets/images/bottom_pic.png">
                        </p>
                    </div>
                </div>
            <?php endforeach;?>
        </div>
        <?php else:?>
            <div class="clearfix margin-bottom-20 padding-top-10">
                <h4 class="pull-left padding-left-30">Details</h4>
                <div class="panel margin-bottom-0 height-500">
                    <div class="text-center padding-top-80">
                        <img src="<?php echo base_url(); ?>assets/images/no_data.png">
                        <h4 class="margin-top-30">NO DATA HERE</h4>
                        <p style="line-height: 18px;">I hate peeping Toms. For one thing they usually step all over<br>the hedges and plants on the side of someone's house killing</p>
                    </div>
                </div>
            </div>
        <?php endif;?>
    </div>
</div>
<?php echo $manager_offer_add;?>
<?php echo $manager_offer_add_event;?>
<script src="<?php echo base_url();?>assets/web/global/vendor/datatables/jquery.dataTables.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/webui-popover/jquery.webui-popover.min.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/toolbar/jquery.toolbar.min.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/editable-table/mindmup-editabletable.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/editable-table/numeric-input-example.js"></script>



 <script src="<?php echo base_url();?>assets/web/global/vendor/bootstrap-datepicker/bootstrap-datepicker.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/jt-timepicker/jquery.timepicker.min.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/datepair-js/datepair.min.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/datepair-js/jquery.datepair.min.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/formatter-js/jquery.formatter.js"></script>


<script src="<?php echo base_url();?>assets/web/global/js/components/datatables.js"></script>
<script src="<?php echo base_url();?>assets/web/assets/examples/js/tables/datatable.js"></script>
<script src="<?php echo base_url();?>assets/web/assets/examples/js/uikit/icon.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/components/masonry.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/components/webui-popover.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/components/toolbar.js"></script>
<script src="<?php echo base_url();?>assets/web/assets/examples/js/uikit/tooltip-popover.js"></script>
<script src="<?php echo base_url();?>assets/js/new_js.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/select2/select2.min.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/components/select2.js"></script>
<script src="<?php echo base_url();?>assets/web/global/vendor/bootstrap-select/bootstrap-select.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/components/bootstrap-select.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/js/components/bootstrap-datepicker.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/js/components/jt-timepicker.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/js/components/datepair-js.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/formvalidation/formValidation.min.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/formvalidation/framework/bootstrap.min.js"></script>

<script src="<?php echo base_url();?>assets/js/my_valiation.js"></script>
<script src="<?php echo base_url();?>assets/js/index_select.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/plugins/selectable.js"></script>
<script src="<?php echo base_url();?>assets/web/global/js/components/selectable.js"></script>


