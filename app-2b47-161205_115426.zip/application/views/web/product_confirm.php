<link rel="stylesheet" href="<?php echo base_url();?>assets/web/assets/examples/css/forms/layouts.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/formvalidation/formValidation.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/assets/examples/css/forms/validation.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/select2/select2.css">
 <link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/bootstrap-datepicker/bootstrap-datepicker.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/bootstrap-select/bootstrap-select.css">

<link rel="stylesheet" href="<?php echo base_url();?>assets/web/global/vendor/jt-timepicker/jquery-timepicker.css">
<style>
    .pearl-icon{width: 30px; height: 30px; line-height: 30px; font-size: 14px;}
    .pearl:after, .pearl:before{top:15px;height:2px;}
    .pearl.current:after, .pearl.current:before{background-color:#12abc5;}
    .pearl.current .pearl-icon, .pearl.current .pearl-number{border:1px solid #12abc5;color:#12abc5;-webkit-transform: scale(1);transform: scale(1);}
    .form-control:focus{
    border:1px solid #12abc5;
    }
    .back_btn{border: 1px solid #12abc5; color:#12abc5!important; background-color: #fff;}
    .btn-group.open .btn-select, .btn-select:focus{border-color:#12abc5!important;}
    .pearl.done:after, .pearl.done:before{background-color:#12abc5;}
    .pearl.done .pearl-icon, .pearl.done .pearl-number{border-color:#12abc5; background-color:#12abc5;}
</style>
<div class="page animsition" >
    <div class="page-header ">
        <h1 class="page-title">Add Product</h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo site_url('setup/product')?>">Products Management</a></li>
            <li class="active">Add Product</li>
        </ol>
    </div>


    <div class="page-content">
        <div class="panel">
            <div class="panel-body container-fluid">
                <div class="pearls row col-xs-offset-3">
                <div class="pearl current col-xs-3">
                  <div class="pearl-icon"><i class="icon md-plus" aria-hidden="true"></i></div>
                </div>
                <div class="pearl col-xs-2">
                  <div class="pearl-icon"><i class="icon md-edit" aria-hidden="true"></i></div>
                </div>
                <div class="pearl col-xs-2">
                  <div class="pearl-icon"><i class="icon md-check" aria-hidden="true"></i></div>
                </div>
              </div>


                <div class="row" data-plugin='masonry'>
                    <div class="col-sm-offset-3 col-md-6">
                        <div class="widget">
                            <p style="color:#3b434a;">Confrim a new product</p>
                            <div class="widget-header white bg-cyan-600 padding-30 clearfix">
                                <a class="avatar avatar-100 pull-left margin-right-20" href="javascript:void(0)">
                                <img src="<?php echo $info['logo']?>" alt="">
                                </a>
                                <div class="pull-left">
                                    <div class="font-size-20 margin-bottom-15"><?php echo $info['name']?></div>
                                    <p class="margin-bottom-5 text-nowrap"><i class="icon wb-large-point margin-right-10" aria-hidden="true"></i>
                                    <span class="text-break"><?php echo $info['app_id']?></span>
                                    </p>
                                    <p class="margin-bottom-5 text-nowrap"><i class="icon wb-large-point margin-right-10" aria-hidden="true"></i>
                                        <span class="text-break"><?php echo $info['category']?></span>
                                    </p>
                                    <p class="margin-bottom-5 text-nowrap"><i class="icon wb-large-point margin-right-10" aria-hidden="true"></i>
                                        <span class="text-break">
                                        <a style="color:#fff" href="<?php echo $info['object_store_url']?>" target="_blank">Object Store Url</a></span></span>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


                <div class="row row-lg">
                    <div class="col-sm-offset-3 col-sm-6">
                        <div class="example-wrap">
                            <h4 class="example-title"></h4>

                            <div class="example">
                                <form autocomplete="off" id="my_form2" action="<?php echo site_url('product/form_confirm_action')?>" method="post">
                                    <input type="hidden" name="product_id" value="<?php echo $info['product_id']?>">
                                
                                    <div class="row">
                                        <div class="form-group col-md-4">
                                            <label class="control-label" for="email">
                                                Advertiser
                                                <span class="required">*</span>
                                            </label>
                                            <select class="form-control" id="select" data-plugin="selectpicker" tabindex="-98" name="select_advertiser" <?php echo $info['status']==0?"":'disabled="disabled"'?>>
                                                <option></option>
                                                <?php foreach($advertiserlist as $key=>$val):?>
                                                    <option value="<?php echo $val['user_id']?>" <?php echo $info['user_id']==$val['user_id']?"selected='selected'":''?>><?php echo $val['first_name']?></option>
                                                <?php endforeach;?>
                                            </select>
                                        </div>

                                        <div class="form-group col-md-4">
                                            <label class="control-label" for="product_name">
                                                Product Name
                                                <span class="required">*</span>
                                            </label>
                                            <input type="text" class="form-control" id="product_name" value="<?php echo $info['name']?>" name="input_product_name" placeholder="Fill a product name" autocomplete="off">
                                        </div>

                                        <div class="form-group col-md-4">
                                            <label class="control-label" for="retention_days">
                                                Retention Days
                                                <span class="required">*</span>
                                            </label>
                                            <input type="text" class="form-control" name="retention_days" id="retention_days" data-fv-lessthan="true" data-fv-lessthan-value="30" data-fv-greaterthan-message="please enter less than 30" placeholder="Days Number" data-fv-field="vMax" value="<?php echo $info['retention_day']?$info['retention_day']:0?>">
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="control-label" for="retention_source">
                                            Retention Source
                                            <span class="required">*</span>
                                        </label>
                                        <div class="input-group">
                                          <div class="f radio-custom radio-default radio-inline">
                                            <input type="radio" id="retention_source_appflyer" name="retention_source" value="appsflyer">
                                            <label for="retention_source_appflyer">Appsflyer</label>
                                        </div>
                                        </div>
                                        
                                    </div>

                                    <div class="form-group">
                                        <label class="control-label" for="inputdesc">
                                            Description
                                            <span class="required">*</span>
                                        </label>
                                        <textarea class="form-control" name="input_desc" id="inputdesc" rows="5"><?php echo $info['description']?></textarea>
                                    </div>
                                    <div class="form-group text-right">
                                        <a href="#" class="btn hover_btn btn-outline btn-primary back_btn margin-right-15" id="">Back</a>
                                        <button type="submit" class="btn btn_self btn-primary" id="my_val">Confirm</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="clearfix hidden-xs"></div>
                </div>

                <!-- 后加的最后一步 -->
                <!-- <div class="row row-lg text-center padding-top-80">
                    <div class="icondemo vertical-align-middle">
                        <i class="icon md-check-all font-size-30" aria-hidden="true" style="color:#12abc5;"></i>
                        <div class="icon-title font-size-16">Add Succeed</div>
                    </div>
                    <div class="form-group text-center margin-top-20">
                        <button type="submit" class="btn btn_self btn-primary" id="">Finish</button>
                    </div>
                </div> -->
            </div>
        </div>
    </div>
</div>


<!--Plugins-->
  <script src="<?php echo base_url();?>assets/web/global/vendor/jquery-placeholder/jquery.placeholder.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/formvalidation/formValidation.min.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/formvalidation/framework/bootstrap.min.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/select2/select2.min.js"></script>

  <script src="<?php echo base_url();?>assets/web/global/vendor/bootstrap-datepicker/bootstrap-datepicker.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/jt-timepicker/jquery.timepicker.min.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/datepair-js/datepair.min.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/datepair-js/jquery.datepair.min.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/formatter-js/jquery.formatter.js"></script>

   <!--Custom-->
  <script src="<?php echo base_url();?>assets/web/global/js/components/jquery-placeholder.js"></script>
<!--  <script src="--><?php //echo base_url();?><!--assets/web/assets/examples/js/forms/validation.js"></script>-->

  <script src="<?php echo base_url();?>assets/web/global/js/components/bootstrap-datepicker.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/js/components/jt-timepicker.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/js/components/datepair-js.js"></script>

  <script src="<?php echo base_url();?>assets/web/global/js/components/select2.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/js/components/multi-select.js"></script>
  <script src="<?php echo base_url();?>assets/web/assets/examples/js/forms/advanced.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/js/components/formatter-js.js"></script>
  <script src="<?php echo base_url();?>assets/js/my_valiation.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/vendor/bootstrap-select/bootstrap-select.js"></script>
  <script src="<?php echo base_url();?>assets/web/global/js/components/bootstrap-select.js"></script>

<script>
    $('#include').click(function(){
        $('#inclue_countries select').attr('name','select_country[]');
        $('#inclue_countries').show();
        $('#exclude_countries').hide();
        $('#exclude_countries select').attr('name','');
    });
    $('#exclude').click(function(){
        $('#exclude_countries select').attr('name','select_country[]');
        $('#inclue_countries select').attr('name','');
        $('#inclue_countries').hide();
        $('#exclude_countries').show();
    });
</script>
