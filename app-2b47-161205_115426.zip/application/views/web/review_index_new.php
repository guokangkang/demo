<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/assets/examples/css/tables/datatable.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/global/vendor/select2/select2.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/global/vendor/owl-carousel/owl.carousel.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/global/vendor/slick-carousel/slick.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/assets/examples/css/uikit/carousel.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/daterangepicker.css"/>

<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/global/fonts/material-design/material-design.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/assets/examples/css/uikit/icon.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/index_select.css">

<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/global/vendor/webui-popover/webui-popover.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/global/vendor/toolbar/toolbar.css">
<style>
    .red_color {
        color: red !important;
    }

    .red_orange {
        color: orange !important;
    }

    .table > tbody > tr > td {
        vertical-align: middle;
    }

    .table > .no_border > tr > td {
        border-top: none;
        font-size: 18px;
    }

    @media screen and (max-width: 767px) {
        .table-responsive {
            border: none;
        }

        .slide_right {
            top: 60px !important;
        }
    }

    .span_block {
        position: relative;
    }

    .span_block span {
        display: block;
        width: 100%;
        height: 100%;
    }

    .span_block input {
        display: none;
    }

    .span_block input.active {
        display: block;
        position: absolute;
        left: 0;
        top: 0;
    }

    .change_btn {
        padding: 2px;
        font-size: 12px;
        margin-top: -6px;
        margin-left: 5px;
    }

    .overlay figcaption .btn {
        margin-left: 4px;
    }

    .tools_btn .btn {
        margin-right: 2px !important;
        padding: 7px !important;
        font-size: 12 !important;
    }

    .panel-actions {
        z-index: 0 !important;
    }

    .exampleVariableWidth img {
        border-top: none;
        border-bottom: none;
    }

    .exampleVariableWidth {
        margin: 0;
    }

    .exampleVariableWidth .slick-prev {
        left: 4px;
        z-index: 12;
    }

    .exampleVariableWidth .slick-next {
        right: 4px;
    }
</style>

<div class="page animsition">
    <div class="page-header">
        <ol class="breadcrumb">
            <li><a href="<?php echo site_url('review') ?>">Creative</a></li>
            <li class="active">Review</li>
        </ol>
    </div>
    <div class="page-content">
        <div class="row">
            <div class="clearfix visible-md-block visible-lg-block"></div>
            <div class="col-md-12">
                <div class="panel">
                    <div class="panel-heading" style="position: relative;">
                        <h3 class="panel-title">Filter</h3>
                        <div class="form-group col-xs-3 col-md-3" style="position: absolute;top:14px;right: 68px;">
                            <div class="input-search margin-0">
                                <button type="submit" class="input-search-btn"><i class="icon wb-search"
                                                                                  aria-hidden="true"></i></button>
                                <input type="text" class="form-control" name="campaign" placeholder="Campaign Name"
                                       class="campaign_name" value="<?php echo trim($this->input->get('campaign')) ?>">
                            </div>
                        </div>
                        <div class="panel-actions">
                            <a class="panel-action icon wb-minus" data-toggle="panel-collapse" aria-hidden="true"></a>
                        </div>
                    </div>
                    <div class="panel-body">
                        <div class="example" style="margin-bottom: 0; margin-top: 0;">
                            <div class="col-md-4">
                                <div class="">
                                    <div class="example">
                                        <form>
                                            <div class="form-group filter-form advertiser-filter"
                                                 style="margin-bottom:10px;line-height:36px;">
                                                <label class="control-label">Conditions</label>
                                            </div>
                                           <div class="form-group filter-form advertiser-filter">
                                               <div class="diy_select">
                                                   <!--【存】当前选中的值-->
                                                   <input type="hidden" name="" class="diy_select_input filter_publisher" value="<?php echo $publisher_params?implode(',',$publisher_params).',':'';?>">
                                                   <!--【显示】当前选中的值-->
                                                   <input type="text" class="diy_select_txt filterinput_1" placeholder="<?php echo count($publisher_params)?count($publisher_params).' items selected':'Publisher';?>">
                                                   <!--下拉三角形-->
                                                   <span class="caret" style="right: 14px;position: absolute;top: 50%;margin-top: -2px;"></span>
                                                   <!--数据列表-->
                                                   <ul class="diy_select_list" style="display:none;" id="radiaobox_1">
                                                       <?php if(isset($user_list)):?>
                                                           <?php foreach ($user_list as $publisher): ?>
                                                               <li data-key="<?php echo $publisher['user_id'] ?>" <?php echo (in_array($publisher['user_id'], $publisher_params))?"class='show_list'":''?>>
                                                                   <span><?php echo $publisher['user_id'] . "(" . $publisher['first_name'] . ')' ?></span>
                                                                   <b class="icon wb-check check-mark"></b>
                                                               </li>
                                                           <?php endforeach;?>
                                                       <?php endif;?>
                                                   </ul>
                                               </div>
                                            </div>

                                           <div class="form-group filter-form product-filter"
                                                 style="margin-bottom:15px;padding-left: 0;">
                                               <div class="diy_select">
                                                   <!--【存】当前选中的值-->
                                                   <input type="hidden" name="" class="diy_select_input filter_product" value="<?php echo $product_params?implode(',',$product_params).',':'';?>">
                                                   <!--【显示】当前选中的值-->
                                                   <input type="text" class="diy_select_txt filterinput_2" placeholder="<?php echo count($product_params)?count($product_params).' items selected':'Product';?>">
                                                   <!--下拉三角形-->
                                                   <span class="caret" style="right: 14px;position: absolute;top: 50%;margin-top: -2px;"></span>
                                                   <!--数据列表-->
                                                   <ul class="diy_select_list" style="display:none;" id="radiaobox_2">
                                                       <?php if(isset($product_list)):?>
                                                           <?php foreach ($product_list as $product): ?>
                                                               <li data-key="<?php echo $product['product_id']?>" <?php echo (in_array($product['product_id'], $product_params))?"class='show_list'":''?>>
                                                                   <span><?php echo "(" . $product['product_id'] . ")" . $product['name']?></span>
                                                                   <b class="icon wb-check check-mark"></b>
                                                               </li>
                                                           <?php endforeach;?>
                                                       <?php endif;?>
                                                   </ul>
                                               </div>
                                                <!--<select class="form-control select2-hidden-accessible filter_product"
                                                        multiple="" data-plugin="select2" tabindex="-1"
                                                        aria-hidden="true" data-placeholder="Product">
                                                    <?php /*foreach ($product_list as $product): */?>
                                                        <option
                                                            value="<?php /*echo $product['product_id']*/?>" <?php /*echo (in_array($product['product_id'], $product_params))?"selected='selected'":'' */?>><?php /*echo "(" . $product['product_id'] . ")" . $product['name']*/?></option>
                                                    <?php /*endforeach; */?>
                                                </select>-->
                                            </div>

                                            <div class="form-group filter-form account-filter"
                                                 style="margin-bottom:15px;padding-left: 0;">

                                                <div class="diy_select">
                                                    <!--【存】当前选中的值-->
                                                    <input type="hidden" name="" class="diy_select_input filter_account" value="<?php echo $account_params?implode(',',$account_params).',':'';?>">
                                                    <!--【显示】当前选中的值-->
                                                    <input type="text" class="diy_select_txt filter_input_1" placeholder="<?php echo count($account_params)?count($account_params).' items selected':'Account';?>">
                                                    <!--下拉三角形-->
                                                    <span class="caret" style="right: 14px;position: absolute;top: 50%;margin-top: -2px;"></span>
                                                    <!--数据列表-->
                                                    <ul class="diy_select_list" style="display:none;" id="radiao_box_1">
                                                        <?php if(isset($account_list)):?>
                                                            <?php foreach ($account_list as $account): ?>
                                                                <li data-key="<?php echo $account['account_id'] ?>" <?php echo (in_array($account['account_id'], $account_params))?"class='show_list'":''?>>
                                                                    <span><?php echo $account['account_id'] . "(" . $account['name'] . ')' ?></span>
                                                                    <b class="icon wb-check check-mark"></b>
                                                                </li>
                                                            <?php endforeach;?>
                                                        <?php endif;?>
                                                    </ul>
                                                </div>
                                              <!--  <select class="form-control select2-hidden-accessible filter_account"
                                                        multiple="" data-plugin="select2" tabindex="-1"
                                                        aria-hidden="true" data-placeholder="Account">
                                                    <?php /*foreach ($account_list as $account): */?>
                                                        <option
                                                            value="<?php /*echo $account['account_id'] */?>" <?php /*echo (in_array($account['account_id'], $account_params))?"selected='selected'":'' */?>><?php /*echo $account['account_id'] . "(" . $account['name'] . ')' */?></option>
                                                    <?php /*endforeach; */?>
                                                </select>-->
                                            </div>

                                            <div class="form-group filter-form account-filter"
                                                 style="margin-bottom:15px;padding-left: 0;">
                                                <select class="form-control select2-hidden-accessible filter_status"
                                                        data-plugin="select2" tabindex="-1" aria-hidden="true"
                                                        data-placeholder="Effective Status">
                                                    <option></option>
                                                    <?php foreach ($status as $s): ?>
                                                        <option
                                                            value="<?php echo $s ?>" <?php echo $this->input->get('status') == $s?"selected='selected'":'' ?>><?php echo $s ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-3">
                                <div class="">
                                    <div class="example">
                                        <form>
                                            <div class="form-group filter-form advertiser-filter"
                                                 style="margin-bottom:15px;line-height:36px;">
                                                <label class="control-label"></label>
                                            </div>
                                            <div class="form-group col-lg-3 col-xlg-3 filter-form account-filter"
                                                 style="margin-bottom:15px;padding-left: 0;text-align: center;">
                                                <div class="form-control" style="width: 225px;">
                                                    <div id="reportrange" class="pull-right">
                                                        <i class="glyphicon glyphicon-calendar fa fa-calendar"></i>&nbsp;
                                                        <span>08/07/2016 - 08/10/2016</span> <b class="caret"></b>

                                                        <input type="hidden" value="" class="date_start"/>
                                                        <input type="hidden" value="" class="date_end"/>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-2">
                                <div class="">
                                    <div class="example">
                                        <form>
                                            <div class="form-group filter-form advertiser-filter">
                                                <label class="control-label">Tag</label>
                                            </div>

                                            <div class="form-group filter-form account-filter">
                                                <div class="radio-custom radio-default radio-inline">
                                                    <input type="radio" id="inputPending" name="tag"
                                                           value="0" <?php echo ($this->input->get('tag') === '0' || !$this->input->get('tag'))?"checked=''":'' ?>>
                                                    <label for="inputPending">Pending</label>
                                                </div>
                                            </div>

                                            <div class="form-group filter-form product-filter">
                                                <div class="radio-custom radio-default radio-inline">
                                                    <input type="radio" id="inputChecked" name="tag"
                                                           value="-1" <?php echo $this->input->get('tag') == '-1'?"checked=''":'' ?>>
                                                    <label for="inputChecked">Checked</label>
                                                </div>
                                            </div>

                                            <div class="form-group filter-form account-filter">
                                                <div class="radio-custom radio-default radio-inline">
                                                    <input type="radio" id="inputFavorite" name="tag"
                                                           value="1" <?php echo $this->input->get('tag') == '1'?"checked=''":'' ?>>
                                                    <label for="inputFavorite">Favorite</label>
                                                </div>
                                            </div>

                                            <div class="form-group filter-form account-filter">
                                                <div class="radio-custom radio-default radio-inline">
                                                    <input type="radio" id="inputSuspected" name="tag"
                                                           value="2" <?php echo $this->input->get('tag') == '2'?"checked=''":'' ?>>
                                                    <label for="inputSuspected">Suspected</label>
                                                </div>
                                            </div>

                                            <div class="form-group filter-form account-filter">
                                                <div class="radio-custom radio-default radio-inline">
                                                    <input type="radio" id="inputIllegal" name="tag"
                                                           value="3" <?php echo $this->input->get('tag') == '3'?"checked=''":'' ?>>
                                                    <label for="inputIllegal">Illegal</label>
                                                </div>
                                            </div>

                                            <div class="form-group filter-form advertiser-filter">
                                                <div class="radio-custom radio-default radio-inline">
                                                    <input type="radio" id="inputAll" name="tag"
                                                           value="all" <?php echo ($this->input->get('tag') == 'all')?"checked=''":'' ?>>
                                                    <label for="inputAll">All</label>
                                                </div>
                                            </div>

                                        </form>

                                    </div>
                                </div>
                            </div>

                            <div class="col-md-3">
                                <div class="">
                                    <div class="example">
                                        <form>
                                            <div class="form-group filter-form advertiser-filter">
                                                <label class="control-label">Type</label>
                                            </div>

                                            <div class="form-group filter-form account-filter">
                                                <div class="radio-custom radio-default radio-inline">
                                                    <input type="radio" id="inputImage" name="type"
                                                           value="share" <?php echo $this->input->get('type') == 'share'?"checked=''":'' ?>>
                                                    <label for="inputImage">Image</label>
                                                </div>
                                            </div>

                                            <div class="form-group filter-form account-filter">
                                                <div class="radio-custom radio-default radio-inline">
                                                    <input type="radio" id="inputProduct" name="type"
                                                           value="more_share" <?php echo $this->input->get('type') == 'more_share'?"checked=''":'' ?>>
                                                    <label for="inputProduct">Product</label>
                                                </div>
                                            </div>

                                            <div class="form-group filter-form account-filter">
                                                <div class="radio-custom radio-default radio-inline">
                                                    <input type="radio" id="inputVideo" name="type"
                                                           value="video" <?php echo $this->input->get('type') == 'video'?"checked=''":'' ?>>
                                                    <label for="inputVideo">Video</label>
                                                </div>
                                            </div>

                                            <div class="form-group filter-form advertiser-filter">
                                                <div class="radio-custom radio-default radio-inline">
                                                    <input type="radio" id="inputTypeAll" name="type"
                                                           value="all" <?php echo (!$this->input->get('type') || $this->input->get('type') == 'all')?"checked=''":'' ?>>
                                                    <label for="inputTypeAll">All</label>
                                                </div>
                                            </div>

                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <a id="ad_list" name="ad_list"></a>
                        <div class="example example-buttons text-center" style="margin-bottom: 0;">
                            <button type="button" class="btn btn-outline btn-primary review_search">Search</button>
                            <button type="button" class="btn btn-outline btn-info review_rest">Reset</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <ul class="blocks blocks-100 blocks-xlg-5 blocks-lg-4 blocks-md-3 blocks-sm-2" id="click_btn"
            data-plugin="masonry" data-plugin="animateList" data-child=">li">
            <?php if($ad_list):?>
            <?php foreach ($ad_list as $key=>$item): ?>
                <li class="masonry-item click_li margin-bottom-0" data-tof="false">
                    <div class="media-item">
                        <div class="widget">
                            <div class="widget-header">
                                <div class="overlay overlay-hover review-cover-image overlay_click">
                                    <?php if ($item['object_type'] == 'SHARE'): ?>
                                        <img class="cover-image img-responsive overlay-scale"
                                             src="<?php echo $item['org_image_url'] ?>" alt=""
                                             onerror="javascript:this.src='<?php echo $item['image_url'] ?>'">
                                    <?php elseif ($item['object_type'] == 'MORE_SHARE'): ?>
                                        <!-- 图片轮播图 -->
                                        <div class="slider exampleVariableWidth" style="width:auto;">
                                            <?php foreach ($item['more_image'] as $image): ?>
                                                <div class="">
                                                    <img class="cover-image img-responsive overlay-scale"
                                                         src="<?php echo $image['url'] ?>" alt=""
                                                         onerror="javascript:this.src='<?php echo base_url(); ?>assets/images/Artboard.png'">
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                    <?php elseif ($item['object_type'] == 'VIDEO'): ?>
                                        <video controls="controls" style="background-color: #000;"
                                               poster="<?php echo $item['org_thumbnail_url'] ?>" preload='none'>
                                            <source src="<?php echo $item['video_url'] ?>" type="video/mp4"></source>
                                        </video>
                                    <?php else: ?>
                                        <img class="cover-image img-responsive overlay-scale"
                                             src="<?php echo $item['org_image_url'] ?>" alt=""
                                             onerror="javascript:this.src='<?php echo $item['image_url'] ?>'">
                                    <?php endif; ?>
                                    <figcaption
                                        class="overlay-top overlay-panel overlay-background overlay-slide-top padding-10 text-center">
                                        <button type="button"
                                                class="btn btn-icon tooltip-success btn-success btn-round  riview-success-btn <?php //echo $item['verify'] == -1?'disabled':'' ?>"
                                                data-click="<?php //echo $item['verify'] == -1?false:true ?>"
                                                data-id="<?php echo $item['ad_id'] ?>"
                                                data-val='-1' <?php //echo $item['verify'] == -1?'':'data-toggle="tooltip"' ?>
                                                data-placement="top" data-trigger="click"
                                                data-original-title="<?php echo "Successfully" ?>">
                                            <i class="icon fa-check" aria-hidden="true"></i>
                                        </button>
                                        <button type="button"
                                                class="btn btn-icon tooltip-danger btn-danger btn-round  riview-danger-btn <?php //echo $item['verify'] == 3?'disabled':'' ?>"
                                                data-click="<?php //echo $item['verify'] == 3?false:true ?>"
                                                data-id="<?php echo $item['ad_id'] ?>"
                                                data-val='3' <?php //echo $item['verify'] == 3?'':'data-toggle="tooltip"' ?>
                                                data-placement="top" data-trigger="click"
                                                data-original-title="<?php echo "Successfully" ?>">
                                            <i class="icon fa-close" aria-hidden="true"></i>
                                        </button>
                                        <button type="button"
                                                class="btn btn-icon tooltip-warning btn-warning btn-round  riview-warning-btn <?php //echo $item['verify'] == 2?'disabled':'' ?>"
                                                data-click="<?php //echo $item['verify'] == 2?'false':'true' ?>"
                                                data-id="<?php echo $item['ad_id'] ?>"
                                                data-val='2' <?php //echo $item['verify'] == 2?'':'data-toggle="tooltip"' ?>
                                                data-placement="top" data-trigger="click"
                                                data-original-title="<?php echo "Successfully" ?>">
                                            <i class="icon fa-question" aria-hidden="true"></i>
                                        </button>
                                        <button type="button"
                                                class="btn btn-icon tooltip-primary btn-primary btn-round riview-like-btn <?php //echo $item['verify'] == 1?'disabled':'' ?>"
                                                data-click="<?php //echo $item['verify'] == 1?false:true ?>"
                                                data-id="<?php echo $item['ad_id'] ?>"
                                                data-val='1' <?php //echo $item['verify'] == 1?'':'data-toggle="tooltip"' ?>
                                                data-placement="top" data-trigger="click"
                                                data-original-title="<?php echo "Successfully" ?>">
                                            <i class="icon fa-heart-o" aria-hidden="true"></i>
                                        </button>
                                        <a target="_blank" type="button" class="btn btn-icon social-facebook btn-round"
                                           href="https://business.facebook.com/ads/manager/ad/ads/?act=<?php echo $item['account_id'] ?>&ids=<?php echo $item['ad_id'] ?>">
                                            <i class="icon fa-facebook" aria-hidden="true"></i>
                                        </a>
                                        <a target="_blank" type="button" class="btn btn-icon btn-primary btn-round"
                                           href="https://translate.google.co.jp/?hl=en&tab=wT#auto/zh-CN/<?php echo urlencode($item['message']) ?>">
                                            <i class="icon fa-google" aria-hidden="true"></i>
                                        </a>
                                    </figcaption>
                                </div>
                            </div>

                            <div class="widget-body" style="padding: 15px 10px;">
                                <h4 class="widget-title"
                                    style="height:42px; overflow:hidden;"><?php echo $item['title'] ?></h4>
                                <p style="text-align:justify; height: 66px; overflow: hidden;">
                                    <?php echo $item['message'] ?>
                                </p>

                                <div class="widget-actions text-center margin-top-50 margin-bottom-10">
                                    <a href="javascript:void(0)" title="Relevance Score" style="width:15%;">
                                        <i class="icon fa-star"></i>
                                        <span><?php echo $item['relevance_score'] ?></span>
                                    </a>
                                    <a href="javascript:void(0)" style="width:45%;">
                                        <i class="icon fa-dollar"></i>
                                        <span><?php echo $item['spend'] ?></span>
                                    </a>
                                    <a href="javascript:void(0)" style="width:29%;">
                                        <i class="icon fa-dot-circle-o"></i>
                                        <span><?php echo $item['link_clicks']?sprintf("%.2f", $item['results'] / $item['link_clicks'] * 100) . "%":'0' ?></span>
                                    </a>
                                </div>

                                <div class="clearfix padding-top-15" style="border-top:1px dashed #ededed;">
                                <span class="widget-metas pull-left text-success">
                                    <?php echo $item['effective_status'] ?>
                                </span>
                                    <?php if ($item['verify'] >= 1): ?>
                                        <?php if ($item['verify'] == 1): ?>
                                            <span class="btn btn-icon tooltip-primary btn-primary btn-round change_btn">
                                            <i class="icon fa-heart-o" aria-hidden="true"></i>
                                        </span>
                                        <?php elseif ($item['verify'] == 2): ?>
                                            <span class="btn btn-icon tooltip-warning btn-warning btn-round change_btn">
                                            <i class="icon fa-question" aria-hidden="true"></i>
                                        </span>
                                        <?php elseif ($item['verify'] == 3): ?>
                                            <span class="btn btn-icon tooltip-danger btn-danger btn-round change_btn">
                                            <i class="icon fa-close" aria-hidden="true"></i>
                                        </span>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                    <?php if ($item['verify'] < 0): ?>
                                        <span class="btn btn-icon tooltip-success btn-success btn-round change_btn">
                                        <i class="icon fa-check" aria-hidden="true"></i>
                                    </span>
                                    <?php endif; ?>

                                    <span
                                        class="widget-metas pull-right"><?php echo date('M d Y', $item['updated_time']) ?></span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- 侧划框 -->
                    <div class="col-md-7 col-sm-8 col-xs-12 slide_right"
                         style="background:#fff;position: fixed;right:-1300px;top: 112px; overflow-y: auto; z-index:100;">
                        <div class="row">
                            <div>
                                <div class="example-wrap" style="margin-bottom:0px;">
                                    <div class="example">
                                        <!-- 轮播图 -->
                                        <div class="slider exampleAdaptiveHeight" id="">
                                            <?php foreach ($item['ad'] as $ad): ?>
                                                <div>
                                                    <div class="col-md-4 col-sm-3">
                                                        <?php if ($ad['object_type'] == 'SHARE'): ?>
                                                            <img class="cover-image img-responsive overlay-scale"
                                                                 src="<?php echo $ad['org_image_url'] ?>" alt=""
                                                                 onerror="javascript:this.src='<?php echo $ad['image_url'] ?>'">
                                                        <?php elseif ($ad['object_type'] == 'MORE_SHARE'): ?>
                                                            <!-- 图片轮播图 -->
                                                            <div class="slider exampleVariableWidth"
                                                                 style="width:auto;">
                                                                <?php foreach ($ad['more_image'] as $image): ?>
                                                                    <div class="">
                                                                        <img class="cover-image img-responsive"
                                                                             src="<?php echo $image['url'] ?>" alt=""
                                                                             onerror="javascript:this.src='<?php echo base_url(); ?>assets/images/Artboard.png'">
                                                                    </div>
                                                                <?php endforeach; ?>
                                                            </div>
                                                        <?php elseif ($ad['object_type'] == 'VIDEO'): ?>
                                                            <video controls="controls"
                                                                   style="background-color: #000;width:100%"
                                                                   poster="<?php echo $ad['org_thumbnail_url'] ?>"
                                                                   preload='none'>
                                                                <source src="<?php echo $ad['video_url'] ?>"
                                                                        type="video/mp4"></source>
                                                            </video>
                                                        <?php else: ?>
                                                            <img class="cover-image img-responsive overlay-scale"
                                                                 src="<?php echo $ad['org_image_url'] ?>" alt=""
                                                                 onerror="javascript:this.src='<?php echo $ad['image_url'] ?>'">
                                                        <?php endif; ?>
                                                    </div>
                                                    <div class="col-md-8">
                                                        <h4 class="widget-title text-left"
                                                            style="padding-top:10px;"><?php echo $ad['title'] ?>
                                                            <span>(<?php echo date('M d Y', $ad['updated_time']) ?>
                                                                )</span></h4>
                                                        <p class="text-left"
                                                           style="margin-bottom:2px;"><?php echo $ad['message'] ?> </p>
                                                        <div class="example example-buttons" style="margin-top:10px">
                                                            <div class="pull-left">
                                                                <a target="_blank"
                                                                   href="https://translate.google.co.jp/?hl=en&tab=wT#auto/zh-CN/<?php echo $ad['title'] . "%0A" . $ad['message'] ?>"
                                                                   type="button" class="btn btn-outline btn-primary">See
                                                                    translate</a>
                                                                <!-- <a href="#" type="button" class="btn btn-outline btn-primary">See post</a> -->
                                                            </div>

                                                            <div class="tools_btn pull-right margin-top-5">
                                                                <button type="button"
                                                                        class="btn btn-icon tooltip-success btn-success btn-round  riview-success-btn <?php echo $item['verify'] == -1?'disabled':'' ?>"
                                                                        data-click="<?php echo $item['verify'] == -1?false:true ?>"
                                                                        data-id="<?php echo $item['market_ad_id'] ?>"
                                                                        data-val='-1' <?php echo $item['verify'] == -1?'':'data-toggle="tooltip"' ?>
                                                                        data-placement="top" data-trigger="click"
                                                                        data-original-title="<?php echo "Successfully" ?>">
                                                                    <i class="icon fa-check" aria-hidden="true"></i>
                                                                </button>
                                                                <button type="button"
                                                                        class="btn btn-icon tooltip-danger btn-danger btn-round  riview-danger-btn <?php echo $item['verify'] == 3?'disabled':'' ?>"
                                                                        data-click="<?php echo $item['verify'] == 3?false:true ?>"
                                                                        data-id="<?php echo $item['market_ad_id'] ?>"
                                                                        data-val='3' <?php echo $item['verify'] == 3?'':'data-toggle="tooltip"' ?>
                                                                        data-placement="top" data-trigger="click"
                                                                        data-original-title="<?php echo "Successfully" ?>">
                                                                    <i class="icon fa-close" aria-hidden="true"></i>
                                                                </button>
                                                                <button type="button"
                                                                        class="btn btn-icon tooltip-warning btn-warning btn-round  riview-warning-btn <?php echo $item['verify'] == 2?'disabled':'' ?>"
                                                                        data-click="<?php echo $item['verify'] == 2?'false':'true' ?>"
                                                                        data-id="<?php echo $item['market_ad_id'] ?>"
                                                                        data-val='2' <?php echo $item['verify'] == 2?'':'data-toggle="tooltip"' ?>
                                                                        data-placement="top" data-trigger="click"
                                                                        data-original-title="<?php echo "Successfully" ?>">
                                                                    <i class="icon fa-question" aria-hidden="true"></i>
                                                                </button>
                                                                <button type="button"
                                                                        class="btn btn-icon tooltip-primary btn-primary btn-round riview-like-btn <?php echo $item['verify'] == 1?'disabled':'' ?>"
                                                                        data-click="<?php echo $item['verify'] == 1?false:true ?>"
                                                                        data-id="<?php echo $item['market_ad_id'] ?>"
                                                                        data-val='1' <?php echo $item['verify'] == 1?'':'data-toggle="tooltip"' ?>
                                                                        data-placement="top" data-trigger="click"
                                                                        data-original-title="<?php echo "Successfully" ?>">
                                                                    <i class="icon fa-heart-o" aria-hidden="true"></i>
                                                                </button>
                                                                <a target="_blank" type="button"
                                                                   class="btn btn-icon social-facebook btn-round"
                                                                   href="https://business.facebook.com/ads/manager/ad/ads/?act=<?php echo $item['account_id'] ?>&ids=<?php echo $item['ad_id'] ?>">
                                                                    <i class="icon fa-facebook" aria-hidden="true"></i>
                                                                </a>
                                                                <a target="_blank" type="button"
                                                                   class="btn btn-icon btn-primary btn-round"
                                                                   href="https://translate.google.co.jp/?hl=en&tab=wT#auto/zh-CN/<?php echo urlencode($item['message']) ?>">
                                                                    <i class="icon fa-google" aria-hidden="true"></i>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endforeach; ?>

                                        </div>

                                        <div
                                            class="col-md-10 col-md-offset-1 margin-top-20 padding-top-25 padding-bottom-15"
                                            style="border-top:1px solid #eee;border-bottom:1px solid #eee; color:#333">
                                            <p class="white_space col-md-5">Product
                                                : <?php echo $item['product_name'] ?></p>
                                            <p class="white_space col-md-7">Adset
                                                : <?php echo $item['adset_name'] ?></p>

                                            <p class="white_space col-md-5">Account
                                                : <?php echo $item['account_id'] ?></p>
                                            <p class="white_space col-md-7">Campaign
                                                : <?php echo $item['campaign_name'] ?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- 详细数据 -->
                            <div class="col-md-10 col-md-offset-1">
                                <ul class="blocks blocks-xs-3 blocks-xlg-5 blocks-lg-5 blocks-md-3 blocks-sm-3">
                                    <li class="icondemo tooltip-primary" style="color:#62a8ea;" data-toggle="tooltip"
                                        data-placement="top"
                                        data-original-title="Impressions : <?php echo number_format($item['impressions']) ?>"
                                        title="">
                                        <i class="font-size-18 md-eye margin-right-5" aria-hidden="true"></i>
                                        <span class="font-size-16"
                                              style="color:#333;"><?php echo number_format($item['impressions']) ?></span>
                                    </li>
                                    <li class="icondemo tooltip-primary" style="color:#62a8ea;" data-toggle="tooltip"
                                        data-placement="top"
                                        data-original-title="Relevance : <?php echo $item['relevance_score'] ?>"
                                        title="">
                                        <i class="font-size-18 md-bookmark margin-right-5" aria-hidden="true"></i>
                                        <span class="font-size-16"
                                              style="color:#333;"><?php echo $item['relevance_score']?$item['relevance_score']:0 ?></span>
                                    </li>
                                    <li class="icondemo tooltip-primary" style="color:#62a8ea;" data-toggle="tooltip"
                                        data-placement="top"
                                        data-original-title="Clicks : <?php echo number_format($item['clicks']) ?>"
                                        title="">
                                        <i class="font-size-18 md-thumb-up margin-right-5" aria-hidden="true"></i>
                                        <span class="font-size-16"
                                              style="color:#333;"><?php echo number_format($item['clicks']) ?></span>
                                    </li>
                                    <li class="icondemo tooltip-primary" style="color:#62a8ea;" data-toggle="tooltip"
                                        data-placement="top"
                                        data-original-title="Shares : <?php echo number_format($item['shares']) ?>"
                                        title="">
                                        <i class="font-size-18 md-share margin-right-5" aria-hidden="true"></i>
                                        <span class="font-size-16"
                                              style="color:#333;"><?php echo number_format($item['shares']) ?></span>
                                    </li>
                                    <li class="icondemo tooltip-primary" style="color:#62a8ea;" data-toggle="tooltip"
                                        data-placement="top" data-original-title="Cost : $<?php echo $item['cost'] ?>"
                                        title="">
                                        <i class="font-size-18 md-money margin-right-5" aria-hidden="true"></i>
                                        <span class="font-size-16"
                                              style="color:#333;">$<?php echo $item['cost'] ?></span>
                                    </li>
                                    <li class="icondemo tooltip-primary" style="color:#62a8ea;" data-toggle="tooltip"
                                        data-placement="top"
                                        data-original-title="Results : <?php echo number_format($item['results']) ?>"
                                        title="">
                                        <i class="font-size-18 md-receipt margin-right-5" aria-hidden="true"></i>
                                        <span class="font-size-16"
                                              style="color:#333;"><?php echo number_format($item['results']) ?></span>
                                    </li>
                                    <li class="icondemo tooltip-primary" style="color:#62a8ea;" data-toggle="tooltip"
                                        data-placement="top"
                                        data-original-title="Likes : <?php echo number_format($item['likes']) ?>"
                                        title="">
                                        <i class="font-size-18 md-thumb-up margin-right-5" aria-hidden="true"></i>
                                        <span class="font-size-16"
                                              style="color:#333;"><?php echo number_format($item['likes']) ?></span>
                                    </li>
                                    <li class="icondemo tooltip-primary" style="color:#62a8ea;" data-toggle="tooltip"
                                        data-placement="top"
                                        data-original-title="Comments : <?php echo number_format($item['comments']) ?>"
                                        title="">
                                        <i class="font-size-18 md-comment-text margin-right-5" aria-hidden="true"></i>
                                        <span class="font-size-16"
                                              style="color:#333;"><?php echo number_format($item['comments']) ?></span>
                                    </li>
                                    <li class="icondemo tooltip-primary" style="color:#62a8ea;" data-toggle="tooltip"
                                        data-placement="top" data-original-title="CPC : $<?php echo $item['cpc'] ?>"
                                        title="">
                                        <i class="font-size-18 md-comment-text margin-right-5" aria-hidden="true"></i>
                                        <span class="font-size-16"
                                              style="color:#333;">$<?php echo $item['cpc'] ?></span>
                                    </li>
                                    <li class="icondemo tooltip-primary" style="color:#62a8ea;" data-toggle="tooltip"
                                        data-placement="top"
                                        data-original-title="Spent : $<?php echo sprintf("%.2f", $item['spend']) ?>"
                                        title="">
                                        <i class="font-size-18 md-balance-wallet margin-right-5" aria-hidden="true"></i>
                                        <span class="font-size-16"
                                              style="color:#333;">$<?php echo sprintf("%.2f", $item['spend']) ?></span>
                                    </li>
                                </ul>
                            </div>
                            <?php if (isset($item['comment_list']) && $item['comment_list']): ?>
                                <!-- table布局 -->
                                <div class="table-responsive col-md-10 col-md-offset-1">
                                    <table class="editable-table table-hover table table-striped"
                                           style="border-top:1px solid #eee; padding:0;">
                                        <thead>
                                        <tr>
                                            <th style="width:15%;">Facebook User</th>

                                            <th style="width:25%;">Post Comments</th>
                                            <th style="width:15%;">Featured</th>
                                            <th style="width:15%;">Created time</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php foreach ($item['comment_list'] as $comment): ?>
                                            <tr>
                                                <td><?php echo $comment['user_name'] ?></td>

                                                <td><?php echo $comment['message'] ?></td>
                                                <td><?php echo $comment['featured'] ?></td>
                                                <td><?php echo date('Y-m-d', $comment['created_time']) ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </li>
            <?php endforeach; ?>
            <?php else:?>
                <div class="clearfix margin-bottom-20 padding-top-10">
                    <h4 class="pull-left padding-left-30">Details</h4>
                    <div class="panel margin-bottom-0 height-500">
                        <div class="text-center padding-top-80">
                            <img src="<?php echo base_url(); ?>assets/images/no_data.png">
                            <h4 class="margin-top-30">NO DATA HERE</h4>
                            <p style="line-height: 18px;">I hate peeping Toms. For one thing they usually step all over<br>the hedges and plants on the side of someone's house killing</p>
                        </div>
                    </div>
                </div>
            <?php endif;?>
        </ul>
        <div class="fixed-table-pagination clearfix">
            <div class="pull-right pagination">
                <?php echo $page_links?>
            </div>
            <div class="pull-right" style="height: 42px;line-height: 42px;margin-right: 20px;    margin-top: 26px;">
                <button type="button" class="btn btn-outline btn-info pagination" id="is_read">Mark as read</button>

            </div>
        </div>
    </div>

</div>
<div id="ad_ids" data="<?php echo $ad_ids ?>"></div>

<script src="<?php echo base_url(); ?>assets/web/global/vendor/datatables/jquery.dataTables.js"></script>
<script
    src="<?php echo base_url(); ?>assets/web/global/vendor/datatables-fixedheader/dataTables.fixedHeader.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/vendor/datatables-bootstrap/dataTables.bootstrap.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/vendor/datatables-responsive/dataTables.responsive.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/vendor/datatables-tabletools/dataTables.tableTools.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/vendor/editable-table/mindmup-editabletable.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/vendor/editable-table/numeric-input-example.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/vendor/owl-carousel/owl.carousel.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/vendor/slick-carousel/slick.js"></script>

<script src="<?php echo base_url(); ?>assets/web/global/js/components/datatables.js"></script>
<script src="<?php echo base_url(); ?>assets/web/assets/examples/js/tables/datatable.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/vendor/select2/select2.min.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/js/components/select2.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/js/components/editable-table.js"></script>
<script src="<?php echo base_url(); ?>assets/web/assets/examples/js/tables/editable.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/js/components/owl-carousel.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/js/components/panel.js"></script>
<script src="<?php echo base_url(); ?>assets/web/assets/examples/js/uikit/panel-actions.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/vendor/slidepanel/jquery-slidePanel.js"></script>
<script src="<?php echo base_url(); ?>assets/web/assets/js/app.js"></script>
<script src="<?php echo base_url(); ?>assets/js/new_js.js"></script>

<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/moment.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/daterangepicker.js"></script>
<script src="<?php echo base_url(); ?>assets/web/assets/examples/js/uikit/icon.js"></script>

<script src="<?php echo base_url(); ?>assets/web/global/vendor/webui-popover/jquery.webui-popover.min.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/vendor/toolbar/jquery.toolbar.min.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/js/components/webui-popover.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/js/components/toolbar.js"></script>
<script src="<?php echo base_url(); ?>assets/web/assets/examples/js/uikit/tooltip-popover.js"></script>
<script src="<?php echo base_url();?>assets/js/index_select.js"></script>
<script type="text/javascript">

    $('.exampleAdaptiveHeight').slick({
        dots: true,
        infinite: true,
        speed: 300,
        slidesToShow: 1,
        adaptiveHeight: true
    });

    $('.exampleVariableWidth').slick({
        dots: true,
        infinite: true,
        speed: 300,
        slidesToShow: 1,
        adaptiveHeight: true
    });

    function cb(start, end) {
        $('#reportrange span').html(start.format('MM/DD/YYYY') + ' - ' + end.format('MM/DD/YYYY'));
        $(".date_start").val(start.format('MM/DD/YYYY'));
        $(".date_end").val(end.format('MM/DD/YYYY'));
    }

    cb(moment().subtract(3, 'days'), moment());

    <?php if($this->input->get('start')):?>
    $('#reportrange').daterangepicker({
        "startDate": "<?php echo urldecode($this->input->get('start'))?>",
        "endDate": "<?php echo urldecode($this->input->get('end'))?>",
        ranges: {
            'Today': [moment(), moment()],
            'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
            'Last 7 Days': [moment().subtract(6, 'days'), moment()],
            'Last 30 Days': [moment().subtract(29, 'days'), moment()],
            'This Month': [moment().startOf('month'), moment().endOf('month')],
            'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
        }
    }, cb);
    $('#reportrange span').html("<?php echo urldecode($this->input->get('start'))?>" + ' - ' + "<?php echo urldecode($this->input->get('end'))?>");
    $(".date_start").val("<?php echo urldecode($this->input->get('start'))?>");
    $(".date_end").val("<?php echo urldecode($this->input->get('end'))?>");
    <?php else:?>
    $('#reportrange').daterangepicker({
        ranges: {
            'Today': [moment(), moment()],
            'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
            'Last 7 Days': [moment().subtract(6, 'days'), moment()],
            'Last 30 Days': [moment().subtract(29, 'days'), moment()],
            'This Month': [moment().startOf('month'), moment().endOf('month')],
            'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
        }
    }, cb);
    <?php endif;?>
    $(function () {
        $('input[name="campaign"]').keydown(function (e) {
            if (e.keyCode == 13) {
                var keyword = $(this).val();
                location.href = site_url + 'review/index?campaign=' + keyword;
            }
        });
        $(".input-search-btn").click(function () {
            var keyword = $('input[name="campaign"]').val();
            location.href = site_url + 'review/index?campaign=' + keyword;
        });
    });

</script>

