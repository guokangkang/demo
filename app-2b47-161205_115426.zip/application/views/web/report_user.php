<style type="text/css">
    #female>div{margin-top:-58px!important;}
    #male>div{z-index: 100;}
</style>
<div class="page animsition">
    <div class="page-header">
      <ol class="breadcrumb">
        <li><a href="<?php echo site_url('reports/index');?>">Reports</a></li>
        <li class="active">User Graphs</li>
      </ol>
    </div>
    <div class="page-content">   
        <!-- Panel Table Tools -->
        <div class="row">
            

            <div class="col-md-6">
                <div class="panel">
                    <div class="panel-body" style="padding-bottom:87px;">
                        <div class="col-md-2 padding-right-0" style="margin-top:50px;">
                            <p style="margin-bottom:30px;margin-top:12px;">
                                <span class="font-weight-600" style="display:block;font-size:16px;color:#41494f;"><?php echo $gender_data['male']?></span>
                                <span style="display:block;line-height:16px; ">
                                    <i class="pull-left" style="width:16px; height:16px;background:#d8d8d8;"></i>
                                    <i class="pull-left" style="margin-left:8px;">Male</i>
                                </span>
                            </p>
                            <p style="margin-bottom:30px;">
                                <span class="font-weight-600" style="display:block;font-size:16px;color:#41494f;"><?php echo $gender_data['female']?></span>
                                <span style="display:block;line-height:16px;">
                                    <i class="pull-left" style="width:16px; height:16px;background:#12abc5;"></i>
                                    <i class="pull-left" style="margin-left:8px;">Female</i>
                                </span>
                            </p>
                        </div>
                        <div class="col-md-10 table-responsive">
                            <div id="male" style="height:140px;" data-age='<?php echo $age_info?>' data-male="<?php echo $male_chart?>"></div>
                            <div id="female" style="height:140px;" data-age='<?php echo $age_info?>' data-female="<?php echo $female_chart?>"></div>
                        </div> 
                    </div>
                </div>  
            </div>

            <!-- 世界地图 -->
            <div class="col-md-6">
                <div class="panel">
                    <div class="panel-body table-responsive" style="height:340px; overflow-y:auto;">
                        <div id="container" style="height:100%;" data-val='<?php echo $country_data?>'></div>
                    </div>
                </div>  
            </div>
            <!-- 时间段 -->
            <div class="col-md-12">
                <div class="panel">
                    <div class="panel-body table-responsive" style="height:472px;">
                        <div id="time" style="height:100%;" data-x='<?php echo $watch_chart_x?>' data-y="<?php echo $watch_chart_y?>"></div> 
                    </div>
                </div>
            </div>
            <!-- 设备 -->
            <div class="col-md-6">
                <div class="panel">
                    <div class="panel-body table-responsive" style="height:465px;">
                        <div id="device" style="height:100%;" data-x='<?php echo $device_chart_x?>' data-y='<?php echo $device_chart_y?>'></div>
                    </div>
                </div>
            </div>
            <!-- 设备 -->
            <div class="col-md-6">
                <div class="panel">
                    <div class="panel-body table-responsive" style="height:465px;">
                        <div id="rose" style="height:100%;" data-x='<?php echo $placement_chart_x?>' data-y='<?php echo $placement_chart_y?>'></div>
                    </div>
                </div>
            </div>

            <!-- 城市 -->
            <div class="col-md-12">
                <div class="panel">
                    <div class="panel-body table-responsive" style="height:350px; overflow-y:auto;">
                        <table  class="table .table-bordered width-full">
                            <thead>
                                <tr>
                                    <th width="width:20%">Region</th>
                                    <th width="width:10%">Installs</th>
                                    <th width="width:20%">Region</th>
                                    <th width="width:10%">Installs</th>
                                    <th width="width:20%">Region</th>
                                    <th width="width:10%">Installs</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($region_info as $item):?>
                                    <tr>
                                        <?php foreach($item as $v):?>
                                            <td><?php echo $v['region']?></td>
                                            <td><?php echo $v['results']?></td>
                                        <?php endforeach;?>
                                    </tr>
                                <?php endforeach;?>
                            </tbody>
                        </table>
                    </div>
                </div>  
            </div>
        </div>
        <!-- End Panel Table Tools -->
    </div>
  </div>




<script type="text/javascript" src="http://echarts.baidu.com/gallery/vendors/echarts/echarts-all-3.js"></script>
<script type="text/javascript" src="http://echarts.baidu.com/gallery/vendors/echarts/extension/dataTool.min.js"></script>
<script type="text/javascript" src="http://echarts.baidu.com/gallery/vendors/echarts/map/js/china.js"></script>
<script type="text/javascript" src="http://echarts.baidu.com/gallery/vendors/echarts/map/js/world.js"></script>
<script type="text/javascript" src="http://api.map.baidu.com/api?v=2.0&ak=ZUONbpqGBsYGXNIYHicvbAbM"></script>
<script src="<?php echo base_url();?>assets/js/echart.js"></script>