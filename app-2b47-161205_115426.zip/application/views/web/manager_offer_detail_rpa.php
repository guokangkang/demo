<div class="panel margin-bottom-0">
    <div class="row padding-top-30">
        <div class="col-sm-6">
            <form class="form-horizontal" autocomplete="off" id="offer_set_rpa_form"  method="post" action="<?php echo site_url('manager/offer/set_offer_rpa_action')?>">
                <input type="hidden" name="product_id" value="<?php echo $product_info['product_id']?>">
                <input type="hidden" name="offer_id" value="<?php echo $offer_info['offer_id']?>">
                
                <div class="form-group">
                    <label class="col-sm-3 control-label" for="contact">RPA</label>
                    <div class="col-sm-9">
                        <div class="input-group">
                            <span class="input-group-addon bootstrap-touchspin-prefix">$</span>
                            <input type="text" class="form-control" id="input_rpa" name="input_rpa" data-fv-notempty="true" onkeyup="value=value.replace(/[^\d|.]/g,'')" value="" />
                        </div>
                    </div>
                </div>
 
                <div class="form-group">
                    <label class="col-sm-3 control-label" for="contact">Effective Time</label>
                    <div class="col-sm-9">
                        <div class="input-daterange">
                            <div class="input-group">
                                <span class="input-group-addon">
                                    <i class="icon wb-calendar" aria-hidden="true"></i>
                                </span>
                                    <input type="text" class="form-control datepair-date datepair-start" data-plugin="datepicker" name="input_date" id="inputdate" value="<?php echo date('m/d/Y')?>">
                            </div>
                            <div class="input-group ">
                                <span class="input-group-addon">
                                    <i class="icon wb-time" aria-hidden="true"></i>
                                </span>
                                <input type="text" class="form-control datepair-time datepair-start" data-plugin="timepicker" name="input_time" id="inputtime"
                                    value="<?php echo date('H:i a')?>" />
                            </div>
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label class="col-sm-3 control-label" for="contact"></label>
                    <div class="col-sm-9">
                        <button class="btn btn-info product_bucket_payout_save" data-dismiss="" type="submit" id="offer_set_rpa_button">Submit</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <header class="panel-heading margin-bottom-0 clearfix">
        <h3 class="panel-title pull-left">Details</h3>
    </header>
    <div class="panel-body table-responsive">
        <table class="table dataTable table-striped width-full" id="facebook_report">
            <thead class="change_thead">
                <tr>
                    <th style="width: 30%">Effective time</th>
                    <th style="width: 20%">RPA</th>
                    <th style="width: 10%"></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($rpa_list as $key=>$item):?>
                <tr>
                    <td><?php echo date('m/d/Y H:i', $item['start_time'])?></td>
                    <td>$<?php echo sprintf("%.2f", $item['rpa'])?></td>
                    <?php if($item['is_current']):?>
                        <td><span class="label label-table label-success">Current</span></td>
                    <?php else:?>
                        <td></td>
                    <?php endif;?>
                </tr>
            <?php endforeach;?>
            </tbody>
        </table>
    </div>
</div>