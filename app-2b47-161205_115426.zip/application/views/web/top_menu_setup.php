<div class="site-menubar site-menubar-light">
    <div class="site-menubar-body">
        <div>
            <div>
                <ul class="site-menu">


                    <?php if($this->router->method=='password' && $this->_class=='setup'):?>
                    <li class="site-menu-item <?php echo ($this->router->class=='setup'&&$this->router->method=='password')?'active':''?>">
                        <a href="<?php echo site_url('setup/password')?>">
                            <i class="site-menu-icon wb-mobile" aria-hidden="true"></i>
                            <span class="site-menu-title">Edit Password</span>
                        </a>
                    </li>
                    <?php endif;?>
                </ul>
            </div>
        </div>
    </div>
</div>