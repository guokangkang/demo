<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/assets/examples/css/tables/datatable.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/global/vendor/select2/select2.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/global/vendor/owl-carousel/owl.carousel.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/global/vendor/slick-carousel/slick.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/assets/examples/css/uikit/carousel.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/daterangepicker.css"/>

<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/global/fonts/material-design/material-design.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/assets/examples/css/uikit/icon.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/index_select.css">

<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/global/vendor/webui-popover/webui-popover.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/global/vendor/toolbar/toolbar.css">
<style>
    .red_color {
        color: red !important;
    }

    .red_orange {
        color: orange !important;
    }

    .table > tbody > tr > td {
        vertical-align: middle;
    }

    .table > .no_border > tr > td {
        border-top: none;
        font-size: 18px;
    }

    @media screen and (max-width: 767px) {
        .table-responsive {
            border: none;
        }

        .slide_right {
            top: 60px !important;
        }
    }

    .span_block {
        position: relative;
    }

    .span_block span {
        display: block;
        width: 100%;
        height: 100%;
    }

    .span_block input {
        display: none;
    }

    .span_block input.active {
        display: block;
        position: absolute;
        left: 0;
        top: 0;
    }

    .change_btn {
        padding: 2px;
        font-size: 12px;
        margin-top: -6px;
        margin-left: 5px;
    }

    .overlay figcaption .btn {
        margin-left: 4px;
    }

    .tools_btn .btn {
        margin-right: 2px !important;
        padding: 7px !important;
        font-size: 12 !important;
    }

    .panel-actions {
        z-index: 0 !important;
    }

    .exampleVariableWidth img {
        border-top: none;
        border-bottom: none;
    }

    .exampleVariableWidth {
        margin: 0;
    }

    .exampleVariableWidth .slick-prev {
        left: 4px;
        z-index: 12;
    }

    .exampleVariableWidth .slick-next {
        right: 4px;
    }
    .right_close{color:#eee;}
    .right_close:hover{color:#76838f;}
</style>

<div class="page animsition">
    <div class="page-header">
        <ol class="breadcrumb">
            <li><a href="<?php echo site_url('review') ?>">Creative</a></li>
            <li><a href="<?php echo site_url('review') ?>">Review</a></li>
            <li class="active">Risk</li>
        </ol>
    </div>
    <div class="page-content">
        <ul class="blocks blocks-100 blocks-xlg-4 blocks-lg-4 blocks-md-3 blocks-sm-2" id="click_btn"
            data-plugin="masonry" data-plugin="animateList" data-child=">li">
            <?php if($ad_list):?>
            <?php foreach ($ad_list as $key=>$item): ?>
                <li class="masonry-item  margin-bottom-0 ad_li">
                    <div class="media-item">
                        <div class="widget">
                            <div class="widget-header">
                                <div class="overlay overlay-hover review-cover-image overlay_click">
                                    <?php if ($item['object_type'] == 'SHARE'): ?>
                                        <img class="cover-image img-responsive"
                                             src="<?php echo $item['org_image_url'] ?>" alt=""
                                             onerror="javascript:this.src='<?php echo $item['image_url'] ?>'">
                                    <?php elseif ($item['object_type'] == 'MORE_SHARE'): ?>
                                        <!-- 图片轮播图 -->
                                        <div class="slider exampleVariableWidth" style="width:auto;">
                                            <?php foreach ($item['more_image'] as $image): ?>
                                                <div class="">
                                                    <img class="cover-image img-responsive"
                                                         src="<?php echo $image['url'] ?>" alt=""
                                                         onerror="javascript:this.src='<?php echo base_url(); ?>assets/images/Artboard.png'">
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                    <?php elseif ($item['object_type'] == 'VIDEO'): ?>
                                        <video controls="controls" style="background-color: #000;"
                                               poster="<?php echo $item['org_thumbnail_url'] ?>" preload='none'>
                                            <source src="<?php echo $item['video_url'] ?>" type="video/mp4"></source>
                                        </video>
                                    <?php else: ?>
                                        <img class="cover-image img-responsive overlay-scale"
                                             src="<?php echo $item['org_image_url'] ?>" alt=""
                                             onerror="javascript:this.src='<?php echo $item['image_url'] ?>'">
                                    <?php endif; ?>
                                    <figcaption
                                        class="overlay-top overlay-panel overlay-background overlay-slide-top padding-10 text-center">
                                        <button type="button"
                                                class="btn btn-icon tooltip-success btn-success btn-round  riview-success-btn <?php echo $item['verify'] == -1?'disabled':'' ?>"
                                                data-click="<?php echo $item['verify'] == -1?false:true ?>"
                                                data-id="<?php echo $item['ad_id'] ?>"
                                                data-val='-1' <?php echo $item['verify'] == -1?'':'data-toggle="tooltip"' ?>
                                                data-placement="bottom" data-trigger="click"
                                                data-original-title="<?php echo "Successfully" ?>">
                                            <i class="icon fa-check" aria-hidden="true"></i>
                                        </button>
                                        <button type="button"
                                                class="btn btn-icon tooltip-danger btn-danger btn-round  riview-danger-btn <?php echo $item['verify'] == 3?'disabled':'' ?>"
                                                data-click="<?php echo $item['verify'] == 3?false:true ?>"
                                                data-id="<?php echo $item['ad_id'] ?>"
                                                data-val='3' <?php echo $item['verify'] == 3?'':'data-toggle="tooltip"' ?>
                                                data-placement="bottom" data-trigger="click"
                                                data-original-title="<?php echo "Successfully" ?>">
                                            <i class="icon fa-close" aria-hidden="true"></i>
                                        </button>
                                        <button type="button"
                                                class="btn btn-icon tooltip-warning btn-warning btn-round  riview-warning-btn <?php echo $item['verify'] == 2?'disabled':'' ?>"
                                                data-click="<?php echo $item['verify'] == 2?'false':'true' ?>"
                                                data-id="<?php echo $item['ad_id'] ?>"
                                                data-val='2' <?php echo $item['verify'] == 2?'':'data-toggle="tooltip"' ?>
                                                data-placement="bottom" data-trigger="click"
                                                data-original-title="<?php echo "Successfully" ?>">
                                            <i class="icon fa-question" aria-hidden="true"></i>
                                        </button>
                                        <button type="button"
                                                class="btn btn-icon tooltip-primary btn-primary btn-round riview-like-btn <?php echo $item['verify'] == 1?'disabled':'' ?>"
                                                data-click="<?php echo $item['verify'] == 1?false:true ?>"
                                                data-id="<?php echo $item['ad_id'] ?>"
                                                data-val='1' <?php echo $item['verify'] == 1?'':'data-toggle="tooltip"' ?>
                                                data-placement="bottom" data-trigger="click"
                                                data-original-title="<?php echo "Successfully" ?>">
                                            <i class="icon fa-heart-o" aria-hidden="true"></i>
                                        </button>
                                        <a target="_blank" type="button" class="btn btn-icon social-facebook btn-round"
                                           href="https://business.facebook.com/ads/manager/ad/ads/?act=<?php echo $item['account_id'] ?>&ids=<?php echo $item['ad_id'] ?>">
                                            <i class="icon fa-facebook" aria-hidden="true"></i>
                                        </a>
                                        <a target="_blank" type="button" class="btn btn-icon btn-primary btn-round"
                                           href="https://translate.google.co.jp/?hl=en&tab=wT#auto/zh-CN/<?php echo urlencode($item['message']) ?>">
                                            <i class="icon fa-google" aria-hidden="true"></i>
                                        </a>
                                    </figcaption>
                                </div>
                            </div>
 
                            <div class="widget-body click_li" data-tof="false" style="padding: 15px 10px;">
                                <h4 class="widget-title"
                                    style="height:42px; overflow:hidden;"><?php echo $item['title']?></h4>
                                <p style="text-align:justify; height: 66px; overflow: hidden;">
                                    <?php echo $item['message'] ?>
                                </p>

                                <div class="widget-actions text-center margin-top-50 margin-bottom-10 row">
                                    <span><?php //echo date('M d Y', $item['start_date'])?>  
                                        <?php 
                                            foreach ($item['risk'] as $key => $value) {
                                                if ($key=='ctr' || $key=='cvr') {
                                                    echo strtoupper($key) ." >= ".$value."%";
                                                }else{
                                                    echo strtoupper($key) ." >= ".$value;
                                                }
                                                echo "<br/>";
                                            }
                                        ?>
                                        
                                    </span>
                                </div>

                                <div class="clearfix padding-top-15" style="border-top:1px dashed #ededed; height:38px;">
                                <span class="widget-metas pull-left text-success">
                                    <?php echo $item['effective_status'] ?>
                                </span>
                                    <?php if ($item['verify'] >= 1): ?>
                                        <?php if ($item['verify'] == 1): ?>
                                            <span class="btn btn-icon tooltip-primary btn-primary btn-round change_btn">
                                            <i class="icon fa-heart-o" aria-hidden="true"></i>
                                        </span>
                                        <?php elseif ($item['verify'] == 2): ?>
                                            <span class="btn btn-icon tooltip-warning btn-warning btn-round change_btn">
                                            <i class="icon fa-question" aria-hidden="true"></i>
                                        </span>
                                        <?php elseif ($item['verify'] == 3): ?>
                                            <span class="btn btn-icon tooltip-danger btn-danger btn-round change_btn">
                                            <i class="icon fa-close" aria-hidden="true"></i>
                                        </span>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                    <?php if ($item['verify'] < 0): ?>
                                        <span class="btn btn-icon tooltip-success btn-success btn-round change_btn">
                                        <i class="icon fa-check" aria-hidden="true"></i>
                                    </span>
                                    <?php endif; ?>

                                    <span
                                        class="widget-metas pull-right"><?php echo date('M d Y', $item['updated_time']) ?></span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- 侧划框 -->
                    <div class="col-md-7 col-sm-8 col-xs-12 slide_right"
                         style="background:#fff;position: fixed;right:-1600px;top: 110px; overflow-y: auto; z-index:100;box-shadow:-5px 2px 7px 0 #f5f8fa;">
                        <div class="row">
                            <div>
                                <div class="example-wrap" style="margin-bottom:0px;">
                                    <div class="example">
                                        <!-- 轮播图 -->
                                        <div class="slider exampleAdaptiveHeight" id="">
                                            <?php foreach ($item['ads'] as $ad): ?>
                                                <div>
                                                    <div class="col-md-4 col-sm-3">
                                                        <?php if ($ad['object_type'] == 'SHARE'): ?>
                                                            <img class="cover-image img-responsive overlay-scale"
                                                                 src="<?php echo $ad['org_image_url'] ?>" alt=""
                                                                 onerror="javascript:this.src='<?php echo $ad['image_url'] ?>'">
                                                        <?php elseif ($ad['object_type'] == 'MORE_SHARE'): ?>
                                                            <!-- 图片轮播图 -->
                                                            <div class="slider exampleVariableWidth"
                                                                 style="width:auto;">
                                                                <?php foreach ($ad['more_image'] as $image): ?>
                                                                    <div class="">
                                                                        <img class="cover-image img-responsive"
                                                                             src="<?php echo $image['url'] ?>" alt=""
                                                                             onerror="javascript:this.src='<?php echo base_url(); ?>assets/images/Artboard.png'">
                                                                    </div>
                                                                <?php endforeach; ?>
                                                            </div>
                                                        <?php elseif ($ad['object_type'] == 'VIDEO'): ?>
                                                            <video controls="controls"
                                                                   style="background-color: #000;width:100%"
                                                                   poster="<?php echo $ad['org_thumbnail_url'] ?>"
                                                                   preload='none'>
                                                                <source src="<?php echo $ad['video_url'] ?>"
                                                                        type="video/mp4"></source>
                                                            </video>
                                                        <?php else: ?>
                                                            <img class="cover-image img-responsive overlay-scale"
                                                                 src="<?php echo $ad['org_image_url'] ?>" alt=""
                                                                 onerror="javascript:this.src='<?php echo $ad['image_url'] ?>'">
                                                        <?php endif; ?>
                                                    </div>
                                                    <div class="col-md-8">
                                                        <h4 class="widget-title text-left"
                                                            style="padding-top:10px;"><?php echo $ad['title'] ?>
                                                            <span>(<?php echo date('M d Y', $ad['updated_time']) ?>
                                                                )</span></h4>
                                                        <p class="text-left"
                                                           style="margin-bottom:2px;"><?php echo $ad['message'] ?> </p>
                                                        <div class="example example-buttons" style="margin-top:10px">
                                                            <div class="pull-left">
                                                                <a target="_blank"
                                                                   href="https://translate.google.co.jp/?hl=en&tab=wT#auto/zh-CN/<?php echo $ad['title'] . "%0A" . $ad['message'] ?>"
                                                                   type="button" class="btn btn-outline btn-primary">See
                                                                    translate</a>
                                                                <!-- <a href="#" type="button" class="btn btn-outline btn-primary">See post</a> -->
                                                            </div>

                                                            <div class="tools_btn pull-right margin-top-5">
                                                                <button type="button"
                                                                        class="btn btn-icon tooltip-success btn-success btn-round  riview-success-btn <?php echo $item['verify'] == -1?'disabled':'' ?>"
                                                                        data-click="<?php echo $item['verify'] == -1?false:true ?>"
                                                                        data-id="<?php echo $item['ad_id'] ?>"
                                                                        data-val='-1' <?php echo $item['verify'] == -1?'':'data-toggle="tooltip"' ?>
                                                                        data-placement="top" data-trigger="click"
                                                                        data-original-title="<?php echo "Successfully" ?>">
                                                                    <i class="icon fa-check" aria-hidden="true"></i>
                                                                </button>
                                                                <button type="button"
                                                                        class="btn btn-icon tooltip-danger btn-danger btn-round  riview-danger-btn <?php echo $item['verify'] == 3?'disabled':'' ?>"
                                                                        data-click="<?php echo $item['verify'] == 3?false:true ?>"
                                                                        data-id="<?php echo $item['ad_id'] ?>"
                                                                        data-val='3' <?php echo $item['verify'] == 3?'':'data-toggle="tooltip"' ?>
                                                                        data-placement="top" data-trigger="click"
                                                                        data-original-title="<?php echo "Successfully" ?>">
                                                                    <i class="icon fa-close" aria-hidden="true"></i>
                                                                </button>
                                                                <button type="button"
                                                                        class="btn btn-icon tooltip-warning btn-warning btn-round  riview-warning-btn <?php echo $item['verify'] == 2?'disabled':'' ?>"
                                                                        data-click="<?php echo $item['verify'] == 2?'false':'true' ?>"
                                                                        data-id="<?php echo $item['ad_id'] ?>"
                                                                        data-val='2' <?php echo $item['verify'] == 2?'':'data-toggle="tooltip"' ?>
                                                                        data-placement="top" data-trigger="click"
                                                                        data-original-title="<?php echo "Successfully" ?>">
                                                                    <i class="icon fa-question" aria-hidden="true"></i>
                                                                </button>
                                                                <button type="button"
                                                                        class="btn btn-icon tooltip-primary btn-primary btn-round riview-like-btn <?php echo $item['verify'] == 1?'disabled':'' ?>"
                                                                        data-click="<?php echo $item['verify'] == 1?false:true ?>"
                                                                        data-id="<?php echo $item['ad_id'] ?>"
                                                                        data-val='1' <?php echo $item['verify'] == 1?'':'data-toggle="tooltip"' ?>
                                                                        data-placement="top" data-trigger="click"
                                                                        data-original-title="<?php echo "Successfully" ?>">
                                                                    <i class="icon fa-heart-o" aria-hidden="true"></i>
                                                                </button>
                                                                <a target="_blank" type="button"
                                                                   class="btn btn-icon social-facebook btn-round"
                                                                   href="https://business.facebook.com/ads/manager/ad/ads/?act=<?php echo $item['account_id'] ?>&ids=<?php echo $item['ad_id'] ?>">
                                                                    <i class="icon fa-facebook" aria-hidden="true"></i>
                                                                </a>
                                                                <a target="_blank" type="button"
                                                                   class="btn btn-icon btn-primary btn-round"
                                                                   href="https://translate.google.co.jp/?hl=en&tab=wT#auto/zh-CN/<?php echo urlencode($item['message']) ?>">
                                                                    <i class="icon fa-google" aria-hidden="true"></i>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endforeach; ?>

                                        </div>

                                        <div
                                            class="col-md-10 col-md-offset-1 margin-top-20 padding-top-25 padding-bottom-15"
                                            style="border-top:1px solid #eee;border-bottom:1px solid #eee; color:#333">
                                            <p class="white_space col-md-5">Product
                                                : <?php echo $item['product_name'] ?></p>
                                            <p class="white_space col-md-7">Adset
                                                : <?php echo $item['adset_name'] ?></p>

                                            <p class="white_space col-md-5">Account
                                                : <?php echo $item['account_id'] ?></p>
                                            <p class="white_space col-md-7">Campaign
                                                : <?php echo $item['campaign_name'] ?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- 详细数据 -->
                            
                            <?php if (isset($item['insights']) && $item['insights']): ?>
                                <!-- table布局 -->
                                <div class="table-responsive col-md-10 col-md-offset-1">
                                    <table class="editable-table table-hover table table-striped"
                                           style="">
                                        <thead>
                                        <tr>
                                            <th style="width:15%;">Date</th>
                                            <th style="width:25%;">Results</th>
                                            <th style="width:15%;">Impressions</th>
                                            <th style="width:15%;">Clicks</th>
                                            <th style="width:15%;">Spend</th>
                                            <th style="width:15%;">CTR</th>
                                            <th style="width:15%;">CVR</th>
                                            <th style="width:15%;">CPI</th>
                                            <th style="width:5%;">Likes</th>
                                            <th style="width:5%;">Comments</th>
                                            <th style="width:5%;">Shares</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php foreach ($item['insights'] as $item): ?>
                                            <tr>
                                                <td><?php echo date('M d', $item['date']) ?></td>

                                                <td><?php echo number_format($item['results']) ?></td>
                                                <td><?php echo number_format($item['impressions']) ?></td>
                                                <td><?php echo number_format($item['clicks']) ?></td>
                                                <td>$<?php echo number_format($item['spend'], 2) ?></td>
                                                <td><?php echo sprintf("%.2f", $item['ctr'])?>%</td>
                                                <td><?php echo sprintf("%.2f", $item['cvr']*100)?>%</td>
                                                <td>$<?php echo sprintf("%.2f", $item['cost'])?></td>
                                                <td><?php echo number_format($item['likes'])?></td>
                                                <td><?php echo number_format($item['comments'])?></td>
                                                <td><?php echo number_format($item['shares'])?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="right_close" style="position: absolute; left:10px;top: 50%;font-size:40px;cursor: pointer;">
                            <i class="icon md-chevron-right" aria-hidden="true"></i>
                        </div>
                    </div>
                </li>
            <?php endforeach; ?>
            <?php else:?>
                <div class="clearfix margin-bottom-20 padding-top-10">
                    <h4 class="pull-left padding-left-30">Details</h4>
                    <div class="panel margin-bottom-0 height-500">
                        <div class="text-center padding-top-80">
                            <img src="<?php echo base_url(); ?>assets/images/no_data.png">
                            <h4 class="margin-top-30">NO DATA HERE</h4>
                            <p style="line-height: 18px;">I hate peeping Toms. For one thing they usually step all over<br>the hedges and plants on the side of someone's house killing</p>
                        </div>
                    </div>
                </div>
            <?php endif;?>
        </ul>
        <div class="fixed-table-pagination clearfix">
            <div class="pull-right pagination">
                <?php echo $page_links?>
            </div>
            <div class="pull-right" style="height: 42px;line-height: 42px;margin-right: 20px;    margin-top: 26px;">
                <button type="button" class="btn btn-outline btn-info pagination" id="is_read">Mark as read</button>

            </div>
        </div>
    </div>

</div>

<script src="<?php echo base_url(); ?>assets/web/global/vendor/datatables/jquery.dataTables.js"></script>
<script
    src="<?php echo base_url(); ?>assets/web/global/vendor/datatables-fixedheader/dataTables.fixedHeader.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/vendor/datatables-bootstrap/dataTables.bootstrap.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/vendor/datatables-responsive/dataTables.responsive.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/vendor/datatables-tabletools/dataTables.tableTools.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/vendor/editable-table/mindmup-editabletable.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/vendor/editable-table/numeric-input-example.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/vendor/owl-carousel/owl.carousel.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/vendor/slick-carousel/slick.js"></script>

<script src="<?php echo base_url(); ?>assets/web/global/js/components/datatables.js"></script>
<script src="<?php echo base_url(); ?>assets/web/assets/examples/js/tables/datatable.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/vendor/select2/select2.min.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/js/components/select2.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/js/components/editable-table.js"></script>
<script src="<?php echo base_url(); ?>assets/web/assets/examples/js/tables/editable.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/js/components/owl-carousel.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/js/components/panel.js"></script>
<script src="<?php echo base_url(); ?>assets/web/assets/examples/js/uikit/panel-actions.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/vendor/slidepanel/jquery-slidePanel.js"></script>
<script src="<?php echo base_url(); ?>assets/web/assets/js/app.js"></script>
<script src="<?php echo base_url(); ?>assets/js/new_js.js"></script>

<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/moment.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/daterangepicker.js"></script>
<script src="<?php echo base_url(); ?>assets/web/assets/examples/js/uikit/icon.js"></script>

<script src="<?php echo base_url(); ?>assets/web/global/vendor/webui-popover/jquery.webui-popover.min.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/vendor/toolbar/jquery.toolbar.min.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/js/components/webui-popover.js"></script>
<script src="<?php echo base_url(); ?>assets/web/global/js/components/toolbar.js"></script>
<script src="<?php echo base_url(); ?>assets/web/assets/examples/js/uikit/tooltip-popover.js"></script>
<script src="<?php echo base_url();?>assets/js/index_select.js"></script>
<script type="text/javascript">

    $('.exampleAdaptiveHeight').slick({
        dots: true,
        infinite: true,
        speed: 300,
        slidesToShow: 1,
        adaptiveHeight: true
    });

    $('.exampleVariableWidth').slick({
        dots: true,
        infinite: true,
        speed: 300,
        slidesToShow: 1,
        adaptiveHeight: true
    });

    function cb(start, end) {
        $('#reportrange span').html(start.format('MM/DD/YYYY') + ' - ' + end.format('MM/DD/YYYY'));
        $(".date_start").val(start.format('MM/DD/YYYY'));
        $(".date_end").val(end.format('MM/DD/YYYY'));
    }

    cb(moment().subtract(3, 'days'), moment());

    <?php if($this->input->get('start')):?>
    $('#reportrange').daterangepicker({
        "startDate": "<?php echo urldecode($this->input->get('start'))?>",
        "endDate": "<?php echo urldecode($this->input->get('end'))?>",
        ranges: {
            'Today': [moment(), moment()],
            'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
            'Last 7 Days': [moment().subtract(6, 'days'), moment()],
            'Last 30 Days': [moment().subtract(29, 'days'), moment()],
            'This Month': [moment().startOf('month'), moment().endOf('month')],
            'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
        }
    }, cb);
    $('#reportrange span').html("<?php echo urldecode($this->input->get('start'))?>" + ' - ' + "<?php echo urldecode($this->input->get('end'))?>");
    $(".date_start").val("<?php echo urldecode($this->input->get('start'))?>");
    $(".date_end").val("<?php echo urldecode($this->input->get('end'))?>");
    <?php else:?>
    $('#reportrange').daterangepicker({
        ranges: {
            'Today': [moment(), moment()],
            'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
            'Last 7 Days': [moment().subtract(6, 'days'), moment()],
            'Last 30 Days': [moment().subtract(29, 'days'), moment()],
            'This Month': [moment().startOf('month'), moment().endOf('month')],
            'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
        }
    }, cb);
    <?php endif;?>
    $(function () {
        $('input[name="campaign"]').keydown(function (e) {
            if (e.keyCode == 13) {
                var keyword = $(this).val();
                location.href = site_url + 'review/index?campaign=' + keyword;
            }
        });
        $(".input-search-btn").click(function () {
            var keyword = $('input[name="campaign"]').val();
            location.href = site_url + 'review/index?campaign=' + keyword;
        });
    });

</script>

