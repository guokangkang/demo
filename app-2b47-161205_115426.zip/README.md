# MarketMax Web Version Development

## 项目配置信息


### 克隆仓库

	git clone git@git.poggy.info:palmax/marketmax-web.git

### 流程示例

	echo "Hello,World!" > foo.txt  	//创建文件
	git add foo.txt 				//添加文件到仓库
	git commit -m 'create foo.txt'	//添加注释
	git push origin develop 		//提交到 develop 分支

### Web 访问地址
	
	http://beta.marketmax.palmax.com/

### phpMyAdmin 地址

	http://sg-web-01.poggy.info/phpMyAdmin-4.6.0/

	Amazon RDS User:  poggy/ N1bQrdBC9aCqwCgx
	Local User: -----


***


## 常用手册

### 本地客户端SSH密钥配置
	
	文档
    http://git.poggy.info/help/ssh/README

	更多可参考:
	https://confluence.atlassian.com/bitbucket/set-up-ssh-for-git-728138079.html

### Git 简要手册

	http://rogerdudler.github.io/git-guide/

### Git Flow

	创建规范的Git仓库
	http://fann.im/blog/2012/03/12/git-flow-notes/



